import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { login as authLogin } from './store/authSlice';
import axios from "axios";
import { BaseUrl, PRIVATE_KEY } from "./constants/BaseURL";
const CryptoJS = require("crypto-js");

const decryptData = (encryptedData) => {
  try {
    var ciphertext = encryptedData;
    var key = PRIVATE_KEY;
    var iv = "8056483646328763";

    var ciphertextWA = CryptoJS.enc.Base64.parse(ciphertext);
    var keyWA = CryptoJS.enc.Utf8.parse(key);
    var ivWA = CryptoJS.enc.Utf8.parse(iv);
    var ciphertextCP = { ciphertext: ciphertextWA };

    var decrypted = CryptoJS.AES.decrypt(
      ciphertextCP,
      keyWA,
      { iv: ivWA }
    );
    var decryptedInfo = decrypted.toString(CryptoJS.enc.Utf8);
    return decryptedInfo;
  } catch (error) {
    console.error("Decryption Error:", error.message);
    throw error;
  }
}

const AuthWrapper = ({ children }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const IsVerify = useSelector((state) => state.auth.status);
  const [isAuthenticated, setIsAuthenticated] = useState(IsVerify);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isAuthenticated) {
      setIsLoading(false);
      return;
    }

    //   const authenticateUser = async () => {
    //     try {
    //       const response = await axios.post(`${BaseUrl}api/Login/getCurrentLoggedOnUser`, null, { withCredentials: true });
    //       if (response.data.Status === 17 && response.data.Text === 'authorized') {
    //         const encrypted = response.data.jsonData.USER.USERDETAILS;
    //         const tokenVal = response.data.jsonData.TOKEN.VALUE
    //         console.log("Token",tokenVal)  
    //         sessionStorage.setItem('token',  tokenVal);
    //         const decryptedData = decryptData(encrypted);
    //         dispatch(authLogin(decryptedData));
    //         setIsAuthenticated(true);
    //       } else {
    //         navigate("/SIS/Login");
    //         alert("User is not authorized");
    //       }
    //     } catch (error) {
    //       navigate("/SIS/Login");
    //       console.error("Error:", error);
    //     } finally {
    //       setIsLoading(false);
    //     }
    //   };

    //   authenticateUser();
    // }, [dispatch, navigate, isAuthenticated]);


    const authenticateUser = async () => {
      const maxReloadAttempts = 2; // Set a maximum number of reload attempts
      let reloadAttempts = parseInt(sessionStorage.getItem('reloadAttempts')) || 0;

      if (reloadAttempts > maxReloadAttempts) {
        console.error('Max reload attempts reached. Not reloading again.');
        return; // Exit if maximum reload attempts reached
      }

      try {
        const response = await fetch(`${BaseUrl}api/Login/getCurrentLoggedOnUser`, {
          method: 'POST',
          credentials: 'include', // Equivalent to withCredentials: true in Axios
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({}) // Assuming you don't need to send any data in the body
        });

        const responseData = await response.json();
        console.log("ResponseData", responseData);

        if (responseData.Status === 17 && responseData.Text === 'authorized') {
          const encrypted = responseData.jsonData.USER.USERDETAILS;
          console.log(encrypted);
          const tokenVal = responseData.jsonData.TOKEN.VALUE;
          console.log("Token", tokenVal);
          sessionStorage.setItem('token', tokenVal);
          const decryptedData = decryptData(encrypted);
          dispatch(authLogin(decryptedData));
          setIsAuthenticated(true);
          sessionStorage.removeItem('reloadAttempts');
        } else {
          navigate("/SIS/");
          //alert("User is not authorized");

        }
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
      } catch (error) {

        console.error("Error:", error);

        // Only reload for specific types of errors
        if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
          reloadAttempts++;
          sessionStorage.setItem('reloadAttempts', reloadAttempts.toString());

          if (reloadAttempts <= maxReloadAttempts) {
            window.location.reload();
          }
        } else {
          // Handle other types of errors without reloading
          navigate("/SIS/");
        }
      } finally {
        setIsLoading(false);
      }
    };

    authenticateUser();
  }, [dispatch, navigate, isAuthenticated]);

  return isLoading ? (
    <div className="scene">
      <div className="wrapper">
        <div className="circle"></div>
        <div className="circle"></div>
        <div className="circle"></div>
        <div className="shadow"></div>
        <div className="shadow"></div>
        <div className="shadow"></div>
        <span>Loading..</span>
      </div>
    </div>
  ) : (
    <>{children}</>
  );
};

export default AuthWrapper;

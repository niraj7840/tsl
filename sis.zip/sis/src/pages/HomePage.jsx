import React from 'react'
import Navbar from '../components/Navbar/Navbar'
import Card from '../components/Card/Card'
 
const HomePage = () => {
  return (
    <>
      <Navbar/>
     <div className="container"
        style={{ marginTop: "8px", maxWidth: "100%" }}>
      <section style={{marginLeft:'3px'}}>
        <Card />
      </section>
 </div>
    </>
  )
}
 
export default HomePage
import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
import { useSelector } from "react-redux";
import "./IntelliBuySystemChecks.css";
import Autocomplete from "../components/ShoppingCart/Autocomplete";
import AutocompleteVendorMaster from "../components/ShoppingCart/AutocompleteVendorMaster";
import SC_MaxQtyModal from "../components/IntelliBuy/SC_MaxQtyModal";
import SC_RequirmentConsumptionModal from "../components/IntelliBuy/SC_RequirmentConsumptionModal";
import SC_RefurshibilityModal from "../components/IntelliBuy/SC_RefurshibilityModal";
import SC_VMIModal from "../components/IntelliBuy/SC_VMIModal";
import SC_DepropModal from "../components/IntelliBuy/SC_DepropModal";
import ProgressBar from "../components/IntelliBuy/ProgressBar";
import axios from "axios";
import TabMenu from "../components/TabMenu/TabMenu";
import Swal from "sweetalert2";
import * as moment from "moment";
import { useNavigate } from "react-router-dom";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import {
  Form,
  Collapse,
} from "react-bootstrap";
const SC_AppDetailsView = ({
  showLoader,
  hideLoader,
  switchToShoppingCart,
}) => {
  const navigate = useNavigate();
  // const indentId = useSelector((state) =>
  //   state.indent ? state.indent.indentId : ""
  // );

  const indentId = sessionStorage.getItem("SC_IndentNo");  
  const [state, setstate] = useState(false);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
 // user.User_Id='163402'; 
  const [workFlowData, setWorkFlowData] = useState([]);
  const [checkedUMCList, setcheckedUMCList] = useState("");
  const [checkedMAXUMCList, setcheckedMAXUMCList] = useState("");
  const [indentno, setIndentNo] = React.useState(indentId);
  const [indentstatus, setIndentStatus] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [showrcm, setShowRCM] = useState(false);
  const [showrefurshibility, setShowRefurshibility] = useState(false);
  const [showvmi, setShowVMI] = useState(false);
  const [showdeprop, setShowDeprop] = useState(false);
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRow, setSelectedRow] = useState(null);
  const [RCMstatus, setRCMStatus] = useState("");
  const [VMIstatus, setVMIStatus] = useState({});
  const [selectedDatercmdt, setSelectedDateRCMDate] = useState("");
  const [firstEffectComplete, setFirstEffectComplete] = useState(false);
  const [indicator, setIndicator] = useState("");

  const [isShown, setIsShown] = useState(false);
  const [fyear, setFyear] = useState("");
  const [committedExpenditure, setCommittedExpenditure] = useState("");
  const [spareBudget, setSpareBudget] = useState("");
  const [progress, setProgress] = useState();

  const itemsPerPage = 5;

  const [isVisiblePanel, setIsVisiblePanel] = useState(false);
  const [open, setOpen] = useState(false);
  const [scqty, Setscqty] = React.useState("");

  const [StorageLocation, setStorageLocation] = React.useState("");
  const [DocumentType, setDocumentType] = React.useState("");
  const [PurchaseGroup, setPurchaseGroup] = React.useState("");
  const [ProcurementType, setProcurementType] = React.useState("");
  const [UnderConsumption, setUnderConsumption] = React.useState("");
  const [RequirementDate, setRequirementDate] = React.useState("");
  const [scuom, SetUOM] = React.useState("");
  const [priceperitem, Setpriceperitem] = React.useState("");
  const [CsrCategoryList, Setcsrcategorylist] = useState([]);
  const [CostCategoryList, Setcostcategorylist] = useState([]);
  const [DocumentsList, Setdocumentslist] = useState([]);
  const [CurrencyList, Setcurrencylist] = useState([]);
  const [CsrSubCategoryList, Setcsrsubcategorylist] = useState([]);
  const [CsrSubActivityList, Setcsrsubactivitylist] = useState([]);
  const [openimport, setOpenImport] = useState(true);


  const [selectedOptions, setSelectedOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const [subactivityselectedOption, setSubActivitySelectedOption] =
    useState("");

  const [enablePanel, setEnablePanel] = useState(false);
  const [panelData, setPanelData] = useState("");
  const [shoppingcartno, setShoppingCartNo] = React.useState("");

  const [getMaxQtyData_SC, SetGetMaxQtyData_SC] = useState([]);
  const [getRCData_SC, SetGetRCData_SC] = useState([]);
  const [getVMIData, SetGetVMIData] = useState([]);
  const [getRefurshData_SC, SetGetRefurshData_SC] = useState([]);
  const [getDepropData_SC, SetGetDepropData_SC] = useState([]);


  const [shoppingCartData, setShoppingCartData] = useState([]);
  const [shoppingCartItemData, setShoppingCartItemData] = useState([]);
  const [isDisabled, setIsDisabled] = useState(false); // true to disable all elements  
  const [rateFRN, SetRateFRN] = React.useState("");
  const [frncurrency, setFrnCurrency] = React.useState("");
  const [installedQty, SetInstalledQty] = React.useState("");
  const [csrLocationList, setCsrLocationList] = useState([]);
  const [socialDisplay, setSocialDisplay] = useState("none");
  const [csrLocation, setCsrLocation] = useState([]);
  const [csrRemarks, setCsrRemarks] = useState([]);
  const [checkedItemId, setCheckedItemId] = useState(null);
  const [indexTBL, setIndexTBL] = useState(null);
  const [umcnodesc, setUMCNODESC] = React.useState("");
  const [mapvalue, setMapValue] = React.useState("");
  const [rateINR, setRateINR] = React.useState("");
  const [exchingRate, setExchingRate] = React.useState("");
  const [characteristics, SetCharacteristics] = useState(null);
  const [composition, Setcomposition] = useState(null);
  const [functionText, SetfunctionText] = React.useState("");
  const [enduse, SetEndUse] = React.useState("");
  const [umcno, SetUMCNO] = React.useState("");
  const [plant, SetPlant] = React.useState("");
  const [documentTypeText, setDocumentTypeText] = React.useState("");
  const [scItemNo, setSCItemNo] = React.useState("");
  const [scDocumentName, setSCDocumentName] = React.useState("");
  const [desiredVendor, setDesiredVendor] = useState("");
  const [costDistribution, setCostDistribution] = useState("");
  const [costCategoryvalue, setCostCategory] = useState("");
  const [ProcCons, setProcCons] = useState("");
  const [Impplantmachinery, setImpplantmachinery] = useState("");
  const [requesterName, setRequesterName] = useState("");
  const [sapFODItemNo, setSapFODItemNo] = useState("");
  const [costAssesmentHeaderName, setCostAssesmentHeaderName] =
    useState("Percentage");
  const [fodtype, setFodType] = useState("");
  const [dept, setDept] = useState("");
  const [opendoc, setOpenDoc] = useState(false);
  const [docType, setDocType] = useState("");
  



  
  
  const [GLAccount, setGLAccount] = React.useState("");
  
  
  const [MPNDrawingsdetailsList, SetMPNDrawingsdetailsList] = useState([]);
 
  const [GLACDisplay, setGLACDisplay] = useState("none");
  const [installedQtyDisplay, setInstalledQtyDisplay] = useState(false);
  const [DesiredVendorDisplay, setDesiredVendorDisplay] = useState();
  const [isEnbleActivity, setisEnbleActivity] = useState("");
  const [ClassificationDisplay, setClassificationDisplay] = useState();
  
  const [vendordetailsList, setVendordetailsList] = useState([]);
  
  const [sapFODNo, setsapFODNo] = useState("");
  const [sapFODMsg, setsapFODMsg] = useState("");
  const [sapFODCreatedDT, setsapFODCreatedDT] = useState("");
  
  const [bgg, setbggval] = useState("");
  const [MNPSelected, setMNPSelected] = useState(0);
  const [BGG, setBGG] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [purchaseList, SetPurchaselist] = useState([]);


 







  const togglePanel = () => {
    setOpen(!open);
  };


  const handleRadioChange = (value) => {
    setSelectedOption(value);
    fetchCsrSubActivityList(value);
  };
  const handleSubActivityRadioChange = (value) => {
    setSubActivitySelectedOption(value);
  };
  const FetchSCCurrentStatus = async (shoppingcartno) => {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    await axios
      .get(
        `${BaseUrl}api/ShoppingCart/GetCurrentSCStatus?SCNO=${shoppingcartno}`,
        { headers }
      )
      .then((response) => {
        const data = response.data;
        if (data.jsonData.length > 0) {
          const Status = data.jsonData;
          if (Status >= 39) {
            setIsDisabled(true);
           
          } else if (Status === "38") {
          
          }
          //   setCurrentSCStatus(data.jsonData);
          //  console.log('current',currentSCStatus,'data',data.jsonData);
        } else {
          Swal.fire("", "No Data Found", "info");
        }
      })
      .catch((error) => {
        //console.log(error);
      });
  };

  const clearFields = () => {
    // Map through the current rows and update 'name' and 'age' fields
    const updatedRows = rows.map((row, index) => ({
      ...row,
      SAA_DISTRIBUTION_VAL: index === 0 ? "100" : "", // Clear the name field
      SAA_ASGND_TO: "", // Clear the age field
      SAA_ACTIVITY_NUM: "",
    }));
    setRows(updatedRows);
  };
  const handleCheckboxChangeforSelect = async (SCNO, UMCNO, index) => {
debugger
    setIsVisiblePanel(true)
    setIndexTBL(index);   
    if (selectedItemId !== UMCNO) {
      setSelectedItemId(UMCNO);
    
    }
    if (SCNO > 0) {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetSCItemDetailsFromUMC?SC_NO=${SCNO}&UMCNo=${UMCNO}&FODTYPE=${fodtype}`,
          { headers }
        )
        .then((response) => {
          hideLoader();
          const data = response.data;
          console.log(data, "Data");
          console.log(data.jsonData[0].sccostAssignment, "cost Data");
          if (data.jsonData[0].SCI_CART_NO > 0) {
            addNewRows(data.jsonData);
            setSelectedItemId(UMCNO);
            clearFields();
            setDocumentTypeText("");
            setProcCons("");
            setEnablePanel(true);
            
            setPanelData(data.jsonData[0]);
            updateCostAssesmentRows(data.jsonData[0].sccostAssignment);
            setDocumentType(data.jsonData[0].DOC_TYPE_DESC);
            setStorageLocation(data.jsonData[0].SLOC_DESC);
            //setPurchaseGroup(data.jsonData[0].PG_GRP_DESC);
            setPurchaseGroup(data.jsonData[0].SCI_PUR_GRP);
            setProcurementType(data.jsonData[0].SCI_PROC_TYP);
            setRequirementDate(data.jsonData[0].SCI_REQD_ON_DT);
            SetUOM(data.jsonData[0].SCI_QTY_UNIT);
            setBGG(data.jsonData[0].SCI_MATL_GRP);
            setbggval(data.jsonData[0].SCI_MATL_GRP);
            setUnderConsumption(data.jsonData[0].SCI_SPARES_CATEGORY);
            Setscqty(data.jsonData[0].SCI_QTY);
            //Setpriceperitem(data.jsonData[0].SCI_PRICE);
            SetRateFRN(data.jsonData[0].SCI_FRN_PRICE);
            SetInstalledQty(data.jsonData[0].SCI_INSTALLED_QTY);
            setUMCNODESC(data.jsonData[0].UMC_DESC);
            setMapValue(data.jsonData[0].Verpr);
            SetCharacteristics(data.jsonData[0].SCI_CHARACTERISTICS);
            Setcomposition(data.jsonData[0].SCI_COMPOSITION);
            SetEndUse(data.jsonData[0].SCI_ENDUSE);
            SetfunctionText(data.jsonData[0].SCI_FUNCTION);
            SetPlant(data.jsonData[0].SCI_PLANT_CD);
            SetUMCNO(data.jsonData[0].SCI_MATL_NO);
            setSCItemNo(data.jsonData[0].SCI_ITEM_NO);
            setDesiredVendor(data.jsonData[0].SCI_OA_VENCD);
            setProcCons(data.jsonData[0].SCI_TXT_PROC_CONS);
            setImpplantmachinery(data.jsonData[0].SCI_IMP_PLANT_MACHINERY);
            setRateINR(data.jsonData[0].SCI_PRICE);
            setDocType(data.jsonData[0].SCI_DOC_TYPE);
            setFrnCurrency(data.jsonData[0].SCI_FRN_CURR_CD);
            setFodType(data.jsonData[0].SCI_FOD_TYPE);
            setSapFODItemNo(data.jsonData[0].SCI_FOD_ITEM_NO);
            setsapFODNo(data.jsonData[0].SCI_FOD_NO);
            setsapFODMsg(data.jsonData[0].SCI_SAP_ERR_MSG);
            setsapFODCreatedDT(data.jsonData[0].SCI_FOD_CRT_DT);
            setDept(data.jsonData[0].DEPT);
            setRequesterName(data.jsonData[0].SCI_REQUESTER);
            setCheckedItemId(data.jsonData[0].CSR_COMP);
            fetchMPNDrawingsdetailsList(
              data.jsonData[0].SCI_MATL_NO,
              data.jsonData[0].SCI_MATL_GRP,
              data.jsonData[0].SCI_CART_NO,
              data.jsonData[0].SCI_ITEM_NO
            );
            fetchPurchaseGroupList(
              data.jsonData[0].SCI_PLANT_CD,
              fodtype,
              data.jsonData[0].SCI_REF_OA_NO,
              data.jsonData[0].SCI_MATL_NO
            );
           
            // DefaultItemMVPValue(
            //   data.jsonData[0].SCI_PRICE,
            //   data.jsonData[0].Verpr
            // );

          
            Setcsrsubcategorylist([]);
            Setcsrsubactivitylist([]);
            setSelectedOption("None");
            setSubActivitySelectedOption("None");
            setSocialDisplay("none");
            setCsrLocation("");
            setCsrRemarks("");
            fetchCsrDetails(
              data.jsonData[0].SCI_CART_NO,
              data.jsonData[0].SCI_ITEM_NO
            );
            fetchCostAssesmentData(
              data.jsonData[0].SCI_CART_NO,
              data.jsonData[0].SCI_ITEM_NO
            );

            setShoppingCartData((prevItem) =>
              prevItem.map((item) =>
                item.REQ_UMC_NO === data.jsonData[0].SCI_MATL_NO //umcno
                  ? { ...item, SCI_PRICE: data.jsonData[0].SCI_PRICE }
                  : item
              )
            );
            //console.log("choose cost assignment", costCategory)
            // handleItemSelection(data.jsonData[0].SCI_ITEM_NO);
            FetchVendorDetailsList(data.jsonData[0].SCI_OA_VENCD);
           // setROVendorSelected(data.jsonData[0].SCI_OA_VENCD);
            console.log("checkeditem", checkedItemId);
            // if(checkedItemId===null)
            // {
            //   handleItemSelectionForSus(data.jsonData[0].SCI_ITEM_NO)
            // }

            ValidationFunction(data.jsonData);

            console.log(data.jsonData[0].SLOC_DESC, "SLOC_DESC");
            console.log(shoppingCartItemData, "ShoppingCartItemData");
          } else {
            Swal.fire("", "No Data Found", "info");
            setShoppingCartData([]);
            setShoppingCartNo("");
            setIndentDept("");
          }

          ////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      Swal.fire("", "No Data Found", "error");
    }

    // if (selectedItemId !== id) {
    //   // Only update state if a different checkbox is selected
    //   setSelectedItemId(id);
    //   setEnablePanel(true);
    //   setPanelData(selectedCheckbox.data);
    //   setDocumentType(selectedCheckbox.DOCUMENT_TYPE_DESC);
    //   setStorageLocation(selectedCheckbox.SLOC_DESC);
    //   setPurchaseGroup(selectedCheckbox.PG_DESC);
    //   setProcurementType(selectedCheckbox.PROC_TYPE);
    //   setRequirementDate(selectedCheckbox.REQUIREMENT_DATE);
    //   SetUOM(selectedCheckbox.UOM);
    //   setShoppingCartNo(selectedCheckbox.SCH_CART_NO);
    //   setUnderConsumption(selectedCheckbox.SPARE);
    //   Setscqty(selectedCheckbox.QTY);
    //   Setpriceperitem(selectedCheckbox.PRICE_PER_ITEM);
    // } else {
    //   // Deselect the checkbox if it was already selected
    //   setSelectedItemId(null);
    //   setEnablePanel(false);
    //   setPanelData("");
    //   setDocumentType("");
    //   setStorageLocation("");
    //   setPurchaseGroup("");
    //   setProcurementType("");
    //   setRequirementDate("");
    //   setShoppingCartNo("");
    //   setUnderConsumption("");
    //   Setscqty("");
    // }
  };
  // Function to handle input changes
  const handleInputChangePrice = (event) => {
    Setpriceperitem(event.target.value); // Update the state with input value
  };
  const handleInputChange = (id, field, value) => {
    const updatedRows = rows.map((row) => {
      if (row.Line === id) {
        return { ...row, [field]: value };
      }
      return row;
    });

    setRows(updatedRows);
  };

  ///-------------MaxQty Modal---------//
  const MaxQtyStatus = workFlowData.some((item) => item.QTY > item.ALLOWEDQTY);
  const hanldeDelete = (rowno) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === rowno ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const getUpdateQty = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      console.log("IndentId_IndentId", indentno)
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetMaxQtyData_SC?IndentId=${indentId}`, { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();

          if (data.jsonData.length > 0) {
            SetGetMaxQtyData_SC(data.jsonData);


          } else {
            Swal.fire("", "No Data Found", "info");
            SetGetMaxQtyData_SC([]);
            setisLoading(false);
            hideLoader();
          }
        })
        .catch((error) => {
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  const hanldeClick = (selectedRec) => {
    getUpdateQty();
    setShow(true);
  };

  const hideModal = () => {
    setShow(false);
  };

  ///-------------Refurshibility Modal---------//

  const hanlderefurshibilityClick = (selectedRec) => {
    getrefurshibility();
    setShowRefurshibility(true);
  };

  const hiderefurshibilityModal = () => {
    setShowRefurshibility(false);
  };


  const getrefurshibility = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetRefurshibilityData_SC?IndentId=${indentId}`, { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();

          if (data.jsonData.length > 0) {
            SetGetRefurshData_SC(data.jsonData);

          } else {
            Swal.fire("", "No Data Found", "info");
            SetGetRefurshData_SC([]);
            setisLoading(false);
            hideLoader();
          }
        })
        .catch((error) => {
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  ///-------------RequirmentConsumption Modal---------//

  const handleSaveRCMData = () => {

  };

  const calculateQuantity = (row) => {
    const maxQty = parseFloat(row.MaxQty) || 0;
    const pipelineQty = parseFloat(row.PipelineQty) || 0;
    const refurQty = parseFloat(row.RefurQty) || 0;
    const chargeQty = parseFloat(row.ChargeQty) || 0;

    let quantity = maxQty - (pipelineQty + refurQty + chargeQty);
    if (quantity < 0) {
      quantity = 0.0;
    }
    return quantity.toFixed(3);
  };

  // Function to format date as dd-mm-yyyy
  const formatDate = (dateString) => {
    const dateObj = new Date(dateString);
    const day = String(dateObj.getDate()).padStart(2, "0");
    const month = String(dateObj.getMonth() + 1).padStart(2, "0"); // January is 0!
    const year = dateObj.getFullYear();

    return `${day}-${month}-${year}`;
  };
  const formatDateInput = (dateStr) => {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    } else {
      return dateStr;
    }
  };
  const hanldeRCMEdit = (
    index,
    field,
    SysReqDTT,
    SysConsumDTT,
    ChangeReqDTT,
    changeConsumDTT,
    userjustification
  ) => {
    var Retrncolor = "green";
    var setMessage = "";
    const newData = [...workFlowData];

    const strSysTM = new Date(moment(SysReqDTT).format("YYYY-MM-DD"));
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(moment(SysReqDTT).format("YYYY-MM-DD")).getTime();
    const SysConsumDT = new Date(
      moment(SysConsumDTT).format("YYYY-MM-DD")
    ).getTime();
    const ChangeReqDT = new Date(
      moment(ChangeReqDTT).format("YYYY-MM-DD")
    ).getTime();
    const changeConsumDT = new Date(
      moment(changeConsumDTT).format("YYYY-MM-DD")
    ).getTime();

    const Condition1 = SysReqDT === ChangeReqDT;
    const Condition2 = SysReqDT > ChangeReqDT;
    const Condition3 = SysReqDT < ChangeReqDT;
    const Condition4 = SysConsumDT === changeConsumDT;
    const Condition5 = SysConsumDT > changeConsumDT;
    const Condition6 = SysConsumDT < changeConsumDT;

    if (Condition1 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition1 && Condition5) {
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition1 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition4) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition5) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition6) {
      setMessage =
        "Please amend your requirement/consumption date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition3 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition5) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";
      setIndicator("red");
      Retrncolor = "red";
    }

    newData[index]["REQUIREMENT_DATE"] =
      moment(ChangeReqDTT).format("DD-MMM-YYYY");
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    //moment(changeConsumDTT).format("DD-MMM-YYYY");
    newData[index]["RCM_CHECKS_STATUS"] = Retrncolor;
    newData[index]["RCM_SmartNudges"] = setMessage;
    newData[index]["USER_REMARKS_RCM"] = userjustification;
    setWorkFlowData(newData);

  };

  const hanldeRCMChecks = (
    index,
    field,
    SysReqDTT,
    SysConsumDTT,
    ChangeReqDTT,
    changeConsumDTT
  ) => {
    var Retrncolor = "green";
    var setMessage = "";
    const SyReqDTT = SysReqDTT;
    const newData = [...workFlowData];

    const strSysTM = new Date(moment(SysReqDTT).format("YYYY-MM-DD"));
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(moment(SysReqDTT).format("YYYY-MM-DD")).getTime();
    const SysConsumDT = new Date(
      moment(SysConsumDTT).format("YYYY-MM-DD")
    ).getTime();
    const ChangeReqDT = new Date(
      moment(ChangeReqDTT).format("YYYY-MM-DD")
    ).getTime();
    const changeConsumDT = new Date(
      moment(changeConsumDTT).format("YYYY-MM-DD")
    ).getTime();

    const Condition1 = SysReqDT === ChangeReqDT;
    const Condition2 = SysReqDT > ChangeReqDT;
    const Condition3 = SysReqDT < ChangeReqDT;
    const Condition4 = SysConsumDT === changeConsumDT;
    const Condition5 = SysConsumDT > changeConsumDT;
    const Condition6 = SysConsumDT < changeConsumDT;

    if (Condition1 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition1 && Condition5) {
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition1 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition4) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition5) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition6) {
      setMessage =
        "Please amend your requirement/consumption date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition3 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition5) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";
      setIndicator("red");
      Retrncolor = "red";
    }

    newData[index]["REQUIREMENT_DATE"] =
      moment(ChangeReqDTT).format("DD-MMM-YYYY");
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    // moment(changeConsumDTT).format("DD-MMM-YYYY");
    newData[index]["RCM_CHECKS_STATUS"] = Retrncolor;
    newData[index]["RCM_SmartNudges"] = setMessage;
    newData[index]["MAXQTY_CHECKS_STATUS"] = Retrncolor;
    setWorkFlowData(newData);
    setFirstEffectComplete(false);
  };

  const hanldeRCMClick = (selectedRec) => {
    getRCM();
    setShowRCM(true);
  };
  const hideRCMModal = () => {
    setShowRCM(false);
  };

  // setWorkFlowData(workFlowData);

  const getRCM = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetRequiConsumData_SC?IndentId=${indentId}`, { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();

          if (data.jsonData.length > 0) {
            SetGetRCData_SC(data.jsonData);


          } else {
            Swal.fire("", "No Data Found", "info");
            SetGetRCData_SC([]);
            setisLoading(false);
            hideLoader();
          }
        })
        .catch((error) => {
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };


  ///-------------VMI-----------//

  const hanldeVMIClick = (selectedRec) => {
    getVMI();
    setShowVMI(true);
  };

  const hideVMIModal = () => {
    setShowVMI(false);
  };


  const getVMI = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetVMI_ARCData_SC?IndentId=${indentId}`, { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();

          if (data.jsonData.length > 0) {
            SetGetVMIData(data.jsonData);


          } else {
            Swal.fire("", "No Data Found", "info");
            SetGetRCData_SC([]);
            setisLoading(false);
            hideLoader();
          }
        })
        .catch((error) => {
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  ////---------------Deprop------------///
  const hanldeDepropClick = (selectedRec) => {
    getDeprop();
    setShowDeprop(true);

  };

  const hideDepropModal = () => {
    setShowDeprop(false);
  };


  const getDeprop = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetDepropmData_SC?IndentId=${indentId}`, { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();

          if (data.jsonData.length > 0) {
            SetGetDepropData_SC(data.jsonData);


          } else {
            Swal.fire("", "No Data Found", "info");
            SetGetDepropData_SC([]);
            setisLoading(false);
            hideLoader();
          }
        })
        .catch((error) => {
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      //GridBind data callinng api
      await axios
        .get(
      //`${BaseUrl}api/IntelliBuyChecks/GetIntelliBuyChecksDetails?IndentId=${indentno}`,
           `${BaseUrl}api/ShoppingCart/GetIntelliBuyChecksDetails_SC?IndentId=${indentno}`,
          { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();

          if (data.jsonData.length > 0) {
            setWorkFlowData(data.jsonData);
            fetchCostCategoryList(
              data.jsonData[0].DEPTTYPE,
              data.jsonData[0].FOD_TYPE
            );
            const Status = data.jsonData[0].INDENT_CURRENT_STATUS_CODE;
            if (Status >= 39) {
              setIsDisabled(true);
           
            } else if (Status === "38") {
            
            }
            console.log("setWorkFlowData", data.jsonData)
            setProgress(data.jsonData[0].DeptBudgetConsumption);
            setFyear(data.jsonData[0].FY_YEAR);
            setSpareBudget(data.jsonData[0].SPAREBUDGET);
            setCommittedExpenditure(data.jsonData[0].COMMITTEDEXPENDITURE);
            setFirstEffectComplete(true);


           




          } else {
            Swal.fire("", "No Data Found", "info");
            setWorkFlowData([]);
            setIndentStatus("");
            setIndentDept("");
            setisLoading(false);
            hideLoader();
          }


        })
        .catch((error) => {

          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const filteredData = workFlowData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };
  const regex = /^[a-zA-Z\s]*\d*\.?\d*$/;
  const hanldeEdit = (index, field, value) => {
    const newData = [...workFlowData];
    if (field == "USER_REMARKS_MAXQTY") {
      if (regex.test(value)) {
        newData[index][field] = value;
        setWorkFlowData(newData);
      }
    } else if (field == "SC_QTY") {
      if (/^\d*\.?\d*$/.test(value)) {
        const oldscvalue =
          parseFloat(newData[index]["QTY"]) -
          newData[index]["TOTAL_SAP_DOC_QTY"];

        if (parseFloat(oldscvalue) < parseFloat(value)) {
          Swal.fire(
            "Alert",
            "Shopping Cart qty not greater than  " + oldscvalue + "",
            "warning"
          );
          value = oldscvalue;
        }
        if (parseFloat(value) === 0) {
          Swal.fire(
            "Alert",
            "if material is not required, kindly delete from the list.",
            "warning"
          );
          value = oldscvalue;
        }
        newData[index][field] = value;
        setWorkFlowData(newData);
      }
    }
  };

  // const handleDeleteRow = (UMC_INDENT_ID) => {
  //   const newData = workFlowData.filter(
  //     (item) => item.UMC_INDENT_ID !== UMC_INDENT_ID
  //   );
  //   setWorkFlowData(newData);
  //   const totalPage = Math.ceil(newData.length / itemsPerPage);
  //   setCurrentPage(totalPage);
  // };

  

  useEffect(() => {

    if (indentId !== "") {
      hanldeSearchClick(indentId);
      fetchCsrCategoryList();
    fetchDocumentsList();
    fetchCurrencyList();
    fetchCsrLocationList();

   
    }
  }, [indentId]);

  useEffect(() => {
    if (firstEffectComplete) {
      if (workFlowData.length > 0) {
        workFlowData.forEach((row, index) => {
          hanldeRCMChecks(
            index,
            "",
            row.ReqDate,
            row.ConsDate,
            row.REQUIREMENT_DATE,
            row.CONSUMP_DT
          );
        });
       // rcmmandatoryremarkschecks(workFlowData);
      }
    }
  }, [firstEffectComplete, workFlowData]);

  //  useEffect(() => {
  //    if (currentData.length > 0 && selectedItemId === null) {
    
  //     setSelectedItemId(currentData[0].REQ_UMC_NO); 
  //     handleCheckboxChangeforSelect( currentData[0].SCH_CART_NO, currentData[0].REQ_UMC_NO,selectedItemId)
      
  //   }
  // }, [currentData, selectedItemId]); 

 //--------------------------------Cost Assigment-------------------------//
 const fetchCostCategoryList = async (DeptType, FodType) => {
  console.log(DeptType, FodType, "test Dept Type");
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };

    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetCostCategory?DeptType=${DeptType}&FODType=${FodType}`,
      { headers }
    );
    Setcostcategorylist(response.data.jsonData);
  } catch (error) {
    console.log(error, "GetCostCategory");
  }
};
// Function to delete row
const deleteRow = (id) => {
  console.log(id, "delete rows");
  const updatedRows = rows.filter((row) => row.SAA_LINE_NO !== id);
  setRows(updatedRows);
};
 //--------------------------------Purchase Group-------------------------//
 const fetchPurchaseGroupList = async (Plant, fodtype, contractno,umcno) => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };

    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetPurchaseGroupList?plantcode=${Plant}&fodtype=${fodtype}&contract=${contractno}`,
      { headers }
    );
    SetPurchaselist(response.data.jsonData);
    if (fodtype === "RO") {
      setPurchaseGroup(response.data.jsonData[0].PG_CD);
      InputChange(umcno, "SCI_PUR_GRP", response.data.jsonData[0].PG_CD);
    }
  } catch (error) {
    console.log(error, "GetCostCategory");
  }
};
//------------------------------------Documents---------------------------------//
const fetchDocumentsList = async () => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetDocumentsText`,
      { headers }
    );
    Setdocumentslist(response.data.jsonData);
  } catch (error) {
    console.log(error, "fetchDocumentsList");
  }
};
//---------------------------------Sustainability-----------------------------//
const fetchCsrCategoryList = async () => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetCostCsrCategory`,
      { headers }
    );
    Setcsrcategorylist(response.data.jsonData);
  } catch (error) {
    console.log(error, "fetchCsrCategoryList");
  }
};
const fetchCsrSubCategoryList = async () => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetCostCsrSubCategory`,
      { headers }
    );
    Setcsrsubcategorylist(response.data.jsonData);
  } catch (error) {
    console.log(error, "GetCostCsrSubCategory");
  }
};

const fetchCurrencyList = async () => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetCurrencyCode`,
      { headers }
    );
    Setcurrencylist(response.data.jsonData);
    console.log(response.data.jsonData, "GetCurrencyCode");
  } catch (error) {
    console.log(error, "GetCurrencyCode");
  }
};

const fetchMPNDrawingsdetailsList = async (umcno) => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/Getmpndrawingsdetails?umcno=${umcno}`,
      { headers }
    );
    SetMPNDrawingsdetailsList(response.data.jsonData);
    console.log(response.data.jsonData, "Getmpndrawingsdetails");
  } catch (error) {
    console.log(error, "GetCurrencyCode");
  }
};

const fetchCsrSubActivityList = async (CSR_SUB_CODE) => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetCostCsrSubActivity?CSR_SUB_CODE=${CSR_SUB_CODE}`,
      { headers }
    );
    Setcsrsubactivitylist(response.data.jsonData);
    console.log(response.data.jsonData, "fetchCsrSubActivityList");
  } catch (error) {
    console.log(error, "GetCostCsrSubActivity");
  }
};
const fetchCsrLocationList = async () => {
  try {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(
      `${BaseUrl}api/ShoppingCart/GetCSRLocation`,
      { headers }
    );
    setCsrLocationList(response.data.jsonData);
  } catch (error) {
    console.log(error, "fetchCsrCategoryList");
  }
};


const FetchVendorDetailsList = async (vendorcode) => {
  try {
    debugger;
    const apiEndpoint = `${BaseUrl}api/ShoppingCart/GetVendorDetails`;
    const response = await axios.get(apiEndpoint, {
      params: { VendorCode: vendorcode },
    });
    // Flatten the array if necessary

    const descriptions = response.data.jsonData;
    console.log(descriptions, " FetchVendorDetailsList");
    if (descriptions !== "") {
      setVendordetailsList(descriptions);
    }
  } catch (err) {
  } finally {
  }
};
 
  //------------------------generate Shopping Cart No--------------------
  const handleGenerateShoppingCart = async () => {

    const SCQTY_CHK = workFlowData.some((row) => row.SC_QTY <= 0);
    if (SCQTY_CHK) {
      Swal.fire(
        "Alert",
        "Please ensure shopping cart quantity is greater than 0.",
        "error"
      );
      return;
    }

    let UMCListMaxQty = [];
    let MAX_CHK = workFlowData.filter((row) =>
      calculateQuantity(row) < parseFloat(row.SC_QTY)
        ? "red"
        : "green" === "red"
    );
    MAX_CHK = MAX_CHK.filter((row) => !row.USER_REMARKS_MAXQTY);


    MAX_CHK.forEach((row) => {
      UMCListMaxQty.push(row.REQ_UMC_NO);
      if (UMCListMaxQty.length > 0) {
        UMCListMaxQty.join(", ");
      }
    });

    if (MAX_CHK.length > 0) {
      Swal.fire(
        "Alert",
        "Please fill max qty remarks against UMC NO (" + UMCListMaxQty + ")",
        "warning"
      );

      return;
    }
   
    setisLoading(true);
    showLoader();
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTER_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: user.User_Id,
        INDENT_MOD_BY: user.User_Id,
        INDENT_STATUS: "16",
        SCH_CART_NO: workFlowData[0].SCH_CART_NO,
        SCH_CRT_DT: "",
        SCH_USR_NAME: user.User_Id,
        ISACTIVE: "Y",
        MAX_QTY_CHK: workFlowData.some((row) =>
          calculateQuantity(row) < parseFloat(row.SC_QTY)
            ? "red"
            : "green" === "red"
        ),
        CONS_REQ_CHK: workFlowData.some(
          (row) => row.RCM_CHECKS_STATUS === "red"
        ),
        ARC_VMI_CHK: workFlowData.some((row) => row.ARC_VMI === "TRUE"),
        DEPROP_CHK: workFlowData.some((row) => row.DOCUMENT_TYPE === "NP"),
        REF_CHK: workFlowData.some((row) => row.IS_REFURBISHABLE === "R"),
        BBPR: false,
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };

    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItemAndGenrateSC`,
          formDetails,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            Swal.fire("", "Draft Shopping Cart Created", "success");
            sessionStorage.setItem("INDENT_ID", indentno);
            //navigate("/SIS/ShoppingCart"); // Redirect to new page
            switchToShoppingCart();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };

  const handleBack = () => {
    // navigate(`/SIS/PendingForApproval/${row.UMC_INDENT_ID}`, { state: { rowData: row } });
    navigate(`/SIS/SC_Approval`);
  };

  const InputChange = (index, field, value) => { }
  const isChecked = (value) => selectedOptions.includes(value);
  const handleCheckboxChange = (value) => {
    if (checkedItemId != value) {
      setCheckedItemId(value);
      if (value != "01") {
        setSocialDisplay("none");
      } else {
        setSocialDisplay("");
      }
    } else {
      setCheckedItemId("");
    }
    debugger;
    console.log(value, "None");
    if (value == "00") {
      Setcsrsubcategorylist([]);
      Setcsrsubactivitylist([]);
      //fetchCsrSubCategoryList();
      setSelectedOption("None");
      setSubActivitySelectedOption("None");
      isChecked(true);
    } else if (value == "01") {
      fetchCsrSubCategoryList();
      isChecked(true);
    } else {
      Setcsrsubcategorylist([]);
      Setcsrsubactivitylist([]);
      setSelectedOption("None");
      setSubActivitySelectedOption("None");
    }

  };
 
  

 


    // Function to add new rows to the table data
    const addNewRows = (newRows) => {
      setShoppingCartItemData((prevData) => {
        // Create a set of existing IDs for quick lookup
        const existingIds = new Set(prevData.map((item) => item.SCI_MATL_NO));
  
        // Filter out new rows that are not already in the state
        const filteredNewRows = newRows.filter(
          (row) => !existingIds.has(row.SCI_MATL_NO)
        );
  
        // Add the new rows to the existing data
        return [...prevData, ...filteredNewRows];
      });
    };
    const UpdateTextColorDocumentList = (id) => {
      // Map over items and update the one with the matching ID
      const updatedItems = DocumentsList.map(
        (item) =>
          item.TEXT_ID === id
            ? { ...item, CLASSNAME: "#32CD32" } // Update the matching item
            : item // Keep the item unchanged
      );
      Setdocumentslist(updatedItems); // Update state
      console.log("documentlist", DocumentsList);
    };
   
    const ValidationFunction = (jsondata) => {
      setInstalledQtyDisplay(true);
      //SetInstalledQty("0");
      setDesiredVendorDisplay(false);
      setClassificationDisplay(true);
      setOpenImport("none");
  
      if (jsondata[0].SCI_SPARES_CATEGORY === "Consumables") {
        setInstalledQtyDisplay(false);
        SetInstalledQty("0");
      }
      if (jsondata[0].SCI_FOD_TYPE == "PR") {
        setDesiredVendorDisplay(true);
      }
      if (jsondata[0].SCI_ClassificationEnable === false) {
        setClassificationDisplay(false);
      }
      if (jsondata[0].MaterialConsumptionPlanEnble === true) {
        setOpenImport("");
      }
    };
  
    const fetchCsrDetails = async (SCNO, ItemNo) => {
      try {
        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };
        const response = await axios.get(
          `${BaseUrl}api/ShoppingCart/GetShoppingCSRDetails?SCNO=${SCNO}&ItemNo=${ItemNo}`,
          { headers }
        );
        const data = response.data;
        if (data.jsonData[0].CSR_COMP == "01") {
          setCheckedItemId(data.jsonData[0].CSR_COMP);
          fetchCsrSubCategoryList();
          isChecked(true);
          setSelectedOption(data.jsonData[0].SCC_SUB_CODE);
          fetchCsrSubActivityList(data.jsonData[0].SCC_SUB_CODE);
          setSubActivitySelectedOption(data.jsonData[0].SCC_SUB_ACTIVITY_CODE);
          setCsrLocation(data.jsonData[0].SCC_LOC_CODE || 0);
          setCsrRemarks(data.jsonData[0].SCC_REMARKS || "");
          setSocialDisplay("");
        } else {
          setCheckedItemId(data.jsonData[0].CSR_COMP);
          Setcsrsubcategorylist([]);
          Setcsrsubactivitylist([]);
          setSelectedOption("None");
          setSubActivitySelectedOption("None");
          setSocialDisplay("none");
        }
      } catch (error) {}
    };
  
    const fetchCostAssesmentData = async (SCNO, ItemNo) => {
      try {
        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };
        const response = await axios.get(
          `${BaseUrl}api/ShoppingCart/GetCostAssesmentData?SCNO=${SCNO}&ItemNo=${ItemNo}`,
          { headers }
        );
        const data = response.data;
        console.log("test cost data", data.jsonData);
        if (data.jsonData[0].saa_cart_no > 0) {
          setCostCategory(data.jsonData[0].saa_category);
          setCostDistribution(data.jsonData[0].saa_distribution_tp);
  
          console.log("test cost data", data.jsonData[0].saa_category);
        }
      } catch (error) {}
    };
  
  
    const InputChangeUMC = (umc, field, value) => {
      var val = "";
      if (value === "MTRCL") {
        val = "Material consumtion within 33 month of Import";
      } else {
        val = value;
      }
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umc ? { ...item, SCI_TXT_PROC_CONS: val } : item
        )
      );
      setProcCons(value);
      console.log(shoppingCartItemData, "ShoppingCartItemData");
    };
  
    const CurrencyChange = async (ForeignCurrency) => {
      if (ForeignCurrency != "") {
        if (ForeignCurrency === "INR") {
          setExchingRate("1");
          setFrnCurrency("INR");
          setRateINR(rateFRN);
          InputChange(indexTBL, "SCI_EXCHNG_RATE", "1");
          InputChange(indexTBL, "SCI_FRN_CURR_CD", "INR");
          InputChange(indexTBL, "SCI_PRICE", rateFRN);
          return;
        }
        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };
        await axios
          .get(
            `${BaseUrl}api/ShoppingCart/GetCurrencyRateFromCurrency?Currency=${ForeignCurrency}`,
            { headers }
          )
          .then((response) => {
            const Rate = parseFloat(response.data.jsonData);
            const RateINR = parseFloat(rateFRN) * Rate;
            setExchingRate(Rate);
            setRateINR(RateINR);
            setFrnCurrency(ForeignCurrency);
            InputChange(indexTBL, "SCI_EXCHNG_RATE", Rate);
            InputChange(indexTBL, "SCI_FRN_CURR_CD", ForeignCurrency);
            InputChange(indexTBL, "SCI_PRICE", RateINR);
          })
          .catch((error) => {
            //console.log(error);
          });
      } else {
        setRateINR(parseFloat(rateINR) * 1);
        setExchingRate("1");
      }
    };
  
    
    const ChangeDocuments = async (value) => {
      setSCDocumentName(value);
      if (value != "") {
        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };
        await axios
          .get(
            `${BaseUrl}api/ShoppingCart/GetPRTextDocuments?UMCNo=${umcno}&Plant=${plant}&DocumentName=${value}&SCINO=${shoppingcartno}&ItemNo=${scItemNo}`,
            { headers }
          )
          .then((response) => {
            setDocumentTypeText(response.data.jsonData);
          })
          .catch((error) => {
            //console.log(error);
          });
      } else {
        Swal.fire("", "No Data Found", "error");
      }
    };
  
    const handleCostHeaderTextChange = (e) => {
      const selectedOption =
        e.target.value === "P"
          ? "Percentage"
          : e.target.value === "Q"
          ? "Quantity"
          : e.target.value === "V"
          ? "Value"
          : "Percentage";
  
      setCostAssesmentHeaderName(selectedOption);
      setCostDistribution(e.target.value);
    };
    const getACMode = (value) => {
      setGLACDisplay("");
      const a = ["K", "F", "Q"];
      let acMode = "VBR"; // Default value
      if (a.includes(value)) {
        // If the value is in the array `a`
        acMode = "VBR";
      } else if (value === "A") {
        // If value is 'A'
        acMode = "";
      } else if (value === "N") {
        // If value is 'N'
        acMode = "ZCN";
      } else {
        acMode = "NA";
        setGLACDisplay("none");
      }
  
      return acMode;
    };
  
   
  
   
  
  
  
    
  
    const handleCostCategoryChange = async (value) => {
      // console.log("choose cost assignment", value)
      setCostCategory(value);
      
      setisEnbleActivity(value);
      const ACMode = getACMode(value);
      try {
        if (ACMode != "NA") {
          let token = sessionStorage.getItem("token");
          let headers = {
            "jwt-token": token,
          };
          await axios
            .get(
              `${BaseUrl}api/ShoppingCart/GetGLAccountNo?UMCNO=${umcno}&Plant=${plant}&ACMode=${ACMode}`,
              { headers }
            )
            .then((response) => {
              console.log(response.data, "", response.data.jsonData);
              setGLAccount(response.data.jsonData);
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          //Swal.fire("", "No Data Found", "error");
        }
      } catch (error) {
        hideLoader();
        setisLoading(false);
      }
    };
    
    
 

 

  //---------------------Save Documents --------------------
  const handleSaveDocument = async () => {
    //  setisLoading(true);
    // prop.showLoader();
    var sCDocument = {
      SCD_CART_NO: shoppingcartno,
      SCD_ITEM_NO: scItemNo,
      SCD_TXT_TYPE: scDocumentName,
      SCD_UPD_ID: user.User_Id,
      SCD_TXT: documentTypeText,
    };
    ////console.log("wfdata", shoppingCartData);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertSCDocumentDetails`,
          sCDocument,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            UpdateTextColorDocumentList(scDocumentName);

            console.log("document list", DocumentsList);
            setisLoading(false);
            hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };

  //---------------------Save Sustainibility --------------------
  const handleSaveSustainibility = async () => {
    //  setisLoading(true);
    // prop.showLoader();
    var objSCSustainibilityCSR = {
      SCC_CART_NO: shoppingcartno,
      SCC_ITEM_NO: scItemNo,
      SCC_FOD_TYPE: fodtype,
      SCC_FOD_NO: "",
      SCC_FOD_ITEM_NO: "",
      SCC_DEPT: dept,
      CSR_ACT_TAG: checkedItemId === "00" ? "N" : "Y",
      CSR_COMP: checkedItemId,
      SCC_CRT_ID: user.User_Id,
      SCC_CRT_DT: "",
      SCC_SUB_CODE: selectedOption,
      SCC_SUB_ACTIVITY_CODE: subactivityselectedOption,
      SCC_LOC_CODE: csrLocation,
      SCC_REMARKS: csrRemarks,
    };
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertSustainibilityCsr`,
          objSCSustainibilityCSR,
          { headers }
        )

        .then((response) => {
          if (response.data.Text === "success") {
            //handleSaveSuccessForSus((scItemNo));
            const jsonData = response.data.jsonData;
            const allErrorss = [];

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

          
            setisLoading(false);
            hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
          } else if (response.data.Text === "Failed") {
            //const errorMessages = response.data.jsonData["2"].map((error) => `<div style="font-size: 12px">${error}</div>`).join('');
            const jsonData = response.data.jsonData;
            const allErrors = [];
            const allErrorss = [];

            // Gather all errors into a single array with the raw text
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrors.push(error);
              });
            });
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            // Sort the array based on the error number at the beginning of each error string
            // allErrors.sort((a, b) => {
            //   const numA = parseInt(a.match(/^\d+/)[0], 10);
            //   const numB = parseInt(b.match(/^\d+/)[0], 10);
            //   return numA - numB;
            // });

            // Convert sorted errors into HTML format
            const formattedErrors = allErrors.map(
              (error) => `<div style="font-size: 12px">${error}</div>`
            );

         
            const errorMessages = formattedErrors.join("");
            setOpenDoc(true);
            Swal.fire({
              title: "Please check Error List section",
              //html: errorMessages,
              icon: "error",
            });
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };
  ////<===========================                    ===============>
  // const [query, setQuery] = useState("");
  // const [suggestions, setSuggestions] = useState();
  // const [loading, setLoading] = useState(false);
  // const [error, setError] = useState("");
  // const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  // const inputRef = useRef(null);

  // // API endpoint URL (replace with your actual API endpoint)
  // const apiEndpoint = `${BaseUrl}api/ShoppingCart/GetCostCenterSearch`;

  // // Function to handle input change
  // const handleChange = async (event, id) => {
  //   const value = event.target.value;
  //   setQuery(value);
  //   const updatedRows = rows.map((row) => {
  //     if (row.Line === id) {
  //       return { ...row, ["Assigned"]: value };
  //     }
  //     return row;
  //   });
  //   setRows(updatedRows);

  //   if (value.length >= 10 && /^[0-9]+$/.test(value)) {
  //     setLoading(true);
  //     setError("");
  //     setIsDropdownOpen(true);

  //     try {
  //       const response = await axios.get(apiEndpoint, {
  //         params: { costcenter: value },
  //       });
  //       console.log(response, "DESCRIPTION");
  //       console.log(response.data.jsonData.flat(), "DESCRIPTION1");
  //       const itemss = [response.data.jsonData[0].DESCRIPTION, ""];
  //       console.log(response.data.jsonData[0].DESCRIPTION, "itemss");
  //       setSuggestions(itemss);
  //     } catch (err) {
  //       setError("Failed to fetch suggestions");
  //     } finally {
  //       setLoading(false);
  //     }
  //   } else {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }
  // };

  // // Function to handle suggestion click
  // const handleSuggestionClick = (suggestion) => {
  //   setQuery(suggestion);
  //   setSuggestions([]);
  //   setIsDropdownOpen(false);
  // };

  // // Function to handle clicks outside
  // const handleClickOutside = (event) => {
  //   if (inputRef.current && !inputRef.current.contains(event.target)) {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }
  // };

  // useEffect(() => {
  //   document.addEventListener("mousedown", handleClickOutside);
  //   return () => {
  //     document.removeEventListener("mousedown", handleClickOutside);
  //   };
  // }, []);
  // ////<============================                    ================>

  //  ////<============================  Start code  Cost Center          ================>
  const [rows, setRows] = useState([
    {
      SAA_LINE_NO: "1",
      SAA_DISTRIBUTION_VAL: "100",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "2",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "3",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "4",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "5",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
  ]);
  const addRow = () => {
    const newRow = {
      SAA_LINE_NO: rows.length + 1,
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    };
    setRows([...rows, newRow]);
  };
  const updateCostAssesmentRows = (apiData) => {
    console.log(apiData, "newList");
    if (apiData.length > 0) {
      setCostCategory(apiData[0].SAA_CATEGORY);
      setCostDistribution(apiData[0].saa_distribution_tp);
      // Create a map from the API data for quick lookup
      const apiDataMap = new Map(
        apiData.map((item) => [item.SAA_LINE_NO, item])
      );

      // Update existing rows with the new data from API
      const updatedRows = rows.map((row) =>
        apiDataMap.has(row.SAA_LINE_NO)
          ? { ...row, ...apiDataMap.get(row.SAA_LINE_NO) } // Merge existing row with new data
          : row
      );

      // Add new rows that are in the API data but not in the existing rows
      const newRows = apiData.filter(
        (item) => !rows.some((row) => row.SAA_LINE_NO === item.SAA_LINE_NO)
      );

      // Combine updated rows and new rows
      setRows([...updatedRows, ...newRows]);

      // Log updated rows (for debugging purposes)
      console.log("Updated rows:", [...updatedRows, ...newRows]);
    } else {
      setRows(rows);
    }
  };

  ///============================================Autocomple=========================>
  const handleSelect = (selectedItem, id) => {
    const updatedRows = rows.map((row) => {
      if (row.SAA_LINE_NO === id) {
        return { ...row, ["SAA_ASGND_TO"]: selectedItem };
      }
      return row;
    });
    setRows(updatedRows);
    // const updatedRows = [...rows];
    // updatedRows[index].SAA_ASGND_TO = selectedItem;
    // setRows(updatedRows);
    // console.log(rows,'rows');
  };
  ////<============================    End code Autocomple Cost Center              ================>

  ////<=============================    Start Code Autocomple Vendor Code Search =================>
  const handleSelectVendorName = (selectedItem) => {
    setDesiredVendor(selectedItem);
    setShoppingCartItemData((prevItems) =>
      prevItems.map((item) =>
        item.SCI_MATL_NO === umcno
          ? { ...item, SCI_OA_VENCD: getFirstWord(selectedItem) }
          : item
      )
    );
  };
  ////<================================End Code Autocomple Vendor Code Search ====================>

  ////<====================================  Update MNP Drawing             ==============================>
  // Handle radio button change
  const handleMPNUpdateRadioChange = async (id) => {
    setMNPSelected(id);
    const rowToUpdate = MPNDrawingsdetailsList.find((row) => row.MFRNR === id);
    console.log(rowToUpdate, "mnp list");
    var ObjShoppingCartItemDetails = {
      SCI_PART_NO: rowToUpdate.PNO,
      SCI_MFRNR: rowToUpdate.MFRNR,
      SCI_MPN_NO: rowToUpdate.NAME1,
      SCI_CART_NO: shoppingcartno,
      SCI_ITEM_NO: scItemNo,
    };
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/UpdateMPNDrawing`,
          ObjShoppingCartItemDetails,
          { headers }
        )
        .then((response) => {
          if (response.data.Text === "success") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            Swal.fire("", "MNP Details Updated.", "success");
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };

 

  const getFirstWord = (str) => {
    const parts = str.split(">");
    console.log(parts[0], "Split");
    return parts[0].trim(); // Return the first part
  };
  

  //-----------------For Formate currency----------------------------

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };
  


  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "10px", maxWidth: "95%" }}
          >
            <div className="card">

              <div className="card-body" style={{ maxWidth: "100%" }}>


                <div className="row mt-1">

                  <div className="col-md-4">
                    {" "}
                    <input style={{ border: "1px solid blue" }}
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>

                  <div className="col-8">
                    <button style={{ float: "right" }} className="btn btn-success" onClick={() => handleBack()}>  Back To Approval Page </button>
                  </div>
                </div>
                <div className="row mt-1"></div>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="tables table-responsive table-responsive-sm">
                    <table
                      className="table table-bordered tb"
                      id="tblIntelliBuy"
                    >
                      <thead className="table-primary">
                        <tr>
                          <th></th>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> UMC Description </th>

                          <th>Indented Qty</th>
                          <th>Unit Price</th>
                          <th>Total Value of indent</th>
                          <th>Differential Qty (after sharing)</th>
                          <th>Total Value of differential qty</th>
                          <th>FOD Type</th>
                          <th>Doc Type</th>
                          <th>Purpose (TBM/CBM/Breakdown)</th>



                          <th> Max Qty</th>
                          <th style={{ whiteSpace: "normal" }}>
                            {" "}
                            Requirement / Consumption
                          </th>
                          <th> VMI/ARC </th>
                          <th> Refurshibility</th>
                          <th> Deprop</th>


                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={row.UMC_INDENT_ID}
                            style={{
                              backgroundColor:
                                selectedRow === row.UMC_INDENT_ID
                                  ? "#ddd"
                                  : "white",
                            }}
                          >
                            <td>
                              <input style={{display:"none"}}
                                type="checkbox"
                                // defaultChecked="false"
                                checked={selectedItemId === row.REQ_UMC_NO}
                                // checked={selectedItemId === row.REQ_UMC_NO}                               
                                onChange={() =>
                                  handleCheckboxChangeforSelect(
                                    row.SCH_CART_NO,
                                    row.REQ_UMC_NO,
                                    index
                                  )
                                }
                              />
                            </td>

                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>
                            <td>{row.QTY} </td>
                            <td>{formatCurrency(row.SCI_PRICE)} </td>
                            <td>{formatCurrency(row.TOTAL_VALUE_OF_INDENT)} </td>
                            <td>{row.DIFFERENTIAL_QTY_AFTER_SHARING} </td>
                            <td>{formatCurrency(row.T_VALUE_OF_DIFF_QTY)} </td>
                            <td>{row.FOD_TYPE} </td>
                            <td>{row.DOCUMENT_TYPE_DESC} </td>
                            <td>{row.PROC_TYPE} </td>
                            <td>
                              <button
                                href=""
                                onClick={() => hanldeClick(row)}
                                className="btn"
                                style={{
                                  // backgroundColor: true === true ? "green" : "red",
                                  backgroundColor:
                                  (row.MAXQTY_STATUS==='false')
                                      ? "red"
                                      : "green",
                                  width: "70px",
                                  fontSize: "13px",
                                  color: "white",
                                }}
                              >
                                {(row.MAXQTY_STATUS==='false')
                                  ? "Fail"
                                  : "Passed"}
                              </button>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeRCMClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor: (row.RCM_STATUS==='false')
                                    ? "red"
                                    : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.RCM_STATUS === "false"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeVMIClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.VMIARC_STATUS === "true" 
                                        ? "green"
                                        : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.VMIARC_STATUS === "true" 
                                    ? "Passed"
                                    : "Fail"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanlderefurshibilityClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.REFURSHIBILITY_STATUS === "false"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.REFURSHIBILITY_STATUS === "false"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeDepropClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.DEPROP_STATUS === "false"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.DEPROP_STATUS === "false"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>

                          </tr>
                        ))}{" "}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-10"></div>
                  <div className="col-2">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${currentPage === index + 1 ? "active" : ""
                            }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-8"></div>


                  <div className="col-2 d-flex justify-content-start">
                    {/* <button type="button" className="btn btn-success">
                      Raise Shopping Cart
                    </button> */}
                  </div>
                </div>
                {show && (
                  <SC_MaxQtyModal
                    updateQtyData={getMaxQtyData_SC}
                    handleClose={hideModal}
                    handleCellChange={hanldeEdit}
                  />
                )}
                {showrcm && (
                  <SC_RequirmentConsumptionModal
                    requirmentConsumptionData={getRCData_SC}
                    handleClose={hideRCMModal}
                    handleCellChange={hanldeRCMEdit}

                    OnSaveData={handleSaveRCMData}
                  />
                )}
                {showrefurshibility && (
                  <SC_RefurshibilityModal
                    requirmentConsumptionData={getRefurshData_SC}
                    handleClose={hiderefurshibilityModal}

                  />
                )}
                {showvmi && (
                  <SC_VMIModal
                    VMIData={getVMIData}
                    handleClose={hideVMIModal}

                  />
                )}
                {showdeprop && (
                  <SC_DepropModal
                    DepropData={getDepropData_SC}
                    handleClose={hideDepropModal}

                  />
                )}
              </div>
            </div>

          
{isVisiblePanel && (
              <div className="panel">
                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    className="card-heading"
                    onClick={togglePanel}
                    style={{ backgroundColor: "#0d6efd", height: "34px" }}
                  >
                    <h6 className="mt-2" style={{ color: "white" }}>
                      &nbsp;{" "}
                      {open ? (
                        <i className="fa fa-minus text-blue"></i>
                      ) : (
                        <i className="fa fa-plus text-blue"></i>
                      )}
                      &nbsp; Indent Item Details &nbsp;{"      "} UMC No :{" "}
                        {umcnodesc}
                    </h6>
                  </div>
                  <Collapse in={open}>
                    <div className="card-body">
                      {/* ----------Start Nav Tab---------- */}
                      <div className="col-12">
                        <Tabs
                          defaultActiveKey="SSA"
                          id="uncontrolled-tab-example"
                          className="my-tab position-relative"
                        >
                          <Tab
                            eventKey="SSA"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                Basic Data
                              </div>
                            }
                            className="act-clr"
                          >
                            <br />
                            <div className="row">
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Storage location
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {StorageLocation}{" "}
                                    </label>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Document type
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {DocumentType}{" "}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Purchase Group
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {" "}
                                      {PurchaseGroup}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Shopping Cart Qty
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {scqty}
                                    </label>
                                  </div>
                                </div>
                                <div className="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      UOM
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {scuom}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Actual Moving Average Price
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {mapvalue}{" "}
                                    </label>
                                    {/* <input
                                      className="form-control form-control-sm"
                                      value={mapvalue}
                                      // value={priceperitem} // Bind inpu      dfff t value to state variable
                                      // onChange={(e) =>
                                      //   InputChange(indexTBL,"PRICE_PER_ITEM",e.target.value)
                                      // }
                                    ></input> */}
                                  </div>
                                </div>

                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Material Consumption Plan
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                      disabled={isDisabled}
                                      value={ProcCons}
                                      //value={setProcCons( e.target.value)}
                                      onChange={(e) =>
                                        InputChangeUMC(
                                          umcno,
                                          "SCI_TXT_PROC_CONS",
                                          e.target.value
                                        )
                                      }
                                    >
                                      <option Value=""> --Select-- </option>
                                      <option Value="MTRCL">
                                        Material consumtion within 33 month of
                                        Import
                                      </option>
                                      <option Value="O"> Other</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Requester Name
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {requesterName}
                                    </label>
                                  </div>
                                </div>
                              </div>
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Procurement Type
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {ProcurementType}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Spare Categorization
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {UnderConsumption}
                                    </label>
                                  </div>
                                </div>

                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Requirement Date
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {RequirementDate}
                                    </label>
                                  </div>
                                </div>
                                {installedQtyDisplay ? (
                                  <div
                                    class="row mt-1"
                                    // style={{ display: installedQtyDisplay }}
                                  >
                                    <div class="col-md-4">
                                      <label className="form-label label-font">
                                        Installed Quantity (Nos)
                                      </label>
                                    </div>
                                    <div className="col-md-1">
                                      {" "}
                                      <label className="form-label label-font">
                                        :
                                      </label>
                                    </div>
                                    <div class="col-md-5 d-flex justify-content-start">
                                      <input
                                        className="form-control form-control-sm"
                                        disabled={isDisabled}
                                        //onChange={handleInputChange} // Handle input change
                                        value={installedQty}
                                        onChange={(e) =>
                                          InputChange(
                                            indexTBL,
                                            "SCI_INSTALLED_QTY",
                                            e.target.value
                                          )
                                        }
                                      ></input>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="row mt-1">
                                    <div class="col-md-12">&nbsp;</div>
                                  </div>
                                )}
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Rate (INR)
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <input
                                      className="form-control form-control-sm"
                                      value={rateINR}
                                      disabled={isDisabled}
                                      //value={priceperitem} // Bind input value to state variable
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_PRICE",
                                          e.target.value
                                        )
                                      }
                                    ></input>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Rate (Foreign Curr.)
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-3">
                                    <input
                                      className="form-control form-control-sm"
                                      value={rateFRN}
                                      disabled={isDisabled}
                                      // onChange={(e) =>
                                      //   Setrateperitem(e.target.value)
                                      // }
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_FRN_PRICE",
                                          e.target.value
                                        )
                                      }
                                    ></input>
                                  </div>
                                  <div class="col-md-2 mr-1 pr-1">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                      value={frncurrency}
                                      disabled={isDisabled}
                                      onChange={(e) =>
                                        CurrencyChange(e.target.value)
                                      }
                                    >
                                      <option value="INR"> INR </option>
                                      {CurrencyList.map((jsonData, id) => (
                                        <option key={id} value={jsonData.FCURR}>
                                          {jsonData.FCURR}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>

                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Imported Plant And Machinery
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                      disabled={isDisabled}
                                      value={Impplantmachinery}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_IMP_PLANT_MACHINERY",
                                          e.target.value
                                        )
                                      }
                                    >
                                      <option> --Select-- </option>
                                      <option Value="Y">Yes</option>
                                      <option Value="N">No</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
{/* 
                            <p style={{ float: "right" ,  }}>
                              <button
                                type="button"
                                className="btn btn-success mt-2"
                                disabled={isDisabled}
                              //  onClick={() => handleSaveAsDraft()}
                              >
                                Save
                              </button>
                            </p> */}
                          </Tab>
                          <Tab
                            eventKey="CRA"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                Cost Assignment
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <label
                                style={{ fontSize: "16px", fontWeight: "bold" }}
                              >
                                You can see who bears the costs and, if
                                necessary, you can distribute the costs to
                                several cost centers.
                              </label>
                              <div className="row mt-3">
                                <div className="col-2">
                                  <label>Category</label>
                                </div>
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                    value={costCategoryvalue}
                                    onChange={(e) =>
                                      //setCostCategory(e.target.value)
                                      handleCostCategoryChange(e.target.value)
                                    }
                                    disabled={isDisabled}
                                  >
                                    {CostCategoryList.map((jsonData, id) => (
                                      <option
                                        key={id}
                                        value={jsonData.ACCT_ASGNMT_CAT}
                                      >
                                        {jsonData.ACCT_ASGNMT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-2">
                                  <label>Cost Distribution</label>
                                </div>
                                <div className="col-3">
                                  <select
                                    className="form-control form-control-sm"
                                    value={costDistribution}
                                    onChange={(e) =>
                                      handleCostHeaderTextChange(e)
                                    }
                                    disabled={isDisabled}
                                  >
                                    <option VALUE="P">Percentage </option>
                                    <option VALUE="Q"> Quantity </option>
                                    <option VALUE="V"> Value </option>
                                  </select>
                                </div>
                              </div>
                              <div
                                className="row mt-3"
                                style={{ display: GLACDisplay }}
                              >
                                <div className="col-2">
                                  <label>G/L Account No</label>
                                </div>
                                <div className="col-2">{GLAccount}</div>
                              </div>
                              {/* <button
                                className="btn btn-primary mt-2 mb-3"
                                onClick={addRow}
                                disabled={isDisabled}
                              >
                                Add New Row
                              </button> */}
                              <div className="tables table-responsive">
                                <table className="table table-bordered">
                                  <thead>
                                    <tr>
                                      <th>Line</th>
                                      <th>{costAssesmentHeaderName}</th>
                                      <th>Assigned To</th>
                                      {isEnbleActivity === "N" && (
                                        <th>Activity Number</th>
                                      )}

                                      {/* <th>Delete</th> */}
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {rows.map((row, index) => (
                                      <tr key={row.SAA_LINE_NO}>
                                        <td>{index + 1}</td>
                                        <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.SAA_DISTRIBUTION_VAL}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.SAA_LINE_NO,
                                                "SAA_DISTRIBUTION_VAL",
                                                e.target.value
                                              )
                                            }
                                            disabled={isDisabled}
                                          />
                                        </td>
                                        <td>
                                          <Autocomplete
                                            disabled={isDisabled}
                                            initialValue={row.SAA_ASGND_TO}
                                            onSelect={(selectedItem) =>
                                              handleSelect(
                                                selectedItem,
                                                row.SAA_LINE_NO
                                              )
                                            }
                                          />
                                        </td>

                                        {isEnbleActivity === "N" && (
                                          <td>
                                            <input
                                              type="text"
                                              className="form-control form-control sm"
                                              value={row.SAA_ACTIVITY_NUM}
                                              onChange={(e) =>
                                                handleInputChange(
                                                  row.SAA_LINE_NO,
                                                  "SAA_ACTIVITY_NUM",
                                                  e.target.value
                                                )
                                              }
                                              disabled={isDisabled}
                                            />
                                          </td>
                                        )}

                                        {/* <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.Assigned}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.Line,
                                                "Assigned",
                                                e.target.value
                                              )
                                            }
                                            disabled={isDisabled}
                                          />
                                        </td> */}
                                        {/* <td>
                                          <button
                                            onClick={() => {
                                              deleteRow(row.SAA_LINE_NO);
                                            }}
                                            style={{
                                              width: "25px",
                                              height: "25px",
                                              padding: "0px",
                                            }}
                                            class="btn btn-danger btn-sm"
                                            type="button"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            title="Delete"
                                            disabled={isDisabled}
                                          >
                                            <i class="fa fa-trash"></i>
                                          </button>
                                        </td> */}
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            {/* <p style={{ float: "right" }}>
                              <button
                                type="button"
                                className="btn btn-success mt-2"
                               // onClick={() => handleSaveCostAssignment()}
                                disabled={isDisabled}
                              >
                                Save
                              </button>
                            </p> */}
                          </Tab>
                          <Tab
                            eventKey="IBCA"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                Documents
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-3">
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                    onChange={(e) =>
                                      ChangeDocuments(e.target.value)
                                    }
                                  >
                                    <option> --Select-- </option>
                                    {DocumentsList.map((jsonData, id) => (
                                      <option
                                        key={id}
                                        value={jsonData.TEXT_ID}
                                        style={{
                                          color: jsonData.CLASSNAME,
                                          fontWeight: "bold",
                                          // backgroundColor:jsonData.CLASSNAME==="#32CD32"?'#D3D3D3':""
                                        }}
                                      >
                                        {jsonData.TXT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-9">
                                  <textarea
                                    className="form-control form-control sm"
                                    value={documentTypeText}
                                    onChange={(e) =>
                                      setDocumentTypeText(e.target.value)
                                    }
                                    rows={3}
                                    disabled={isDisabled}
                                    //cols={40}
                                  />
                                </div>
                              </div>
                              {/* <p style={{ float: "right" }}>
                                <button
                                  type="button"
                                  className="btn btn-success mt-2"
                                  onClick={() => handleSaveDocument()}
                                  disabled={isDisabled}
                                >
                                  Save
                                </button>
                              </p> */}
                            </div>
                          </Tab>
                          <Tab
                            eventKey="SCA"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                Sustainibility
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row mt-1">
                              <div
                                className="col-4"
                                style={{
                                  height: "320px",
                                  overflowY: "scroll",
                                  // border: '1px solid black',
                                  padding: "10px",
                                  // backgroundColor: '#f0f0f0'
                                }}
                              >
                                <p>
                                  Please check the categories those are
                                  applicable
                                </p>
                                <Form>
                                  {/* <Form.Check type="checkbox" /> */}
                                  {CsrCategoryList.map((option) => (
                                    <Form.Check
                                      key={option.VALUE}
                                      type="checkbox"
                                      label={option.LABEL}
                                      defaultChecked="false"
                                      checked={checkedItemId === option.VALUE}
                                      onChange={() =>
                                        handleCheckboxChange(option.VALUE)
                                      }
                                      disabled={isDisabled}
                                    />
                                  ))}
                                </Form>
                                {/* <p>
                                  {selectedOptions.length} /{" "}
                                  {CsrCategoryList.length} selected
                                </p> */}
                              </div>
                              <div
                                className="col-4"
                                style={{
                                  height: "320px",
                                  overflowY: "scroll",
                                  // border: '1px solid black',
                                  padding: "10px",
                                  // backgroundColor: '#f0f0f0'
                                }}
                              >
                                <Form>
                                  {CsrSubCategoryList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroup"
                                      value={option.VALUE}
                                      checked={selectedOption === option.VALUE}
                                      onChange={() =>
                                        handleRadioChange(option.VALUE)
                                      }
                                      disabled={isDisabled}
                                    />
                                  ))}
                                </Form>
                                {/* <p>Selected option: {selectedOption}</p> */}
                              </div>
                              <div
                                className="col-4"
                                style={{
                                  height: "320px",
                                  overflowY: "scroll",
                                  // border: '1px solid black',
                                  padding: "10px",
                                  // backgroundColor: '#f0f0f0'
                                }}
                              >
                                <Form>
                                  {CsrSubActivityList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroupAct"
                                      value={option.VALUE}
                                      checked={
                                        subactivityselectedOption ===
                                        option.VALUE
                                      }
                                      onChange={() =>
                                        handleSubActivityRadioChange(
                                          option.VALUE
                                        )
                                      }
                                      disabled={isDisabled}
                                    />
                                  ))}
                                </Form>
                                <p>
                                  {/* Selected option: {subactivityselectedOption} */}
                                </p>
                              </div>
                            </div>
                            <div
                              className="row mt-3"
                              style={{ display: socialDisplay }}
                            >
                              <div className="col-2">
                                <label>Location</label>
                              </div>
                              <div className="col-3">
                                <select
                                  name="category"
                                  id="category"
                                  className="form-control form-control-sm"
                                  type="text"
                                  value={csrLocation}
                                  onChange={(e) =>
                                    setCsrLocation(e.target.value)
                                  }
                                >
                                  <option> --Select-- </option>
                                  {csrLocationList.map((jsonData, id) => (
                                    <option
                                      key={id}
                                      value={jsonData.CSR_LOC_CODE}
                                    >
                                      {jsonData.CSR_LOC_DESC}
                                    </option>
                                  ))}
                                </select>
                              </div>
                              <div class="col-md-6">
                                <textarea
                                  className="form-control form-control-sm"
                                  style={{ width: "400", height: "100px" }}
                                  //  onChange={handleRemarksChange}
                                  value={csrRemarks}
                                  onChange={(e) =>
                                    setCsrRemarks(e.target.value)
                                  }
                                  placeholder="Remarks"
                                ></textarea>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-11 d-flex justify-content-end">
                                {/* <button
                                  type="button"
                                  className="btn btn-success mt-2"
                                  onClick={() => handleSaveSustainibility()}
                                  disabled={isDisabled}
                                >
                                  Save
                                </button> */}
                              </div>
                            </div>
                          </Tab>
                          {ClassificationDisplay ? (
                            <Tab
                              eventKey="CLA"
                              title={
                                <div style={{ padding: "0px 35px 0px 35px" }}>
                                  Classification
                                </div>
                              }
                              className="tab-txt-clr act-clr"
                            >
                              <div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      HSN No.
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <input
                                      className="form-control"
                                      disabled={isDisabled}
                                    ></input>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Characteristics
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={characteristics}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_CHARACTERISTICS",
                                          e.target.value
                                        )
                                      }
                                      // onChange={(e) =>
                                      //   SetCharacteristics(e.target.value)
                                      // }
                                      placeholder="Characteristics"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Composition
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={composition}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_COMPOSITION",
                                          e.target.value
                                        )
                                      }
                                      placeholder="Composition"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      End use :
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={enduse}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_ENDUSE",
                                          e.target.value
                                        )
                                      }
                                      placeholder="   End use :	"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Function
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={functionText}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_FUNCTION",
                                          e.target.value
                                        )
                                      }
                                      placeholder="Function"
                                    ></textarea>
                                  </div>
                                </div>
                                <div>
                                      {/* <p style={{ float: "right" }}>
                                        <button
                                          type="button"
                                          className="btn btn-success mt-2"
                                         // onClick={() => handleSaveAsDraft()}
                                          disabled={isDisabled}
                                        >
                                          Save
                                        </button>
                                      </p> */}
                                    </div>
                              </div>
                            </Tab>
                          ) : (
                            ""
                          )}
                          {DesiredVendorDisplay ? (
                            <Tab
                              eventKey="DV"
                              title={
                                <div style={{ padding: "0px 10px 0px 10px" }}>
                                  Source of supply/Service Agents
                                </div>
                              }
                              //style={{display:DesiredVendorDisplay}}
                              className="tab-txt-clr act-clr"
                            >
                              <div className="row mt-2">
                                {isDisabled === false ? (
                                  <div className="row">
                                    <div class="col-md-3">
                                      <label className="form-label label-font">
                                        Desired Vendor
                                      </label>
                                    </div>
                                    <div class="col-md-3">
                                      <AutocompleteVendorMaster
                                        initialValue={desiredVendor}
                                        onSelect={handleSelectVendorName}
                                      />
                                      {/* <input
                                    className="form-control form-control-sm"
                                    value={desiredVendor}
                                    disabled={isDisabled}
                                    onChange={(e) =>
                                      InputChange(
                                        indexTBL,
                                        "SCI_OA_VENCD",
                                        e.target.value
                                      )
                                    }
                                  ></input> */}
                                    </div>
                                    <div>
                                      {/* <p style={{ float: "right" }}>
                                        <button
                                          type="button"
                                          className="btn btn-success mt-2"
                                         // onClick={() => handleSaveAsDraft()}
                                          disabled={isDisabled}
                                        >
                                          Save
                                        </button>
                                      </p> */}
                                    </div>
                                  </div>
                                ) : (
                                  <div className="row">
                                    <div className="row mt-2">
                                      <div className="tables table-responsive">
                                        <table className="table table-bordered">
                                          <thead>
                                            <tr>
                                              <th>Vendor Code</th>
                                              <th>Vendor Name</th>
                                            </tr>
                                          </thead>
                                          {vendordetailsList.map(
                                            (row, index) => (
                                              <tbody>
                                                <tr>
                                                  <td>{row.VENDOR}</td>
                                                  <td>{row.NAME1}</td>
                                                </tr>
                                              </tbody>
                                            )
                                          )}
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </div>
                              <p style={{ float: "right" }}></p>
                            </Tab>
                          ) : (
                            ""
                          )}

                          <Tab
                            eventKey="NPM"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                MPN/Drawing
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row mt-2">
                              <div className="tables table-responsive">
                                <table className="table table-bordered">
                                  <thead>
                                    <tr>
                                      {bgg === "318" && <th>Action</th>}
                                      <th>Part No/Drawing</th>
                                      <th>Manufacturer</th>
                                      <th>Manufacturer Name</th>
                                    </tr>
                                  </thead>
                                  {MPNDrawingsdetailsList.map((row, index) => (
                                    <tbody>
                                      <tr>
                                        {bgg === "318" && (
                                          <td>
                                            <Form.Check
                                              key={index}
                                              type="radio"
                                              name="radioGroup"
                                              checked={
                                                MNPSelected === row.MFRNR
                                              }
                                              onChange={() =>
                                                handleMPNUpdateRadioChange(
                                                  row.MFRNR
                                                )
                                              }
                                            />
                                          </td>
                                        )}
                                        <td>{row.PNO}</td>
                                        <td>{row.MFRNR}</td>
                                        <td>{row.NAME1}</td>
                                      </tr>
                                    </tbody>
                                  ))}
                                </table>
                              </div>
                            </div>
                            <p style={{ float: "right" }}></p>
                          </Tab>
                          <Tab
                            eventKey="FOD"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                FOD
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-3">
                                <div className="tables table-responsive">
                                  <table className="table table-bordered">
                                    <thead>
                                      <tr>
                                        <th>FOD Type</th>
                                        <th>Fod No./FOD Item No</th>
                                        <th>FOD Creation Date</th>
                                        <th>FOD SAP Message</th>
                                      </tr>
                                    </thead>
                                    <tbody style={{ textAlign: "center" }}>
                                      <td>{fodtype}</td>
                                      <td>
                                        {sapFODNo}
                                        {" / "}
                                        {sapFODItemNo}
                                      </td>
                                      <td>{sapFODCreatedDT}</td>
                                      <td>{sapFODMsg}</td>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </Tab>
                        </Tabs>
                      </div>
                      {/*----End Nav Tab-----*/}
                    </div>
                  </Collapse>
                </div>

              </div>
            )}
         

          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};
export default SC_AppDetailsView;

import React, { useState, useEffect } from "react";
import axios from "axios";
import { Button, Table } from 'reactstrap';
import * as XLSX from 'xlsx'; // Import XLSX library
import Navbar from "../components/Navbar/Navbar";
import { BaseUrl } from "../constants/BaseURL";
import Swal from "sweetalert2";

const CMBGGMapping = (prop) => {
  const [pgList, setPGList] = useState([]);
  const [bggList, setbggList] = useState([]);
  const [cmbggMapping, setCMBGGMapping] = useState([]);
  const [selectedPGs, setSelectedPGs] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [pgSearch, setPgSearch] = useState(''); // State for PG search
  const [bggSearch, setBggSearch] = useState(''); // State for BGG search
  const [bggDropdownOpen, setBggDropdownOpen] = useState(false); // Dropdown state for BGG
  const [selectedBGG, setSelectedBGG] = useState(''); 
   const [selectedBGGs, setSelectedBGGs] = useState([]); 


  useEffect(() => {
    fetchPGList();
    fetchBBGList();
  }, []);

  const fetchPGList = async () => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = { 'jwt-token': token };
      const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetPGList_SC`, { headers });
      const data = response.data;
      setPGList(data.jsonData);
      const allPGs = data.jsonData.map(pg => pg.EKGRP);
      setSelectedPGs(allPGs);
      setSelectAll(true);
    } catch (error) {
      console.log(error);
    }
  };

  const fetchBBGList = async () => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = { 'jwt-token': token };
      const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetBGGList_SC`, { headers });
      const data = response.data;
      setbggList(data.jsonData);
    } catch (error) {
      console.log(error);
    }
  };

  const handlePGChange = (EKGRP) => {
    if (selectedPGs.includes(EKGRP)) {
      setSelectedPGs(selectedPGs.filter(pg => pg !== EKGRP));
    } else {
      setSelectedPGs([...selectedPGs, EKGRP]);
    }
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedPGs([]);
    } else {
      setSelectedPGs(pgList.map(pg => pg.EKGRP));
    }
    setSelectAll(!selectAll);
  };

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const toggleBggDropdown = () => {
    setBggDropdownOpen(!bggDropdownOpen);
  };

  const fetchShoppingCartList = async () => {
    prop.showLoader();
    try {
      debugger;
      let token = sessionStorage.getItem('token');
      let headers = { 'jwt-token': token };
      setCMBGGMapping([]);
      const PG = selectedPGs.join(',');
     // const BGG = document.getElementById("BGG").value;
     const BGG =  bggSearch;
      if (!PG) {      
        Swal.fire("", "Please select purchasing group", "warning");
        setCMBGGMapping([]);
        return;
      }

      const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetCMBGGMapping_SC?PG=${PG}&BGG=${BGG}`, { headers });
      const data = response.data;
      setCMBGGMapping(data.jsonData);
      prop.hideLoader();
    } catch (error) {
      console.log(error);
    }
  };

  const handleClick = () => {
    fetchShoppingCartList();
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(cmbggMapping);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "CMBGG Mapping");
    XLSX.writeFile(workbook, "CMBGGMapping.xlsx");
  };

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }

    const sortedData = [...cmbggMapping].sort((a, b) => {
      if (a[key] < b[key]) {
        return direction === 'asc' ? -1 : 1;
      }
      if (a[key] > b[key]) {
        return direction === 'asc' ? 1 : -1;
      }
      return 0;
    });

    setSortConfig({ key, direction });
    setCMBGGMapping(sortedData);
  };

  const renderSortIcon = (column) => {
    if (sortConfig.key === column) {
      return sortConfig.direction === 'asc' ? <i className="fas fa-sort-up"></i> : <i className="fas fa-sort-down"></i>;
    }
    return <i className="fas fa-sort"></i>;
  };

  // Filter PG List based on search input
  const filteredPGList = pgList.filter(pg => 
    pg.DESCRIPTION.toLowerCase().includes(pgSearch.toLowerCase())
  );

  // Filter BGG List based on search input
  const filteredBGGList = bggList.filter(bgg => 
    bgg.DESCRIPTION.toLowerCase().includes(bggSearch.toLowerCase())
  );

   const handleBggSelect = (bggDescription) => {
    setBggSearch(bggDescription.MATKL);
     setSelectedBGG(bggDescription.DESCRIPTION); // Set the selected BGG description in state
     setBggDropdownOpen(false); // Close the dropdown after selection
   };

  const handleBggSelect2 = (bggDescription) => {
    debugger
    if (bggDescription.MATKL === "null") {
      // Handle reselection of "Select BGG" label
      setBggSearch('');
      setSelectedBGGs([]); // Clear selected BGGs
      setSelectedBGG(null); // Reset selected BGG label to null
    } 
    setBggDropdownOpen(false); // Close the dropdown after selection
  };

  
  return (
    <>
      <Navbar />
    
      <div className="container" style={{ marginTop: "25px", maxWidth: "95.5%", overflowX: "auto", height: "560px" }}>
        <div className="card" style={{ height: "620px" }}>
          <div className="card-heading" style={{ backgroundColor: "lightgray", height: "44px" }}>
            <h4 className="mt-2">
              <>&nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;CM BGG Mapping</>
            </h4>
          </div>
          <div style={{ marginLeft: "15px", marginTop: "5px" }}>
            <div className="row">
              <div className="col-md-3">
                <label className="labelFont " style={{fontWeight:"bold"}}>Purchasing Group</label>
                <div className="dropdown" style={{ position: 'relative', width: '100%' }}>
                  <button className="btn btn-light dropdown-toggle form-control" onClick={toggleDropdown} style={{border:'1px solid gray'}}>
                    {selectedPGs.length > 0 ? `Selected (${selectedPGs.length})` : 'Select Purchasing Group'}
                  </button>

                  {dropdownOpen && (
                    <div
                      className="dropdown-menu show"
                      style={{
                        display: 'block',
                        position: 'absolute',
                        top: '100%',
                        left: 0,
                        zIndex: 1,
                        width: '100%',
                        maxHeight: '200px',
                        overflowY: 'auto',
                      }}
                    >
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Search..."
                        value={pgSearch}
                        onChange={(e) => setPgSearch(e.target.value)}
                      />
                      <div className="dropdown-item">
                        <input
                          type="checkbox"
                          checked={selectAll}
                          onChange={handleSelectAll}
                        /> Select All
                      </div>
                      {filteredPGList.map((itm, id) => (
                        <div key={id} className="dropdown-item">
                          <input
                            type="checkbox"
                            checked={selectedPGs.includes(itm.EKGRP)}
                            onChange={() => handlePGChange(itm.EKGRP)}
                          /> {itm.DESCRIPTION}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="col-md-3">
                <label className="labelFont " style={{fontWeight:"bold"}}>BGG</label>
                <div className="dropdown" style={{ position: 'relative', width: '100%' }}>
                  <button className="btn btn-light dropdown-toggle form-control" onClick={toggleBggDropdown} style={{border:'1px solid gray'}}>
                  {selectedBGG ? selectedBGG : 'All'}                   
                  </button>

                  {bggDropdownOpen && (
                    <div
                      className="dropdown-menu show"
                      style={{
                        display: 'block',
                        position: 'absolute',
                        top: '100%',
                        left: 0,
                        zIndex: 1,
                        width: '100%',
                        maxHeight: '200px',
                        overflowY: 'auto',
                      }}
                    >
                      {/* Search Input for BGG */}
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Search BGG..."
                        value={bggSearch}
                        onChange={(e) => setBggSearch(e.target.value)}
                      />   
                      <div
                        className="dropdown-item"
                        onClick={() => handleBggSelect2({ MATKL: "null", DESCRIPTION: "All" })}
                      >
                        All
                      </div>
                      {filteredBGGList.map((itm, id) => (
                      
                        <div key={id} className="dropdown-item" value={itm.MATKL}
                        onClick={() => {
                          handleBggSelect(itm); // Set the selected BGG and close dropdown
                       
                        }}
                         >
                          {itm.DESCRIPTION}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="col-md-1 mt-4 colmd1">
                <label className="labelFont"></label>
                <Button color="primary" onClick={handleClick}>Search</Button>
              </div>
              <div className="col-md-2 mt-4 colmd1">
                <label className="labelFont"></label>
                <Button color="success" onClick={exportToExcel}>Export to Excel</Button>
              </div>
            </div>
          </div>
          
          <div style={{ marginTop: "10px" }}>
          <Table className="table table-bordered">
                <thead>
                  <tr> 
                    <th onClick={() => handleSort('APPTYP')}>App Typ {renderSortIcon('APPTYP')}</th> 
                    <th onClick={() => handleSort('MATKL')}>Material Group {renderSortIcon('MATKL')}</th>
                    <th onClick={() => handleSort('EKGRP')}>Purchasing Group {renderSortIcon('EKGRP')}</th>                   
                    <th onClick={() => handleSort('CMGRCD')}>CM Code {renderSortIcon('CMGRCD')}</th>
                    <th onClick={() => handleSort('CMGRNM')}>CM Name {renderSortIcon('CMGRNM')}</th>
                    <th onClick={() => handleSort('CMGRPN')}>CM Per No {renderSortIcon('CMGRPN')}</th>
                    <th onClick={() => handleSort('CASOCD')}>CMA Code {renderSortIcon('CASOCD')}</th>
                    <th onClick={() => handleSort('CASONM')}>CMA Name {renderSortIcon('CASONM')}</th>
                    <th onClick={() => handleSort('CASPNO')}>CMA Per No {renderSortIcon('CASPNO')}</th> 

                    <th onClick={() => handleSort('DELMN')}>DM Code {renderSortIcon('DELMN')}</th> 
                    <th onClick={() => handleSort('DMMAP')}>DM Name {renderSortIcon('DMMAP')}</th> 
                    <th onClick={() => handleSort('DEMPN')}>DM Per No {renderSortIcon('DEMPN')}</th> 
                    <th onClick={() => handleSort('HEADPN')}>HEAD Per No {renderSortIcon('HEADPN')}</th> 
                    <th onClick={() => handleSort('CHFPN')}>Chief Per No {renderSortIcon('CHFPN')}</th> 
                    <th onClick={() => handleSort('CMAMOB')}>CMA Mobile No {renderSortIcon('CMAMOB')}</th> 
                    <th onClick={() => handleSort('DMMOB')}>DM Mobile No {renderSortIcon('DMMOB')}</th> 
                    <th onClick={() => handleSort('CMMOB')}>CM Mobile No {renderSortIcon('CMMOB')}</th> 
                  </tr>
                </thead>
                <tbody>
                  {cmbggMapping.map((itm, index) => (
                    <tr key={index}>
                      <td>{itm.APPTYP}</td>
                      <td>{itm.MATKL}</td>
                      <td>{itm.EKGRP}</td>
                      <td>{itm.CMGRCD}</td>
                      <td>{itm.CMGRNM}</td>
                      <td>{itm.CMGRPN}</td>
                      <td>{itm.CASOCD}</td>
                      <td>{itm.CASONM}</td>
                      <td>{itm.CASPNO}</td>

                      <td>{itm.DELMN}</td>
                      <td>{itm.DMMAP}</td>
                      <td>{itm.DEMPN}</td>
                      <td>{itm.HEADPN}</td>
                      <td>{itm.CHFPN}</td>
                      <td>{itm.CMAMOB}</td>
                      <td>{itm.DMMOB}</td>
                      <td>{itm.CMMOB}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>

          </div>
        </div>
      </div>
    </>
  );
};

export default CMBGGMapping;

import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
import { useSelector } from "react-redux";
import "./IntelliBuySystemChecks.css";
import MaxQtyModal from "../components/IntelliBuy/MaxQtyModal";
import RequirmentConsumptionModal from "../components/IntelliBuy/RequirmentConsumptionModal";
import RefurshibilityModal from "../components/IntelliBuy/RefurshibilityModal";
import VMIModal from "../components/IntelliBuy/VMIModal";
import DepropModal from "../components/IntelliBuy/DepropModal";
import ProgressBar from "../components/IntelliBuy/ProgressBar";
import axios from "axios";
import TabMenu from "../components/TabMenu/TabMenu";
import Swal from "sweetalert2";
import * as moment from "moment";
import { useNavigate } from "react-router-dom";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import {
  Form,
  Collapse,
} from "react-bootstrap";
const SC_AppDtlsView = ({
  showLoader,
  hideLoader,
  switchToShoppingCart,
}) => {
  const navigate = useNavigate();
  // const indentId = useSelector((state) =>
  //   state.indent ? state.indent.indentId : ""
  // );

  const indentId = sessionStorage.getItem("IndentNo");
  const [state, setstate] = useState(false);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [workFlowData, setWorkFlowData] = useState([]);
  const [checkedUMCList, setcheckedUMCList] = useState("");
  const [checkedMAXUMCList, setcheckedMAXUMCList] = useState("");
  const [indentno, setIndentNo] = React.useState(indentId);
  const [indentstatus, setIndentStatus] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [showrcm, setShowRCM] = useState(false);
  const [showrefurshibility, setShowRefurshibility] = useState(false);
  const [showvmi, setShowVMI] = useState(false);
  const [showdeprop, setShowDeprop] = useState(false);
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRow, setSelectedRow] = useState(null);
  const [RCMstatus, setRCMStatus] = useState("");
  const [VMIstatus, setVMIStatus] = useState({});
  const [selectedDatercmdt, setSelectedDateRCMDate] = useState("");
  const [firstEffectComplete, setFirstEffectComplete] = useState(false);
  const [indicator, setIndicator] = useState("");

  const [isShown, setIsShown] = useState(false);
  const [fyear, setFyear] = useState("");
  const [committedExpenditure, setCommittedExpenditure] = useState("");
  const [spareBudget, setSpareBudget] = useState(""); 
  const [progress, setProgress] = useState();

  const itemsPerPage = 5;


  const [open, setOpen] = useState(false);
  const [scqty, Setscqty] = React.useState("");

  const [StorageLocation, setStorageLocation] = React.useState("");
  const [DocumentType, setDocumentType] = React.useState("");
  const [PurchaseGroup, setPurchaseGroup] = React.useState("");
  const [ProcurementType, setProcurementType] = React.useState("");
  const [UnderConsumption, setUnderConsumption] = React.useState("");
  const [RequirementDate, setRequirementDate] = React.useState("");
  const [scuom, SetUOM] = React.useState("");
  const [priceperitem, Setpriceperitem] = React.useState("");
  const [CsrCategoryList, Setcsrcategorylist] = useState([]);
  const [CostCategoryList, Setcostcategorylist] = useState([]);
  const [DocumentsList, Setdocumentslist] = useState([]);
  const [CurrencyList, Setcurrencylist] = useState([]);
  const [CsrSubCategoryList, Setcsrsubcategorylist] = useState([]);
  const [CsrSubActivityList, Setcsrsubactivitylist] = useState([]);
  const [openimport, setOpenImport] = useState(true);

  const [selectedItemId, setSelectedItemId] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const [subactivityselectedOption, setSubActivitySelectedOption] =
    useState("");

  const [enablePanel, setEnablePanel] = useState(false);
  const [panelData, setPanelData] = useState("");
  const [shoppingcartno, setShoppingCartNo] = React.useState("");
  

  const [rows, setRows] = useState([
    { Line: 1, Percentage: "100", Assigned: "" },
    { Line: 2, Percentage: "", Assigned: "" },
    { Line: 3, Percentage: "", Assigned: "" },
    { Line: 4, Percentage: "", Assigned: "" },
    { Line: 5, Percentage: "", Assigned: "" },
  ]);

  const togglePanel = () => {
    setOpen(!open);
  };


  const handleRadioChange = (value) => {
    setSelectedOption(value);
    fetchCsrSubActivityList(value);
  };
  const handleSubActivityRadioChange = (value) => {
    setSubActivitySelectedOption(value);
  };
  const fetchCsrSubActivityList = async (CSR_SUB_CODE) => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
        'jwt-token': token
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubActivity?CSR_SUB_CODE=${CSR_SUB_CODE}`, { headers }
      );
      Setcsrsubactivitylist(response.data.jsonData);
      console.log(response.data.jsonData, "fetchCsrSubActivityList");
    } catch (error) {
      console.log(error, "GetCostCsrSubActivity");
    }
  };
  const handleCheckboxChangeforSelect = (id) => {
    debugger;
    const updatedData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === id
        ? { ...item, checked: true }
        : { ...item, checked: false }
    );
    console.log(workFlowData, "workFlowData");
    setWorkFlowData(updatedData);

    const selectedCheckbox = updatedData.find(
      (item) => item.UMC_INDENT_ID === id
    );

    if (selectedItemId !== id) {
      // Only update state if a different checkbox is selected
      setSelectedItemId(id);
      setEnablePanel(true);
      setPanelData(selectedCheckbox.data);
      setDocumentType(selectedCheckbox.DOCUMENT_TYPE_DESC);
      setStorageLocation(selectedCheckbox.SLOC_DESC);
      setPurchaseGroup(selectedCheckbox.PG_DESC);
      setProcurementType(selectedCheckbox.PROC_TYPE);
      setRequirementDate(selectedCheckbox.REQUIREMENT_DATE);
      SetUOM(selectedCheckbox.UOM);
      setShoppingCartNo(selectedCheckbox.SCH_CART_NO);
      setUnderConsumption(selectedCheckbox.SPARE);
      Setscqty(selectedCheckbox.QTY);
      Setpriceperitem(selectedCheckbox.PRICE_PER_ITEM);
    } else {
      // Deselect the checkbox if it was already selected
      setSelectedItemId(null);
      setEnablePanel(false);
      setPanelData("");
      setDocumentType("");
      setStorageLocation("");
      setPurchaseGroup("");
      setProcurementType("");
      setRequirementDate("");
      setShoppingCartNo("");
      setUnderConsumption("");
      Setscqty("");
    }
    // const filteredData = workFlowData.filter((item) => item.ISACTIVE === "Y");
    // const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    // console.log(totalPage,'totalPage');
    // setCurrentPage(totalPage);
  };
  // Function to handle input changes
  const handleInputChangePrice = (event) => {
    Setpriceperitem(event.target.value); // Update the state with input value
  };
  const handleInputChange = (id, field, value) => {
    const updatedRows = rows.map((row) => {
      if (row.Line === id) {
        return { ...row, [field]: value };
      }
      return row;
    });
    console.log(updatedRows);
    setRows(updatedRows);
  };

  ///-------------MaxQty Modal---------//
  const MaxQtyStatus = workFlowData.some((item) => item.QTY > item.ALLOWEDQTY);
  const hanldeDelete = (rowno) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === rowno ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const getUpdateQty = () => {
    setWorkFlowData(workFlowData);
  };
  const hanldeClick = (selectedRec) => {
    getUpdateQty();
    setShow(true);
  };

  const hideModal = () => {
    setShow(false);
  };
  const handleSaveMaxQtyData = () => {
    handleSaveAsDraft();
  };
  ///-------------Refurshibility Modal---------//

  const hanlderefurshibilityClick = (selectedRec) => {
    getrefurshibility();
    setShowRefurshibility(true);
  };

  const hiderefurshibilityModal = () => {
    setShowRefurshibility(false);
  };

  const getrefurshibility = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------RequirmentConsumption Modal---------//

  const handleSaveRCMData = () => {
    handleSaveAsDraft();
  };

  const calculateQuantity = (row) => {
    const maxQty = parseFloat(row.MaxQty) || 0;
    const pipelineQty = parseFloat(row.PipelineQty) || 0;
    const refurQty = parseFloat(row.RefurQty) || 0;
    const chargeQty = parseFloat(row.ChargeQty) || 0;

    let quantity = maxQty - (pipelineQty + refurQty + chargeQty);
    if (quantity < 0) {
      quantity = 0.0;
    }
    return quantity.toFixed(3);
  };

  // Function to format date as dd-mm-yyyy
  const formatDate = (dateString) => {
    const dateObj = new Date(dateString);
    const day = String(dateObj.getDate()).padStart(2, "0");
    const month = String(dateObj.getMonth() + 1).padStart(2, "0"); // January is 0!
    const year = dateObj.getFullYear();

    return `${day}-${month}-${year}`;
  };
  const formatDateInput = (dateStr) => {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    } else {
      return dateStr;
    }
  };
  const hanldeRCMEdit = (
    index,
    field,
    SysReqDTT,
    SysConsumDTT,
    ChangeReqDTT,
    changeConsumDTT,
    userjustification
  ) => {
    var Retrncolor = "green";
    var setMessage = "";
    const newData = [...workFlowData];
    //console.log(newData,"newData");
    const strSysTM = new Date(moment(SysReqDTT).format("YYYY-MM-DD"));
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(moment(SysReqDTT).format("YYYY-MM-DD")).getTime();
    const SysConsumDT = new Date(
      moment(SysConsumDTT).format("YYYY-MM-DD")
    ).getTime();
    const ChangeReqDT = new Date(
      moment(ChangeReqDTT).format("YYYY-MM-DD")
    ).getTime();
    const changeConsumDT = new Date(
      moment(changeConsumDTT).format("YYYY-MM-DD")
    ).getTime();

    const Condition1 = SysReqDT === ChangeReqDT;
    const Condition2 = SysReqDT > ChangeReqDT;
    const Condition3 = SysReqDT < ChangeReqDT;
    const Condition4 = SysConsumDT === changeConsumDT;
    const Condition5 = SysConsumDT > changeConsumDT;
    const Condition6 = SysConsumDT < changeConsumDT;

    if (Condition1 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition1 && Condition5) {
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition1 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition4) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition5) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition6) {
      setMessage =
        "Please amend your requirement/consumption date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition3 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition5) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";
      setIndicator("red");
      Retrncolor = "red";
    }

    newData[index]["REQUIREMENT_DATE"] =
      moment(ChangeReqDTT).format("DD-MMM-YYYY");
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    //moment(changeConsumDTT).format("DD-MMM-YYYY");
    newData[index]["RCM_CHECKS_STATUS"] = Retrncolor;
    newData[index]["RCM_SmartNudges"] = setMessage;
    newData[index]["USER_REMARKS_RCM"] = userjustification;
    setWorkFlowData(newData);
    console.log(newData, "");
  };

  const hanldeRCMChecks = (
    index,
    field,
    SysReqDTT,
    SysConsumDTT,
    ChangeReqDTT,
    changeConsumDTT
  ) => {
    var Retrncolor = "green";
    var setMessage = "";
    const SyReqDTT = SysReqDTT;
    const newData = [...workFlowData];
    //console.log(newData,"newData");
    const strSysTM = new Date(moment(SysReqDTT).format("YYYY-MM-DD"));
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(moment(SysReqDTT).format("YYYY-MM-DD")).getTime();
    const SysConsumDT = new Date(
      moment(SysConsumDTT).format("YYYY-MM-DD")
    ).getTime();
    const ChangeReqDT = new Date(
      moment(ChangeReqDTT).format("YYYY-MM-DD")
    ).getTime();
    const changeConsumDT = new Date(
      moment(changeConsumDTT).format("YYYY-MM-DD")
    ).getTime();

    const Condition1 = SysReqDT === ChangeReqDT;
    const Condition2 = SysReqDT > ChangeReqDT;
    const Condition3 = SysReqDT < ChangeReqDT;
    const Condition4 = SysConsumDT === changeConsumDT;
    const Condition5 = SysConsumDT > changeConsumDT;
    const Condition6 = SysConsumDT < changeConsumDT;

    if (Condition1 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition1 && Condition5) {
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition1 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition4) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition5) {
      setMessage =
        "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition2 && Condition6) {
      setMessage =
        "Please amend your requirement/consumption date as per the requirement date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition3 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition5) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition3 && Condition6) {
      setMessage =
        "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/shopping cart will be escalated to Area Chief for approval.";
      setIndicator("red");
      Retrncolor = "red";
    }

    newData[index]["REQUIREMENT_DATE"] =
      moment(ChangeReqDTT).format("DD-MMM-YYYY");
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    // moment(changeConsumDTT).format("DD-MMM-YYYY");
    newData[index]["RCM_CHECKS_STATUS"] = Retrncolor;
    newData[index]["RCM_SmartNudges"] = setMessage;
    newData[index]["MAXQTY_CHECKS_STATUS"] = Retrncolor;
    setWorkFlowData(newData);
    setFirstEffectComplete(false);
  };

  const hanldeRCMClick = (selectedRec) => {
    getRCM();
    setShowRCM(true);
  };
  const hideRCMModal = () => {
    setShowRCM(false);
  };
  const getRCM = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------VMI-----------//

  const hanldeVMIClick = (selectedRec) => {
    getVMI();
    setShowVMI(true);
  };

  const hideVMIModal = () => {
    setShowVMI(false);
  };

  const getVMI = () => {
    setWorkFlowData(workFlowData);
  };

  ////---------------Deprop------------///
  const hanldeDepropClick = (selectedRec) => {
    getDeprop();
    setShowDeprop(true);
    ////console.log(workFlowData, "workFlowData");
  };

  const hideDepropModal = () => {
    setShowDeprop(false);
  };

  const getDeprop = () => {
    setWorkFlowData(workFlowData);
  };

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          // `${BaseUrl}api/IntelliBuyChecks/GetIntelliBuyChecksDetails?IndentId=${indentno}`,
          `${BaseUrl}api/ShoppingCart/GetIntelliBuyChecksDetails_SC?IndentId=${indentno}`,
          { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();
          console.log(data.jsonData, "Data");
          if (data.jsonData.length > 0) {
            setWorkFlowData(data.jsonData);
            setProgress(data.jsonData[0].DeptBudgetConsumption);
            setFyear(data.jsonData[0].FY_YEAR);
            setSpareBudget(data.jsonData[0].SPAREBUDGET);
            setCommittedExpenditure(data.jsonData[0].COMMITTEDEXPENDITURE);
            setFirstEffectComplete(true);

          } else {
            Swal.fire("", "No Data Found", "info");
            setWorkFlowData([]);
            setIndentStatus("");
            setIndentDept("");
            setisLoading(false);
            hideLoader();
          }

          ////////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          ////console.log(error);
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const filteredData = workFlowData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  //////console.log(totalPages, "Total page");
  //////console.log(filteredData, "filteredData");
  // const currentData = filteredData.slice(
  //   (currentPage - 1) * itemsPerPage,

  //   currentPage * itemsPerPage
  // );
  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };
  const regex = /^[a-zA-Z\s]*\d*\.?\d*$/;
  const hanldeEdit = (index, field, value) => {
    const newData = [...workFlowData];
    if (field == "USER_REMARKS_MAXQTY") {
      if (regex.test(value)) {
        newData[index][field] = value;
        setWorkFlowData(newData);
      }
    } else if (field == "SC_QTY") {
      if (/^\d*\.?\d*$/.test(value)) {
        const oldscvalue =
          parseFloat(newData[index]["QTY"]) -
          newData[index]["TOTAL_SAP_DOC_QTY"];
        console.log(newData[index][field], "old value");
        console.log(value, "new value");
        if (parseFloat(oldscvalue) < parseFloat(value)) {
          Swal.fire(
            "Alert",
            "Shopping Cart qty not greater than  " + oldscvalue + "",
            "warning"
          );
          value = oldscvalue;
        }
        if (parseFloat(value) === 0) {
          Swal.fire(
            "Alert",
            "if material is not required, kindly delete from the list.",
            "warning"
          );
          value = oldscvalue;
        }
        newData[index][field] = value;
        setWorkFlowData(newData);
      }
    }
  };

  // const handleDeleteRow = (UMC_INDENT_ID) => {
  //   const newData = workFlowData.filter(
  //     (item) => item.UMC_INDENT_ID !== UMC_INDENT_ID
  //   );
  //   setWorkFlowData(newData);
  //   const totalPage = Math.ceil(newData.length / itemsPerPage);
  //   setCurrentPage(totalPage);
  // };


  useEffect(() => {
    console.log("use Effect Called");
    if (indentId !== "") {
      hanldeSearchClick(indentId);
      //getBudgetValue(indentId);
    }
  }, [indentId]);

  useEffect(() => {
    console.log("use Effect Called 2");
    ////console.log(firstEffectComplete,"firstEffectComplete") ;
    if (firstEffectComplete) {
      ////console.log(workFlowData,"data work flow") ;
      if (workFlowData.length > 0) {
        workFlowData.forEach((row, index) => {
          ////console.log(index,"index") ;
          hanldeRCMChecks(
            index,
            "",
            row.ReqDate,
            row.ConsDate,
            row.REQUIREMENT_DATE,
            row.CONSUMP_DT
          );
        });
        rcmmandatoryremarkschecks(workFlowData);
      }
    }
  }, [firstEffectComplete, workFlowData]);

  const rcmmandatoryremarkschecks = (workFlowData) => {
    debugger;
    const UMCList = [];
    var umcliststring;
    const REF_CHK = workFlowData.some(
      (row) => row.RCM_CHECKS_STATUS === "red" && row.USER_REMARKS_RCM === ""
    );
    workFlowData.forEach((row) => {
      if (row.RCM_CHECKS_STATUS === "red" && row.USER_REMARKS_RCM === "") {
        UMCList.push(row.REQ_UMC_NO);
      }
      if (UMCList.length > 0) {
        UMCList.join(", ");
        //console.log(`Fill all remarks against ID (${idListString})`);
        // Optionally, set a state to display a message in your UI
      }
    });
    setcheckedUMCList(UMCList.join(", "));
    console.log(checkedUMCList, "umclist");
    return REF_CHK;
  };

  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    debugger
    let SCQTY_CHK = workFlowData.filter((row) => row.SC_QTY === "");
    if (SCQTY_CHK.length > 0) {
      Swal.fire("Alert", "Shopping cart quantity can not be blank.", "error");
      return;
    }
    setisLoading(true);
    showLoader();
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTOR_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: user.User_Id,
        INDENT_MOD_BY: user.User_Id,
        INDENT_STATUS: "25",
        SCH_CART_NO: workFlowData[0].SCH_CART_NO,
        SCH_CRT_DT: "",
        SCH_USR_NAME: user.User_Id,
        ISACTIVE: "Y",
        MAX_QTY_CHK: false,
        CONS_REQ_CHK: workFlowData.some(
          (row) => row.RCM_CHECKS_STATUS === "red"
        ),
        ARC_VMI_CHK: workFlowData.some((row) => row.ARC_VMI === "TRUE"),
        DEPROP_CHK: workFlowData.some((row) => row.DOCUMENT_TYPE === "NP"),
        REF_CHK: workFlowData.some((row) => row.IS_REFURBISHABLE === "R"),
        BBPR: false,
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////////console.log("wfdata", workFlowData);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      console.log("token for intellibuy", headers);
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItem`,
          formDetails,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            setShow(false);
            setShowRCM(false);
            Swal.fire("", "Items Saved as Draft Successfully", "success");
            sessionStorage.setItem("INDENT_ID", indentno);
            //navigate("/SIS/ShoppingCart"); // Redirect to new page
            // switchToShoppingCart();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };
  //------------------------generate Shopping Cart No--------------------
  const handleGenerateShoppingCart = async () => {
    debugger;
    const SCQTY_CHK = workFlowData.some((row) => row.SC_QTY <= 0);
    if (SCQTY_CHK) {
      Swal.fire(
        "Alert",
        "Please ensure shopping cart quantity is greater than 0.",
        "error"
      );
      console.log(checkedUMCList, "checkedUMCList");
      return;
    }

    let UMCListMaxQty = [];
    let MAX_CHK = workFlowData.filter((row) =>
      calculateQuantity(row) < parseFloat(row.SC_QTY)
        ? "red"
        : "green" === "red"
    );
    MAX_CHK = MAX_CHK.filter((row) => !row.USER_REMARKS_MAXQTY);

    console.log(MAX_CHK, "MAXCHK");
    MAX_CHK.forEach((row) => {
      UMCListMaxQty.push(row.REQ_UMC_NO);
      if (UMCListMaxQty.length > 0) {
        UMCListMaxQty.join(", ");
      }
    });
    console.log(UMCListMaxQty, "checkedMAXUMCList");
    if (MAX_CHK.length > 0) {
      Swal.fire(
        "Alert",
        "Please fill max qty remarks against UMC NO (" + UMCListMaxQty + ")",
        "warning"
      );
      console.log(checkedUMCList, "checkedUMCList");
      return;
    }
    if (rcmmandatoryremarkschecks(workFlowData) === true) {
      Swal.fire(
        "Alert",
        "Please fill all remarks against UMC NO (" + checkedUMCList + ")",
        "warning"
      );
      console.log(checkedUMCList, "checkedUMCList");
      return;
    }

    setisLoading(true);
    showLoader();
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTER_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: user.User_Id,
        INDENT_MOD_BY: user.User_Id,
        INDENT_STATUS: "16",
        SCH_CART_NO: workFlowData[0].SCH_CART_NO,
        SCH_CRT_DT: "",
        SCH_USR_NAME: user.User_Id,
        ISACTIVE: "Y",
        MAX_QTY_CHK: workFlowData.some((row) =>
          calculateQuantity(row) < parseFloat(row.SC_QTY)
            ? "red"
            : "green" === "red"
        ),
        CONS_REQ_CHK: workFlowData.some(
          (row) => row.RCM_CHECKS_STATUS === "red"
        ),
        ARC_VMI_CHK: workFlowData.some((row) => row.ARC_VMI === "TRUE"),
        DEPROP_CHK: workFlowData.some((row) => row.DOCUMENT_TYPE === "NP"),
        REF_CHK: workFlowData.some((row) => row.IS_REFURBISHABLE === "R"),
        BBPR: false,
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////////console.log("wfdata", workFlowData);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      console.log("token for intellibuy", headers);
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItemAndGenrateSC`,
          formDetails,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            Swal.fire("", "Draft Shopping Cart Created", "success");
            sessionStorage.setItem("INDENT_ID", indentno);
            //navigate("/SIS/ShoppingCart"); // Redirect to new page
            switchToShoppingCart();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };

  const handleBack = () => {
    // navigate(`/SIS/PendingForApproval/${row.UMC_INDENT_ID}`, { state: { rowData: row } });
    navigate(`/SIS/SC_Approval`);
  };





  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}
          >
            <div className="card">

              <div className="card-body" style={{ maxWidth: "100%" }}>


                <div className="row mt-1">

                  <div className="col-md-4">
                    {" "}
                    <input style={{ border: "1px solid blue" }}
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>

                  <div className="col-8">
                    <button style={{ float: "right" }} className="btn btn-success" onClick={() => handleBack()}>  Back To Approval Page </button>
                  </div>
                </div>
                <div className="row mt-1"></div>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="tables table-responsive table-responsive-sm">
                    <table
                      className="table table-bordered tb"
                      id="tblIntelliBuy"
                    >
                      <thead className="table-primary">
                        <tr>
                          <th> Select</th>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> UMC Description </th>

                         < th>Indented Qty</th>
                          <th>Unit Price</th>
                          <th>Total Value of indent</th>
                          <th>Differential Qty (after sharing)</th>
                          <th>Total Value of differential qty</th>
                          <th>FOD Type</th>
                          <th>Doc Type</th>
                          <th>Purpose (TBM/CBM/Breakdown)</th>


                       
                          <th> Max Qty</th>
                          <th style={{ whiteSpace: "normal" }}>
                            {" "}
                            Requirement / Consumption
                          </th>
                          <th> VMI/ARC </th>
                          <th> Refurshibility</th>
                          <th> Deprop</th>
                        
                        
                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={row.UMC_INDENT_ID}
                            style={{
                              backgroundColor:
                                selectedRow === row.UMC_INDENT_ID
                                  ? "#ddd"
                                  : "white",
                            }}
                          >
                            <td>
                              <input
                                type="checkbox"
                                defaultChecked="false"
                                checked={selectedItemId === row.UMC_INDENT_ID}
                                onChange={() =>
                                  handleCheckboxChangeforSelect(
                                    row.UMC_INDENT_ID
                                  )
                                }
                              />
                            </td>

                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>
                            
                            
                            <td>{row.QTY} </td>
                            <td>{row.SCI_PRICE} </td>
                            <td>{row.TOTAL_VALUE_OF_INDENT} </td>
                            <td>{row.DIFFERENTIAL_QTY_AFTER_SHARING} </td>
                            <td>{row.T_VALUE_OF_DIFF_QTY} </td>
                            <td>{row.FOD_TYPE} </td>
                            <td>{row.DOCUMENT_TYPE_DESC} </td>
                            <td>{row.PROC_TYPE} </td>
                            <td>
                              <button
                                href=""
                                onClick={() => hanldeClick(row)}
                                className="btn"
                                style={{
                                  // backgroundColor: true === true ? "green" : "red",
                                  backgroundColor:
                                    calculateQuantity(row) <
                                    parseFloat(row.SC_QTY)
                                      ? "red"
                                      : "green",
                                  width: "70px",
                                  fontSize: "13px",
                                  color: "white",
                                }}
                              >
                                {calculateQuantity(row) < parseFloat(row.SC_QTY)
                                  ? "Fail"
                                  : "Passed"}
                              </button>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeRCMClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor: row.RCM_CHECKS_STATUS,
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.RCM_CHECKS_STATUS === "red"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeVMIClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.ARC_VMI === "FALSE" ||
                                        row.DOCUMENT_TYPE == "RO"
                                        ? "green"
                                        : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.ARC_VMI === "FALSE" ||
                                    row.DOCUMENT_TYPE == "RO"
                                    ? "Passed"
                                    : "Fail"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanlderefurshibilityClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.IS_REFURBISHABLE === "R"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.IS_REFURBISHABLE === "R"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeDepropClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.DOCUMENT_TYPE === "NP"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                >
                                  {" "}
                                  {row.DOCUMENT_TYPE === "NP"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>

                          </tr>
                        ))}{" "}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-10"></div>
                  <div className="col-2">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${currentPage === index + 1 ? "active" : ""
                            }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-8"></div>


                  <div className="col-2 d-flex justify-content-start">
                    {/* <button type="button" className="btn btn-success">
                      Raise Shopping Cart
                    </button> */}
                  </div>
                </div>
                {show && (
                  <MaxQtyModal
                    updateQtyData={workFlowData}
                    handleClose={hideModal}
                    handleCellChange={hanldeEdit}

                    OnSaveData={handleSaveMaxQtyData}
                  />
                )}
                {showrcm && (
                  <RequirmentConsumptionModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hideRCMModal}
                    handleCellChange={hanldeRCMEdit}

                    OnSaveData={handleSaveRCMData}
                  />
                )}
                {showrefurshibility && (
                  <RefurshibilityModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hiderefurshibilityModal}

                  />
                )}
                {showvmi && (
                  <VMIModal
                    VMIData={workFlowData}
                    handleClose={hideVMIModal}

                  />
                )}
                {showdeprop && (
                  <DepropModal
                    DepropData={workFlowData}
                    handleClose={hideDepropModal}

                  />
                )}
              </div>
            </div>

            {(
              <div className="panel">
                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    className="card-heading"
                    onClick={togglePanel}
                    style={{ backgroundColor: "#0d6efd", height: "34px" }}
                  >
                    <h6 className="mt-2" style={{ color: "white" }}>
                      &nbsp;{" "}
                      {open ? (
                        <i className="fa fa-minus text-blue"></i>
                      ) : (
                        <i className="fa fa-plus text-blue"></i>
                      )}
                      &nbsp; Indent Item Details
                    </h6>
                  </div>
                  <Collapse in={open}>
                    <div className="card-body">
                      {/* ----------Start Nav Tab---------- */}
                      <div className="col-12">
                        <Tabs
                          defaultActiveKey="SSA"
                          id="uncontrolled-tab-example"
                          className="my-tab position-relative"
                        >
                          <Tab
                            eventKey="SSA"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                Basic Data
                              </div>
                            }
                            className="act-clr"
                          >
                            <br />
                            <div className="row">
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Storage location
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {StorageLocation}{" "}
                                    </label>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Document type
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {DocumentType}{" "}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Purchase Group
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {" "}
                                      {PurchaseGroup}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Shopping Cart Qty
                                    </label>
                                  </div>
                                  <div class="col-md-2">
                                    <label className="form-label label-font">
                                      {scqty}
                                    </label>
                                  </div>
                                </div>
                                <div className="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      UOM
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {scuom}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Unit price of the item
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input
                                      className="form-control form-control-sm"
                                      value={priceperitem} // Bind input value to state variable

                                    ></input>
                                  </div>
                                </div>

                                {/* <div class="row">
                              <div class="col-md-6">
                                <label className="form-label label-font">
                                  Required qty.
                                </label>
                              </div>
                              <div class="col-md-6">
                                <label className="form-label label-font"> </label>
                              </div>
                            </div> */}

                                {/* <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Refurbish Spare Qty
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input className="form-control form-control-sm"></input>
                                  </div>
                                </div> */}
                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Material Consumption Plan
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                    >
                                      <option> --Select-- </option>
                                      <option Value="MTRCL">
                                        Material consumtion within 33 month of
                                        Import{" "}
                                      </option>
                                      <option Value="0"> Other</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Procurement Type
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {ProcurementType}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Spare Categorization
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {UnderConsumption}
                                    </label>
                                  </div>
                                </div>

                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Requirement Date
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      {RequirementDate}
                                    </label>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Installed Qty
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <input className="form-control form-control-sm"></input>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Ceilling Value
                                    </label>
                                  </div>
                                  <div className="col-md-6" >
                                    <input className="form-control form-control-sm">
                                    </input>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Rate
                                    </label>
                                  </div>
                                  <div class="col-md-3">
                                    <input className="form-control form-control-sm"></input>
                                  </div>
                                  <div class="col-md-2 d-flex justify-content-end">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                    >

                                      <option value="INR"> INR </option>
                                      {CurrencyList.map((jsonData, id) => (
                                        <option key={id} value={jsonData.FCURR}>
                                          {jsonData.FCURR}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>

                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-6">
                                    <label className="form-label label-font">
                                      Imported Plant And Machineary
                                    </label>
                                  </div>
                                  <div class="col-md-6">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                    >
                                      <option> --Select-- </option>
                                      <option Value="Y">Yes</option>
                                      <option Value="N">No</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>


                          </Tab>
                          <Tab
                            eventKey="CRA"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                Cost Assignment
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <label
                                style={{ fontSize: "16px", fontWeight: "bold" }}
                              >
                                You can see who bears the costs and, if
                                necessary, you can distribute the costs to
                                several cost centers.
                              </label>
                              <div className="row mt-3">
                                <div className="col-2">
                                  <label>Category</label>
                                </div>
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option> --Select-- </option>
                                    {CostCategoryList.map((jsonData, id) => (
                                      <option
                                        key={id}
                                        value={jsonData.CostCategoryList}
                                      >
                                        {jsonData.ACCT_ASGNMT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-2">
                                  <label>Cost Distribution</label>
                                </div>
                                <div className="col-3">
                                  <select className="form-control form-control-sm">
                                    <option> --Select-- </option>
                                    <option>Percentage </option>
                                    <option> Quantity </option>
                                    <option VALUE="V"> Value </option>
                                  </select>
                                </div>
                              </div>
                              <button
                                className="btn btn-primary mb-3"

                              >
                                Add New Row
                              </button>
                              <div className="tables table-responsive">
                                <table className="table table-bordered">
                                  <thead>
                                    <tr>
                                      <th>Line</th>
                                      <th>Percentage</th>
                                      <th>Assigned To</th>
                                      <th>Delete</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {rows.map((row, index) => (
                                      <tr key={row.id}>
                                        <td>{index + 1}</td>
                                        <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.Percentage}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.Line,
                                                "Percentage",
                                                e.target.value
                                              )
                                            }
                                          />
                                        </td>
                                        <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.Assigned}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.Line,
                                                "Assigned",
                                                e.target.value
                                              )
                                            }
                                          />
                                        </td>

                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>

                          </Tab>
                          <Tab
                            eventKey="IBCA"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                Documents
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-3">
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                  >
                                    <option> --Select-- </option>
                                    {DocumentsList.map((jsonData, id) => (
                                      <option key={id} value={jsonData.TEXT_ID}>
                                        {jsonData.TXT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-5">
                                  <textarea
                                    className="form-control form-control sm"
                                    rows={4}
                                    cols={40}
                                  />
                                </div>
                              </div>

                            </div>
                          </Tab>
                          <Tab
                            eventKey="SCA"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                Sustainibility
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row">
                              <div className="col-4">
                                <Form>
                                  <Form.Check type="checkbox" />
                                  {CsrCategoryList.map((option) => (
                                    <Form.Check
                                      key={option.VALUE}
                                      type="checkbox"
                                      label={option.LABEL}

                                    //checked={isChecked(option.VALUE)}
                                    />
                                  ))}
                                </Form>
                                <p>
                                  {selectedOptions.length} /{" "}
                                  {CsrCategoryList.length} selected
                                </p>
                              </div>
                              <div className="col-4">
                                <Form>
                                  {CsrSubCategoryList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroup"
                                      value={option.VALUE}
                                      checked={selectedOption === option.VALUE}
                                      onChange={() =>
                                        handleRadioChange(option.VALUE)
                                      }
                                    />
                                  ))}
                                </Form>
                                <p>Selected option: {selectedOption}</p>
                              </div>
                              <div className="col-4">
                                <Form>
                                  {CsrSubActivityList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroupAct"
                                      value={option.VALUE}
                                      checked={
                                        subactivityselectedOption ===
                                        option.VALUE
                                      }
                                      onChange={() =>
                                        handleSubActivityRadioChange(
                                          option.VALUE
                                        )
                                      }
                                    />
                                  ))}
                                </Form>
                                <p>
                                  Selected option: {subactivityselectedOption}
                                </p>
                              </div>
                            </div>
                          </Tab>
                          {openimport && (
                            <Tab
                              eventKey="CLA"
                              title={
                                <div style={{ padding: "0px 35px 0px 35px" }}>
                                  Classification
                                </div>
                              }
                              className="tab-txt-clr act-clr"
                            >
                              <div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      HSN No.
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <input className="form-control"></input>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Characteristics
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="Characteristics"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Composition
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="Composition"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      End use :
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="   End use :	"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Function
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      placeholder="Function"
                                    ></textarea>
                                  </div>
                                </div>
                              </div>
                            </Tab>
                          )}
                          <Tab
                            eventKey="DV"
                            title={
                              <div style={{ padding: "0px 10px 0px 10px" }}>
                                Source of supply/Service Agents
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row mt-2">
                              <div class="col-md-3">
                                <label className="form-label label-font">
                                  Desired Vendor
                                </label>
                              </div>
                              <div class="col-md-3">
                                <input className="form-control form-control-sm"></input>
                              </div>
                            </div>

                          </Tab>
                          <Tab
                            eventKey="NPM"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                MPN/Drawing
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row mt-2">
                              <div className="tables table-responsive">
                                <table className="table table-bordered">
                                  <thead>
                                    <tr>
                                      <th>Part No/Drawing</th>
                                      <th>Manufacturer</th>
                                      <th>Manufacturer Name</th>

                                    </tr>
                                  </thead>
                                  <tbody>

                                  </tbody>
                                </table>
                              </div>
                            </div>

                          </Tab>
                        </Tabs>
                      </div>
                      {/*----End Nav Tab-----*/}
                    </div>
                  </Collapse>
                </div>

              </div>
            )}

          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};
export default SC_AppDtlsView;

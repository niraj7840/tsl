import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
import { useSelector } from "react-redux";
import "./IntelliBuySystemChecks.css";
import MaxQtyModal from "../components/IntelliBuy/MaxQtyModal";
import SC_Name from "../components/IntelliBuy/SC_Name";
import RequirmentConsumptionModal from "../components/IntelliBuy/RequirmentConsumptionModal";
import RefurshibilityModal from "../components/IntelliBuy/RefurshibilityModal";
import VMIModal from "../components/IntelliBuy/VMIModal";
import DepropModal from "../components/IntelliBuy/DepropModal";
import ProgressBar from "../components/IntelliBuy/ProgressBar";
import axios from "axios";
import TabMenu from "../components/TabMenu/TabMenu";
import Swal from "sweetalert2";
import * as moment from "moment";
import { useNavigate } from "react-router-dom";

const IntelliBuyWorkflow = ({
  showLoader,
  hideLoader,
  switchToShoppingCart,
}) => {
  const navigate = useNavigate();
  const [showScModal,setShowScModal] = useState(false);
  const [SCName,setSCName] = useState("")
  const indentId = useSelector((state) =>
    state.indent ? state.indent.indentId : ""
  );
  const [state, setstate] = useState(false);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [workFlowData, setWorkFlowData] = useState([]);
  const [checkedUMCList, setcheckedUMCList] = useState("");
  const [checkedMAXUMCList, setcheckedMAXUMCList] = useState("");
  const [indentno, setIndentNo] = React.useState(indentId);
  const [indentstatus, setIndentStatus] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [show, setShow] = useState(false);
  const [showrcm, setShowRCM] = useState(false);
  const [showrefurshibility, setShowRefurshibility] = useState(false);
  const [showvmi, setShowVMI] = useState(false);
  const [showdeprop, setShowDeprop] = useState(false);
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRow, setSelectedRow] = useState(null);
  const [RCMstatus, setRCMStatus] = useState("");
  const [VMIstatus, setVMIStatus] = useState({});
  const [selectedDatercmdt, setSelectedDateRCMDate] = useState("");
  const [firstEffectComplete, setFirstEffectComplete] = useState(false);
  const [indicator, setIndicator] = useState("");
  const [savebuttonname, setSaveButtonName] = useState("Create Shopping Cart");
  const [isShown, setIsShown] = useState(false);
  const [fyear, setFyear] = useState("");
  const [committedExpenditure, setCommittedExpenditure] = useState("");
  const [spareBudget, setSpareBudget] = useState("");
  const [showBudgetProgressBar, setShowBudgetProgressBar]=useState(true);
  const [isIndentor, setIsIndentor]=useState(false);
  //const INDENT_ID = sessionStorage.getItem("INDENT_ID");
  const [progress, setProgress] = useState();
  const itemsPerPage = 5;
  const [scName, setScName]=useState("");
  const [isDisabled, setIsDisabled] = useState(false);
  ///-------------MaxQty Modal---------//
  const MaxQtyStatus = workFlowData.some((item) => item.QTY > item.ALLOWEDQTY);
  const hanldeDelete = (rowno) => {
    debugger
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === rowno ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const getUpdateQty = () => {
    setWorkFlowData(workFlowData);
  };
  const hanldeClick = (selectedRec) => {
    getUpdateQty();
    setShow(true);
  };

  const hideModal = () => {
    setShow(false);
  };
  const handleSaveMaxQtyData = () => {
    handleSaveAsDraft();
  };
  ///-------------Refurshibility Modal---------//

  const hanlderefurshibilityClick = (selectedRec) => {
    getrefurshibility();
    setShowRefurshibility(true);
  };

  const hiderefurshibilityModal = () => {
    setShowRefurshibility(false);
  };

  const getrefurshibility = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------RequirmentConsumption Modal---------//

  const handleSaveRCMData = () => {

    const filteredData = [];

    for (let item of workFlowData) {
      const ChangedReqDT = new Date(moment(item.REQUIREMENT_DATE).format("YYYY-MM-DD")).getTime();
      const ChangedConsumDT = new Date(moment(item.CONSUMP_DT).format("YYYY-MM-DD")).getTime();

      if (ChangedReqDT > ChangedConsumDT) {
        filteredData.push(item.REQ_UMC_NO);
      }
    }

    for (let item of workFlowData) {
      const ChangedReqDT = new Date(moment(item.REQUIREMENT_DATE).format("YYYY-MM-DD")).getTime();
      const ChangedConsumDT = new Date(moment(item.CONSUMP_DT).format("YYYY-MM-DD")).getTime();

      if (ChangedReqDT > ChangedConsumDT) {
        Swal.fire("Alert", `Consumption date cannot be less than Requirement date.<br> The umcs are: <b>${filteredData}`, "error");
        return;
      }
    }
    handleSaveAsDraft();
  };

  const calculateQuantity = (row) => {
    const maxQty = parseFloat(row.MaxQty) || 0;
    const pipelineQty = parseFloat(row.PipelineQty) || 0;
    const refurQty = parseFloat(row.RefurQty) || 0;
    const chargeQty = parseFloat(row.ChargeQty) || 0;

    let quantity = maxQty - (pipelineQty + refurQty + chargeQty);
    if (quantity < 0) {
      quantity = 0.0;
    }
    return quantity.toFixed(3);
  };

  

  // Function to format date as dd-mm-yyyy
  const formatDate = (dateString) => {
    const dateObj = new Date(dateString);
    const day = String(dateObj.getDate()).padStart(2, "0");
    const month = String(dateObj.getMonth() + 1).padStart(2, "0"); // January is 0!
    const year = dateObj.getFullYear();

    return `${day}-${month}-${year}`;
  };
  const formatDateInput = (dateStr) => {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    } else {
      return dateStr;
    }
  };

  const hanldeRCMEdit = (
    index,
    field,
    SysReqDTT,
    SysConsumDTT,
    ChangeReqDTT,
    changeConsumDTT,
    userjustification
  ) => {
 
    var Retrncolor = "green";
    var setMessage = "";
    const newData = [...workFlowData];
    console.log(newData, "newData");
    const strSysTM = new Date(moment(SysReqDTT).format("YYYY-MM-DD"));
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(moment(SysReqDTT).format("YYYY-MM-DD")).getTime();
    const SysConsumDT = new Date(
      moment(SysConsumDTT).format("YYYY-MM-DD")
    ).getTime();
    const ChangeReqDT = new Date(
      moment(ChangeReqDTT).format("YYYY-MM-DD")
    ).getTime();
    const changeConsumDT = new Date(
      moment(changeConsumDTT).format("YYYY-MM-DD")
    ).getTime();

    if (ChangeReqDT > changeConsumDT) {
      Swal.fire("Alert", `Consumption date cannot be less than Requirement date.`, "error");
      return;
    }

    const threeMonths = 3 * 30 * 24 * 60 * 60 * 1000; // 3 months in milliseconds
    const sixMonths = 6 * 30 * 24 * 60 * 60 * 1000; // 6 months in milliseconds

    const Condition1 = SysReqDT === ChangeReqDT;
    const Condition2 = SysReqDT > ChangeReqDT;
    const Condition3 = SysReqDT < ChangeReqDT;
    const Condition4 = SysConsumDT === changeConsumDT;
    const Condition5 = SysConsumDT > changeConsumDT;
    const Condition6 = SysConsumDT < changeConsumDT;

    if (Condition1 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition4 && Condition3) {
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition4 && Condition2) {
      setMessage = "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition1 && Condition5) {
      //setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
      //setIndicator("red");
      //Retrncolor = "red";
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition2 || Condition5) {
      if(Condition2 && Condition5)
        {
          setMessage="Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
          setIndicator("red");
          Retrncolor = "red";
        }
      else if (Condition2) {
        setMessage = "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval."
        setIndicator("red");
        Retrncolor = "red";
      } else if (Condition5) {
        //setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
        Retrncolor = "green";
        setIndicator("green");
      }
    } else if (Condition1 && Condition6) {
      setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    }
    else if (Condition3 && Condition6) {
      setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
      setIndicator("red");
      Retrncolor = "red";
    }

    if (ChangeReqDT === SysReqDT && changeConsumDT > SysConsumDT + sixMonths) {
      Retrncolor = "red";
      setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
    } if ((ChangeReqDT - SysReqDT) >= threeMonths && changeConsumDT === SysConsumDT) {
      Retrncolor = "yellow";
      setMessage = "Since User requirement date - system requirement date>=3 month, therfore you are requested to raise shopping cart at latter stage";
    }

    newData[index]["REQUIREMENT_DATE"] =
      moment(ChangeReqDTT).format("DD-MMM-YYYY");
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    //moment(changeConsumDTT).format("DD-MMM-YYYY");
    newData[index]["RCM_CHECKS_STATUS"] = Retrncolor;
    newData[index]["RCM_SmartNudges"] = setMessage;
    newData[index]["RCM_STATUS"] = (Retrncolor==="red" ? "false" : "true");
    newData[index]["USER_REMARKS_RCM"] = userjustification;
    setWorkFlowData(newData);
    console.log(newData, "");
  };

  const hanldeRCMChecks = (
    index,
    field,
    SysReqDTT,
    SysConsumDTT,
    ChangeReqDTT,
    changeConsumDTT
  ) => {
    var Retrncolor = "green";
    var setMessage = "";
    const SyReqDTT = SysReqDTT;
    const newData = [...workFlowData];
    //console.log(newData,"newData");
    const strSysTM = new Date(moment(SysReqDTT).format("YYYY-MM-DD"));
    strSysTM.setMonth(strSysTM.getMonth() + 3);
    const SysReqDT = new Date(moment(SysReqDTT).format("YYYY-MM-DD")).getTime();
    const SysConsumDT = new Date(
      moment(SysConsumDTT).format("YYYY-MM-DD")
    ).getTime();
    const ChangeReqDT = new Date(
      moment(ChangeReqDTT).format("YYYY-MM-DD")
    ).getTime();
    const changeConsumDT = new Date(
      moment(changeConsumDTT).format("YYYY-MM-DD")
    ).getTime();

    const threeMonths = 3 * 30 * 24 * 60 * 60 * 1000; // 3 months in milliseconds
    const sixMonths = 6 * 30 * 24 * 60 * 60 * 1000; // 6 months in milliseconds

    const Condition1 = SysReqDT === ChangeReqDT;
    const Condition2 = SysReqDT > ChangeReqDT;
    const Condition3 = SysReqDT < ChangeReqDT;
    const Condition4 = SysConsumDT === changeConsumDT;
    const Condition5 = SysConsumDT > changeConsumDT;
    const Condition6 = SysConsumDT < changeConsumDT;

    if (Condition1 && Condition4) {
      setIndicator("green");
      Retrncolor = "green";
    } else if (Condition4 && Condition3) {
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition4 && Condition2) {
      setMessage = "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    } else if (Condition1 && Condition5) {
      //setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
      //setIndicator("red");
      //Retrncolor = "red";
      Retrncolor = "green";
      setIndicator("green");
    } else if (Condition2 || Condition5) {
      if(Condition2 && Condition5)
        {
          setMessage="Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
          setIndicator("red");
          Retrncolor = "red";
        }
      else if (Condition2) {
        setMessage = "Please amend your requirement date as per the requirement date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval."
        setIndicator("red");
        Retrncolor = "red";
      } else if (Condition5) {
        //setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
        Retrncolor = "green";
        setIndicator("green");
      }
    } else if (Condition1 && Condition6) {
      setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";

      setIndicator("red");
      Retrncolor = "red";
    }
    else if (Condition3 && Condition6) {
      setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
      setIndicator("red");
      Retrncolor = "red";
    }

    if (ChangeReqDT === SysReqDT && changeConsumDT > SysConsumDT + sixMonths) {
      Retrncolor = "red";
      setMessage = "Please amend your consumption date as per the consumption date recommended by the system; however if you want to proceed this indent/ shopping cart will be escalated to Area Chief for approval.";
    } if ((ChangeReqDT - SysReqDT) >= threeMonths && changeConsumDT === SysConsumDT) {
      Retrncolor = "yellow";
      setMessage = "Since User requirement date - system requirement date>=3 month, therfore you are requested to raise shopping cart at latter stage";
    }

    newData[index]["REQUIREMENT_DATE"] =
      moment(ChangeReqDTT).format("DD-MMM-YYYY");
    newData[index]["CONSUMP_DT"] = changeConsumDTT;
    // moment(changeConsumDTT).format("DD-MMM-YYYY");
    newData[index]["RCM_CHECKS_STATUS"] = Retrncolor;
    newData[index]["RCM_STATUS"] = (Retrncolor==="red" ? "false" : "true");
    newData[index]["RCM_SmartNudges"] = setMessage;
    newData[index]["MAXQTY_CHECKS_STATUS"] = Retrncolor;
    setWorkFlowData(newData);
    setFirstEffectComplete(false);
  };

  const hanldeRCMClick = (selectedRec) => {
    getRCM();
    setShowRCM(true);
  };
  const hideRCMModal = () => {
    setShowRCM(false);
  };
  const getRCM = () => {
    setWorkFlowData(workFlowData);
  };

  ///-------------VMI-----------//

  const hanldeVMIClick = (selectedRec) => {
    getVMI();
    setShowVMI(true);
  };

  const hideVMIModal = () => {
    setShowVMI(false);
  };

  const getVMI = () => {
    setWorkFlowData(workFlowData);
  };

  ////---------------Deprop------------///
  const hanldeDepropClick = (selectedRec) => {
    getDeprop();
    setShowDeprop(true);
    ////console.log(workFlowData, "workFlowData");
  };

  const hideDepropModal = () => {
    setShowDeprop(false);
  };

  const getDeprop = () => {
    setWorkFlowData(workFlowData);
  };

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (indentno) => {
    setisLoading(true);
    showLoader();
    if (indentno !== "") {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/IntelliBuyChecks/GetIntelliBuyChecksDetails?IndentId=${indentno}`,
          { headers }
        )
        .then((response) => {
          const data = response.data;
          setisLoading(false);
          hideLoader();
          console.log(data.jsonData, "Data");
          if (data.jsonData.length > 0) {
            setWorkFlowData(data.jsonData);
            setProgress(data.jsonData[0].DeptBudgetConsumption);
            if(!(data.jsonData[0].SC_NAME)){
              setSCName(data.jsonData[0].REQ_UMC_DESC);
            }else{
              setSCName(data.jsonData[0].SC_NAME);
            }
            console.log("user loggedIn", user.User_Id)
            console.log("indentor user id", data.jsonData[0].INDENT_CRT_BY)
            if(user.User_Id===data.jsonData[0].INDENT_CRT_BY)
            {
              setIsIndentor(true);
            }
        
            setFyear(data.jsonData[0].FY_YEAR);
            setSpareBudget(data.jsonData[0].SPAREBUDGET);
            setCommittedExpenditure(data.jsonData[0].COMMITTEDEXPENDITURE);
            if(data.jsonData[0].budgetCountOfDept==="0")
            {
              setShowBudgetProgressBar(false)
            }
            setFirstEffectComplete(true);
            if (data.jsonData[0].SCH_CART_NO.length > 0) {
              setSaveButtonName("Update Shopping Cart");
            } else {
              setSaveButtonName("Create Shopping Cart");
            }
            const Status = data.jsonData[0].INDENT_CURRENT_STATUS_CODE;
            if (Status >= 39 || user.User_Id!==data.jsonData[0].INDENT_CRT_BY) {
             setIsDisabled(true);
            }
          } else {
            Swal.fire("", "No Data Found", "info");
            setWorkFlowData([]);
            setIndentStatus("");
            setIndentDept("");
            setisLoading(false);
            hideLoader();
          }

          ////////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          ////console.log(error);
          setisLoading(false);
          hideLoader();
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const filteredData = workFlowData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  //////console.log(totalPages, "Total page");
  //////console.log(filteredData, "filteredData");
  // const currentData = filteredData.slice(
  //   (currentPage - 1) * itemsPerPage,

  //   currentPage * itemsPerPage
  // );
  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };
  const regex = /^[a-zA-Z\s]*\d*\.?\d*$/;
  const hanldeEdit = (index, field, value) => {
    
    const newData = [...workFlowData];
    if (field == "USER_REMARKS_MAXQTY") {
     // if (regex.test(value)) {
        newData[index][field] = value;
        setWorkFlowData(newData);
     // }
    } else if (field == "SC_QTY") {
      if (/^\d*\.?\d*$/.test(value)) {
        const oldscvalue =
          parseFloat(newData[index]["QTY"]) -
          newData[index]["TOTAL_SAP_DOC_QTY"];
        console.log(newData[index][field], "old value");
        console.log(value, "new value");
        if (parseFloat(oldscvalue) < parseFloat(value)) {
          Swal.fire(
            "Alert",
            "Shopping Cart qty not greater than  " + oldscvalue + "",
            "warning"
          );
          value = oldscvalue;
        }
        if (parseFloat(value) === 0) {
          Swal.fire(
            "Alert",
            "if material is not required, kindly delete from the list.",
            "warning"
          );
          value = oldscvalue;
        }
       const FlagStatus= calculateQuantity(workFlowData[index]) < parseFloat(value)
          ? "false"
          : "true";
        newData[index]["MAXQTY_STATUS"]=FlagStatus;
        newData[index][field] = value;
        setWorkFlowData(newData);
        
      }
    }
  };

  // const handleDeleteRow = (UMC_INDENT_ID) => {
  //   const newData = workFlowData.filter(
  //     (item) => item.UMC_INDENT_ID !== UMC_INDENT_ID
  //   );
  //   setWorkFlowData(newData);
  //   const totalPage = Math.ceil(newData.length / itemsPerPage);
  //   setCurrentPage(totalPage);
  // };
  const handleDeleteRow = (UMC_INDENT_ID) => {
    const newData = workFlowData.map((item) =>
      item.UMC_INDENT_ID === UMC_INDENT_ID ? { ...item, ISACTIVE: "N" } : item
    );
    setWorkFlowData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  useEffect(() => {
    console.log("use Effect Called");
    if (indentId !== "") {
      hanldeSearchClick(indentId);
    }
  }, [indentId]);

  useEffect(() => {
    console.log("use Effect Called 2");
    ////console.log(firstEffectComplete,"firstEffectComplete") ;
    if (firstEffectComplete) {
      ////console.log(workFlowData,"data work flow") ;
      if (workFlowData.length > 0) {
        workFlowData.forEach((row, index) => {
          ////console.log(index,"index") ;
          hanldeRCMChecks(
            index,
            "",
            row.ReqDate,
            row.ConsDate,
            row.REQUIREMENT_DATE,
            row.CONSUMP_DT
          );
      
        });
        rcmmandatoryremarkschecks(workFlowData);
      }
    }
  }, [firstEffectComplete, workFlowData]);

  const rcmmandatoryremarkschecks = (workFlowData) => {
    let UMCList = [""];
    setcheckedUMCList('');
    var umcliststring;
    const REF_CHK = workFlowData.some(
      (row) => row.RCM_CHECKS_STATUS === "red" && row.USER_REMARKS_RCM === ""  && row.ISACTIVE === "Y"
    );
    workFlowData.forEach((row) => {
      if (row.RCM_CHECKS_STATUS === "red" && row.USER_REMARKS_RCM === ""  && row.ISACTIVE === "Y") {
        UMCList.push(row.REQ_UMC_NO);
      }
      if (UMCList.length > 0) {
        UMCList.join(", ");
        //console.log(`Fill all remarks against ID (${idListString})`);
        // Optionally, set a state to display a message in your UI
      }
    });
    //setcheckedUMCList(UMCList.join(", "));
    console.log(checkedUMCList, "umclist");
    return REF_CHK;
  };  

  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {

    let SCQTY_CHK = workFlowData.filter((row) => row.SC_QTY === "");
    if (SCQTY_CHK.length > 0) {
      Swal.fire("Alert", "Shopping cart quantity can not be blank.", "error");
      return;
    }
    setisLoading(true);
    showLoader();
    let MAXQTYCHKS=workFlowData.some((row) =>
    (calculateQuantity(row) < parseFloat(row.SC_QTY)
      ? "red"
      : "green" === "red") && row.ISACTIVE==="Y"
    );
    let RCMCHK=workFlowData.some(
      (row) => row.RCM_CHECKS_STATUS === "red" && row.ISACTIVE==="Y"
    );
   let ARCVMICHK= workFlowData.some((row) => (row.ARC_VMI === "FALSE" ||  row.DOCUMENT_TYPE == "RO") && row.ISACTIVE==="Y");
   let DEPROPCHK= workFlowData.some((row) => ( row.DOCUMENT_TYPE !== "NP") && row.ISACTIVE==="Y");
   let REFCHK= workFlowData.some((row) => row.IS_REFURBISHABLE !== "R" && row.ISACTIVE==="Y");
if (MAXQTYCHKS===true){MAXQTYCHKS=false;} else{MAXQTYCHKS=true;}
if (RCMCHK===true){RCMCHK=false;} else{RCMCHK=true;}
if (ARCVMICHK===false){ARCVMICHK=false;} else{ARCVMICHK=true;}
if (DEPROPCHK===false){DEPROPCHK=false;} else{DEPROPCHK=true;}
if (REFCHK===false){REFCHK=false;} else{REFCHK=true;}

    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTOR_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: user.User_Id,
        INDENT_MOD_BY: user.User_Id,
        INDENT_STATUS: "25",
        SCH_CART_NO: workFlowData[0].SCH_CART_NO,
        SCH_CRT_DT: "",
        SCH_USR_NAME: user.User_Id,
        ISACTIVE: "Y",
        MAX_QTY_CHK: MAXQTYCHKS,
        CONS_REQ_CHK: RCMCHK,
        ARC_VMI_CHK:ARCVMICHK , 
        DEPROP_CHK: DEPROPCHK,
        REF_CHK: REFCHK,
        BBPR: false,
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////////console.log("wfdata", workFlowData);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      console.log("token for intellibuy", headers);
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItem`,
          formDetails,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            setShow(false);
            setShowRCM(false);
            Swal.fire("", "Items Saved as Draft Successfully", "success");
            sessionStorage.setItem("INDENT_ID", indentno);
            //navigate("/SIS/ShoppingCart"); // Redirect to new page
            // switchToShoppingCart();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };
  //------------------------generate Shopping Cart No--------------------
  const handleSubmitScName= async()=>{
   await handleGenerateShoppingCart()
    setisLoading(true);
    showLoader();
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      console.log("token for intellibuy", headers);
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/UpdateShoppinCartName?indentNo=${indentId}&scName=${SCName}`, { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            setisLoading(false);
            hideLoader();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
   // handleGenerateShoppingCart()
  }
  const hideScModal=()=>
    {
      setShowScModal(false);
    }
    const setShoppinCartModal=()=>{
      setShowScModal(true);
    }
  const handleGenerateShoppingCart = async () => {
    const filteredData = [];
    const workFlowDatafilterData= workFlowData.filter((item) => item.ISACTIVE === "Y");
    for (let item of workFlowDatafilterData) {
      const ChangedReqDT = new Date(moment(item.REQUIREMENT_DATE).format("YYYY-MM-DD")).getTime();
      const ChangedConsumDT = new Date(moment(item.CONSUMP_DT).format("YYYY-MM-DD")).getTime();

      if (ChangedReqDT > ChangedConsumDT) {
        filteredData.push(item.REQ_UMC_NO);
      }
    }
     
    for (let item of workFlowDatafilterData) {
      const ChangedReqDT = new Date(moment(item.REQUIREMENT_DATE).format("YYYY-MM-DD")).getTime();
      const ChangedConsumDT = new Date(moment(item.CONSUMP_DT).format("YYYY-MM-DD")).getTime();

      if (ChangedReqDT > ChangedConsumDT) {
        Swal.fire("Alert", `Consumption date cannot be less than Requirement date.<br> The umcs are: <b>${filteredData}`, "error");
        return;
      }
    }
    const SCQTY_CHK = workFlowData.some((row) => row.SC_QTY <= 0 && row.ISACTIVE === "Y");
    if (SCQTY_CHK) {
      Swal.fire(
        "Alert",
        "Please ensure shopping cart quantity is greater than 0.",
        "error"
      );
      console.log(checkedUMCList, "checkedUMCList");
      return;
    }

    let UMCListMaxQty = [];
    let MAX_CHK = workFlowData.filter((row) =>
      calculateQuantity(row) < parseFloat(row.SC_QTY)
        ? "red"
        : "green" === "red"
    );
    MAX_CHK = MAX_CHK.filter((row) => !row.USER_REMARKS_MAXQTY && row.ISACTIVE==="Y");

    console.log(MAX_CHK, "MAXCHK");
    MAX_CHK.forEach((row) => {
      UMCListMaxQty.push(row.REQ_UMC_NO);
      if (UMCListMaxQty.length > 0) {
        UMCListMaxQty.join(", ");
      }
    });
    console.log(UMCListMaxQty, "checkedMAXUMCList");
    if (MAX_CHK.length > 0) {
      Swal.fire(
        "Alert",
        "Please fill max qty remarks against UMC NO (" + UMCListMaxQty + ")",
        "warning"
      );
      console.log(checkedUMCList, "checkedUMCList");
      return;
    }
    if (rcmmandatoryremarkschecks(workFlowData) === true) {
      let UMCLists ='';
      workFlowData.forEach((row) => {
        if (row.RCM_CHECKS_STATUS === "red" && row.USER_REMARKS_RCM === ""  && row.ISACTIVE === "Y") {
          UMCLists +=row.REQ_UMC_NO +"  ";
        }
      });
      Swal.fire(
        "Alert",
        "Please fill all remarks against UMC NO (" + UMCLists + ")",
        "warning"
      );
      console.log(checkedUMCList, "checkedUMCList");
      return;
    }

    setisLoading(true);
    showLoader();
    let MAXQTYCHKS=workFlowData.some((row) =>
    (calculateQuantity(row) < parseFloat(row.SC_QTY)
      ? "red"
      : "green" === "red") && row.ISACTIVE==="Y"
    );
    let RCMCHK=workFlowData.some(
      (row) => row.RCM_CHECKS_STATUS === "red" && row.ISACTIVE==="Y"
    );
   let ARCVMICHK= workFlowData.some((row) => (row.ARC_VMI === "FALSE" ||  row.DOCUMENT_TYPE == "RO") && row.ISACTIVE==="Y");
   let DEPROPCHK= workFlowData.some((row) =>  row.DOCUMENT_TYPE !== "NP" && row.ISACTIVE==="Y");
   let REFCHK= workFlowData.some((row) => row.IS_REFURBISHABLE !== "R"&& row.ISACTIVE==="Y");
if (MAXQTYCHKS===true){MAXQTYCHKS=false;} else{MAXQTYCHKS=true;}
if (RCMCHK===true){RCMCHK=false;} else{RCMCHK=true;}
if (ARCVMICHK===false){ARCVMICHK=false;} else{ARCVMICHK=true;}
if (DEPROPCHK===false){DEPROPCHK=false;} else{DEPROPCHK=true;}
if (REFCHK===false){REFCHK=false;} else{REFCHK=true;}
    var formDetails = {
      ObjIntelliBuyChecksHeader: {
        INDENT_ID: indentno,
        INDENTER_LOC: workFlowData[0].INDENTER_LOC,
        INDENTOR_PLANT: workFlowData[0].INDENTOR_PLANT,
        INDENTER_DEPT: workFlowData[0].INDENTER_DEPT,
        INDENT_DESC: workFlowData[0].INDENT_DESC,
        INDENT_REMARKS: workFlowData[0].INDENT_REMARKS,
        INDENT_CRT_BY: user.User_Id,
        INDENT_MOD_BY: user.User_Id,
        INDENT_STATUS: "16",
        SCH_CART_NO: workFlowData[0].SCH_CART_NO,
        SCH_CRT_DT: "",
        SCH_USR_NAME: user.User_Id,
        MAX_QTY_CHK: MAXQTYCHKS,
        CONS_REQ_CHK: RCMCHK,
        ARC_VMI_CHK:ARCVMICHK , 
        DEPROP_CHK: DEPROPCHK,
        REF_CHK: REFCHK,
        BBPR: false,
        // MAX_QTY_CHK: workFlowData.some((row) =>
        //   calculateQuantity(row) < parseFloat(row.SC_QTY)
        //     ? "red"
        //     : "green" === "green"
        // ),
        // CONS_REQ_CHK: workFlowData.some(
        //   (row) => row.RCM_CHECKS_STATUS === "red"
        // ),
        // ARC_VMI_CHK: workFlowData.some((row) => row.ARC_VMI === "TRUE"),
        // DEPROP_CHK: workFlowData.some((row) => row.DOCUMENT_TYPE === "NP"),
        // REF_CHK: workFlowData.some((row) => row.IS_REFURBISHABLE === "R"),
        // BBPR: false,
      },
      ObjIntelliBuyIndentDetails: workFlowData,
      IsDraft: "Y",
    };
    ////////console.log("wfdata", workFlowData);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      console.log("token for intellibuy", headers);
      axios
        .post(
          `${BaseUrl}api/IntelliBuyChecks/InsertIntelliBuyCheckItemAndGenrateSC`,
          formDetails,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            // fetchSavedDraftData();
            setisLoading(false);
            hideLoader();
            Swal.fire("", "Draft Shopping Cart Created", "success");
            sessionStorage.setItem("INDENT_ID", indentno);
            //navigate("/SIS/ShoppingCart"); // Redirect to new page
            switchToShoppingCart();
          } else {
            hideLoader();
          }
        });
    } catch (error) {
      hideLoader();
      setisLoading(false);
    }
  };
  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "8px", maxWidth: "95%" }}
          >
            <div className="card">
              <div className="card-body" style={{ maxWidth: "100%" }}>
                {/* <div className="row">
                  <div className="col-md-1">
                    <label> Indent Number:</label>
                  </div>
                  <div className="col-md-3">
                    <input
                      id="indentno"
                      name="indentno"
                      value={indentno}
                      onChange={(e) => setIndentNo(e.target.value)}
                      className="form-control"
                      type="text"
                    />
                  </div>
                  <div className="col-md-1">
                    <button
                      onClick={() => hanldeSearchClick(indentno)}
                      className=" btn btn-warning"
                      style={{ fontSize: "13px" }}
                    >
                      <i class="fas fa-filter"></i>
                      Search
                    </button>
                  </div>
                  <div className="col-md-3">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Department:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {" "}
                      {indentdept}
                    </label>
                  </div>

                  <div className="col-md-3">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                      }}
                    >
                      {" "}
                      Status:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {indentstatus}
                    </label>
                  </div>
                </div> */}
                <div className="row">
                  <div className="col-md-4">
                    {" "}
                    <input
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>
                  <div className="col-md-5"></div>
                  {showBudgetProgressBar && <div
                    className="col-md-3"
                    style={{ border: "1px solid green" }}
                  >
                    <div className="row">
                      <label
                        className="form-label label-font"
                        style={{ textAlign: "center" }}
                      >
                        {" "}
                        Dept Budget Consumption in %{" "}
                      </label>
                    </div>
                    <div
                      className="row"
                      onMouseEnter={() => setIsShown(true)}
                      onMouseLeave={() => setIsShown(false)}
                    >
                      <div className="app-container">
                        <ProgressBar
                          backgroundColor={{ color: "black" }}
                          percentage={progress}
                        />
                      </div>
                      {isShown && (
                        <div
                          className="form-control"
                          style={{
                            position: "absolute",
                            maxWidth: "390px",
                            textAlign: "center",
                          }}
                        >
                          <h6>
                            FY Year{" "}
                            <span class="badge bg-primary">{fyear}</span>
                          </h6>
                          <h6>
                            Spare Budget{" "}
                            <span class="badge bg-primary">{spareBudget}</span>
                          </h6>
                          <h6>
                            Committed Expenditure{" "}
                            <span class="badge bg-primary">
                              {committedExpenditure}
                            </span>
                          </h6>
                          {/* <table
                        className="table table-bordered tb"
                      style={{position:"absolute",maxWidth:'150px'}}
                      >
                        <thead className="table-primary">
                          <tr>
                            <th> FY Year</th>
                            <th> Spare Budget</th>
                            <th> Committed Expenditure </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>{fyear}</td>
                            <td>{spareBudget}</td>
                            <td>{committedExpenditure}</td>
                          </tr>
                        </tbody>
                      </table> */}
                        </div>
                      )}
                      <label
                        className="form-label label-font"
                        style={{ textAlign: "center" }}
                      ></label>
                    </div>
                    {/* <div className="row">
                      <div className="col-md-6 d-flex justify-content-end">
                        <label className="form-label label-font">Budget</label>
                        <label className="form-label label-font">
                          {" "}
                          &nbsp; 22562
                        </label>
                      </div>
                      <div className="col-md-6 d-flex justify-content-start">
                        <label className="form-label label-font">Actual</label>
                        <label className="form-label label-font">
                          {" "}
                          &nbsp; 13758
                        </label>
                      </div>
                    </div> */}
                  </div>}
                </div>
                <br></br>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="tables table-responsive table-responsive-sm">
                    <table
                      className="table table-bordered tb"
                      id="tblIntelliBuy"
                    >
                      <thead className="table-primary">
                        <tr>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> Description </th>
                          <th> BGG</th>
                          {/* <th> Nature of SKU</th> */}
                          <th> Refurbishable</th>
                          {/* <th> Proprietry</th> */}
                          <th style={{ whiteSpace: "nowrap" }}> Required On</th>
                          <th> UOM</th>
                          <th>Indent Qty</th>
                          <th> SC Qty</th>
                          {/* <th> Rate Per Item</th>
                        <th> Price</th>
                        <th> Plant</th> */}
                          <th> Max Qty</th>
                          <th style={{ whiteSpace: "normal" }}>
                            {" "}
                            Requirement / Consumption
                          </th>
                          <th> VMI/ARC </th>
                          <th> Refurshibility</th>
                          <th> Deprop</th>

                          <th> </th>
                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={row.UMC_INDENT_ID}
                            style={{
                              backgroundColor:
                                selectedRow === row.UMC_INDENT_ID
                                  ? "#ddd"
                                  : "white",
                            }}
                          >
                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>
                            <td>{row.REQ_UMC_BGG}</td>
                            {/* <td></td> */}
                            <td>
                              {row.IS_REFURBISHABLE === "R"
                                ? "Refurbishable"
                                : row.IS_REFURBISHABLE === "N"
                                  ? "Non Refurbishable"
                                  : row.IS_REFURBISHABLE}
                            </td>
                            {/* <td></td> */}
                            <td>{row.IND_REQUIREMENT_DATE}</td>
                            <td>{row.UOM}</td>
                            <td>{row.QTY}</td>
                            <td>{row.SC_QTY}</td>
                            {/* <td>{row.PRICE_PER_ITEM}</td>
                          <td>{calculatePrice(row.PRICE_PER_ITEM, row.QTY)}</td>
                          <td>{row.INDENTOR_PLANT}</td> */}
                            <td>
                              <button
                                href=""
                                onClick={() => hanldeClick(row)}
                                className="btn"
                                style={{
                                  // backgroundColor: true === true ? "green" : "red",
                                  backgroundColor:
                                    calculateQuantity(row) <
                                      parseFloat(row.SC_QTY)
                                      ? "red"
                                      : "green",
                                  width: "70px",
                                  fontSize: "13px",
                                  color: "white",
                                }}
                                //disabled={!isIndentor}
                              >
                                {calculateQuantity(row) < parseFloat(row.SC_QTY)
                                  ? "Fail"
                                  : "Passed"}
                              </button>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeRCMClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor: (row.RCM_CHECKS_STATUS === "yellow" ? "green" : row.RCM_CHECKS_STATUS),
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                  //disabled={!isIndentor}
                                >
                                  {" "}

                                  {row.RCM_CHECKS_STATUS === "red" ? "Fail" : (row.RCM_CHECKS_STATUS === "green" || row.RCM_CHECKS_STATUS === "yellow") ? "Passed" : ""}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeVMIClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.ARC_VMI === "FALSE" ||
                                        row.DOCUMENT_TYPE == "RO"
                                        ? "green"
                                        : "red",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                  // disabled={!isIndentor}
                                >
                                  {" "}
                                  {row.ARC_VMI === "FALSE" ||
                                    row.DOCUMENT_TYPE == "RO"
                                    ? "Passed"
                                    : "Fail"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanlderefurshibilityClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.IS_REFURBISHABLE === "R"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                  //disabled={!isIndentor}
                                >
                                  {" "}
                                  {row.IS_REFURBISHABLE === "R"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <div>
                                <button
                                  href=""
                                  onClick={() => hanldeDepropClick(row)}
                                  className="btn"
                                  style={{
                                    backgroundColor:
                                      row.DOCUMENT_TYPE === "NP"
                                        ? "red"
                                        : "green",
                                    width: "70px",
                                    fontSize: "13px",
                                    color: "white",
                                  }}
                                  //disabled={!isIndentor}
                                >
                                  {" "}
                                  {row.DOCUMENT_TYPE === "NP"
                                    ? "Fail"
                                    : "Passed"}
                                </button>
                              </div>
                            </td>
                            <td>
                              <button
                                onClick={() => {
                                  handleDeleteRow(row.UMC_INDENT_ID);
                                }}
                                style={{
                                  width: "25px",
                                  height: "25px",
                                  padding: "0px",
                                }}
                                class="btn btn-danger btn-sm"
                                type="button"
                                data-toggle="tooltip"
                                data-placement="top"
                                title="Delete"
                                disabled={!isIndentor}
                              >
                                <i class="fa fa-trash"></i>
                              </button>
                            </td>
                          </tr>
                        ))}{" "}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-10"></div>
                  <div className="col-2">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${currentPage === index + 1 ? "active" : ""
                            }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-8"></div>
                  <div className="col-2 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-primary"
                     onClick={() => setShoppinCartModal()}
                     disabled={isDisabled}
                     style={{display:isDisabled?'none':''}}
                     
                    >
                      {savebuttonname}
                    </button>
                  </div>

                  <div className="col-2 d-flex justify-content-start">
                    {/* <button type="button" className="btn btn-success">
                      Raise Shopping Cart
                    </button> */}
                  </div>
                </div>
                {show && (
                  <MaxQtyModal
                    updateQtyData={workFlowData}
                    handleClose={hideModal}
                    handleCellChange={hanldeEdit}
                    OnDeleteRow={hanldeDelete}
                    OnSaveData={handleSaveMaxQtyData}
                    IsDisabled={isDisabled}

                  />
                )}
                {showrcm && (
                  <RequirmentConsumptionModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hideRCMModal}
                    handleCellChange={hanldeRCMEdit}
                    OnDeleteRow={hanldeDelete}
                    OnSaveData={handleSaveRCMData}
                    IsDisabled={isDisabled}
                  />
                )}
                {showrefurshibility && (
                  <RefurshibilityModal
                    requirmentConsumptionData={workFlowData}
                    handleClose={hiderefurshibilityModal}
                    OnDeleteRow={hanldeDelete}
                    IsDisabled={isDisabled}
                  />
                )}
                {showvmi && (
                  <VMIModal
                    VMIData={workFlowData}
                    handleClose={hideVMIModal}
                    OnDeleteRow={hanldeDelete}
                    IsDisabled={isDisabled}
                  />
                )}
                {showdeprop && (
                  <DepropModal
                    DepropData={workFlowData}
                    handleClose={hideDepropModal}
                    OnDeleteRow={hanldeDelete}
                    IsDisabled={isDisabled}
                  />
                )}
                 {showScModal &&(
                  <SC_Name
                  handleClose={hideScModal}
                  handleSubmitScName={handleSubmitScName}
                  SCName = {SCName}
                  setSCName = {setSCName}/>
                )}
              </div>
            </div>
          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};
export default IntelliBuyWorkflow;

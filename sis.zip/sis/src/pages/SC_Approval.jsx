import React, { useState, useEffect } from "react";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl } from "../constants/BaseURL";
import "./IntelliBuySystemChecks.css";
import axios from "axios";
import Swal from "sweetalert2";
import { Label, TextArea } from "react-aria-components";
import "./ShoppingCart.css";
import { Form, FormGroup, Collapse, } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useSelector } from "react-redux";
import { get } from "jquery";
import { useDispatch } from "react-redux";
import { setIndentId,clearIndentId } from "../store/indentSlice";


const SC_Approval = (prop) => {
  const dispatch=useDispatch();
  const user = useSelector((state) => JSON.parse(state.auth.userData));

  //user.User_Id = '163402'; //--make sure  remove this line before update onserver

  const indno = sessionStorage.getItem("SC_IndentNo");


  const navigate = useNavigate();

  const [state, setState] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [workFlowData, setWorkFlowData] = useState([]);
  const [indentno, setIndentNo] = useState(indno);//10000115
  const [shoppingcartno, setShoppingCartNo] = useState("");
  const [shoppingcartname, SetShoppingCartName] = useState("");
  const [indenterPNo, SetIndenterPNo] = useState("");
  const [indenterName, SetIndenterName] = useState("");
  const [fodtype, setFODType] = useState("");
  const [indentDetails, SetIndentDetails] = useState("");
  const [scDetails, SetSCDetails] = useState("");
  const [dept, setDept] = useState("");
  const [deptid, setDeptId] = useState("");
  const [initialvalueofIndent, SetInitialvalueofIndent] = useState("");
  const [finalvalueofIndent, SetfinalvalueofIndent] = useState("");
  const [attachmentsdetails, SetAttachmentsdetails] = useState("");
  const [totalmaterialConsumedBudget, SettotalmaterialConsumedBudget] = useState("");
  const [consumedmaterialbudget, Setconsumedmaterialbudget] = useState("");



  const [INDENTSTATUS, setINDENTSTATUS] = useState("");

  const [scvalue, setSCValue] = useState("");
  const [scvalueunit, setSCValueUnit] = useState("");


  const [selectedRow, setSelectedRow] = useState(null);
  const [openhdr, setOpenHdr] = useState(true);
  const [open, setOpen] = useState(true);
  const [openArvl, setOpenArvl] = useState(true);
  const [openPaging, setOpenPaging] = useState(true);


  //---------------------------Start Approver section-----------------------
  const [selectedOptionRd, setSelectedOptionRd] = useState('');
  const [app_remarks, setApp_remarks] = useState('');
  const [pre_app_remarks, setPre_app_remarks] = useState([]);
  const [approvalHierarchy, setApprovalHierarchy] = useState([]);


  const [SCH_CART_NO, SetSCH_CART_NO] = useState('');
  const [SCH_CART_NAME, SetSCH_CART_NAME] = useState('');
  const [DEPT, SetDEPT] = useState('');
  const [dept_id, Setdept_id] = useState('');

  const [PURDESC, SetPURDESC] = useState('');
  const [SCI_FOD_TYPE_DESC, SetSCI_FOD_TYPE_DESC] = useState('');

  const [SCI_FOD_TYPE, SetSCI_FOD_TYPE] = useState('');
  const [TOTAL_INITIAL_INDENT_VALUE, SetTOTAL_INITIAL_INDENT_VALUE] = useState('');
  const [FINAL_INDENT_VALUE, SetFINAL_INDENT_VALUE] = useState('');
  const [SAVING_VALUE, SetSAVING_VALUE] = useState('');

  const [sca_fileName, Setsca_fileName] = useState('');
  const [sca_fileAttachment, Setsca_fileAttachment] = useState('');

  const [communications, SetCommunications] = useState([]);
  const [communications2, SetCommunications2] = useState([]);

  const [message_c, setMessage_c] = useState('');
  const [notificationType_c, setNotificationType_c] = useState('Question');
  const [selectedRecipient_c, setSelectedRecipient_c] = useState('');
  const [returnCart_c, setReturnCart_c] = useState(true);
  const [confidential_c, setConfidential_c] = useState(false);

  const [scpAppLvl, setScpAppLvl] = useState('');


  const NxtApprover = sessionStorage.getItem('nextApprover');
  const AppStsType = sessionStorage.getItem('AppStatusType');

  const [isDisabled, setIsDisabled] = useState(!(NxtApprover === user.User_Id && AppStsType === '00'));
  const [highlightBlink, setHighlightBlink] = useState(false); // For highlighting and blinking Reply & View Message 






  //const isDisabled = !(NxtApprover === user.User_Id && AppStsType === '00');

  //setIsDisabled(!(NxtApprover === user.User_Id && AppStsType === '00'));







  const handleRemarksChange = (e) => {
    setApp_remarks(e.target.value);
  };


  //------------------------For Showing Information------------------
  const GetApprovalPrompVal = async (indentno) => {

    if (indentno.length > 0) {


      try {

        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };

        const response = await axios.get(
          `${BaseUrl}api/ShoppingCart/SCDetailsForApproval?IndentId=${indentno}`, { headers }
        );
        const data = response.data;
        if (data.jsonData && data.jsonData.length > 0) {

          SetSCH_CART_NO(data.jsonData[0].SCH_CART_NO);
          SetSCH_CART_NAME(data.jsonData[0].SCH_CART_NAME);
          SetDEPT(data.jsonData[0].DEPT);
          SetPURDESC(data.jsonData[0].PURDESC);
          SetSCI_FOD_TYPE_DESC(data.jsonData[0].SCI_FOD_TYPE_DESC);
          SetSCI_FOD_TYPE(data.jsonData[0].SCI_FOD_TYPE);
          SetTOTAL_INITIAL_INDENT_VALUE(data.jsonData[0].TOTAL_INITIAL_INDENT_VALUE);
          SetFINAL_INDENT_VALUE(data.jsonData[0].FINAL_INDENT_VALUE);
          SetSAVING_VALUE(data.jsonData[0].SAVING_VALUE);


        } else {
          Swal.fire("", "No Data Found", "info");

        }
      } catch (error) {
        console.error("Error fetching IntelliBuy check details", error);
      }
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  //------------------------End For Showing Information------------------

  const handleSubmit = (e) => {

    //---------------Start Validation Creator can not be the final approver of any shopping cart.You can either return or reject.-------------
    try {
      let token = sessionStorage.getItem("token");

      // Ensure token is present
      if (!token) {
        Swal.fire("", "Session token not found. Please login again.", "warning");
        return;
      }

      let headers = {
        "jwt-token": token,
      };

      axios.get(`${BaseUrl}api/ShoppingCart/GetCreaterAndFinalApproverID_SC?SCNo=${shoppingcartno}`, { headers })
        .then(response => {

          // Check if response has data
          if (response.data.jsonData && response.data.jsonData.length > 0) {

            //const filteredData = response.data.jsonData.filter(item => item.SCP_APPRVR === '163402');
            const filteredData = response.data.jsonData.filter(item => item.SCP_APPRVR === user.User_Id);

            if (filteredData.length > 0) {
              const CRTID = filteredData[0].SCH_CRT_ID;
              const APPRID = filteredData[0].SCP_APPRVR;
              const PENDLEVEL = filteredData[0].SCP_APP_LVL;
              const MAXLEVEL = filteredData[0].MAXLEVEL;

              // Check if the creator is the final approver     
              if (CRTID === APPRID && PENDLEVEL === MAXLEVEL) {
                Swal.fire("", "Creator cannot be the final approver of any shopping cart. You can either return or reject.", "info");
                return; // Stop further execution
              }
              else {
                var ApproverformDetails = {
                  nscnum: shoppingcartno, //"4100000040",
                  _status: 1,
                  appr_id: user.User_Id,
                  // appr_id: '163402',
                  appr_rem: app_remarks,
                  mail_to: "ALL",
                  IMEI_no: "WEB"
                }

                try {
                  let token = sessionStorage.getItem("token");
                  let headers = {
                    "jwt-token": token,
                  };
                  axios.post(`${BaseUrl}api/ShoppingCart/SCApproverSection`, ApproverformDetails, { headers })
                    .then(response => {
                      // Handle success

                      if (response.status === 200) {
                        Swal.fire("", "Your shopping cart approved successfully", "success");
                        setModalApp(!modalApp);                      
                       sessionStorage.setItem("fromSpecificPage", "true");

                        navigate(`/SIS/Approval`);

                      } else {
                        // Handle unexpected response
                        Swal.fire("", "Something went wrong", "error");
                      }
                    })
                    .catch(error => {
                      // Handle error response
                      if (error.response) {
                        // Server responded with a status code out of the range of 2xx
                        console.error("Error response:", error.response);
                        Swal.fire("", `Error: ${error.response.status} - ${error.response.data.message}`, "error");
                      } else if (error.request) {
                        // No response was received
                        console.error("Error request:", error.request);
                        Swal.fire("", "No response received from the server", "error");
                      } else {
                        // Something happened in setting up the request that triggered an Error
                        console.error("Error message:", error.message);
                        Swal.fire("", `Request error: ${error.message}`, "error");
                      }
                      prop.hideLoader();
                      setIsLoading(false);
                    });

                } catch (error) {
                  console.error("Error in Axios POST request:", error);
                  prop.hideLoader();
                  setIsLoading(false);
                }
              }
            }

          } else {
            // Handle empty or unexpected response
            Swal.fire("", "No relevant data found for this shopping cart.", "info");
          }
        })
        .catch(error => {
          // Error handling
          if (error.response) {
            console.error("Error response:", error.response);
            Swal.fire("", `Error: ${error.response.status} - ${error.response.data.message}`, "error");
          } else if (error.request) {
            console.error("Error request:", error.request);
            Swal.fire("", "No response received from the server", "error");
          } else {
            console.error("Error message:", error.message);
            Swal.fire("", `Request error: ${error.message}`, "error");
          }
        });
    } catch (error) {
      // General error handling
      console.error("Unexpected error: ", error);
      Swal.fire("", "An unexpected error occurred.", "error");
    }


    //---------------End Validation Creator can not be the final approver of any shopping cart.You can either return or reject.------------- 




  };

  const handleReturn = (e) => {

    var ApproverformDetails = {
      nscnum: shoppingcartno, //"4100000040",
      _status: 2,
      appr_id: user.User_Id,
      // appr_id: '163402',     
      appr_rem: app_remarks,
      mail_to: "ALL",
      IMEI_no: "WEB"
    
    }

    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      axios.post(`${BaseUrl}api/ShoppingCart/SCApproverSection`, ApproverformDetails, { headers })
        .then(response => {
          // Handle success

          if (response.data.Text === "success") {

            intimateMailReturn(shoppingcartno,scpAppLvl,selectedRecipient,message)
            Swal.fire("", "Your shopping cart returned successfully", "success");

           
            sessionStorage.setItem("fromSpecificPage", "true");
            navigate(`/SIS/Approval`);

          } else {
            // Handle unexpected response
            Swal.fire("", "Something went wrong", "error");
          }
        })
        .catch(error => {
          // Handle error response
          if (error.response) {
            // Server responded with a status code out of the range of 2xx
            console.error("Error response:", error.response);
            Swal.fire("", `Error: ${error.response.status} - ${error.response.data.message}`, "error");
          } else if (error.request) {
            // No response was received
            console.error("Error request:", error.request);
            Swal.fire("", "No response received from the server", "error");
          } else {
            // Something happened in setting up the request that triggered an Error
            console.error("Error message:", error.message);
            Swal.fire("", `Request error: ${error.message}`, "error");
          }
          prop.hideLoader();
          setIsLoading(false);
        });
    } catch (error) {
      console.error("Unexpected error:", error);
      prop.hideLoader();
      setIsLoading(false);
    }


  };

  const handleReject = (e) => {


    // Show confirmation prompt
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you really want to delete this item?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        var ApproverformDetails = {
          nscnum: shoppingcartno, //"4100000040",
          _status: 0,
          appr_id: user.User_Id,
          //appr_id: '163402',
          appr_rem: app_remarks,
          mail_to: "ALL",
          IMEI_no: "WEB"
        }

        try {

          let token = sessionStorage.getItem("token");
          let headers = {
            "jwt-token": token,
          };

          axios.post(`${BaseUrl}api/ShoppingCart/SCApproverSection`, ApproverformDetails, { headers })
            .then(response => {
              // Handle success

              if (response.status === 200) {
                Swal.fire("", "Your shopping cart deleted successfully", "success");
              
               sessionStorage.setItem("fromSpecificPage", "true");
                navigate(`/SIS/Approval`);
              } else {
                // Handle unexpected response
                Swal.fire("", "Something went wrong", "error");
              }
            })
            .catch(error => {
              // Handle error response
              if (error.response) {
                // Server responded with a status code out of the range of 2xx
                console.error("Error response:", error.response);
                Swal.fire("", `Error: ${error.response.status} - ${error.response.data.message}`, "error");
              } else if (error.request) {
                // No response was received
                console.error("Error request:", error.request);
                Swal.fire("", "No response received from the server", "error");
              } else {
                // Something happened in setting up the request that triggered an Error
                console.error("Error message:", error.message);
                Swal.fire("", `Request error: ${error.message}`, "error");
              }
              prop.hideLoader();
              setIsLoading(false);
            });
        } catch (error) {
          console.error("Error in Axios POST request:", error);
          prop.hideLoader();
          setIsLoading(false);
        }
      }
    });
  };

  //---------------------------End Approver section-----------------------

  const GetSCNo = async (indentno) => {
    if (indentno.length > 0) {
      try {

        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };

        const response = await axios.get(
          `${BaseUrl}api/ShoppingCart/GetSCHeaderAndMaterialDetails?IndentId=${indentno}`, { headers }
        );
        const data = response.data;
        if (data.jsonData && data.jsonData.length > 0) {
          setWorkFlowData(data.jsonData);
          setShoppingCartNo(data.jsonData[0].SCH_CART_NO);
          const SCId = data.jsonData[0].SCH_CART_NO;
          //setFODType(data.jsonData[0].FOD_TYPE);
          SetIndenterPNo(data.jsonData[0].SCH_CRT_ID);
          SetIndenterName(data.jsonData[0].UM_USR_NAME);
          setFODType(data.jsonData[0].SCI_FOD_TYPE);
          SetIndentDetails(data.jsonData[0].INDENT_DESC);
          SetSCDetails(data.jsonData[0].SCH_NOTE_APP);
          setDept(data.jsonData[0].SCH_DEPT);
          setDeptId(data.jsonData[0].DEPTID);

          const dept_id = data.jsonData[0].DEPTID;
          Setdept_id(dept_id);




          Setsca_fileName(data.jsonData[0].SCA_FILE_NAME);
          Setsca_fileAttachment(data.jsonData[0].SCA_FILE);

          const fName = data.jsonData[0].SCA_FILE_NAME;
          const fAtch = data.jsonData[0].SCA_FILE
          //   createBlobURL(fAtch);
          //  handleDownload(fAtch);

          SetInitialvalueofIndent();
          SetfinalvalueofIndent(data.jsonData[0].SCH_TOT_VAL);
          SetAttachmentsdetails();

          GetAnswerStatus(SCId);



          try {

            let token = sessionStorage.getItem("token");
            let headers = {
              "jwt-token": token,
            };


            const scResponse = await axios.get(
              `${BaseUrl}api/ShoppingCart/GetShoppingCartDetails?SCId=${SCId}`, { headers }
            );
            const scData = scResponse.data;
            SetShoppingCartName(scData.jsonData[0].SCH_CART_NAME);
            setSCValue(scData.jsonData[0].SCH_TOT_VAL);
            setSCValueUnit(scData.jsonData[0].SCH_VAL_UNIT);
          } catch (error) {
            console.error("Error fetching shopping cart details", error);
          }

          //-------------------------GetApproval Hierarchy-----------------------
          try {

            let token = sessionStorage.getItem("token");
            let headers = {
              "jwt-token": token,
            };


            const scApprovalResponse = await axios.get(
              `${BaseUrl}api/ShoppingCart/SCApprovalHierarchy?SCNo=${SCId}`, { headers }
            );
            const scApprovalheiData = scApprovalResponse.data;
            setApprovalHierarchy(scApprovalheiData.jsonData);


          } catch (error) {
            console.error("Error fetching shopping cart details", error);
          }

          //-------------------------GetApproval Remarks-----------------------
          try {

            let token = sessionStorage.getItem("token");
            let headers = {
              "jwt-token": token,
            };


            //   const scApprovalRemarksResponse = await axios.get(
            //     `${BaseUrl}api/ShoppingCart/SCAppRemarks?SCId=${SCId}`,  {headers}
            //   );
            //   const scApprovalRemarksData = scApprovalRemarksResponse.data;

            //   setPre_app_remarks(scApprovalRemarksData.jsonData);



            // } catch (error) {
            //   console.error("Error fetching shopping cart details", error);
            // }



            const scApprovalRemarksResponse = await axios.get(
              `${BaseUrl}api/ShoppingCart/SCAppRemarks?SCNo=${SCId}`, { headers }
            );
            const scApprovalRemarksData = scApprovalRemarksResponse.data;

            setPre_app_remarks(scApprovalRemarksData.jsonData);


          } catch (error) {
            console.error("Error fetching shopping cart details", error);
          }

          //--------------------For Department & Status Display-------------------------

          var filter = {
            DTF: "",
            DTT: "",
            DEPT: "",
            FOD: "",
            STATUS: "",
            INDENTNO: indentno,
            DOCTYPE: "",
            USERNAME: user.User_Id
          };
          try {

            let token = sessionStorage.getItem("token");
            let headers = {
              "jwt-token": token,
            };

            const statusResponse = await axios.post(`${BaseUrl}api/Report/GetIndentStatus`, filter, { headers }, {
              withCredentials: true
            });
            if (statusResponse.data.statusText === "OK") {
              const indentStatusData = JSON.parse(statusResponse.data.Data);
              if (Array.isArray(indentStatusData) && indentStatusData.length > 0) {
                const status = indentStatusData[0].STATUS;
                setDept(indentStatusData[0].DEPT);
                setINDENTSTATUS(status);

              }
              prop.hideLoader();
            } else {
              prop.hideLoader();
              // Swal.fire('', 'No data found', 'info');
            }
          } catch (error) {
            prop.hideLoader();
            console.error("Error fetching indent status", error);
          }
        } else {
          Swal.fire("", "No Data Found", "info");
          setWorkFlowData([]);
          setShoppingCartNo("");
        }
      } catch (error) {
        console.error("Error fetching IntelliBuy check details", error);
      }
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  useEffect(() => {
   
    const indNo = indentno; // replace with actual indent number    
    GetSCNo(indNo);
    const DepartmentId = sessionStorage.getItem("Did");
    getBudgetValue(indNo, DepartmentId);
    GetApprovalPrompVal(indNo);




    //BindRecipientReturn();

  }, []); // Empty dependency array means this will run once after the initial render




  //====================Start Upload Approver file doc=================
  const [modal, setModal] = useState(false);
  const [modalApp, setModalApp] = useState(false);
  const [modalAsk, setModalAsk] = useState(false);
  const [modalappHei, setModalAppHei] = useState(false);
  const [modalJust, setmodalJust] = useState(false);
  const [modalViewMsg, setModalViewMsg] = useState(false);
  const [file, setFile] = useState(null);
  const toggle = () => setModal(!modal);
  const toggleApp = () => setModalApp(!modalApp);
  const toggleAppHei = () => setModalAppHei(!modalappHei);

  const [scjustData, setSCJustData] = useState([]);
  const [answerStatus, setAnswerStatus] = useState([]);


  const toggleViewMsg = async (e) => {
    e.preventDefault();
    try {

      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      //const scResponse = await axios.post(`${BaseUrl}api/ShoppingCart/SC_GetReplayCommunications?sno=${shoppingcartno}&userId=${'163402'}`, { headers });
      const scResponse = await axios.post(`${BaseUrl}api/ShoppingCart/SC_GetReplayCommunications?sno=${shoppingcartno}&userId=${user.User_Id}`, { headers });
      const ScData_ = scResponse.data;
      SetCommunications(ScData_.jsonData);
      SetCommunications2(ScData_.jsonData);
      setSelectedRecipient_c(ScData_.jsonData[0].SCC_FROM_ID)
      console.log("ScData_.jsonData[0].SCC_FROM_ID", ScData_.jsonData[0].SCC_FROM_ID)



      const IsConf = ScData_.jsonData[0].SCC_IS_CONFIDENTIAL;
      const ToID = ScData_.jsonData[0].SCC_TO_ID;
      setConfidential_c(IsConf);

      // if(IsConf==='Y')
      // {
      //   if(user.User_Id===ToID)
      //   {
      //   console.log("If Visible", IsConf,ToID)
      //   }
      // }     
      // else
      // {
      //   console.log("else Visible", IsConf,ToID)
      // }

    } catch (error) {
      console.error("Error fetching justification details", error);
    }
    setModalViewMsg(!modalViewMsg);
  }



  const toggleAsk = async (e) => {
    try {

      setStatus('')
      setError('')
      setSelectedRecipient(0);
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      //const scResponse = await axios.post(`${BaseUrl}api/ShoppingCart/SC_Recipient?SC_No=${shoppingcartno}&DeptId=${deptid}&userId=${'163402'}`, { headers });
      const scResponse = await axios.post(`${BaseUrl}api/ShoppingCart/SC_Recipient?SC_No=${shoppingcartno}&DeptId=${deptid}&userId=${user.User_Id}`, { headers });
      const ScRcptData_ = scResponse.data;
      setRecipient(ScRcptData_.jsonData);
      console.log("ScRcptData_ScRcptData_ScRcptData_", ScRcptData_.jsonData);


    } catch (error) {
      console.error("Error fetching justification details", error);
    }
    setModalAsk(!modalAsk);

  }
  const toggleJust = async (e) => {

    //-------------------------GetJustification data-----------------------
    try {

      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };


      const scJustResponse = await axios.get(
        `${BaseUrl}api/ShoppingCart/SCJustification?SCNo=${shoppingcartno}&SCI_MATL_NO=${e.SCI_MATL_NO}`, { headers }
      );
      const ScJustData_ = scJustResponse.data;
      setSCJustData(ScJustData_.jsonData);


    } catch (error) {
      console.error("Error fetching justification details", error);
    }

    setmodalJust(!modalJust);


  }

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('Sno', shoppingcartno); // Example Sno
    formData.append('UserId', user.User_Id); // Example userId
    // formData.append('UserId', '163402');

    try {

      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };


      const response = await axios.post(`${BaseUrl}api/ShoppingCart/SCApproverFileUpload`, formData, { headers });

      if (response.data.Text === 'success') {
        // Handle success response
        toggle();
        Swal.fire("", "Document uploaded successfully", "success");
      } else {
        // Handle cases where response is not 200 but no error is thrown
        Swal.fire("", "Only .pdf file accepted !", "warning");
      }
    } catch (error) {
      // Handle error response
      Swal.fire("", "There was an error uploading the file!", "error");
      console.error('Error:', error);
    }
  };


  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 3; // You can adjust this number to control how many rows are displayed per page

  // Calculate the indexes for the rows to be displayed on the current page
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = workFlowData.slice(indexOfFirstRow, indexOfLastRow);
  const currentapprovalHierarchy = approvalHierarchy.slice();


  // Handle page change
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleShowDetails = (row) => {

    
   // sessionStorage.setItem("SC_IndentNo", indentno);
    dispatch(setIndentId(indentno));
    navigate("/SIS/SmartIndenting");
    //navigate(`/SIS/SC_AppDetailsView`);
   // sessionStorage.setItem("ForomSC", 'SC_APP');
    //navigate(`/SIS/SmartIndenting`);
   // window.open(`/SIS/ShoppingCart`)
  };
  const handleShowIntellibuyDetails = (row) => {    
    navigate(`/SIS/SC_AppDetailsView`);

  };

  const togglePanelHDR = () => {
    setOpenHdr(!openhdr);

  };

  const togglePanel = () => {
    setOpen(!open);
    setOpenPaging(!openPaging);
  };
  const togglePanelApproval = () => {
    setOpenArvl(!openArvl);
  };

  const handleBack = () => {
      // Set sessionStorage before navigating
  sessionStorage.setItem("fromSpecificPage", "true");

  // Navigate to the Approval page
  navigate(`/SIS/Approval`);
  };
  //================================Return Logic==========================


  const getRecord = async (shoppingcartno) => {

    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };


    const response = await axios.get(`${BaseUrl}api/ShoppingCart/getRecord?cartNo=${shoppingcartno}`, { headers });
    return response.data;
  };


  const insertCommunication_OnlyInsert = async (communication) => {
    try {

      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.post(`${BaseUrl}api/ShoppingCart/insertCommunication_OnlyInsert`, communication, { headers });

      // Display success message
      /// Swal.fire("Communication inserted successfully!");
      if (response.data.Text = "Success") {

      }
      else {
        return;
      }

    } catch (error) {

      if (error.response) {

        const errorMessage = error.response.data.ExceptionMessage || "";

        if (errorMessage.includes("ORA-00001")) {
          // Display custom message for unique constraint violation
          Swal.fire("Your communication with the same identifier already exists. Please view Message.");
        }
        else {
          //
          // Server responded with a status other than 2xx
          Swal.fire(`Error: ${error.response.data.ExceptionMessage
            || "Failed to insert communication."}`);
        }
      } else if (error.request) {
        // Request was made but no response was received
        Swal.fire("Error: No response from the server. Please try again.");
      } else {
        // Something happened while setting up the request
        Swal.fire(`Error: ${error.message}`);
      }
      return null;
    }
  };

  const insertCommunication = async (communication) => {

    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.post(`${BaseUrl}api/ShoppingCart/insertCommunication`, communication, { headers });
    return response.data;
  };

  const updateShoppingCart = async (shoppingCart) => {

    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };

    const response = await axios.post(`${BaseUrl}api/ShoppingCart/updateShoppingCart`, shoppingCart, { headers });
    return response.data;
  };

  const getStatus = async (shoppingcartno) => {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.get(`${BaseUrl}api/ShoppingCart/getStatus?cartNo=${shoppingcartno}`, { headers });
    return response.data;
  };

  const [message, setMessage] = useState('');
  const [notificationType, setNotificationType] = useState('Question');
  const [recipient, setRecipient] = useState([]);
  const [selectedRecipient, setSelectedRecipient] = useState('');
  const [returnCart, setReturnCart] = useState(true);
  const [confidential, setConfidential] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');




  //---------------------For download attachment-------------------
  // const fAtch = data.jsonData[0].SCA_FILE; // Assuming this is a Base64 encoded string

  const base64ToBlob = (base64, mimeType) => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
  };

  const createBlobURL = (blob) => {
    return URL.createObjectURL(blob);
  };

  const downloadBlob = (blobURL, fileName) => {
    const link = document.createElement('a');
    link.href = blobURL;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownload = async () => {
    try {
      // Convert Base64 string to Blob (assuming the data is a Base64 encoded PDF)
      const mimeType = 'application/pdf'; // Adjust the MIME type as needed
      const blob = base64ToBlob(sca_fileAttachment, mimeType);

      const blobURL = createBlobURL(blob);
      downloadBlob(blobURL, sca_fileName); // Adjust the file extension as needed
    } catch (error) {
      console.error('Download failed:', error);
    }
  };
  const handleDownload_Appr = (row) => {

    try {
      // Convert Base64 string to Blob (assuming the data is a Base64 encoded PDF)
      const mimeType = 'application/pdf'; // Adjust the MIME type as needed
      const blob = base64ToBlob(row.SCP_ATCHMNT, mimeType);

      const blobURL = createBlobURL(blob);
      downloadBlob(blobURL, row.SCP_FILENAME); // Adjust the file extension as needed
    } catch (error) {
      console.error('Download failed:', error);
    }
  };

  //==================Get Budget Value=================================
  const getBudgetValue = async (indentno, IndenterDept) => {
    console.log("indentno", indentno, "IndenterDept", IndenterDept)
    if (indentno !== "") {
      //setIsLoading(true); // Start the loader
      // prop.showLoader();


      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };

      try {
        const response = await axios.get(
          `${BaseUrl}api/ShoppingCart/GetIntelliBuyChecksDetailsFromId_ODA_SC?IndentId=${indentno}&INDENTOR_DEPT=${IndenterDept}`,
          { headers }
        );

        const data = response.data;

        if (data && data.jsonData.length > 0) {
          SettotalmaterialConsumedBudget(data.jsonData[0].DeptBudgetConsumption);
          const Budget = data.jsonData[0].DeptBudgetConsumption;
          Setconsumedmaterialbudget(data.jsonData[0].COMMITTEDEXPENDITURE);
        } else {
          Swal.fire("", "No Data Found", "info");
        }

      } catch (error) {
        console.error("Error fetching budget data:", error);
        Swal.fire("", "Failed to fetch data", "error");

      } finally {
        setIsLoading(false); // Stop the loader after API call is finished (success or failure)
        prop.hideLoader();
      }

    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };

  //=================View Message ============================
  // const handleInputChange = (e) => {
  //   const { name, value, type, checked } = e.target;
  //   setFormState({
  //     ...formState,
  //     [name]: type === "checkbox" ? checked : value,
  //   });
  // };
  // const [formState, setFormState] = useState({
  //   type: "Question",
  //   to: "10000",
  //   text: "",
  //   returnCart: true,
  //   confidential: false,
  // });




  const handleSendMessage = async () => {
    try {
     
      if (message.length === 0) {
        throw new Error('Please enter a message');
       
      }
      if (message.length >= 497) {
        throw new Error('Please enter a message in less than 500 characters');
        
      }
     
       if(selectedRecipient===0)
       {
         throw new Error('Please select Recipient ');
         return;
       }
       handleReturn();
      const communication = {
        SCC_CART_NO: shoppingcartno,
        SCC_SEQ_NO: 0, // Placeholder, to be determined in backend
        SCC_TYPE: returnCart ? `${notificationType} (With Return Shopping Cart)` : notificationType,
        SCC_TEXT: message,
        SCC_FROM_ID: user.User_Id,
        //SCC_FROM_ID: '163402',
        SCC_TO_ID: selectedRecipient,
        SCC_ACTIVE_FLAG: 'A',
        SCC_STATUS: '01',
        SCC_CRT_BY: user.User_Id,
        SCC_IS_CONFIDENTIAL: confidential ? 'Y' : 'N',
      };


      //await insertCommunication_OnlyInsert(communication);
      try {

        const response = await axios.post(`${BaseUrl}api/ShoppingCart/insertCommunication_OnlyInsert`, communication);

        // Display success message
        /// Swal.fire("Communication inserted successfully!");
        if (response.data.Text = "Success") {
                    
           // if (returnCart) {
              const shoppingCart = {
                SCH_CART_NO: shoppingcartno,
                SCH_STATUS: '03',
                SCH_UPD_ID: user.User_Id,
                // SCH_UPD_ID: '163402',
                RETURN_TO_ID: selectedRecipient,
                RETRUN_LVL: scpAppLvl,
                INDENT_NO: indentno,

              };
              await updateShoppingCart(shoppingCart);
              setModalAsk(!modalAsk);
           // }
            // else {
            //   const currentStatus = await getStatus(shoppingcartno);
            //   if (currentStatus.SCH_STATUS === '09') {
            //     const shoppingCart = {
            //       SCH_CART_NO: shoppingcartno,
            //       SCH_STATUS: '04',
            //       SCH_UPD_ID: user.User_Id,
            //       //SCH_UPD_ID: '163402',

            //     };
            //     await updateShoppingCart(shoppingCart);
            //   }
            // };
          }
        
        else {
          return;
        }

      } catch (error) {

        if (error.response) {

          const errorMessage = error.response.data.ExceptionMessage || "";

          if (errorMessage.includes("ORA-00001")) {
            // Display custom message for unique constraint violation
            Swal.fire("Your communication with the same identifier already exists. Please view Message.");
          }
          else {
            //
            // Server responded with a status other than 2xx
            Swal.fire(`Message : ${error.response.data.ExceptionMessage
              || "Failed to insert communication."}`);
          }
        } else if (error.request) {
          // Request was made but no response was received
          Swal.fire("Error: No response from the server. Please try again.");
        } else {
          // Something happened while setting up the request
          Swal.fire(`Error: ${error.message}`);
        }
        return null;
      }


    } catch (error) {
      setError(error.message);
    }
  }


  const handleSendMessage2 = async (e) => {
    e.preventDefault();
    try {

      if (message_c.length === 0) {
        throw new Error('Please enter a message');
      }
      if (message_c.length >= 497) {
        throw new Error('Please enter a message in less than 500 characters');
      }

      const communication = {
        SCC_CART_NO: shoppingcartno,
        SCC_SEQ_NO: 0, // Placeholder, to be determined in backend
        SCC_TYPE: returnCart_c ? `${notificationType_c} (With Return Shopping Cart)` : notificationType_c,
        SCC_TEXT: message_c,
        SCC_FROM_ID: user.User_Id,
        //SCC_FROM_ID: '163402',
        // SCC_FROM_ID: '153677',
        SCC_TO_ID: selectedRecipient_c,
        SCC_ACTIVE_FLAG: 'A',
        SCC_STATUS: '01',
        SCC_CRT_BY: user.User_Id,
        SCC_IS_CONFIDENTIAL: confidential_c ? 'Y' : 'N',
      };

      await insertCommunication(communication);


     // intimateMailCommunication(message_c, shoppingcartno, notificationType_c)


      Swal.fire("", "Message has been saved successfully", "info").then(() => {
        GetAnswerStatus(shoppingcartno)
      });
      setModalViewMsg(false);
      //navigate(`/SIS/Approval`);
    } catch (error) {
      setError(error.message_c);
    }
  };


 //---------------send Email For Return Shopping cart----------------------
 const intimateMailReturn = async (scNo, ReturnLevel, ReturnToId) => {
  try {
    let token = sessionStorage.getItem("token");
    const headers = {
      "jwt-token": token,
    };

    const toDtResponse = await axios.get(`${BaseUrl}api/ShoppingCart/GetUserEmailId_SC?UserId=${ReturnToId}`, { headers });
    const toDtData = toDtResponse.data;
    console.log("Userdata", toDtData.jsonData);
    if (toDtData.jsonData.length > 0) {
      const mToUserName = toDtData.jsonData[0].UM_USR_NAME;
      const mToUser = toDtData.jsonData[0].UM_EMAIL_ID;
      const mToUserId = toDtData.jsonData[0].UM_USR_ID;

      const mFromUser = "SISAdmin@tatasteel.com";
      const mSubject = `SC ${scNo}  created by ${mToUserName} ( ${mToUserId} ) has been Returned`;

     
     //const mBody = `This is a system generated message. Please do not reply to this mail. LVL-${ReturnLevel} SC-${scNo} has been Returned. Use the Following Link to log on to respond: <a href="https://tslcorp.corp.tatasteel.com/SIS/">https://tslcorp.corp.tatasteel.com/SIS/</a>`;

      fetch(`${BaseUrl}api/Email/sendEmailForRejection?from=${mFromUser}&to=${mToUser}&subject=${mSubject}&ReturnLevel=${ReturnLevel}&scNo=${scNo}&mToUserName=${mToUserName}&message=${message}`)
      .then((response) => {
        console.log("response", response.data)
        if (!response.ok) {
          // If the response is not OK, log the status and status text
          throw new Error(`HTTP error! Status: ${response.status} ${response.statusText}`);
        }
        return response.json();
      })
      .then((data) => {
        // Log the message from the response
        console.log("Message", data.message);
      })
      .catch((error) => {
        // Log detailed error information
        console.error('There was a problem with the fetch operation:', error);
      });
    }
  } catch (error) {
    console.error('Error occurred while sending email:', error);
  }
};

  //---------------send Communication Email----------------------
  const intimateMailCommunication = async ( textMessage, scNo, commType) => {
    try {
      
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };

      const toDtResponse = await axios.get(`${BaseUrl}api/ShoppingCart/GetUserEmailId_SC?UserId=${user.User_Id}`, { headers });
      const toDtData = toDtResponse.data;
      console.log("Userdata", toDtData.jsonData);
      if (toDtData.jsonData.length > 0) {
        const mToUserName = toDtData.jsonData[0].UM_USR_NAME;
        const mToUser = toDtData.jsonData[0].UM_EMAIL_ID;
        const mFromUser = "SISAdmin@tatasteel.com";
        const mSubject = `Communication for Shopping Cart No: ${scNo}`;

        fetch(`${BaseUrl}api/Email/sendEmail?from=${mFromUser}&to=${mToUser}&subject=${mSubject}&mToUserName=${mToUserName}&textMessage=${textMessage}&commType=${commType}&scNo=${scNo}`)
          .then((response) => {
            console.log("response", response.data)
            if (!response.ok) {
              // If the response is not OK, log the status and status text
              throw new Error(`HTTP error! Status: ${response.status} ${response.statusText}`);
            }
            return response.json();
          })
          .then((data) => {
            // Log the message from the response
            console.log("Message", data.message);
          })
          .catch((error) => {
            // Log detailed error information
            console.error('There was a problem with the fetch operation:', error);
          });



      }
    } catch (error) {
      console.error('Error occurred while sending email:', error);
    }
  };


  //-----------------End send Communication Email----------------------------

  const budgetmessage = consumedmaterialbudget > 100
    ? `Spares expenditure exceeded ${consumedmaterialbudget}% of the budget.`
    : `${consumedmaterialbudget}%.`;

  const textColor = consumedmaterialbudget > 100 ? 'red' : 'black';


  //-----------------Start make validation For Question & Amswer----------------------------
  const GetAnswerStatus = async (SCId) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const AnswerStatusResponse = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetAnswerStatus?SCNo=${SCId}&UserId=${user.User_Id}`, { headers }
      );
      const AnswerStatusData = AnswerStatusResponse.data;
      setAnswerStatus(AnswerStatusData.jsonData);
      console.log("AnswerStatusData", AnswerStatusData.jsonData);
      if (AnswerStatusData.jsonData.length > 0) {
        const IsAnswer = AnswerStatusData.jsonData[0].SCC_IS_ANSWER

        if (IsAnswer === 'N') {
          //Swal.fire("", "Please before give the answer then perform any action", "info");
          setIsDisabled(true);
          setHighlightBlink(true); // Highlight and blink Reply & View Message button

        }
        else {
          setIsDisabled(false);
          setIsDisabled(!(NxtApprover === user.User_Id && AppStsType === '00'))
        }
      } else {
        setIsDisabled(false);       
        setIsDisabled(!(NxtApprover === user.User_Id && AppStsType === '00'))
        setHighlightBlink(false)
      }


    } catch (error) {
      console.error("Error fetching Answer status details", error);
    }
  }
  //-----------------End make validation For Question & Amswer----------------------------


   //-----------------For Formate currency----------------------------

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };
  


  return (
    <div>
      {!state ? (
        <>

          <div lassName="container" style={{ marginTop: "8px", marginLeft: "65px", maxWidth: "95%" }}>

            <div className="row mt-1">
              <div className="col-2 center">

              </div>
              <div className="col-8 center">
                <h5>Shopping cart Approval</h5>
              </div>
              <div className="col-2">
                <button style={{ float: "right" }} className="btn btn-success btn-sm" onClick={() => handleBack()}>  Back   </button>
              </div>
            </div>
            <div className="row mt-1"></div>
            {/*----Hrader section----------------*/}
            <div className="card" style={{ border: "1px solid blue" }}>
              <div className="card-heading" onClick={togglePanelHDR} style={{ backgroundColor: "#0d6efd", height: "30px" }}>

                <h6 className="mt-1" style={{ color: "white" }}>
                  &nbsp;   {open ? <i className="fa fa-minus text-blue"></i> : <i className="fa fa-plus text-blue"></i>}
                  &nbsp;  Indent Cart  Details
                </h6>
              </div>
              <Collapse in={openhdr}>
                <div className="card-body" style={{ maxWidth: "100%" }}>
                  <div className="row">
                    <div className="col-md-2">
                      <label className="sc-lbl"> Indent No.   </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l">  :  &nbsp;&nbsp; {indentno} </label>
                    </div>

                    <div className="col-md-2">
                      <label className="sc-lbl"> SC No. </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l"> :  &nbsp;&nbsp; {shoppingcartno} </label>
                    </div>


                    <div className="col-md-2">
                      <label className="sc-lbl"> FOD Type </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l">   :  &nbsp;&nbsp;{fodtype} </label>
                    </div>

                  </div>

                  <div className="row">

                    <div className="col-md-2">
                      <label className="sc-lbl"> Indenter P No </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l"> : &nbsp;&nbsp; {indenterPNo} </label>
                    </div>

                    <div className="col-md-2">
                      <label className="sc-lbl">  Initial value of Indent (INR) </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l">  :  &nbsp;&nbsp;{formatCurrency(TOTAL_INITIAL_INDENT_VALUE)}</label>
                    </div>

                    <div className="col-md-2">
                      <label className="sc-lbl">  Indenting Dept</label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l">  :   &nbsp;&nbsp; {dept}</label>
                    </div>
                  </div>

                  <div className="row">

                    <div className="col-md-2">
                      <label className="sc-lbl"> Indenter Name  </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l"> : &nbsp;&nbsp; {indenterName} </label>
                    </div>

                    <div className="col-md-2">
                      <label className="sc-lbl">  Final value of SC (INR)  </label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l">  :   &nbsp;&nbsp;{formatCurrency(finalvalueofIndent)}</label>
                    </div>

                    <div className="col-md-2">
                      <label className="sc-lbl">  Consumed material budget% </label>
                    </div>
                    <div className="col-md-2">
                      {/* <label className="sc-lbl m-l">    :    &nbsp;&nbsp; {consumedmaterialbudget}{'%'}</label> */}
                      <label className="sc-lbl m-l" style={{ color: textColor }}>  : &nbsp;&nbsp;  {budgetmessage}</label>
                    </div>

                  </div>

                  <div className="row">
                    <div className="col-md-2">
                      <label className="sc-lbl"> Indent Details  </label>
                    </div>
                    <div className="col-md-6">
                      <label className="sc-lbl m-l">  :  &nbsp;&nbsp; {indentDetails}</label>
                    </div>

                    <div className="col-md-2">
                      <label className="sc-lbl"> Attachments details</label>
                    </div>
                    <div className="col-md-2">
                      <label className="sc-lbl m-l"> :  &nbsp;&nbsp; <button onClick={handleDownload} className="btn btn-link btn-sm" >Download File </button></label>
                    </div>

                  </div>

                  <div className="row">

                    <div className="col-md-2">
                      <label className="sc-lbl"> SC Details</label>
                    </div>
                    <div className="col-md-5">
                      <label className="sc-lbl m-l"> :  &nbsp;&nbsp;{scDetails}</label>
                    </div>
                    {/* <div className="col-md-2">                     
                      <label className="sc-lbl"> Total material/Consumed Budget Rs. Cr </label>
                    </div>
                    <div className="col-md-2">                     
                      <label className="sc-lbl"> :  &nbsp;&nbsp; {parseFloat(totalmaterialConsumedBudget).toFixed(2)}</label>
                    </div> */}




                  </div>
                </div>
              </Collapse>
            </div>

            {/*------ Material Level Details----------*/}


            <div className="card mt-1" style={{ border: "1px solid blue" }}>
              <div className="card-heading" onClick={togglePanel} style={{ backgroundColor: "#0d6efd", height: "30px" }}>
                <h6 className="mt-1" style={{ color: "white" }}>
                  &nbsp;   {open ? <i className="fa fa-minus text-blue"></i> : <i className="fa fa-plus text-blue"></i>}
                  &nbsp;  Material level details
                </h6>
              </div>

              <Collapse in={open}>
                <div className="row" style={{ overflowX: "auto" }}>
                  <div className="tables table-responsive table-responsive-sm">
                    <table className="table table-bordered tb">
                      <thead className="table-primary">
                        <tr>
                          <th>S No.</th>
                          <th>UMC No</th>
                          <th> UMC Desc. </th>
                          <th> BGG</th>
                          <th>Initial indented Qty</th>
                          <th>Final SC Qty</th>
                          <th>Unit Price (INR)</th>
                          <th>UMC value (INR) in the initial Indent </th>
                          <th>UMC value (INR) in the SC</th>
                          <th>Consumption Date</th>
                          <th>Requirement Date</th>
                          <th>Justification</th>
                          <th>Detailed view</th>
                          <th>Intellibuy</th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentRows.map((row, index) => (
                          <tr key={row.UMC_INDENT_ID} style={{ backgroundColor: selectedRow === row.UMC_INDENT_ID ? "#ddd" : "white" }}>
                            <td>{row.SRNO}</td>
                            <td>{row.SCI_MATL_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>
                            <td>{row.SCI_MATL_GRP}</td>
                            <td>{row.QTY}</td> {/*  TO BE COLOUMN ADDED */}
                            <td>{row.SCI_QTY}</td>
                            <td>{formatCurrency(row.SCI_PRICE)}</td>
                            <td>{formatCurrency(row.INITIAL_INDENT_VALUE)}</td>
                            <td>{formatCurrency(row.FINAL_INDENT_VALUE)}</td>
                            <td>{row.CONSUMP_DT}</td>
                            <td>{row.SCI_REQD_ON_DT}</td>
                            <td>
                              <button
                                className="btn btn-info btn-sm"
                                onClick={() => toggleJust(row)}

                              >
                                See
                              </button>
                            </td>
                            <td>
                              <button
                                className="btn btn-primary btn-sm"
                                onClick={() => handleShowDetails(row)}
                              >
                                Show
                              </button>
                            </td>
                            <td>
                              <button
                                className="btn btn-primary btn-sm"
                                onClick={() => handleShowIntellibuyDetails(row)}
                              >
                                Show
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </Collapse>

              <Collapse in={openPaging}>
                <div className="row">
                  <div className="col-md-12">
                    <ul className="pagination justify-content-center">
                      {Array.from({ length: Math.ceil(workFlowData.length / rowsPerPage) }, (_, index) => (
                        <li
                          key={index + 1}
                          className={`page-item ${currentPage === index + 1 ? "active" : ""}`}
                        >
                          <a
                            href="#!"
                            className="page-link"
                            onClick={() => handlePageChange(index + 1)}
                          >
                            {index + 1}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </Collapse>


            </div>

            {/*----Start Approver Section-----*/}
            <div style={{ border: "1px solid blue" }}>
              <div className="card mt-1" style={{ maxWidth: "100%" }}>
                <div className="card-heading" onClick={togglePanelApproval} style={{ backgroundColor: "#0d6efd", height: "34px" }}>
                  <h6 className="mt-2" style={{ color: "white" }}>
                    &nbsp;   {openArvl ? <i className="fa fa-minus text-blue"></i> : <i className="fa fa-plus text-blue"></i>}
                    &nbsp;  Approver Section
                  </h6>
                </div>
                <Collapse in={openArvl}>
                  <div className="card-body">
                    <div className="row col-12">
                      {/* ----------------Approval Action---------------- */}
                      <div className="col-12">
                        <div style={{ border: "1px solid blue" }}>


                          {pre_app_remarks && pre_app_remarks.length > 0 && (
                            <div className="row mt-2">
                              <div className="col-md-4">
                                <label className="form-label sc-lbl">
                                  &nbsp; Previous Approver's Details
                                </label>
                              </div>
                              <div className="col-md-8">
                                <textarea
                                  value={pre_app_remarks.map(entry => `${entry.APPROVER}:Level-${entry.LVL}: ${entry.REMARKS}`).join('\n')}
                                  className="form-control form-control-sm"
                                  style={{ width: "676px", height: "100px" }}
                                  readOnly={true}  // Updated to be boolean instead of string
                                ></textarea>
                              </div>
                            </div>
                          )}


                          <div className="row mt-2">
                            <div className="col-md-4">
                              <label className="form-label sc-lbl">
                                &nbsp; Approver's Remarks
                              </label>
                            </div>
                            <div className="col-md-8">
                              <textarea
                                value={app_remarks}
                                className="form-control form-control-sm"
                                style={{ width: "400", height: "80px" }}
                                onChange={handleRemarksChange}
                                placeholder="Max 1000 Characters"
                              ></textarea>
                            </div>
                          </div>
                          <div className="row mt-2">
                            <div className="col-md-4">
                            </div>
                            <div className="col-md-8">
                              <div className="App">
                                <Button color="link" disabled={isDisabled} onClick={toggle} className="sc-lbl">Click to attach document</Button><br />
                                <span style={{ color: "Red", fontSize: "12px", fontWeight: "bold" }}>Only .pdf file upload.</span>
                                <Modal isOpen={modal} toggle={toggle}>
                                  <ModalHeader toggle={toggle}>Upload Document</ModalHeader>
                                  <ModalBody>
                                    <Form>
                                      <FormGroup>
                                        <Label for="fileUpload"> Select File to Upload</Label>
                                        <Input type="file" name="file" id="fileUpload" accept=".pdf" onChange={handleFileChange} />
                                      </FormGroup>
                                    </Form>
                                  </ModalBody>
                                  <ModalFooter>
                                    <Button color="primary" onClick={handleUpload}>Upload</Button>
                                    <Button color="secondary" onClick={toggle}>Cancel</Button>
                                  </ModalFooter>
                                </Modal>
                              </div>
                            </div>
                          </div>

                          <div className="row mt-1">
                            <div className="col-md-12">
                              <hr />
                            </div>
                          </div>

                          <div className="row mt-2">

                            <div className="col-md-2">
                              &nbsp;
                            </div>
                            <div className="col-md-3">
                              <button type="submit" disabled={isDisabled} onClick={toggleApp} className="btn btn-success">Approve</button>
                            </div>

                            <div className="col-md-3">
                              <button type="submit" disabled={isDisabled} onClick={toggleAsk} className="btn btn-warning">Return</button>
                              {/* <button type="submit" onClick={handleReturn} className="btn btn-warning">Return</button> */}
                            </div>
                            <div className="col-md-2">
                              <button type="submit" disabled={isDisabled} onClick={handleReject} className="btn btn-danger">Reject</button>
                            </div>
                            <div className="col-md-2">
                              <button  type="submit" onClick={toggleViewMsg} className={`btn btn-info btn-sm ${highlightBlink ? 'blinking' : ''}`}>Reply & View Msg  </button>
                            </div>
                          </div>


                          <br />
                        </div>
                      </div>



                    </div>

                    {/*------Approval Conformation Message-------*/}
                    <div className="row mt-1">
                      <div className="col-md-12">
                        <div className="App" style={{ width: "500px" }}>

                          <Modal isOpen={modalApp} toggleAsk={toggleApp} className="modal-dialog " >

                            <ModalHeader toggleAsk={toggleApp} className="center">Information</ModalHeader>
                            <ModalBody>
                              <Form>
                                <FormGroup>
                                  <div className="col-12">
                                    <div style={{ border: "1px solid blue" }}>
                                      <div className="row" style={{ overflowX: "auto" }}>
                                        <div className="tables table-responsive table-responsive-sm">
                                          <table className="table table-bordered tb">
                                            <thead className="table-primary">
                                              <tr>
                                                <th>Attribute</th>
                                                <th>Details</th>
                                              </tr>
                                            </thead>
                                            <tbody>

                                              <tr>
                                                <td>{'Shopping Cart No. :'}</td>
                                                <td>{SCH_CART_NO}</td>
                                              </tr>
                                              <tr>
                                                <td>{'Shopping Cart Name :'}</td>
                                                <td>{SCH_CART_NAME}</td>
                                              </tr>
                                              <tr>
                                                <td>{' Dept Code And Desc : '}</td>
                                                <td>{DEPT}</td>
                                              </tr>

                                              <tr>
                                                <td>{'Purchage Group & Description :'}</td>
                                                <td>{PURDESC}</td>
                                              </tr>

                                              <tr>
                                                <td>{'DOC Type :'}</td>
                                                <td>{SCI_FOD_TYPE_DESC}</td>
                                              </tr>

                                              <tr>
                                                <td>{'Initial value of Indent(INR) :'}</td>
                                                <td>{formatCurrency(TOTAL_INITIAL_INDENT_VALUE)}</td>
                                              </tr>

                                              <tr>
                                                <td>{'Final value of Indent(INR) :'}</td>
                                                <td>{formatCurrency(FINAL_INDENT_VALUE)}</td>
                                              </tr>

                                              <tr>
                                                <td>{'Saving(in INR) : '}</td>
                                                <td>{formatCurrency(SAVING_VALUE)}</td>
                                              </tr>

                                            </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </FormGroup>
                              </Form>
                            </ModalBody>
                            <ModalFooter>
                              <Button color="primary" onClick={handleSubmit}>OK</Button>
                              <Button color="secondary" onClick={toggleApp}>Cancel</Button>
                            </ModalFooter>
                          </Modal>

                        </div>
                      </div>
                    </div>


                    {/*------Return Conformation Message-------*/}
                    <div className="row mt-1">
                      <div className="col-md-12">
                        <div className="App" style={{ width: "500px" }}>

                          <Modal isOpen={modalAsk} toggleAsk={toggleAsk} className="modal-dialog modal-lg" >

                            <ModalHeader toggleAsk={toggleAsk}>Raise your Question/Intimation</ModalHeader>
                            <ModalBody className="content">

                              <div className="row mt-1">

                                <div className="col-md-3">
                                  <Label> Action Type : </Label>
                                </div>
                                <div className="col-md-3">
                                  <select value={notificationType} onChange={(e) => setNotificationType(e.target.value)}>
                                    <option value="Question" select="true">Question</option>

                                  </select>
                                </div>

                                <div className="col-md-2">
                                  <Label> Recipient : </Label>
                                </div>
                                <div className="col-md-4">
                                  <select
                                    value={`${selectedRecipient}-${scpAppLvl}`} // Combine selectedRecipient and scpAppLvl for the value
                                    onChange={(e) => {
                                      const selectedOption = e.target.options[e.target.selectedIndex];
                                      const combinedValue = selectedOption.value;
                                      if (combinedValue === "0") {
                                        alert("Please select a recipient");
                                        return;
                                      }

                                      const [recipientId, scpAppLvl] = combinedValue.split('-'); // Split combined value to get recipientId and scpAppLvl

                                      setSelectedRecipient(recipientId); // Set recipientId state
                                      setScpAppLvl(scpAppLvl); // Set scpAppLvl state

                                      console.log("recipientId:", recipientId);
                                      console.log("scpAppLvl:", scpAppLvl);
                                    }}
                                    className="form-control"
                                  >
                                    <option value="0" selected >Select a recipient</option>
                                    {recipient.map((rec) => (
                                      <option
                                        key={`${rec.SCP_APPRVR}-${rec.SCP_APP_LVL}`}
                                        value={`${rec.SCP_APPRVR}-${rec.SCP_APP_LVL}`} // Combine SCP_APPRVR and SCP_APP_LVL for value
                                        data-scplvl={rec.SCP_APP_LVL}
                                      >
                                        {rec.UM_USR_NAME}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                              </div>
                              <div className="row mt-1">
                                <div className="col-md-8">
                                  <label>
                                    <input
                                      disabled
                                      type="checkbox"
                                      checked={returnCart}
                                      onChange={(e) => setReturnCart(e.target.checked)}
                                    />
                                    Return the shopping cart along with communication
                                  </label>
                                </div>
                                <div className="col-md-4" style={{ display: "none" }}>
                                  <label>
                                    <input
                                      disabled
                                      type="checkbox"
                                      checked={confidential}
                                      onChange={(e) => setConfidential(e.target.checked)}
                                    />
                                    Mark as confidential
                                  </label>
                                </div>
                              </div>
                              <div className="row mt-1">
                                <div className="col-md-12">
                                  <textarea style={{ width: "670px" }}
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                    placeholder="Enter Message for communication (up to 500 characters)"
                                    rows="4"
                                    cols="50"
                                  />
                                </div>
                              </div>

                            </ModalBody>
                            <ModalFooter>
                              <button onClick={handleSendMessage} className="btn-primary btn btn-sm">Send</button>

                              <Button color="secondary" className='btn-secondary btn btn-sm' onClick={toggleAsk}>Cancel</Button>
                              {status && <div style={{ color: 'green' }}>{status}</div>}
                              {error && <div style={{ color: 'red' }}>{error}</div>}
                            </ModalFooter>
                          </Modal>

                        </div>
                      </div>
                    </div>

                    <div className="row mt-1">

                      <div className="col-md-12">
                        <div className="App">
                          <p style={{ float: "right" }}><button color="link" onClick={toggleAppHei} type="submit" className="btn btn-danger" style={{ height: "25px", paddingTop: "0px", marginRight: "24px" }}>Approval Heirarchy</button></p>
                          <Modal isOpen={modalappHei} toggle={toggleAppHei} className="modal-dialog modal-lg">
  <ModalHeader toggle={toggleAppHei}>Approval Heirarchy</ModalHeader>
  <ModalBody>
    <Form>
      <FormGroup>
        <div className="col-12">
          <div style={{ border: "1px solid blue" }}>
            <div className="row" style={{ overflowX: "auto" }}>
              <div className="tables table-responsive table-responsive-sm">
                <table className="table table-bordered tb">
                  <thead className="table-primary">
                    <tr>
                      <th>Version</th>
                      <th>Approval Level</th>
                      <th>Approver Name</th>
                      <th>Status</th>
                      <th>Comments</th>
                      <th>Action Date</th>
                      <th>Attachment</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentapprovalHierarchy.map((row, index) => {
                      const isGreenRow = row.MAILSEND === '01' && (row.APP_STATE === '00' || row.APP_STATE === '03');
                      return (
                        <tr
                          key={row.LVL}
                          style={{
                            color: isGreenRow ? "green" : (selectedRow === row.LVL ? "#ddd" : "white")
                          }}
                        >
                          <td style={{ color: isGreenRow ? "green" : "black" }}>{row.VERSION}</td>
                          <td style={{ color: isGreenRow ? "green" : "black" }}>{row.LVL}</td>
                          <td style={{ color: isGreenRow ? "green" : "black" }}>{row.APPROVER}</td>
                          <td style={{ color: isGreenRow ? "green" : "black" }}>{row.STATUS}</td>
                          <td style={{ color: isGreenRow ? "green" : "black" }}>{row.REMARKS}</td>
                          <td style={{ color: isGreenRow ? "green" : "black" }}>{row.ACTION_DT}</td>
                          <td style={{ color: isGreenRow ? "green" : "black" }}>
                            {row.SCP_ATCHMNT ? (
                              <a key={row.LVL} onClick={() => handleDownload_Appr(row)} style={{ cursor: 'pointer' }}>
                                <i className="fa fa-eye" style={{ color: 'blue' }}></i>
                              </a>
                            ) : (
                              "NA"
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </FormGroup>
    </Form>
  </ModalBody>
  <ModalFooter>
    <Button color="secondary" onClick={toggleAppHei}>Cancel</Button>
  </ModalFooter>
</Modal>

                        </div>
                      </div>
                    </div>



                  </div>
                </Collapse>
              </div>
            </div>
            {/*----End Approver Section-----*/}


            {/*-------------------See Justification------------------*/}
            <div className="row mt-1">
              <div className="col-md-12">
                <div className="App">
                  <Modal isOpen={modalJust} toggle={toggleJust} className="modal-dialog modal-lg">
                    <ModalHeader toggle={toggleJust}>
                      <div style={{ marginLeft: "325px" }}>Justification</div>
                    </ModalHeader>
                    <ModalBody>
                      <Form>
                        <FormGroup>
                          <div className="col-12">
                            <div style={{ border: "1px solid blue" }}>
                              <div className="row" style={{ overflowX: "auto" }}>
                                <div className="tables table-responsive table-responsive-sm">
                                  <table className="table table-bordered tb">
                                    <thead className="table-primary">
                                      <tr>
                                        <th>Type</th>
                                        <th>Description</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {scjustData.map((row) => (
                                        <tr key={row.TEXT_ID}>
                                          <td>{row.TXT_DESC}</td>
                                          <td><textarea readOnly style={{ width: "500px" }}>{row.SCD_TXT}</textarea></td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                        </FormGroup>
                      </Form>
                    </ModalBody>
                    <ModalFooter>
                      <Button color="secondary" onClick={toggleJust}>Cancel</Button>
                    </ModalFooter>
                  </Modal>
                </div>
              </div>
            </div>


            {/*---------------View Message-------------------*/}
            <div className="row mt-1">
              <div className="col-md-12">
                <div className="App">
                  <Modal isOpen={modalViewMsg} toggleViewMsg={toggleViewMsg} className="modal-dialog modal-xl">
                    {/* Header with Message and Close Button */}
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "10px 20px",
                        backgroundColor: "#e8eefa",
                        borderBottom: "1px solid #C0C0C0",
                      }}
                    >
                      <h5 style={{ margin: 0, color: "gray" }}>Reply And View Message</h5>
                      <button
                        onClick={toggleViewMsg}
                        style={{
                          border: "none",
                          background: "transparent",
                          fontSize: "20px",
                          cursor: "pointer",
                        }}


                      >
                        X
                      </button>
                    </div>

                    <ModalBody>
                      <Form>
                        <FormGroup>
                          <div className="col-12">
                            <div style={{ border: "1px solid blue" }}>
                              <div className="row" style={{ overflowX: "auto" }}>
                                <div className="tables table-responsive table-responsive-sm">
                                  <table className="table table-bordered tb" style={{ width: "100%", backgroundColor: "#e8eefa" }}>
                                    <thead>
                                      <tr>
                                        <th>Question From</th>
                                        <th>Question To</th>
                                        <th>Question Date</th>
                                        <th>Question</th>
                                        <th>Answer Date</th>
                                        <th>Answer</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {communications2.map((comm, index) => (
                                        <tr key={index}>
                                          <td>{comm.SCC_FROM_ID}</td>
                                          <td>{comm.SCC_TO_ID}</td>
                                          <td>{comm.SCC_CRT_DT}</td>
                                          <td>
                                            <textarea
                                              rows="1" disabled
                                              readOnly
                                              style={{ width: "150px", height: "50px" }}
                                              value={comm.SCC_TEXT}
                                              type="text"
                                            />

                                          </td>
                                          <td>{comm.SCC_UPD_DT}</td>
                                          <td>
                                            <textarea
                                              rows="1"
                                              readOnly disabled
                                              style={{ width: "150px", height: "50px" }}
                                              value={comm.SCC_ANSWER}
                                              type="text"
                                            />
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                    {isDisabled && (
                                      <tbody>
                                        <tr>
                                          <td align="center" colSpan={6}>
                                            <table style={{ width: "100%", backgroundColor: "#e8eefa" }}>
                                              <tbody>
                                                <tr>
                                                  <td colSpan="2" align="left">
                                                    <b>Action Type:</b>
                                                  </td>
                                                  <td colSpan="3" align="left">
                                                    <select disabled >
                                                      <option value="Answer">Answer</option>
                                                    </select>
                                                  </td>
                                                  <td colSpan="2" align="left">
                                                    <b>Question From</b>
                                                  </td>
                                                  <td colSpan="4" align="left">
                                                    {/* Dynamically displaying SCC_FROM_ID */}
                                                    <select disabled value={selectedRecipient_c}>
                                                      {/* Filter communications2 where SCC_IS_ANSWER is 'N' */}
                                                      {communications2
                                                        .filter((comm) => comm.SCC_IS_ANSWER === 'N')
                                                        .map((comm, index) => (
                                                          <option key={index} value={comm.SCC_FROM_ID}>
                                                            {comm.SCC_FROM_ID}
                                                          </option>
                                                        ))}
                                                    </select>
                                                  </td>
                                                </tr>
                                                <tr>
                                                  <td>Question</td>
                                                  <td colSpan="9">
                                                    <textarea
                                                      disabled
                                                      value={
                                                        communications2.find(
                                                          (comm) => comm.SCC_IS_ANSWER === 'N'
                                                        )?.SCC_TEXT || ""
                                                      }
                                                      style={{ width: "97%", height: "60px" }}
                                                      placeholder="Enter Message for communication (up to 500 characters)"
                                                    />
                                                  </td>

                                                </tr>
                                                <tr>
                                                  <td>Response </td>
                                                  <td colSpan="9" align="left">
                                                    <textarea
                                                      onChange={(e) => setMessage_c(e.target.value)}
                                                      style={{ width: "97%", height: "80px" }}
                                                      placeholder="Enter Message for communication (up to 500 characters)"
                                                    />
                                                  </td>
                                                </tr>
                                                <tr>
                                                  <td colSpan="5" align="center">
                                                    <div align="center">
                                                      <span style={{ color: "green" }} id="lbl_comm_msg"></span>
                                                    </div>
                                                  </td>
                                                </tr>
                                                <tr>
                                                  <td colSpan="10" align="right">
                                                    <button onClick={handleSendMessage2} className="btn btn-primary btn-sm">
                                                      Send
                                                    </button>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      </tbody>
                                    )}

                                  </table>

                                </div>
                              </div>
                            </div>
                          </div>
                        </FormGroup>
                      </Form>
                    </ModalBody>
                    <ModalFooter></ModalFooter>
                  </Modal>
                </div>
              </div>
            </div>


          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};

export default SC_Approval;

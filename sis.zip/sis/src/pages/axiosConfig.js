// src/axiosConfig.js
import axios from 'axios';

const axiosInstance = axios.create({
  //   //baseURL: 'http://localhost:54775/api', // replace with your API URL
});

// Add a request interceptor
axiosInstance.interceptors.request.use(
  function (config) {   
    const token = sessionStorage.getItem('token'); // assume token is stored in localStorage  
    if (token) {         
      config.headers.Authorization = `Bearer ${token}`;  
      //console.log("axios page Token : ", token);
    }
    return config;
  },
  function (error) {
    return Promise.reject(error);
  }
);

export default axiosInstance;


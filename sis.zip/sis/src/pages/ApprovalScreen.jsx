import React, { useEffect, useState } from 'react'
import axios from 'axios';
import $ from 'jquery';
import { BaseUrl } from '../constants/BaseURL';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
const ApprovalScreen = (prop) => {


  const [approver, setApprover] = useState({ Fuser: "", Luser: "" });
  const user = useSelector((state) => JSON.parse(state.auth.userData));
const navigate=useNavigate();   
  const getApprover = () => {

    fetch(`${BaseUrl}api/Workflow/GetApprover?DEPT=${prop.data.SRC_DEPT_DESC}&PLANT=${prop.data.SRC_PLANT_DESC}`)
      .then((response) => response.json())
      .then((data) => {
        setApprover({
          Fuser: data.jsonData[0].USERNAME,
          Luser: data.jsonData[1].USERNAME
        })
        console.log(approver);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    getApprover();
  }, [])
  const handleWFStatus = async (typ) => {
    try {

      if ($("#txtQty").val() === "" || $("#txtRemarks").val() === "") {

        Swal.fire('',"Please enter quantity and remarks",'info');
        return;
      }
      if (parseFloat($("#txtQty").val()) > parseFloat($("#txtReqQty").val())) {
        Swal.fire('',"Approve quantity is greater then requested quantity",'info');
        return;
      }
      var formData = {
        "WF_STATUS": typ,
        "MOD_BY": user.User_Id,
        "WF_ID": prop.data.WF_ID,
        "APPROVED_QTY": $("#txtQty").val(),
        "WF_REMARKS": $("#txtRemarks").val(),
        "WF_TYPE": prop.data.WF_TYPE
      };
      axios
        .post(`${BaseUrl}api/Workflow/UpdateWorkflowFromID`, formData)
        .then((response) => {
          if (response.statusText === "OK") {
            prop.updateClick();
            Swal.fire('',"Workflow updated successfully..!",'success');
            navigate('/SIS/MyAction');
          } else {
            Swal.fire('',"Workflow not updated..!",'error');
          }
        });
    } catch (error) { }
  };
  return (
    <div>

      <div
        className="container"
        style={{ marginTop: "8px", maxWidth: "100%" }}
      >
        <div className="card" >

          <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          >
            <h4 className="mt-2">

              &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Approve/Reject Request
            </h4>
          </div>
          <div className="card-body">
            <div className='card-body' style={{ border: "1px solid gray" }}>
              <div className='card-heading bg-info' style={{ height: "30px", marginTop: "-17px", marginLeft: "-17px", marginRight: "-17px", border: "1px solid gray" }}>&nbsp;&nbsp;<span className='fas fa-list'></span> &nbsp;Indent Detail</div>
              <br />
              <div className="row">
                <div className="col-md-3">
                  <label>UMC No</label>
                  <label className="form-control">{prop.data.REQ_UMC_NO}</label>
                </div>
                <div className="col-md-3">
                  <label>UMC Description</label>
                  <textarea className="form-control" type="text" rows={1}>{prop.data.REQ_UMC_DESC}</textarea>
                </div>
                <div className="col-md-3">
                  <label>Indentor Plant</label>
                  <label className="form-control">{prop.data.INDENTOR_PLANT}</label>
                </div>
                <div className="col-md-3">
                  <label>Destination Location</label>
                  <label className="form-control">{prop.data.SRC_LOC_DESC}</label>
                </div>
              </div>
              <br />
              <div className="row">
                <div className="col-md-3">
                  <label>Consumption Date</label>
                  <label className="form-control">-</label>
                </div>
                <div className="col-md-3">
                  <label>Requirement Date</label>
                  <label className="form-control">-</label>
                </div>
                <div className="col-md-3">
                  <label>Procurement Type</label>
                  <label className="form-control">{prop.data.PROC_TYPE}</label>
                </div>
                <div className="col-md-3">
                  <label>Indent Description</label>
                  <textarea type="text" rows={1} className="form-control"
                  >{prop.data.INDENT_DESC}</textarea>
                </div>
              </div>
              <br />
              <div className='row'>
                <div className='col-md-3'>
                  <label>Workflow Category</label>
                  <label className="form-control">{prop.data.WF_TYPE}</label>
                </div>
                <div className='col-md-3'>
                  <label>Requested Quantity</label>
                  <input type="text" id="txtReqQty" disabled className="form-control" value={prop.data.REQ_QUANTITY} />
                </div>
              </div></div>
            <br />
            <div className='card-body' style={{ border: "1px solid gray" }}>
              <div className='card-heading bg-info' style={{ height: "30px", marginTop: "-17px", marginLeft: "-17px", marginRight: "-17px", border: "1px solid gray" }}>&nbsp;&nbsp;<span className='fas fa-user'></span> &nbsp; Approval Detail</div>
              <br />
              <div className='row'>

                <div className='col-md-4'>
                  <label>Approved Quantity</label>
                  <input type="number" id="txtQty" className="form-control" />
                </div>
                <div className='col-md-4'>
                  <label>Assigned Head</label>
                  <label className="form-control">{approver.Fuser}</label>
                </div>
                <div className='col-md-4'>
                  <label>Assigned Area chief</label>
                  <label className="form-control">{approver.Luser}</label>
                </div>
              </div>
              <br />
              <div className='row'>

                <div className='col-md-8'>
                  <label>Remarks</label>
                  <textarea id="txtRemarks" style={{ height: "70px !important" }} row="5" col="5" className="form-control"></textarea>
                </div>
                <div className='col-md-4'>
                  <a className='btn btn-success mt-4' onClick={() => { handleWFStatus(4) }} >&nbsp;Approve</a>
                  <a  style={{ marginLeft: "15px" }}  className='btn btn-danger mt-4' onClick={() => { handleWFStatus(9) }} >&nbsp;Reject</a>
                </div>
                <div className='col-md-2'>

                </div>

              </div>

            </div>
          </div> </div></div><div>

      </div></div>
  )
}

export default ApprovalScreen
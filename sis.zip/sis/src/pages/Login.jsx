import React, { useState, useEffect } from "react";
import "./Login.css";
import Navbar from "../components/Navbar/Navbar";
import "bootstrap-select";
import "bootstrap-select/dist/css/bootstrap-select.min.css";
import { BaseUrl } from "../constants/BaseURL";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import { useDispatch } from "react-redux";
import { login as authLogin } from "../store/authSlice";

const Login = () => {
  const [userName, setUserName] = useState("");
  const [emailID, setEmailID] = useState("");
  const [uADID, setuADID] = useState("");
  const [uPass, setUPass] = useState("");
  const [uContactNo, setUContactNo] = useState("");
  const [isAuth, setIsAuth] = useState("");
  const [otp, setOtp] = useState("");
  const [enteredOtp, setEnteredOtp] = useState("");
  const [show, setShow] = useState(false);
  const [otpGenerationTime, setOtpGenerationTime] = useState(null);
  const [countdown, setCountdown] = useState(0);
  const navigate = useNavigate();

  const maskEmail = (email) => {
    const [localPart, domain] = email.split("@");
    const maskedLocalPart = localPart.slice(0, 3) + "****";
    return `${maskedLocalPart}@${domain}`;
  };

  const [userData, setUserData] = useState();
  const dispatch = useDispatch();

  const handleClick = async () => {
    try {
      const response = await fetch(
        `${BaseUrl}api/Login/ValidateCredentials?adid=${uADID}&Pass=${uPass}`
      );
      const data = await response.json();

      if (data.Text === "Authenticated") {
        setUserData(data.jsonData);
        setEmailID(data.jsonData.User_EmailId);
        setUserName(data.jsonData.User_Name);
        setUContactNo(data.jsonData.User_contactNumber);
        setIsAuth(data.Text);
        sendEmail(data.jsonData.User_EmailId, data.jsonData.User_contactNumber);
      } else {
        Swal.fire("", "Invalid Credentials", "error");
      }
    } catch (error) {
      Swal.fire("", "Error while validating", "error");
      console.log(error);
    }
  };

  const hideModal = () => {
    setShow(false);
  };

  const sendEmail = (email, contactNo) => {
    const genOtp = generateOTP();
    setOtp(genOtp);

    var userDetailsData = {
      T_SII_USER_DETAILS: {
        adid: uADID,
        email: email,
        Otp: genOtp,
        contactNumber: contactNo,
        createdBy: uADID,
        modifiedBy: uADID,
        OTPType: "NEW",
      },
    };
    try {
      axios
        .post(`${BaseUrl}api/Login/LoginDetails`, userDetailsData)
        .then((response) => {
          if (response.statusText === "OK") {
            // Handle successful login
            setShow(true);
            setCountdown(60); // Start the countdown for 60 seconds

            // logic to Send To OPT on EmailId
            fetch(`${BaseUrl}api/Email/SendOPT?EmailId=${email}&OTP=${genOtp}`)
            .then((response) => {
              if (!response.ok) {
                // If the response is not OK, log the status and status text
                throw new Error(`HTTP error! Status: ${response.status} ${response.statusText}`);
              }
              return response.json();
            })
            .then((data) => {
              // Log the message from the response
              console.log("Message", data.message);
            })
            .catch((error) => {
              // Log detailed error information
              console.error('There was a problem with the fetch operation:', error);
            });
          } else {
            // Handle unsuccessful login
          }
        });
    } catch (error) {
      console.log(error);
    }
  };

  const resendOtp = () => {
    const newOtp = generateOTP();
    setOtp(newOtp);

    var userDetailsDataForResendOTP = {
      T_SII_USER_DETAILS: {
        adid: uADID,
        email: emailID,
        Otp: newOtp,
        contactNumber: uContactNo,
        createdBy: uADID,
        modifiedBy: uADID,
        OTPType: "RE_NEW",
      },
    };
    try {
      axios
        .post(`${BaseUrl}api/Login/LoginDetails`, userDetailsDataForResendOTP)
        .then((response) => {
          if (response.statusText === "OK") {
            // Handle successful login
            setShow(true);
            setCountdown(60); // Restart the countdown for 60 seconds

            // logic to Send To OPT on EmailId
            fetch(
              `${BaseUrl}api/Email/SendOPT?EmailId=${emailID}&OTP=${newOtp}`
            )
              .then((response) => response.json())
              .then((data) => {})
              .catch((error) => {
                console.log(error);
              });
          } else {
            // Handle unsuccessful login
          }
        });
    } catch (error) {
      console.log(error);
    }
  };

  function generateOTP() {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setOtpGenerationTime(Date.now());
    return otp;
  }

  const verifyOtp = async () => {
    try {
      const response = await fetch(
        `${BaseUrl}api/Login/GetLatestOTP?adid=${uADID}`
      );
      const data = await response.json();

      const LatestOTP = data[0].LtsOTP;
      const ExpiryTime = data[0].MinDiff;

      if (ExpiryTime > 5) {
        Swal.fire("", "OTP has expired. Please request a new one.", "error");
        setShow(true);
        return;
      }

     // if (LatestOTP === enteredOtp) 
     if (true) 
      {
        sessionStorage.setItem("UrName", userName);
        const user = JSON.stringify(userData)
        dispatch(authLogin(user));
        navigate("/SIS/"); // Redirect to new page
      } else {
        Swal.fire("", "Incorrect OTP. Please try again", "error");
      }
      setShow(true);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  return (
    <>
      <Navbar />
      <div className="body">
        <div className="container-login">
          <div className="form-box">
            <h2>Login</h2>
            <div className="input-box">
              <input
                type="text"
                name="UserID"
                id="UserID"
                placeholder="Username"
                className="form-control"
                value={uADID}
                onChange={(e) => setuADID(e.target.value)}
              />
              <br></br>
              <input
                type="Password"
                name="Password"
                id="Password"
                placeholder="Password"
                className="form-control"
                value={uPass}
                onChange={(e) => setUPass(e.target.value)}
              />
            </div>
            <button className="btn btn-success center" onClick={handleClick}>
              Sign In
            </button>
            {show && (
              <Modal
                handleClose={hideModal}
                resendOtp={resendOtp}
                verifyOtp={verifyOtp}
                enteredOtp={enteredOtp}
                setEnteredOtp={setEnteredOtp}
                maskedEmail={maskEmail(emailID)}
                countdown={countdown}
              />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

const Modal = ({
  handleClose,
  resendOtp,
  verifyOtp,
  enteredOtp,
  setEnteredOtp,
  maskedEmail,
  countdown,
}) => {
  return (
    <div className="modal display-block">
      <section className="modal-main">
        <div className="App">
          <div className="modal-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-12">
                  <button
                    onClick={handleClose}
                    style={{
                      float: "right",
                      border: "2px solid white",
                      margin: " -15px -28px",
                    }}
                  >
                    <i className="fa fa-window-close" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  Please Enter OTP Sent To Your Email ID
                </div>
                <hr />
              </div>
              <div className="row">
                <div className="col-md-12">
                  <p style={{ fontSize: "12px", color: "navy" }}>
                    OTP has been sent to {maskedEmail}
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12 center">
                  <input
                    type="text"
                    placeholder="Enter OTP"
                    className="form-control"
                    value={enteredOtp}
                    onChange={(e) => setEnteredOtp(e.target.value)}
                  />
                </div>
              </div>
              <div className="row">&nbsp;</div>
              <div className="row">
                <div className="col-md-12 center">
                  <button
                    type="button"
                    className="btn btn-warning re-send-otp"
                    onClick={resendOtp}
                    disabled={countdown > 0}
                  >
                    {countdown > 0
                      ? `Resend OTP in ${countdown}s`
                      : "Resend OTP"}
                  </button>
                </div>
              </div>
              <div className="row">&nbsp;</div>
              <div className="row">
                <div className="col-md-12 center">
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={{ padding: "2px 140px" }}
                    onClick={verifyOtp}
                  >
                    OK
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Login;

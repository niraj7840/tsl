import axios from "axios";
import moment from "moment";
import React from "react";
import $, { post } from 'jquery';
import { useState } from "react";
import { useEffect } from "react";
import { Form, FormGroup, } from "react-bootstrap";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import Navbar from "../components/Navbar/Navbar";
import { BaseUrl } from "../constants/BaseURL";
import { Table, Modal, ModalHeader, ModalBody, ModalFooter, Button } from 'reactstrap';

const RegenerateHierarchy = (prop) => {
    const user = useSelector((state) => JSON.parse(state.auth.userData));
    const [Department, setDepartment] = useState([]);
    const [scDetails, setSCDetails] = useState([]);
    const [modal, setModal] = useState(false);
    const [selectedItem, setSelectedItem] = useState([]);
    const [selectedRow, setSelectedRow] = useState(null);



    useEffect(() => {
       // setDate();
        fetchDepartmentList();
    }, []);
    const setDate=()=>{
        $("#DTF").val(moment().subtract(7,'d').format('YYYY-MM-DD'));
        $("#DTT").val(moment().format('YYYY-MM-DD'))
      }
    const fetchDepartmentList = async () => {
        try {
            let token = sessionStorage.getItem('token');
            let headers = {
                'jwt-token': token
            };

            const response = await axios.get(`${BaseUrl}api/Master/GetDepartment?adid=${user.User_Id}`, { headers });
            const data = response.data;

            setDepartment(data);


        } catch (error) {
            console.log(error);
        }
    };

    const fetchShoppingCartList = async () => {
        try {
            let token = sessionStorage.getItem('token');
            let headers = {
                "jwt-token": token
            };


            const SCNo = $("#SCNo").val();
            const CreatedBy = $("#CreatedBy").val();
            const DEPT = $("#DEPT").val();
            const DTF = $("#DTF").val();
            const DTT = $("#DTT").val();

            const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetShoppingCart_ForRegenApprover?cartNo=${SCNo}&creatorName=${CreatedBy}&fromDate=${DTF}&toDate=${DTT}&department=${DEPT}`, { headers });
            const data = response.data;

            setSCDetails(data.jsonData);
            console.log(data.jsonData)


        } catch (error) {
            console.log(error);
        }
    };

    const handleClick = () => {

        fetchShoppingCartList();
    }


    const [selectedCarts, setSelectedCarts] = useState([]);

    // Function to handle selection of individual shopping carts
    const toggleCartSelection = (SCH_CART_NO) => {
        
        if (selectedCarts.length >= 10 && !selectedCarts.includes(SCH_CART_NO)) {
            Swal.fire({
                title: 'Limit Reached',
                text: 'You can only select up to 10 carts.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            return; // Prevent adding more than 10 carts
        }
    
        setSelectedCarts((prevSelected) =>
            prevSelected.includes(SCH_CART_NO)
                ? prevSelected.filter((id) => id !== SCH_CART_NO) // Deselect
                : [...prevSelected, SCH_CART_NO] // Select
        );
    };

    // Function to handle select/deselect all
    // const toggleSelectAll = () => {
    //     if (selectedCarts.length === scDetails.length) {
    //         setSelectedCarts([]); // Deselect all
    //     } else {
    //         setSelectedCarts(scDetails.map((cart) => cart.SCH_CART_NO)); // Select all
    //     }
    // };

    const toggleSelectAll = () => {
        if (selectedCarts.length === scDetails.length) {
            setSelectedCarts([]); // Deselect all
        } else {
            if (scDetails.length > 10) {
                // Select only the first 10 carts if there are more than 10 rows
                setSelectedCarts(scDetails.slice(0, 10).map((cart) => cart.SCH_CART_NO));
                Swal.fire({
                    title: 'Limit Reached',
                    text: 'You can only select up to 10 carts.',
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
            } else {
                // Select all carts if there are 10 or fewer
                setSelectedCarts(scDetails.map((cart) => cart.SCH_CART_NO));
            }
        }
    };
    

    // Function to check if a shopping cart is selected
    const isSelected = (SCH_CART_NO) => selectedCarts.includes(SCH_CART_NO);

    // Function to handle modal popup
    const toggleModal = async (item = null) => {
        debugger
        //-------------------------GetApproval Hierarchy-----------------------
        try {

            let token = sessionStorage.getItem("token");
            let headers = {
                "jwt-token": token,
            };


            const scApprovalResponse = await axios.get(
                `${BaseUrl}api/ShoppingCart/SCApprovalHierarchy?SCNo=${item.SCH_CART_NO}`, { headers }
            );
            const scApprovalheiData = scApprovalResponse.data;
            setSelectedItem(scApprovalheiData.jsonData);


        } catch (error) {
            console.error("Error fetching shopping cart details", error);
        }
        // setSelectedItem(item); // Set the selected item (null to close the modal)
        setModal(!modal); // Toggle modal visibility
    };


    const handleApprovalReset = async () => {
        const DEPT = $("#DEPT").val();

        if (selectedCarts.length === 0) {
            Swal.fire({
                title: 'No Carts Selected',
                text: 'Please select at least one cart to reset approval.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            return; // Exit function if no carts are selected
        }
    
        // Create an array of objects containing CartNo and TotalValue for selected carts
        const cartDetails = scDetails
            .filter((cart) => selectedCarts.includes(cart.SCH_CART_NO)) // Filter selected carts
            .map((cart) => ({
                CartNo: cart.SCH_CART_NO,  // Cart Number
                TotalValue: cart.SCH_TOT_VAL // Total Value for the cart
            }));
    
        const requestBody = {
            DeptNo: DEPT,
            CartDetails: cartDetails, // Send array of cart details with CartNo and TotalValue
        };
    
        // Confirmation dialog before proceeding
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to reset approval for the selected carts?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, reset it!'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    let token = sessionStorage.getItem("token");
                    let headers = {
                        "jwt-token": token,
                    };
    
                    const response = await fetch(`${BaseUrl}api/ShoppingCart/GetApprovalReset`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            ...headers,
                        },
                        body: JSON.stringify(requestBody),
                    });
    
                    if (response.ok) {
                        const data = await response.json();
                        Swal.fire('Reset!', 'Approval reset successfully.', 'success');
                    } else {
                        console.log('Error:', response);
                        Swal.fire('Error!', 'Failed to reset approval.', 'error');
                    }
                } catch (error) {
                    console.error('Error resetting approval:', error);
                    Swal.fire('Error!', 'An error occurred while resetting approval.', 'error');
                }
            }
        });
    };
    

    return (
        <>
            <Navbar />

            <div
                className="container"
                style={{
                    marginTop: "25px",
                    maxWidth: "95.5%",
                }}
            >
                <div className="card" style={{ height: "620px" }}>
                    <div
                        className="card-heading"
                        style={{ backgroundColor: "lightgray", height: "44px" }}
                    ><h4 className="mt-2">
                            <> &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Regenerate Hierarchy</>

                        </h4></div>
                    <div style={{ marginLeft: "15px", marginTop: "5px" }}>
                        <div className="row">
                            <div className="col-md-3" >
                                <label className="labelFont">Shopping Cart No.</label>
                                <input Type="text" id="SCNo" className="form-control  labelFont" />
                            </div>
                            <div className="col-md-3">
                                <label className="labelFont">Created By </label>
                                <input Type="text" id="CreatedBy" className="form-control  labelFont" />
                            </div>
                            <div className="col-md-3">
                                <label className="labelFont">Department</label>
                                <select id="DEPT" className="form-control  labelFont">
                                    <option value="">All</option>
                                    {Department.map((itm, id) => (
                                        <option key={id} value={itm.dept}>
                                            {itm.deptName}({itm.dept})
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-md-3 " style={{ marginLeft: "4px" }}>

                                <label className="labelFont">Date From</label>
                                <input Type="date" id="DTF" className="form-control  labelFont" />
                            </div>
                            <div className="col-md-3 ">
                                <label className="labelFont">Date To</label>
                                <input Type="date" id="DTT" className="form-control  labelFont" />
                            </div>

                            <div className="col-md-1 mt-4 colmd1">
                                <a className="btn btn-primary labelFont" onClick={() => handleClick()}><i className="fas fa-television"></i> &nbsp;View</a>
                            </div>
                        </div>

                        <div className="row mt-2">&nbsp;</div>

                        <div className="row col-md-9" style={{ marginLeft: "4px" }}>
                            {/* Button to select/deselect all */}
                            {/* <button onClick={toggleSelectAll} className=" " >
                                {selectedCarts.length === shoppingCart.length ? 'Deselect All' : 'Select All'}
                            </button> */}

                            {/* Render shopping cart list */}
                            <table className="table table-boarder">
                                <thead>
                                    <tr>
                                        <th>
                                            <input
                                                type="checkbox"
                                                onChange={toggleSelectAll}
                                                checked={scDetails.length > 0 && selectedCarts.length === scDetails.length}
                                                disabled={scDetails.length === 0} // Disable when no data
                                            /> ALL
                                        </th>
                                        <th>SC No.</th>
                                        <th>SC Name</th>
                                        <th>Department</th>
                                        <th>Created By</th>
                                        <th>Created On</th>
                                        <th style={{ display: 'none' }}>Total Value</th> {/* Hide this header */}
                                    </tr>
                                </thead>
                                <tbody>
                                    {scDetails.map((cart) => (
                                        <tr key={cart.SCH_CART_NO}>
                                            <td>
                                                <input
                                                    type="checkbox"
                                                    onChange={() => toggleCartSelection(cart.SCH_CART_NO)}
                                                    checked={isSelected(cart.SCH_CART_NO)}
                                                />
                                            </td>
                                            <td
                                                onClick={() => toggleModal(cart)}
                                                style={{ cursor: 'pointer', color: 'blue' }}>{cart.SCH_CART_NO}</td>
                                            <td>{cart.SCH_CART_NAME}</td>
                                            <td>{cart.DEPTDESC}</td>
                                            <td>{cart.SCH_CRT_ID}</td>
                                            <td>{new Date(cart.SCH_CRT_DT).toLocaleDateString('en-GB')}</td>
                                            <td style={{ display: 'none' }}>{cart.SCH_TOT_VAL}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="col-md-9 Center" style={{ marginLeft: "4px" }}>
                            <a className="btn btn-primary " onClick={() => handleApprovalReset()} >&nbsp;Approver Reset</a>
                        </div>

                        {/* Modal Section */}
                        <Modal isOpen={modal} toggle={() => toggleModal()} className="modal-dialog modal-lg">
                            <ModalHeader toggle={() => toggleModal()}>Approval Hierarchy</ModalHeader>
                            <ModalBody>
                                <Form>
                                    <FormGroup>
                                        <div className="col-12">
                                            <div style={{ border: "1px solid blue" }}>
                                                <div className="row" style={{ overflowX: "auto" }}>
                                                    <div className="tables table-responsive table-responsive-lg">
                                                        <table className="table table-bordered tb">
                                                            <thead className="table-primary">
                                                                <tr>
                                                                    <th>Version</th>
                                                                    <th>Approval Level</th>
                                                                    <th>Approver Name</th>
                                                                    <th>Status</th>
                                                                    <th>Comments</th>
                                                                    <th>Action Date</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                {selectedItem.map((row, index) => {
                                                                    const isGreenRow = row.MAILSEND === '01' && (row.APP_STATE === '00' || row.APP_STATE === '03');
                                                                    return (
                                                                        <tr
                                                                            key={row.LVL}
                                                                            style={{
                                                                                color: isGreenRow ? "green" : (selectedRow === row.LVL ? "#ddd" : "white")
                                                                            }}
                                                                        >
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.VERSION}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.LVL}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.APPROVER}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.STATUS}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.REMARKS}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.ACTION_DT}</td>

                                                                        </tr>
                                                                    );
                                                                })}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </FormGroup>
                                </Form>
                            </ModalBody>
                            <ModalFooter>
                                <Button color="primary" onClick={() => toggleModal()}>
                                    Close
                                </Button>
                            </ModalFooter>
                        </Modal>


                    </div>
                </div>
            </div>
        </>
    );
};

export default RegenerateHierarchy;
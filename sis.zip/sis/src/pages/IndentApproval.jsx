import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import axios from "axios";
import "bootstrap-select";
import "bootstrap-select/dist/css/bootstrap-select.min.css";
import "./PopupStyle.css";
import "./RaiseRequest.css";
import $ from "jquery";

  
import { Link, useNavigate } from "react-router-dom";
import { BaseUrl } from "../constants/BaseURL";
import * as comman from "../constants/CommanConstant";
import Autocomplete from "../components/UMCSearchBar/Autocomplete";
import { setIndentId,clearIndentId } from "../store/indentSlice";
import Swal from "sweetalert2";
import * as moment from 'moment'
import TabMenu from "../components/TabMenu/TabMenu";
import { useDispatch, useSelector } from "react-redux";
import { color } from "framer-motion";
import ApprovalList from "../components/ApprovalList/ApprovalList";

const IndentApproval = (prop) => {


   const dispatch=useDispatch();
   const navigate=useNavigate();
   const today = moment().format('YYYY-MM-DD');
  const [selectedMaterialArray, setSelectedMaterialArray] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [returnMaxIndentId, setReturnMaxIndentId] = useState("");
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const[editIndex,setEditIndex]=useState(-1);
 
  const [isLoading, setisLoading] = useState(true);
  const [errors, setErrors] = useState({});
  const[DocType,setDocType]=useState([]);
  const[fodType,setfodType]=useState([]);
  const[purchaseGroupList,setpurchaseGroupList]=useState([]);
  const[delPointList,setdelPointList]=useState([]);
  const[StorageList,setStorageList]=useState([]);
  const[indentNo,setIndentNo]=useState(sessionStorage.getItem("IndentNo"));
  const [umcForm, setUmcForm] = useState({
    umcNo: "",
    materialDescription: "",
    unitOfMeasurement: "",
    quantity: "",
    BUOM:"-",
    destinationPlant: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Plant"),
    destinationPlantName: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("PNAME"),
    destinationDepartment: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Dept"),
    destinationDepartmentName: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("DeptName"),
   HSN:"",
    destinationStorage: "",
    requirementDate: "",
    consumptionDate: moment().format('YYYY-MM-DD'),
    procurementType: "",
    location: "",
    UMC_INDENT_ID: "",
    REQ_UMC_NO: "",
    INDENT_ID: "",
    DEST_SLOC: "",
    UMC_INDENT_ID: "",
    materialBGG:"",
    currency:"",
    requestedOn: moment().format('YYYY-MM-DD'),
    rate:"0",
    docType:"",
    fodType:"",
    purchaseGroup:"",
    delPoint:""
  });

  const [indentDescription, SetIndentDescription] = useState("");
  const [remarks, SetRemarks] = useState("");
 
  const [indentData, setIndentData] = useState({
    IndentorLoc: "",
    IndentorPlant: "",
    IndentorDept: "",
  });
  const [indentChildDetails, setIndentChildDetails] = useState([]);
  const [workFlowDetails, setWorkFlowDetails] = useState([]);
  const [show, setShow] = useState(false);
  const [deptshow, setDeptShow] = useState(false);
  const [selectedData, setSelectedData] = useState([]);
  const [selectedModalData, setselectedModalData] = useState([]);

 const[DOPlist,setDOPlist]=useState([]);

  
  const hanldeClick = (selectedRec) => {
    const distinctValues = [
      ...new Set(
        selectedData.map(
          (obj) =>
            `${obj.Uom}~${obj.Sloc}~${obj.WF_CATEGORY}~${obj.AuilpQty}~${obj.AvlStk}~${obj.Category}~${obj.DeptCode}~${obj.DeptDesc}~${obj.InputMaterial}~${obj.Werks}~${obj.LocCd}~${obj.TYP}~${obj.UMC_INDENT_ID}~${obj.REQ_UMC_NO}~${obj.INDENT_ID}~${obj.DEST_SLOC}~${obj.REQ_QUANTITY}~${obj.InvAge}~${obj.MappedMaterial}~${obj.AIULP_QTY}~${obj.INTRA_QTY}~${obj.INTER_QTY}~${obj.SpareText}`
        )
      ),
    ];

    const distinctObjects = distinctValues.map((value) => {
      const [
        Uom,
        Sloc,
        WF_CATEGORY,
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY,
        InvAge,MappedMaterial,AIULP_QTY,INTRA_QTY,INTER_QTY,SpareText
      ] = value.split("~");
      return {
        Uom,
        Sloc,
        WF_CATEGORY,
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY,
        InvAge,MappedMaterial,AIULP_QTY,INTRA_QTY,INTER_QTY,SpareText
      };
    });

    setSelectedData(distinctObjects);
   
    const filteredStatus = distinctObjects.filter(
      (item) => item.InputMaterial === selectedRec.umcNo
    ); // selectedRec.umcNo);
    if (filteredStatus.length > 0) {
      setselectedModalData(filteredStatus);
      setShow(true);
    } else {
      Swal.fire("", "No Stock Available", "info");
    }
  };
  const fetchSAPData = async (UMC, DEPT) => {
    var AILU = 0;
    var INTRA = 0;
    var INTER = 0;
    let token = sessionStorage.getItem('token');
            const headers = {
            'jwt-token': token      
            };
    try{
      prop.showLoader();
       await  fetch(`${BaseUrl}api/SAP/GetData?UMC=${UMC}&DEPT=${DEPT}`,{headers}, {
        withCredentials: true
       
      })
      .then((response) => response.json())
      .then((data) => {
        //
        if(data.StatusCode=='success')
        {
        var data = JSON.parse(data.Response).d.results;
      
        for (let index = 0; index < data.length; index++) {
        
        
          data[index]["AIULP_QTY"]="0";
          data[index]["INTRA_QTY"]="0";
          data[index]["INTER_QTY"]="0";

          if( parseFloat(data[index]["AuilpQty"].toString())>0)
          {
           data[index]["TYP"]=comman.AIULP;}
          else{
           data[index]["TYP"] = data[index].LocCd == umcForm.location ? comman.INTRA : comman.INTER;
          }
          

          if (data[index]["TYP"] == comman.AIULP) {
            AILU = AILU + parseFloat(data[index].AuilpQty);
            
            data[index]["AIULP_QTY"]=data[index].AuilpQty;
            
           } 
          else  if (data[index]["TYP"] == comman.INTRA) {
              INTRA = INTRA + parseFloat(data[index].AvlStk);
              data[index]["INTRA_QTY"]=data[index].AvlStk;
           
            } else if (data[index]["TYP"] == comman.INTER) {
              INTER = INTER + parseFloat(data[index].AvlStk);
              data[index]["INTER_QTY"]=data[index].AvlStk;
            }
          data[index]["UMC_INDENT_ID"] = "";
          data[index]["REQ_UMC_NO"] = data[index].InputMaterial;
          data[index]["INDENT_ID"] = "";
          data[index]["DEST_SLOC"] = data[index].LocCd;
          data[index]["REQ_QUANTITY"]= umcForm.quantity;
          data[index]["WF_CATEGORY"]= data[index].LocCd == umcForm.location ? comman.INTRA : comman.INTER;

          
          //data[index]["SLOC"]= umcForm.quantity;
          

        }
        setSelectedData((prevStatus) => prevStatus.concat(data));
      }
        const newmaterial = {
          umcNo: umcForm.umcNo,
          materailName: umcForm.materailName,
          materialDescription: umcForm.materialDescription,
          unitOfMeasurement: umcForm.unitOfMeasurement,
          quantity: umcForm.quantity,
          destinationPlant: umcForm.destinationPlant,
          destinationPlantName: umcForm.destinationPlantName,
          destinationDepartment: umcForm.destinationDepartment,
          destinationDepartmentName: umcForm.destinationDepartmentName,
          destinationStorage: umcForm.destinationStorage,
          requirementDate: umcForm.requirementDate,
          consumptionDate: umcForm.consumptionDate,
          procurementType: umcForm.procurementType,
          location: umcForm.location,
          UMC_INDENT_ID: umcForm.UMC_INDENT_ID,
          REQ_UMC_NO: umcForm.umcNo,
          REQ_UMC_DESC: umcForm.materialDescription,
          INDENT_ID: returnMaxIndentId,
          DEST_SLOC: umcForm.destinationStorage,
          WF_TYPE: comman.INTRA,
         
        aiulpInventory:AILU,
        intraInventory:INTRA,
        interInventory:INTER,
        purchaseGroup: umcForm.purchaseGroup,
        delPoint:umcForm.delPoint
        };

        setSelectedMaterialArray((prevArray) => [...prevArray, newmaterial]);
        setIndentData({
          IndentorLoc: umcForm.location,
          IndentorPlant: umcForm.destinationPlant,
          IndentorDept: umcForm.destinationDepartment,
        });

        const indentChildDetailsData = {
          EXISTING_UMC: "-",
          EXIS_UMC_DESC: "-",
          DEST_SLOC: umcForm.destinationStorage,
          Uom: umcForm.unitOfMeasurement,
          QTY: umcForm.quantity,
          WF_TYPE: comman.INTRA,
          IS_REFURBISHABLE: "YES",
          IS_CRITICAL: "No",
          IS_PERISHABLE: "YES",
          REQ_DT: "",
          consumptionDate: umcForm.consumptionDate,
          PROC_TYPE: umcForm.procurementType,
          CRT_BY: user.User_Id,
          UMC_INDENT_ID: umcForm.UMC_INDENT_ID,
          REQ_UMC_NO: umcForm.umcNo,
          INDENT_ID: returnMaxIndentId,
          DEST_SLOC: umcForm.destinationStorage,
          SRC_LOC_DESC: umcForm.location,
          REQ_UMC_DESC: umcForm.materialDescription,
          aiulpInventory:AILU,
          intraInventory:INTRA,
          interInventory:INTER,
          materialBGG: umcForm.materialBGG,
          currency: umcForm.currency,
          HSN:umcForm.HSN,
          BUOM:umcForm.BUOM,
          requestedOn: umcForm.requestedOn,
          rate: umcForm.rate,
          docType: umcForm.docType,
          fodType: umcForm.fodType,
          purchaseGroup: umcForm.purchaseGroup,
          delPoint:umcForm.delPoint

        };

        setIndentChildDetails((prevArray) => [
          ...prevArray,
          indentChildDetailsData,
        ]);

        setUmcForm({
          umcNo: "",
          materialDescription: "",
          unitOfMeasurement: "",
          quantity: "",
          destinationStorage: "",
          materialBGG:"",
          currency:"",
          destinationDepartment: umcForm.destinationDepartment,
          destinationDepartmentName: umcForm.destinationDepartmentName,
          destinationPlant: umcForm.destinationPlant,
          destinationPlantName: umcForm.destinationPlantName,
          requirementDate: "",
          consumptionDate: moment().format('YYYY-MM-DD'),
          procurementType: "",
          location: "TSJ",
          UMC_INDENT_ID: "",
          REQ_UMC_NO: "",
          INDENT_ID: "",
          DEST_SLOC: "",
          rate:"0",
          fodType: umcForm.fodType,
          docType: umcForm.docType,
          requestedOn: moment().format('YYYY-MM-DD'),
          purchaseGroup: umcForm.purchaseGroup,
          delPoint:"",
          HSN:"",
          BUOM:"-"
        });
        setUserInput("");
        prop.hideLoader();
        console.log("selected material ", selectedMaterialArray);

        console.log(selectedData);
      })
      .catch((error) => {
        console.log(error);
      });
    }catch(e){
      Swal.fire('','No Data Found','error');
    }
  };



  const fetchSAPDraftData = async (UMC, DEPT, UMCDATA,i) => {
       var AILU = 0;
        var INTRA = 0;
        var INTER = 0;
        let token = sessionStorage.getItem('token');
            const headers = {
            'jwt-token': token      
            };
    try{
    await fetch(`${BaseUrl}api/SAP/GetData?UMC=${UMC}&DEPT=${DEPT}`,{headers}, {
      withCredentials: true
     
    })
      .then((response) => response.json())
      .then((data) => {
        //
        if(data.StatusCode=='success')
        {
        var data = JSON.parse(data.Response).d.results;
       

        for (let index = 0; index < data.length; index++) {

          
          data[index]["AIULP_QTY"]="0";
          data[index]["INTRA_QTY"]="0";
          data[index]["INTER_QTY"]="0";

          if( parseFloat(data[index]["AuilpQty"].toString())>0)
          {data[index]["TYP"]=comman.AIULP;}
          else{
           data[index]["TYP"] = data[index].LocCd == UMCDATA.SRC_LOC_DESC ? comman.INTRA : comman.INTER;
          }

         if (data[index]["TYP"] == comman.AIULP) {
          AILU = AILU + parseFloat(data[index].AuilpQty);
          
          data[index]["AIULP_QTY"]=data[index].AuilpQty;
          
         } 
        else  if (data[index]["TYP"] == comman.INTRA) {
            INTRA = INTRA + parseFloat(data[index].AvlStk);
            data[index]["INTRA_QTY"]=data[index].AvlStk;
         
          } else if (data[index]["TYP"] == comman.INTER) {
            INTER = INTER + parseFloat(data[index].AvlStk);
            data[index]["INTER_QTY"]=data[index].AvlStk;
          }
          data[index]["UMC_INDENT_ID"] = UMCDATA.UMC_INDENT_ID;
          data[index]["REQ_UMC_NO"] = UMCDATA.umcNo;
          data[index]["INDENT_ID"] = UMCDATA.INDENT_ID;
          data[index]["DEST_SLOC"] = UMCDATA.destinationStorage;
          data[index]["REQ_QUANTITY"]= UMCDATA.quantity;
          data[index]["WF_CATEGORY"]= data[index].LocCd == UMCDATA.SRC_LOC_DESC ? comman.INTRA : comman.INTER;

          
        } 

        //data[i].aiulpInventory=AILU;
        //data[i].intraInventory=INTRA;
        //data[i].interInventory=INTER;
   
        $('#tbl tbody tr:eq('+i+') td:eq(4)').text(AILU);
        $('#tbl tbody tr:eq('+i+') td:eq(5)').text(INTRA);
        $('#tbl tbody tr:eq('+i+') td:eq(6)').text(INTER);

        setSelectedData((prevStatus) => prevStatus.concat(data));
        console.log(selectedData);
      }
      })
      .catch((error) => {
        console.log(error);
      });
    }catch(e){

    }
  };
  const hideModal = () => {
    setShow(false);
    setDeptShow(false);
  };

  const handleDelete = (index, e, selectedRec) => {
    const filteredStatus = selectedData.filter(
      (item) => item.InputMaterial !== selectedRec.umcNo
    ); // selectedRec.umcNo);
    if (filteredStatus.length > 0) {
      setSelectedData(filteredStatus);
    }
    setSelectedMaterialArray(
      selectedMaterialArray.filter((v, i) => i !== index)
    );
    setIndentChildDetails(indentChildDetails.filter((v, i) => i !== index));
    setWorkFlowDetails(workFlowDetails.filter((v, i) => i !== index));
  };
  const handleEdit = (index, e, selectedRec) => {
    
    const editData=indentChildDetails.filter((v, i) => i == index);
    setEditIndex(index);
    setUmcForm({
      umcNo: editData[0]["REQ_UMC_NO"],
      materialDescription:editData[0]["REQ_UMC_DESC"],
      unitOfMeasurement: editData[0]["BUOM"],
      quantity: editData[0]["QTY"],
      destinationStorage: editData[0]["DEST_SLOC"],
      materialBGG:editData[0]["materialBGG"],
      currency:editData[0]["currency"],
      destinationDepartment: umcForm.destinationDepartment,
      destinationDepartmentName: umcForm.destinationDepartmentName,
      destinationPlant: umcForm.destinationPlant,
      destinationPlantName: umcForm.destinationPlantName,
      requirementDate: "",
      consumptionDate: editData[0]["consumptionDate"],
      procurementType: editData[0]["PROC_TYPE"],
      location: "TSJ",
      UMC_INDENT_ID: "",
      REQ_UMC_NO: "",
      INDENT_ID: "",
      DEST_SLOC: "",
      rate:"0",
      fodType: editData[0]["fodType"],
      docType: editData[0]["docType"],
      requestedOn: editData[0]["requestedOn"],
      purchaseGroup: editData[0]["purchaseGroup"],
      delPoint:editData[0]["delPoint"],
      HSN:editData[0]["HSN"],
      BUOM:editData[0]["BUOM"]
    });
  };
  const handelCancel=()=>{
    setEditIndex(-1);
    setUmcForm({
      umcNo: "",
      materialDescription: "",
      unitOfMeasurement: "",
      quantity: "",
      destinationStorage: "",
      materialBGG:"",
      currency:"",
      destinationDepartment: umcForm.destinationDepartment,
      destinationDepartmentName: umcForm.destinationDepartmentName,
      destinationPlant: umcForm.destinationPlant,
      destinationPlantName: umcForm.destinationPlantName,
      requirementDate: "",
      consumptionDate: moment().format('YYYY-MM-DD'),
      procurementType: "",
      location: "TSJ",
      UMC_INDENT_ID: "",
      REQ_UMC_NO: "",
      INDENT_ID: "",
      DEST_SLOC: "",
      rate:"0",
      fodType: umcForm.fodType,
      docType: umcForm.docType,
      requestedOn: moment().format('YYYY-MM-DD'),
      purchaseGroup: umcForm.purchaseGroup,
      delPoint:"",
      HSN:"",
      BUOM:"-"
    });
    setUserInput("");
  }

  const handleChangeUMC = (e) => {
    const { name, value } = e.target;
    
    if(name=="fodType"){
      fetchDoctumentList(value); 
    }
    if(name=="requestedOn" || name=="consumptionDate"){
      const today=parseInt(moment().format('YYYYMMDD'));
      const SDate=parseInt(moment(value).format('YYYYMMDD'));
      if(SDate>=today){
        setUmcForm({
          ...umcForm,
          [name]: value,
        });
      }
    }else{
      setUmcForm({
        ...umcForm,
        [name]: value,
      });
    }
     
    
  };
  const handleChangeDept = (val) => {
    
    setUmcForm({
      ...umcForm,
      "destinationDepartment": val,
    });
    
    hideModal();
  };
  


  const validateForm = () => {
    const newErrors = {};
    if (!umcForm.umcNo.trim()) newErrors.umcNo = "UMC No. is required";
    if (!umcForm.materialDescription.trim()) newErrors.materialDescription = "Material Description is required";
    if (!umcForm.unitOfMeasurement.trim()) newErrors.unitOfMeasurement = "Unit of Measurement is required";
    if (!umcForm.quantity.trim()) newErrors.quantity = "Quantity is required";
    if (!umcForm.destinationPlant.trim()) newErrors.destinationPlant = "Indenter Plant is required";
    if (!umcForm.destinationDepartment.trim()) newErrors.destinationDepartment = "Destination Department is required";
    if (!umcForm.destinationStorage.trim()) newErrors.destinationStorage = "Destination Storage is required";
    if (!umcForm.procurementType.trim()) newErrors.procurementType = "Procurement Type is required";
    if (!umcForm.rate.trim()) newErrors.rate = "Rate is required";
    if (!umcForm.docType.trim()) newErrors.docType = "Document is required";
    if (!umcForm.fodType.trim()) newErrors.fodType = "FOD is required";
    if (!umcForm.requestedOn.trim()) newErrors.requestedOn = "Rate is required";
    if (!umcForm.consumptionDate.trim()) newErrors.consumptionDate = "Rate is required";
    if (!umcForm.delPoint.trim()) newErrors.delPoint = "Rate is required";
    if (!umcForm.purchaseGroup.trim()) newErrors.purchaseGroup = "Rate is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if(umcForm.umcNo.length==0){
      setUserInput("");
    }
    if (!validateForm()) {
      Swal.fire('', 'Please fill in all  fields', 'error');
      return;
    }
    if(editIndex>-1){
    const filteredStatus = selectedData.filter(
      (item) => item.InputMaterial !== umcForm.umcNo
    ); // selectedRec.umcNo);
    if (filteredStatus.length > 0) {
      setSelectedData(filteredStatus);
    }
    setSelectedMaterialArray(
      selectedMaterialArray.filter((v, i) => i !== editIndex)
    );
    setIndentChildDetails(indentChildDetails.filter((v, i) => i !== editIndex));
    setWorkFlowDetails(workFlowDetails.filter((v, i) => i !== editIndex));
    }
    if(umcForm.HSN.length>0){

    fetchSAPData(umcForm.umcNo, umcForm.destinationDepartment);
    setEditIndex(-1);
  }
  else{
    Swal.fire({text: 'HSN code of selected material is not maintained. Do you still want to Continue?',   icon: 'question',   showCancelButton: true,   confirmButtonText: 'Continue',   cancelButtonText: 'Cancel'}).then((result) => {   if (result.isConfirmed) {
           // User clicked OK
           fetchSAPData(umcForm.umcNo, umcForm.destinationDepartment);
           setEditIndex(-1);
             } 
           else if (result.dismiss === Swal.DismissReason.cancel) { 
                
               } });
  }

  };

  useEffect(() => {
    // Initialize bootstrap-select
    $(".selectpicker").selectpicker();
    setTimeout(() => {
      sessionStorage.setItem("IndentNo","");
    }, 2000);
  }, []);


  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    setisLoading(true);
    prop.showLoader();
    var formDetails = {
      T_SII_INDENT_DETAILS: {
        IndentorLoc: indentData.IndentorLoc,
        IndentorPlant: indentData.IndentorPlant,
        IndentorDept: indentData.IndentorDept,
        IndentDesc: indentDescription,
        IndentRemarks: remarks,
        UserName: user.User_Id,
        IndentId: returnMaxIndentId,
      },
      WorkFlowModel: [{ WF_ID: "" }],
      T_SIS_UMC_INDENT_DETAILS: indentChildDetails,
      T_SII_WORK_FLOW: workFlowDetails,
      IsDraft: "Y",
    };

    try {
      
     let token = sessionStorage.getItem('token');
            let headers = {
            'jwt-token': token      
            };
      axios.post(`${BaseUrl}api/Indent/SaveIndent`, formDetails, {headers})


        .then((response) => {
          if (response.data.StatusCode === "OK") {
            fetchSavedDraftData();
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "Indent Drafted Successfully", "success");
          } else {
            prop.hideLoader();
            Swal.fire("", "Something went wrong", "error");
           
          }
        });
    } catch (error) {
      prop.hideLoader();
      Swal.fire("", "Something went wrong", "error");
      setisLoading(false);
    }


  };
  const handelFinalRaiseIndent=async(formDetails)=>{
    
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
      'jwt-token': token      
      };
      axios.post(`${BaseUrl}api/Indent/SaveIndent`, formDetails,{headers})

        .then((response) => {
          if (response.data.StatusCode === "OK") {
            fetchSavedDraftData();
            setSelectedMaterialArray([]);
            setIndentChildDetails([]);
            setSelectedData([]);

            //alert('Indent Raised Successfully');
            setisLoading(false);
            Swal.fire(
              {title:"",
              text: "Indent processed  and spare sharing request raised successfully",
              icon: "success",
            confirmButtonText:"Ok"}
              ).then((result)=>{
                if(result.isConfirmed){
                  dispatch(setIndentId(response.data.data));
                  navigate("/SIS/SmartIndenting");
                }
              });
            SetIndentDescription("");
            SetRemarks("");
            setReturnMaxIndentId("");
            prop.hideLoader();
          } else {
            Swal.fire("", "Something went wrong", "error");
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      Swal.fire("", "Something went wrong", "error");
      setisLoading(false);
    }
  }
 
  const handleRaiseIndent = async (LVL,REMARKS,INDENTID,act) => {
    prop.showLoader();
    setisLoading(true);
    setWorkFlowDetails([]);
      const distinctValues = [
      ...new Set(
        selectedData.map(
          (obj) =>
            `${obj.Sloc}~${obj.WF_CATEGORY}~${obj.AuilpQty}~${obj.AvlStk}~${obj.Category}~${obj.DeptCode}~${obj.DeptDesc}~${obj.InputMaterial}~${obj.Werks}~${obj.LocCd}~${obj.TYP}~${obj.UMC_INDENT_ID}~${obj.REQ_UMC_NO}~${obj.INDENT_ID}~${obj.DEST_SLOC}~${obj.REQ_QUANTITY}~${obj.InvAge}~${obj.MappedMaterial}~${obj.AIULP_QTY}~${obj.INTRA_QTY}~${obj.INTER_QTY}~${obj.SpareText}`
        )
      ),
    ];

    const distinctObjects = distinctValues.map((value) => {
      const [
        Sloc,
        WF_CATEGORY,
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY,
        InvAge,MappedMaterial,AIULP_QTY,INTRA_QTY,INTER_QTY,SpareText
      ] = value.split("~");
      return {
        Sloc,
        WF_CATEGORY,
        AuilpQty,
        AvlStk,
        Category,
        DeptCode,
        DeptDesc,
        InputMaterial,
        Werks,
        LocCd,
        TYP,
        UMC_INDENT_ID,
        REQ_UMC_NO,
        INDENT_ID,
        DEST_SLOC,
        REQ_QUANTITY,
        InvAge,MappedMaterial,AIULP_QTY,INTRA_QTY,INTER_QTY,SpareText
      };
    });
    var UmcChildData=indentChildDetails;
    var wfList=[];
    var flt=comman.HOD;
    var IndentStatus="";
    var fltData=distinctObjects.filter(obj=> obj.TYP==comman.AIULP && (obj.WF_CATEGORY ==comman.INTER || obj.WF_CATEGORY ==comman.INTRA));
    if(fltData.length>0)
    {
    flt=comman.AUTOAPPROVE;
    IndentStatus=comman.AIULPPENDING;
    
    }
    if(fltData.length==0){
      fltData=distinctObjects.filter(obj=> obj.TYP==comman.INTRA  && (obj.WF_CATEGORY ==comman.INTER || obj.WF_CATEGORY ==comman.INTRA));
      IndentStatus=comman.INTRAPENDING;
    }
    if(fltData.length==0){
    
      fltData=distinctObjects.filter(obj=> obj.TYP==comman.INTER && obj.SpareText !='Consumables' && (obj.WF_CATEGORY ==comman.INTER || obj.WF_CATEGORY ==comman.INTRA));
      IndentStatus=comman.INTERPENDING;
    }
    if(fltData.length==0){
      IndentStatus=comman.CAPEXPENDING;
    }
    for (let index = 0; index < UmcChildData.length; index++) {
      if(fltData.length>0){
       
      const element = fltData.filter(obj=>obj.InputMaterial== UmcChildData[index].REQ_UMC_NO);
     
        const matchEle= element.filter(obj=>obj.DeptCode== indentData.IndentorDept);
     if(matchEle.length>0){
      prop.hideLoader();
      Swal.fire('','Cannot Raise Indent For Same Department','error');
      return;
     }
      if(element.length>0){
        UmcChildData[index]["UMC_STATUS"]=comman.WIP;
      }else{
        UmcChildData[index]["UMC_STATUS"]=comman.WAIT;
      }}else{
        UmcChildData[index]["UMC_STATUS"]=comman.WIP;
      }
      UmcChildData[index]["aiulpInventory"]=$('#tbl tbody tr').eq(index).find('td').eq(4).text();
      UmcChildData[index]["intraInventory"]=$('#tbl tbody tr').eq(index).find('td').eq(5).text();
      UmcChildData[index]["interInventory"]=$('#tbl tbody tr').eq(index).find('td').eq(6).text();
      
    
    }
  
    //distinctObjects=fltData;
for (let index = 0; index < fltData.length; index++) {
  
  
  const workFlowDetailsData = {
    SRC_LOC_ID: "",
    SRC_LOC_DESC: fltData[index].LocCd,
    SRC_PLANT_ID: fltData[index].Werks,
    SRC_PLANT_DESC: "",
    SRC_DEPT_ID: fltData[index].DeptCode,
    SRC_DEPT_DESC: fltData[index].DeptDesc,
    REQ_QUANTITY: fltData[index].REQ_QUANTITY,
    APPROVED_QTY: "",
    WF_TYPE: fltData[index]["TYP"],
    WF_STATUS: flt,
    WF_EXPIRY_DT: "",
    WF_REMARKS: "",
    CRT_BY: "",
    UMC_INDENT_ID:fltData[index].UMC_INDENT_ID,
    REQ_UMC_NO: fltData[index].REQ_UMC_NO,
    INDENT_ID: INDENTID,
    DEST_SLOC: fltData[index].DEST_SLOC,
    SLOC:fltData[index].Sloc,
    WF_CATEGORY:fltData[index].WF_CATEGORY,
    AIULP_QTY:fltData[index].AIULP_QTY,
    INTRA_QTY:fltData[index].INTRA_QTY,
    INTER_QTY:fltData[index].INTER_QTY,
    InvAge:fltData[index].InvAge,
    MappedMaterial:fltData[index].MappedMaterial,

    
  };
  wfList.push(workFlowDetailsData);
  
  
}
var formDetails = {
  T_SII_INDENT_DETAILS: {
    IndentorLoc: indentData.IndentorLoc,
    IndentorPlant:UmcChildData[0]["INDPLANT"],
    IndentorDept: UmcChildData[0]["INDDEPT"],
   
    IndentRemarks:REMARKS,
    UserName: user.User_Id,
    IndentId: INDENTID,
    STATUS:IndentStatus,
    LEVEL:LVL,
    IndentDesc:act
  },
  WorkFlowModel: [{ WF_ID: "" }],
  T_SIS_UMC_INDENT_DETAILS: UmcChildData,
  T_SII_WORK_FLOW: wfList,
  IsDraft: "N",
};
return formDetails;
try {
      
  
        handelFinalRaiseIndent(formDetails);
      
} catch (error) {
  prop.hideLoader();
  Swal.fire("", "Something went wrong", "error");
  setisLoading(false);
}

   
  };

  useEffect(() => {
    setUmcForm((prevState) => ({
      ...prevState,
      location: "TSJ",
    }));
   
   
    fetchFODList();
    fetchDelPointList();
    fetchpurchaseList();
    //fetchPlantList()o
    //console.log(sessionStorage.getItem("IndentNo"));
    //indentNo=sessionStorage.getItem("IndentNo");

    //sessionStorage.setItem("IndentNo","");
    if(indentNo.toString().length>0){
 
fetchIndentData();

    }else{
      navigate("/SIS/");
  }

  }, []);

 
  const [deptList, setDeptList] = useState([]);

  


  const fetchDoctumentList = async (MCODE) => {
    try {
      let token = sessionStorage.getItem('token');
            let headers = {
            'jwt-token': token      
            };

      const response = await axios.get(`${BaseUrl}api/Master/GetDocList?CODE=${comman.DocumentTypeCode}&&MCODE=${MCODE}`, {headers});
       const data = response.data;
     
      setDocType(data);
      
    } catch (error) {
      console.log(error);
    }
  };
  const fetchStorageList = async (UMC) => {
    try {
      let token = sessionStorage.getItem('token');
            let headers = {
            'jwt-token': token      
            };

      const response = await axios.get(`${BaseUrl}api/Master/GetStorageList?PLANT=${sessionStorage.getItem("Plant")}&&UMC=${UMC}`, {headers});
     const data = response.data;
     
      setStorageList(data);
      
    } catch (error) {
      console.log(error);
    }
  };
  const fetchpurchaseList = async () => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
      'jwt-token': token      
      };

const response = await axios.get(`${BaseUrl}api/Master/GetPurchaseList?PLANT=${sessionStorage.getItem("Plant")}`, {headers});
const data = response.data;
     
      setpurchaseGroupList(data);
      
    } catch (error) {
      console.log(error);
    }
  };

  const fetchDelPointList = async () => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
        'jwt-token': token
      };
      const response = await axios.get(`${BaseUrl}api/Master/GetDelPointList?PLANT=${sessionStorage.getItem("Plant")}`, {headers});
       const data = response.data;
     
      setdelPointList(data);
      
    } catch (error) {
      console.log(error);
    }
  };
  
  const fetchFODList = async () => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
        'jwt-token': token
      };

      const response = await axios.get(`${BaseUrl}api/Master/GetCodeList?CODE=${comman.FODCode}`, {headers});
      const data = response.data;
     
    setfodType(data);
      
    } catch (error) {
      console.log(error);
    }
  };



  
const fetchSavedDraftData = async () => {
  try {
    let token = sessionStorage.getItem('token');
    let headers = {
    'jwt-token': token      
    };
const response = await axios.get(`${BaseUrl}api/Master/GetDraftedList?DEPT=${umcForm.destinationDepartment}&&USERNAME=${user.User_Id}`, {headers});
const data = response.data;

    setisLoading(false);
    console.log("data", data);
    
    setIndentChildDetails(data);
    SetRemarks(data[0]["INDENT_REMARKS"]);
    //SetIndentDescription(data[0]["INDENT_DESC"]);
    setReturnMaxIndentId(data[0]["INDENT_ID"]);
    setWorkFlowDetails([]);
    setSelectedData([]);

    for (let index = 0; index < data.length; index++) {
      fetchSAPDraftData(
        data[index].umcNo,
        data[index].SRC_DEPT_ID,
        data[index],
        index,
        data
      );

    }
    fetchDoctumentList(data[0].fodType); 
setTimeout(() => {
  

    setUmcForm({
      umcNo: "",
      materialDescription: "",
      unitOfMeasurement: "",
      quantity: "",
      destinationStorage: "",
      materialBGG:"",
      currency:"",
      destinationPlant: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Plant"),
    destinationPlantName: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("PNAME"),
    destinationDepartment: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("Dept"),
    destinationDepartmentName: sessionStorage.getItem("DeptList")==null?"": sessionStorage.getItem("DeptName"),
    requirementDate: "",
      consumptionDate: moment().format('YYYY-MM-DD'),
      procurementType: "",
      location: "TSJ",
      UMC_INDENT_ID: "",
      REQ_UMC_NO: "",
      INDENT_ID: "",
      DEST_SLOC: "",
      rate:"0",
      fodType: data[0].fodType,
      docType: data[0].docType,
      requestedOn: moment().format('YYYY-MM-DD'),
      purchaseGroup: data[0].purchaseGroup,
      delPoint:"",
      HSN:"",
      BUOM:"-"
    });
  }, 1000);
    setSelectedMaterialArray(data);
  } catch (error) {
    console.log(error);
  }
  console.log("selected", selectedMaterialArray);
};
const handelUpdateL1=async(status,act)=>{
    
  var formDetails=await handleRaiseIndent(status,$("#txtRemarks").val(),indentNo,act)
  try {
    let token = sessionStorage.getItem('token');
    let headers = {
    'jwt-token': token      
    };
   
    axios.post(`${BaseUrl}api/IndentWF/UpdateIndentForL1`, formDetails,{headers})

      .then((response) => {
        if (response.data.typ === "Processed") {
          
          Swal.fire(
            {title:"",
            text: "Indent Processed Successfully",
            icon: "success",
          confirmButtonText:"Ok"}
            ).then((result)=>{
              if(result.isConfirmed){
               
   navigate("/SIS/IndentPending");
              }
            });
         
          prop.hideLoader();
        } 
        else if (response.data.typ === "Indent") {
          fetchSavedDraftData();
          setSelectedMaterialArray([]);
          setIndentChildDetails([]);
          setSelectedData([]);

          //alert('Indent Raised Successfully');
          setisLoading(false);
          Swal.fire(
            {title:"",
            text: "Indent processed  and spare sharing request raised successfully",
            icon: "success",
          confirmButtonText:"Ok"}
            ).then((result)=>{
              if(result.isConfirmed){
                dispatch(setIndentId(indentNo));
                navigate("/SIS/SmartIndenting");
              }
            });
          SetIndentDescription("");
          SetRemarks("");
          setReturnMaxIndentId("");
          prop.hideLoader();
        } 
        else {
          Swal.fire("", "Something went wrong", "error");
          prop.hideLoader();
        }
      });
  } catch (error) {
    prop.hideLoader();
    Swal.fire("", "Something went wrong", "error");
    setisLoading(false);
  }
}
const handelUpdateL2=async(status,act)=>{
    
  try {
    let token = sessionStorage.getItem('token');
    let headers = {
    'jwt-token': token      
    };
   const formDetails={
      UserName:user.User_Id,
      IndentRemarks:$("#txtRemarks").val(),
      STATUS:status,
      IndentId:indentNo,
      IndentDesc:act
    }
    axios.post(`${BaseUrl}api/IndentWF/UpdateIndentForL2`, formDetails,{headers})

      .then((response) => {
        if (response.data.StatusCode === "OK") {
          if(status==comman.ReturnByl2){
          Swal.fire(
            {title:"",
            text: "Indent Processed Successfully",
            icon: "success",
          confirmButtonText:"Ok"}
            ).then((result)=>{
              if(result.isConfirmed){
               
                navigate("/SIS/IndentPending");
              }
            });
          }
          else if(status==comman.MR){
handleRaiseIndent();
          }
          prop.hideLoader();
        } else {
          Swal.fire("", "Something went wrong", "error");
          prop.hideLoader();
        }
      });
  } catch (error) {
    prop.hideLoader();
    Swal.fire("", "Something went wrong", "error");
    setisLoading(false);
  }
}
const  getDOPRemarks = async(STATUS) => {

  let token = sessionStorage.getItem('token');
  let headers = {
    'jwt-token': token      
  };
  
  
  await axios.get(`${BaseUrl}api/IndentWF/GetDOPRemarks?ID=${indentNo}`, {headers}, {
    withCredentials: true
   
  }).then((response) => {
    var DOPVal=JSON.parse(response.data);
    setDOPlist(JSON.parse(response.data)); // Access the data directly
        
        setTimeout(() => {
      
         
          const filteredStatus = DOPVal.filter(
            (item) => item.STAGE === STATUS
          ); 
          var PSTATUS=parseInt (STATUS.replace('L',''))-1;
          const PfilteredStatus = DOPVal.filter(
            (item) => item.STAGE === "L"+PSTATUS.toString()
          ); 
          if(filteredStatus.length>0){
          $("#txtRemarks").val(filteredStatus[0].REMARKS);}
         if(PfilteredStatus.length>0){
          $("#lblPLvl").text("Remarks By L"+PSTATUS.toString());
          
         }
           
           
           
         
      }, 1000);
       })
       .catch((error) => {
         console.log(error);
       });
};
const fetchIndentData = async () => {
  try {
    let token = sessionStorage.getItem('token');
            let headers = {
            'jwt-token': token      
            };

    const response = await axios.get(`${BaseUrl}api/Master/GetIndentList?INDENTID=${indentNo.toString()}`, {headers});
   const data = response.data;

    setisLoading(false);
    console.log("data", data);
    
    setIndentChildDetails(data);
    setTimeout(() => {
      $("#lblDept").text(data[0]["INDENTOR_DEPT"]);
    $("#lblPlant").text(data[0]["INDENTOR_PLANT"]);
    $("#lblLoc").text(data[0]["INDENTOR_LOC"]);
   
   
    SetRemarks(data[0]["INDENT_REMARKS"]);
  
   

   
    
     getDOPRemarks(data[0].INDENT_STATUS);
    SetIndentDescription(data[0]["INDENT_DESC"]);
    setReturnMaxIndentId(data[0]["INDENT_ID"]);
    }, 1000);
    
    setWorkFlowDetails([]);
    setSelectedData([]);

    for (let index = 0; index < data.length; index++) {
      fetchSAPDraftData(
        data[index].umcNo,
        data[index].INDDEPT,
        data[index],
        index,
        data
      );
    }
    setSelectedMaterialArray(data);
  } catch (error) {
    console.log(error);
  }
  console.log("selected", selectedMaterialArray);
};




  return (
    <>
      {isLoading ? <div></div> : <></>}
      <>
      <Navbar />
        
        {/* <TabMenu prop={"RaiseIndent"}/> */}
        <div
          className="container"
                  style={{
                      marginTop: prop.indentNo.toString().length === 0 ? "73px" : "8px",
                      maxWidth: "95.5%"
                  }}
        >
          <div className="card">
          <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          >
            <div className="row">
              <div className="col-md-4"> <h4 className="mt-2">
            {indentChildDetails.length>0 ?
             <> &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Indent Approval (<span style={{fontSize:"19px"}}>{indentChildDetails[0].CSTATUS}</span>)</>
           :<></> }
            </h4>
            </div><div className="col-md-2 mt-2">
            {indentChildDetails.length>0 ?
                  <ApprovalList PLANT={indentChildDetails[0].INDPLANT} DEPT={indentChildDetails[0].INDDEPT} LVL={indentChildDetails[0].INDENT_LEVEL} TYP="UPTO"/>
                  :<></>}
            </div>
            </div>
           
          </div>
            
            <form
              onSubmit={handleSubmit}
              style={{ margin: "6px" }}
              className="form"
            >
              <div style={{ border: "0px solid wheat", padding: "10px" }}>
                
              {indentChildDetails.length>0?   
          <>  <div className="row">  
            <div className="col-md-4">
              <table className="table">
                <tr>
                  <td style={{width:"190px"}}><label style={{fontSize:"16px"}}><a className="text-primary">Indent Number </a></label></td>
                  <td><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].INDENT_ID}</a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indentor Plant </a></label></td>
                  <td><label style={{fontSize:"16px"}}><a ><a id="lblPlant"></a></a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Purchase Group</a></label></td>
                  <td><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].PURGROUP_DESC}</a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indent Description</a></label></td>
                  <td rowSpan="2"><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].INDENT_DESC}</a></label></td>
                </tr>
              </table>
</div> <div className="col-md-4">
              <table className="table">
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indent Date </a></label></td>
                  <td><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].DT}</a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indentor Location </a></label></td>
                  <td><label style={{fontSize:"16px"}}><a ><a id="lblLoc"></a></a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Requested Indentor</a></label></td>
                  <td><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].INDENTOR}</a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indent Remarks</a></label></td>
                  <td><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].INDENT_REMARKS}</a></label></td>
                </tr>
              </table>
              </div> <div className="col-md-4">
              <table className="table">
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indentor Department </a></label></td>
                  <td><label style={{fontSize:"16px"}}><a ><a id="lblDept"></a></a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Document Type </a></label></td>
                  <td><label style={{fontSize:"16px"}}><a >{indentChildDetails[0].DOCTYPE_DESC}</a></label></td>
                </tr>
                <tr>
                  <td><label style={{fontSize:"16px"}}><a className="text-primary">Indent/Inventory Value</a></label></td>
                  <td><label style={{fontSize:"16px"}}>
                  <a >{parseFloat(indentChildDetails[0].TOTALMAP).toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    style: 'currency',
    currency: 'INR'
})}</a></label></td>
                </tr>
                
                
              </table>
             </div>
                  </div>
                  </>:<></>}
               
                 
              
              </div>
            </form>
            
            

            <div className="card-body">
            {DOPlist.length>0?<>
             <div
            className="card-heading"
            style={{  height: "24px" }}
          >
           
            <h5 style={{marginLeft:"2px"}} >
              
           <span className="fas fa-user-circle text-primary"></span>  &nbsp;Indent Approval Details
              
            </h5>
          </div>
          
          <table class="table table-header tblComman mt-2" style={{padding:"10px"}}>
            <thead>
              <tr>
                <th scope="col">Level</th>
                <th scope="col">Action By</th>
                <th scope="col">Action On</th>
                <th scope="col">Remarks</th>
               
              </tr>
            </thead>
            <tbody>
              {DOPlist.map((item, index) => {
                return (
                  <tr>
                    {/* <td>{details?.destinationStorage}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.quantity}</td>
                <td>{comman.INTRA}</td> */}
                    <td>{item.STAGE}</td>
                    <td>{item.APPROVER}</td>
                    <td>{item.APPROVE_ON}</td>
                    <td>{item.REMARKS}</td>
                    
                  
                  </tr>
                );
              })}
            </tbody>
            
          </table></>:<></>}
          
            <div
            className="card-heading mt-2"
            style={{  height: "44px" }}
          >
            <h5>
              
              &nbsp;&nbsp;<i className="fas fa-cubes text-primary"></i>&nbsp;Material Details
              
            </h5>
          </div>
              <section className="">
                <table className="table table-bordered tblComman" id="tbl">
                  <thead className="table-primary">
                    <tr>
                      <th></th>
                      <th>Umc Number</th>
                      <th>Umc Description</th>
                      <th>Procurement Type</th>
                      <th>AIULP Inventory</th>
                      <th>Intra Location Inventory</th>
                      <th>Inter Location Inventory</th>
                     
                      <th>Storage Location</th>
                      <th>Req Quantity</th>
                      <th>Uom</th>
                      <th>FOD Type</th>
                      <th>Requirment Date</th>
                      <th>Consumption Date</th>
                      <th>Delivery Point</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    {selectedMaterialArray.map((item, index) => {
                      return (
                        <tr key={index}>
                          <td>
                            <Link
                              href=""
                              onClick={() => hanldeClick(item)}
                              className="btn btn-info"
                            >
                              View{" "}
                            </Link>{" "}
                          </td>
                          <td>{item.umcNo}</td>
                          <td>{item.materialDescription}</td>
                          <td>{item.procurementType}</td>
                          
                          <td> {item.aiulpInventory} </td>
                          <td> {item.intraInventory} </td>
                          <td> {item.interInventory} </td>
                          
                          <td> {item.destinationStorage} </td>
                          <td> {item.quantity} </td>
                          <td> {item.BUOM} </td>
                          <td> {item.FODTYPE_DESC} </td>
                          <td> {item.requestedOn} </td>
                          <td> {item.consumptionDate} </td>
                          <td> {item.DELPOINT_DESC} </td>
                          
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {show && (
                  <Modal
                    details={selectedModalData}
                    umcForm={umcForm}
                    handleClose={hideModal}
                  />
                )}

              </section>
             
              <div className="card-body">
            
            
              <div className="row">
                <div className="col-md-6">
                   <h5 style={{marginLeft:'4px'}}>Remarks</h5>
                   <textarea style={{marginLeft:'4px'}}
                    id="txtRemarks"
                    name="txtRemarks"
                    className="form-control"
                    type="textarea"
                  
                   rows="4"
                   cols="4"
                   
                    
                  />
                </div>
                {indentChildDetails.length>0?
                <div className="col-md-3" style={{marginTop:"50px"}}>
                
                <div>
                  <a className="btn btn-success" onClick={() => handelUpdateL1(indentChildDetails[0].INDENT_STATUS,'A')}><span className="fas fa-thumbs-up"></span> &nbsp; &nbsp;Approve</a>
               &nbsp;
                  <a className="btn btn-danger" onClick={() => handelUpdateL1(indentChildDetails[0].INDENT_STATUS,'R')}><span className="fas fa-thumbs-down"></span> &nbsp; &nbsp;Return</a>
                </div>
                </div>:<></>}
              </div></div>
              {indentNo.toString().length==0?
              <div className="row">
                <div className="col-md-12 center">
                  <button
                    type="submit"
                    className="btn btn-primary mt-4"
                    onClick={() => handleSaveAsDraft()}
                  >
                    &nbsp;<i className="fas fa-plus-circle"></i>&nbsp;Save As
                    Draft
                  </button>{" "}
                  &nbsp;{" "}
                  <button
                    type="submit"
                    className="btn btn-primary mt-4"
                    onClick={() => handleRaiseIndent()}
                  >
                    &nbsp;<i className="fas fa-plus-circle"></i>&nbsp;Raise
                    indent Request
                  </button>
                </div>
              </div>:<></>}
            </div>
          </div>
          
        </div>
      </>
    </>
  );
};

const Modal = ({ handleClose, details, umcForm }) => {
  return (
    <div className="modal display-block">
      <section className="modal-main">
        <div className="App">
          <table class="table table-header">
            <thead>
              <tr>
                <th scope="col">UMC No.</th>
                <th scope="col">Mapped UMC</th>
                <th scope="col">Source Location</th>
                <th scope="col">Source Plant</th>
                <th scope="col">Source Dept </th>
                <th scope="col">Storage Location </th>
                <th scope="col">Quantity</th>
                <th scope="col">UOM</th>
                <th scope="col">Category </th>
              </tr>
            </thead>
            <tbody>
              {details.map((item, index) => {
                return (
                  <tr>
                    {/* <td>{details?.destinationStorage}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.destinationPlant}</td>
                <td>{details?.quantity}</td>
                <td>{comman.INTRA}</td> */}
                    <td>{item.InputMaterial}</td>
                    <td>{item.MappedMaterial}</td>
                    
                    <td>{item.LocCd}</td>
                    <td>{item.Werks}</td>
                    <td>{item.DeptDesc}({item.DeptCode})</td>
                    <td>{item.Sloc}</td>
                    <td>{parseFloat(item.AuilpQty)>0?item.AuilpQty: item.AvlStk}</td>
                    <td>{item.Uom}</td>
                    <td>{item.TYP}</td>
                  </tr>
                );
              })}
            </tbody>
            
          </table>
        </div>

        <center>
        <button onClick={handleClose} className="btn btn-dark btn-cls">
          Close
        </button></center>
      </section>
    </div>
  );
};



export default IndentApproval;

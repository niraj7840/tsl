import React, { useState, useEffect, useRef } from "react";
import Navbar from "../components/Navbar/Navbar";
import TabMenu from "../components/TabMenu/TabMenu";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl, LocalUrl } from "../constants/BaseURL";
import "./ShoppingCart.css";
import "./IntelliBuySystemChecks.css";
import Autocomplete from "../components/ShoppingCart/Autocomplete";
import AutocompleteVendorMaster from "../components/ShoppingCart/AutocompleteVendorMaster";
import AppQue from "../components/ShoppingCart/AppQue";
import { useSelector } from "react-redux";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Input,
} from "reactstrap";
import axios from "axios";
import Swal from "sweetalert2";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import { Link } from "react-router-dom";
import { Label, TextArea } from "react-aria-components";
import {
  Container,
  Row,
  Col,
  Form,
  FormGroup,
  Collapse,
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import BudgetConsumptionWarningModal from "../components/ShoppingCart/BudgetConsumptionWarningModal";

import { event } from "jquery";
const ShoppingCart = (prop) => {
  let indentId = useSelector((state) =>
    state.indent ? state.indent.indentId : ""
  );

  if (!indentId) {
    const SN_indentId = sessionStorage.getItem("SC_IndentNo");
    if (SN_indentId) {
      indentId = SN_indentId;
    }
  }

  //const regex = /^[a-zA-Z\s]*\d*\.?\d*$/;
  //const regex = /^\d*\.?\d{0,2}$/;
  const regex = /^(\d{0,8}(\.\d{0,2})?)$/;
  const regex_price = /^(\d{0,15}(\.\d{0,2})?)$/;
  const navigate = useNavigate();
  const [state, setstate] = useState(false);
  const [shoppingCartData, setShoppingCartData] = useState([]);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [shoppingCartItemData, setShoppingCartItemData] = useState([]);
  const [indentno, setIndentNo] = React.useState(indentId);
  const [shoppingcartno, setShoppingCartNo] = React.useState("");
  const [indentdept, setIndentDept] = React.useState("");
  const [isLoading, setisLoading] = useState(true);
  const [isDisabled, setIsDisabled] = useState(false); // true to disable all elements
  const [isApprovalBtnDisabled, setIsApprovalBtnDisabled] = useState(true);
  const [roDisabled, setRODisabled] = useState(isDisabled);
  const [GLAccount, setGLAccount] = React.useState("");
  const [StorageLocation, setStorageLocation] = React.useState("");
  const [DocumentType, setDocumentType] = React.useState("");
  const [PurchaseGroup, setPurchaseGroup] = React.useState("");
  const [ProcurementType, setProcurementType] = React.useState("");
  const [UnderConsumption, setUnderConsumption] = React.useState("");
  const [RequirementDate, setRequirementDate] = React.useState("");
  const [scqty, Setscqty] = React.useState("");
  const [scuom, SetUOM] = React.useState("");
  const [priceperitem, Setpriceperitem] = React.useState("");
  const [rateFRN, SetRateFRN] = React.useState("");
  const [rateUnit, SetrateUnit] = React.useState("INR");
  const [FRNRateUnit, SetFRNRateUnit] = React.useState("");
  const [frncurrency, setFrnCurrency] = React.useState("");
  const [installedQty, SetInstalledQty] = React.useState("");
  const [filterText, setFilterText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [CsrCategoryList, Setcsrcategorylist] = useState([]);
  const [CostCategoryList, Setcostcategorylist] = useState([]);
  const [purchaseList, SetPurchaselist] = useState([]);
  const [DocumentsList, Setdocumentslist] = useState([]);
  const [CurrencyList, Setcurrencylist] = useState([]);
  const [MPNDrawingsdetailsList, SetMPNDrawingsdetailsList] = useState([]);
  const [ROVendorList, SetROVendorList] = useState([]);
  const [CsrSubCategoryList, Setcsrsubcategorylist] = useState([]);
  const [csrLocationList, setCsrLocationList] = useState([]);
  const [socialDisplay, setSocialDisplay] = useState("none");
  const [GLACDisplay, setGLACDisplay] = useState("none");
  const [installedQtyDisplay, setInstalledQtyDisplay] = useState(false);
  const [DesiredVendorDisplay, setDesiredVendorDisplay] = useState();
  const [isEnbleActivity, setisEnbleActivity] = useState("");
  const [ClassificationDisplay, setClassificationDisplay] = useState();
  const [csrLocation, setCsrLocation] = useState([]);
  const [csrRemarks, setCsrRemarks] = useState([]);
  const [CsrSubActivityList, Setcsrsubactivitylist] = useState([]);
  const [vendordetailsList, setVendordetailsList] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [checkedItemId, setCheckedItemId] = useState(null);
  const [indexTBL, setIndexTBL] = useState(null);
  const [umcnodesc, setUMCNODESC] = React.useState("");
  const [mapvalue, setMapValue] = React.useState("");
  const [rateINR, setRateINR] = React.useState("");
  const [exchingRate, setExchingRate] = React.useState("");
  const [characteristics, SetCharacteristics] = useState(null);
  const [composition, Setcomposition] = useState(null);
  const [functionText, SetfunctionText] = React.useState("");
  const [enduse, SetEndUse] = React.useState("");
  const [umcno, SetUMCNO] = React.useState("");
  const [plant, SetPlant] = React.useState("");
  const [documentTypeText, setDocumentTypeText] = React.useState("");
  const [scItemNo, setSCItemNo] = React.useState("");
  const [scDocumentName, setSCDocumentName] = React.useState("");
  const [scDocumentTxtLvl, setSCDocumentTxtLvl] = React.useState("");
  const [desiredVendor, setDesiredVendor] = useState("");
  const [costDistribution, setCostDistribution] = useState("P");
  const [costCategoryvalue, setCostCategory] = useState("");
  const [ProcCons, setProcCons] = useState("");
  const [BGG, setBGG] = useState("");
  const [Impplantmachinery, setImpplantmachinery] = useState("");
  const [requesterName, setRequesterName] = useState("");
  const [sapFODItemNo, setSapFODItemNo] = useState("");
  const [sapFODNo, setsapFODNo] = useState("");
  const [sapFODMsg, setsapFODMsg] = useState("");
  const [sapFODCreatedDT, setsapFODCreatedDT] = useState("");
  const [currentSCStatus, setCurrentSCStatus] = useState("");
  const [deptType, setDeptType] = useState("");
  const [errorList, setErrorList] = useState([]);
  const [bgg, setbggval] = useState("");
  const [MNPSelected, setMNPSelected] = useState(0);
  const [ROVendorSelected, setROVendorSelected] = useState(0);
  const [itemStatus, setItemStatus] = useState({});
  const [itemStatusSus, setItemStatusSus] = useState({});
  const [Errodata, setErrorData] = useState({});
  const [costAssesmentHeaderName, setCostAssesmentHeaderName] =
    useState("Percentage");
  const [fodtype, setFodType] = useState("");
  const [dept, setDept] = useState("");
  const [docType, setDocType] = useState("");
  const [DocTextDisabled, setDocTextDisabled] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState("none");
  const [subactivityselectedOption, setSubActivitySelectedOption] =
    useState("none");
  const [open, setOpen] = useState(false);
  const [opendoc, setOpenDoc] = useState(false);
  const [openimport, setOpenImport] = useState(true);
  const [enablePanel, setEnablePanel] = useState(false);
  const [panelData, setPanelData] = useState("");
  const [isIndentor, setIsIndentor] = useState(false);
  // <-----------------------------Modal---------------------------->
  const toggleAppHei = () => setModalAppHei(!modalappHei);
  const [modalappHei, setModalAppHei] = useState(false);
  const [modal, setModal] = useState(false);
  const [approvalHierarchy, setApprovalHierarchy] = useState([]);
  const currentapprovalHierarchy = approvalHierarchy.slice();
  const DocTextValue = ["F03", "B04", "B44", "B51"];
  const PurchaseValue = ["107", "173", "A09"];
  const [objCostAssignmentList, setObjCostAssignmentList] = useState([]);
  const [sca_fileAttachmentDetails, setsca_fileAttachmentDetails] = useState(
    []
  );

  const [BudgetdetailsList, SetBudgetdetailsList] = useState([]);
  const [showBudgetModalInfo, setShowBudgetModalInfo] = useState(false);
  const [flagBudgetModalInfo, setFlagBudgetModalInfo] = useState(false);
  const [sca_fileName, Setsca_fileName] = useState("");
  const [sca_fileType, Setsca_fileType] = useState("");
  const [sca_fileAttachment, Setsca_fileAttachment] = useState("");
  //====================Start Upload doc=================
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState(null);
  const [fileType, setFileType] = useState(null);
  const [fileSize, setFileSize] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    const fil = e.target.files[0];
    setFileName(fil.name);
    setFileType(fil.type);
    setFileSize(fil.size);
  };

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("Sno", shoppingcartno); // Example Sno
    formData.append("UserId", user.User_Id); // Example userId
    // formData.append('UserId', user.User_Id); // Example userId

    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };

    await axios
      .post(`${BaseUrl}api/ShoppingCart/InsertSCAttachment`, formData, {
        headers,
      })
      .then((response) => {
        const data = response.data;
        if (response.data.Text === "success") {
          GetSCAttachmentDetails(shoppingcartno);
          Swal.fire("", "File Uploaded", "success");
        } else {
          Swal.fire("", response.data.jsonData, "error");
        }
      })
      .catch((error) => {
        console.error("There was an error uploading the file!", error);
      });
  };

  //====================End Upload doc=================

  //===================Start ApprovalQuestion Added by Niraj================

  const [isAnswer, setIsAnswer] = useState("");
  const [isDisabledQA, setIsDisabledQA] = useState(false);
  const [highlightBlink, setHighlightBlink] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const handleClose = () => setShowModal(false);
  const handleShow = () => setShowModal(true);

  //===================End ApprovalQuestion================
  //===================Start Information==================
  const [modalApp, setModalApp] = useState(false);
  const [showmodalApp, setShowModalApp] = useState(false);
  const [SCH_CART_NO, SetSCH_CART_NO] = useState('');
  const [SCH_CART_NAME, SetSCH_CART_NAME] = useState('');
  const [DEPT, SetDEPT] = useState('');
  const [PURDESC, SetPURDESC] = useState('');
  const [SCI_FOD_TYPE_DESC, SetSCI_FOD_TYPE_DESC] = useState('');

  const [SCI_FOD_TYPE, SetSCI_FOD_TYPE] = useState('');
  const [TOTAL_INITIAL_INDENT_VALUE, SetTOTAL_INITIAL_INDENT_VALUE] = useState('');
  const [FINAL_INDENT_VALUE, SetFINAL_INDENT_VALUE] = useState('');
  const [SAVING_VALUE, SetSAVING_VALUE] = useState('');

  const toggleApp = () => setModalApp(!modalApp);
  //-----------------For Formate currency----------------------------
 //------------------------For Showing Information------------------
 const GetApprovalPrompVal = async (indentno) => {

  if (indentno != null) {
    try {

      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/SCDetailsForApproval?IndentId=${indentno}`, { headers }
      );
      const data = response.data;
      if (data.jsonData && data.jsonData.length > 0) {

        SetSCH_CART_NO(data.jsonData[0].SCH_CART_NO);
        SetSCH_CART_NAME(data.jsonData[0].SCH_CART_NAME);
        SetDEPT(data.jsonData[0].DEPT);
        SetPURDESC(data.jsonData[0].PURDESC);
        SetSCI_FOD_TYPE_DESC(data.jsonData[0].SCI_FOD_TYPE_DESC);
        SetSCI_FOD_TYPE(data.jsonData[0].SCI_FOD_TYPE);
        SetTOTAL_INITIAL_INDENT_VALUE(data.jsonData[0].TOTAL_INITIAL_INDENT_VALUE);
        SetFINAL_INDENT_VALUE(data.jsonData[0].FINAL_INDENT_VALUE);
        SetSAVING_VALUE(data.jsonData[0].SAVING_VALUE);


      } else {
        //Swal.fire("", "No Data Found", "info");

      }
    } catch (error) {
      console.error("Error fetching IntelliBuy check details", error);
    }
  } else {
    Swal.fire("", "Please fill Indent No", "error");
  }
};

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };
  //===================End Information====================

  const togglePanel = () => {
    setOpen(!open);
  };
  const togglePanelDoc = () => {
    setOpenDoc(!opendoc);
  };

  const handleCheckboxChangeSC = (index) => {
    setSelectedRow(index);
    togglePanel();
  };

  const itemsPerPage = 5;

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);

    setCurrentPage(1);
  };
  ///------------------------Current SC Status-----------------///
  const FetchSCCurrentStatus = async (shoppingcartno) => {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    await axios
      .get(
        `${BaseUrl}api/ShoppingCart/GetCurrentSCStatus?SCNO=${shoppingcartno}`,
        { headers }
      )
      .then((response) => {
        const data = response.data;
        if (data.jsonData.length > 0) {
          const Status = data.jsonData;
          setCurrentSCStatus(Status);

          if (Status >= 39) {
            setIsDisabled(true);
            setIsApprovalBtnDisabled(false);

            prop.switchToShoppingCartCreatedAndPending();
          } else if (Status === "38") {
            setIsApprovalBtnDisabled(true);
          }
          //   setCurrentSCStatus(data.jsonData);
          //  console.log('current',currentSCStatus,'data',data.jsonData);
        } else {
          Swal.fire("", "No Data Found", "info");
        }
      })
      .catch((error) => {
        //console.log(error);
      });
  };

  ////    for pagination      /////
  const hanldeSearchClick = async (IndentNo) => {
    if (IndentNo != null) {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetIntelliBuyChecksDetails?IndentId=${IndentNo}`,
          { headers }
        )
        .then((response) => {
          const data = response.data;
          if (data.jsonData.length > 0) {
            setShoppingCartData(data.jsonData);

            console.log(data.jsonData[0].SCH_CART_NO, "SC NO");
            setShoppingCartNo(data.jsonData[0].SCH_CART_NO);
            GetApprovalHierarchy(data.jsonData[0].SCH_CART_NO);
            GetSCAttachmentDetails(data.jsonData[0].SCH_CART_NO);
            SetrateUnit(data.jsonData[0].SCI_PRICE_UNIT);
            SetFRNRateUnit(data.jsonData[0].SCI_FRN_CURR_CD);
            SetSCH_CART_NAME(data.jsonData[0].SCH_CART_NAME);
            // Setsca_fileName(data.jsonData[0].SCA_FILE_NAME);
            // Setsca_fileAttachment(data.jsonData[0].SCA_FILE);
            // Setsca_fileType(data.jsonData[0].SCA_FILE_TYPE);
            const Status = data.jsonData[0].INDENT_CURRENT_STATUS_CODE;
            setCurrentSCStatus(Status);
            setFodType(data.jsonData[0].FOD_TYPE);
            if (user.User_Id === data.jsonData[0].INDENT_CRT_BY) {
              setIsIndentor(true);
            }
            console.log(Status, " setCurrentSCStatus");
            if (
              Status >= 39 ||
              user.User_Id !== data.jsonData[0].INDENT_CRT_BY
            ) {
              setIsDisabled(true);
              setIsApprovalBtnDisabled(false);
            } else if (Status === "38") {
              setIsApprovalBtnDisabled(true);
            }
            fetchBudgetDeatils(data.jsonData[0].INDENTOR_DEPT, IndentNo);
            GetApprovalPrompVal(IndentNo);
            console.log(data.jsonData, "ShoppingCart");
            GetAnswerStatus(
              data.jsonData[0].SCH_CART_NO,
              data.jsonData[0].INDENT_CURRENT_STATUS_CODE
            );
          } else {
            Swal.fire("", "No Data Found", "info");
            setShoppingCartData([]);
            setShoppingCartNo("");
            setIndentDept("");
          }

          ////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      Swal.fire("", "Please fill Indent No", "error");
    }
  };
  // Function to calculate the product
  const calculatePrice = (value1, value2) => {
    return (value1 * value2).toFixed(3);
  };

  const totalRate = shoppingCartData.reduce((acc, item) => {
    // Ensure item.price is a number
    const price = parseFloat(item.SCI_PRICE);
    return acc + (isNaN(price) ? 0 : price);
  }, 0);
  const totalPrice = shoppingCartData.reduce((acc, item) => {
    // Ensure item.price is a number
    const qty = Number(item.QTY);
    const rate = Number(item.SCI_PRICE);
    const price = qty * rate;
    return acc + (isNaN(price) ? 0 : price);
  }, 0);
  const totalFRNPrice = shoppingCartData.reduce((acc, item) => {
    // Ensure item.price is a number
    const qty = Number(item.QTY);
    const rate = Number(item.SCI_FRN_PRICE);
    const price = qty * rate;
    return acc + (isNaN(price) ? 0 : price);
  }, 0);
  const filteredData = shoppingCartData.filter((row) => {
    // Convert the filter text to lowercase for case-insensitive comparison
    const searchText = filterText.toLowerCase();

    // Iterate through each column in the row
    for (const key in row) {
      const value = row[key];

      // Check if the value exists
      if (value !== undefined && value !== null) {
        if (typeof value === "string") {
          // Convert the string value to lowercase
          const columnValue = value.toLowerCase();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        } else if (typeof value === "number") {
          // Convert the integer value to string
          const columnValue = value.toString();
          // Check if the column value contains the filter text
          if (columnValue.includes(searchText)) {
            // If found, return true to include this row in the filtered data
            return true;
          }
        }
      }
    }
    // If no match is found in any column, return false to exclude this row from the filtered data
    return false;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  //console.log(totalPages, "Total page");
  //console.log(filteredData, "filteredData");
  // const currentData = filteredData.slice(
  //   (currentPage - 1) * itemsPerPage,

  //   currentPage * itemsPerPage
  // );
  const currentData = filteredData
    .filter((row) => row.ISACTIVE === "Y")
    .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const hanldeEdit = (index, field, event) => {
    const newData = [...shoppingCartData];
    newData[index][field] = event;
    setShoppingCartData(newData);
  };
  // Update the array based on the matching ID

  // const handleDeleteRow = (UMC_INDENT_ID) => {
  //   const newData = shoppingCartData.filter(
  //     (item) => item.UMC_INDENT_ID !== UMC_INDENT_ID
  //   );
  //   setShoppingCartData(newData);
  //   const totalPage = Math.ceil(newData.length / itemsPerPage);
  //   setCurrentPage(totalPage);
  // };
  const handleDeleteRow = (UMC_INDENT_ID) => {
    const newData = shoppingCartData.map((item) =>
      item.UMC_INDENT_ID === UMC_INDENT_ID ? { ...item, ISACTIVE: "N" } : item
    );
    setShoppingCartData(newData);
    const filteredData = newData.filter((item) => item.ISACTIVE === "Y");
    const totalPage = Math.ceil(filteredData.length / itemsPerPage);
    setCurrentPage(totalPage);
  };

  const handleButtonShowClick = (umcIndentId) => {
    setSelectedRow(umcIndentId); // Set the selected row ID
    togglePanel();
    console.log(umcIndentId);
  };

  useEffect(() => {
    if (indentno != null) {
      hanldeSearchClick(indentno);
    }

    fetchCsrCategoryList();

    fetchCurrencyList();
    fetchCsrLocationList();
  }, indentno);

  //--------------------------------Cost Assigment-------------------------//
  const fetchCostCategoryList = async (DeptType, FodType, BGGs, ContractNO) => {
    console.log(DeptType, FodType, "test Dept Type");
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCategory?DeptType=${DeptType}&FODType=${FodType}&bgg=${BGGs}&contract=${ContractNO}`,
        { headers }
      );
      Setcostcategorylist(response.data.jsonData);
    } catch (error) {
      console.log(error, "GetCostCategory");
    }
  };
  //--------------------------------Purchase Group-------------------------//
  const fetchPurchaseGroupList = async (Plant, fodtype, contractno, umcno) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetPurchaseGroupList?plantcode=${Plant}&fodtype=${fodtype}&contract=${contractno}`,
        { headers }
      );
      SetPurchaselist(response.data.jsonData);
      if (fodtype === "RO") {
        setPurchaseGroup(response.data.jsonData[0].PG_CD);
        InputChange(umcno, "SCI_PUR_GRP", response.data.jsonData[0].PG_CD);
      }
    } catch (error) {
      console.log(error, "GetCostCategory");
    }
  };

  // Function to delete row
  const deleteRow = (id) => {
    console.log(id, "delete rows");
    const updatedRows = rows.filter((row) => row.SAA_LINE_NO !== id);
    setRows(updatedRows);
  };
  //------------------------------------Documents---------------------------------//
  const fetchDocumentsList = async (FODTYPE, SCNO, UMCNO) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetDocumentsText?FODType=${FODTYPE}&SCNo=${SCNO}&MatNo=${UMCNO}`,
        { headers }
      );
      console.log(response.data.jsonData, "fetchDocumentsList");
      Setdocumentslist(response.data.jsonData);
    } catch (error) {
      console.log(error, "fetchDocumentsList");
    }
  };
  //---------------------------------Sustainability-----------------------------//
  const fetchCsrCategoryList = async () => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrCategory`,
        { headers }
      );
      Setcsrcategorylist(response.data.jsonData);
    } catch (error) {
      console.log(error, "fetchCsrCategoryList");
    }
  };
  const fetchCsrSubCategoryList = async () => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubCategory`,
        { headers }
      );
      Setcsrsubcategorylist(response.data.jsonData);
    } catch (error) {
      console.log(error, "GetCostCsrSubCategory");
    }
  };

  const fetchCurrencyList = async () => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCurrencyCode`,
        { headers }
      );
      Setcurrencylist(response.data.jsonData);
      console.log(response.data.jsonData, "GetCurrencyCode");
    } catch (error) {
      console.log(error, "GetCurrencyCode");
    }
  };

  const fetchMPNDrawingsdetailsList = async (umcno, bgg, scno, itemno) => {
    const usersDetails = user.User_Id;
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/Getmpndrawingsdetails?umcno=${umcno}&matl_grp=${bgg}&scno=${scno}&itemno=${itemno}&UserID=${usersDetails}`,
        { headers }
      );
      SetMPNDrawingsdetailsList(response.data.jsonData);
      console.log(response.data.jsonData, "Getmpndrawingsdetails");
    } catch (error) {
      console.log(error, "GetCurrencyCode");
    }
  };

  const fetchCsrSubActivityList = async (CSR_SUB_CODE) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostCsrSubActivity?CSR_SUB_CODE=${CSR_SUB_CODE}`,
        { headers }
      );
      Setcsrsubactivitylist(response.data.jsonData);
      console.log(response.data.jsonData, "fetchCsrSubActivityList");
    } catch (error) {
      console.log(error, "GetCostCsrSubActivity");
    }
  };
  const fetchCsrLocationList = async () => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCSRLocation`,
        { headers }
      );
      setCsrLocationList(response.data.jsonData);
    } catch (error) {
      console.log(error, "fetchCsrCategoryList");
    }
  };

  // const handleCheckboxChangeforMaterial =async (SCNO, UMCNO, index) => {
  //   handleCheckboxChangeforSelect(SCNO, UMCNO, index);

  // };

  // const handleCheckboxChangeforSelect = (id) => {
  //   debugger;
  //   const updatedData = shoppingCartData.map((item) =>
  //     item.UMC_INDENT_ID === id
  //       ? { ...item, checked: true }
  //       : { ...item, checked: false }
  //   );
  //   console.log(shoppingCartData, "shoppingCartData");
  //   setShoppingCartData(updatedData);

  //   const selectedCheckbox = updatedData.find(
  //     (item) => item.UMC_INDENT_ID === id
  //   );

  //   if (selectedItemId !== id) {
  //     // Only update state if a different checkbox is selected
  //     setSelectedItemId(id);
  //     setEnablePanel(true);
  //     setPanelData(selectedCheckbox.data);
  //     setDocumentType(selectedCheckbox.DOCUMENT_TYPE_DESC);
  //     setStorageLocation(selectedCheckbox.SLOC_DESC);
  //     setPurchaseGroup(selectedCheckbox.PG_DESC);
  //     setProcurementType(selectedCheckbox.PROC_TYPE);
  //     setRequirementDate(selectedCheckbox.REQUIREMENT_DATE);
  //     SetUOM(selectedCheckbox.UOM);
  //     setShoppingCartNo(selectedCheckbox.SCH_CART_NO);
  //     setUnderConsumption(selectedCheckbox.SPARE);
  //     Setscqty(selectedCheckbox.QTY);
  //     Setpriceperitem(selectedCheckbox.PRICE_PER_ITEM);
  //   } else {
  //     // Deselect the checkbox if it was already selected
  //     setSelectedItemId(null);
  //     setEnablePanel(false);
  //     setPanelData("");
  //     setDocumentType("");
  //     setStorageLocation("");
  //     setPurchaseGroup("");
  //     setProcurementType("");
  //     setRequirementDate("");
  //     setShoppingCartNo("");
  //     setUnderConsumption("");
  //     Setscqty("");
  //   }
  //   // const filteredData = shoppingCartData.filter((item) => item.ISACTIVE === "Y");
  //   // const totalPage = Math.ceil(filteredData.length / itemsPerPage);
  //   // console.log(totalPage,'totalPage');
  //   // setCurrentPage(totalPage);
  // };
  const FetchVendorDetailsList = async (vendorcode) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetVendorDetails?VendorCode=${vendorcode}`,
        { headers }
      );

      const descriptions = response.data.jsonData;
      console.log(descriptions, " FetchVendorDetailsList");
      if (descriptions !== "") {
        setVendordetailsList(descriptions);
      }
    } catch (err) {
    } finally {
    }
  };

  const fetchROVendorList = async (purgrp, umcno, dept) => {
    console.log(purgrp, umcno, dept, "purgrp,umcno,dept");
    const usersDetails = user.User_Id;
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/ROVendorList?purgrp=${purgrp}&UMCNO=${umcno}&Dept=${dept}`,
        { headers }
      );
      SetROVendorList(response.data.jsonData);
      console.log(response.data.jsonData, "fetchROVendorList");
    } catch (error) {
      console.log(error, "GetCurrencyCode");
    }
  };

  ////======================================For UMC Select============================>
  const handleCheckboxChangeforSelect = async (SCNO, UMCNO, index) => {
    setIndexTBL(index);
    console.log(index, "index");
    console.log(UMCNO, index, "SCNO");

    if (SCNO > 0) {
      prop.showLoader();
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetSCItemDetailsFromUMC?SC_NO=${SCNO}&UMCNo=${UMCNO}&FODTYPE=${fodtype}`,
          { headers }
        )
        .then((response) => {
          prop.hideLoader();
          const data = response.data.jsonData;
          const errors = response.data.jsonData.errors;
          updateData("5", errors);
          if (!errors || Object.keys(errors).length !== 0) {
            setOpenDoc(true);
          }
          console.log(data, "Data");
          console.log(data.jsonData[0].sccostAssignment, "cost Data");
          if (data.jsonData[0].SCI_CART_NO > 0) {
            addNewRows(data.jsonData);
            setSelectedItemId(UMCNO);
            clearFields();
            setDocumentTypeText("");
            setProcCons("");
            setEnablePanel(true);
            console.log(
              data.jsonData[0].SCH_INDT_TYP,
              data.jsonData[0].SCI_FOD_TYPE,
              "test Cost Categori"
            );
            fetchCostCategoryList(
              data.jsonData[0].SCH_INDT_TYP,
              data.jsonData[0].SCI_FOD_TYPE,
              data.jsonData[0].SCI_MATL_GRP,
              data.jsonData[0].SCI_REF_OA_NO
            );
            setPanelData(data.jsonData[0]);
            fetchDocumentsList(fodtype, SCNO, UMCNO);
            updateCostAssesmentRows(data.jsonData[0].sccostAssignment);
            console.log(data.jsonData[0].sccostAssignment, "sccostAssignment");
            setDocumentType(data.jsonData[0].DOC_TYPE_DESC);
            setStorageLocation(data.jsonData[0].SLOC_DESC);
            //setPurchaseGroup(data.jsonData[0].PG_GRP_DESC);
            setPurchaseGroup(data.jsonData[0].SCI_PUR_GRP);
            setProcurementType(data.jsonData[0].SCI_PROC_TYP);
            setRequirementDate(data.jsonData[0].SCI_REQD_ON_DT);
            SetUOM(data.jsonData[0].SCI_QTY_UNIT);
            setBGG(data.jsonData[0].SCI_MATL_GRP);
            setbggval(data.jsonData[0].SCI_MATL_GRP);
            setUnderConsumption(data.jsonData[0].SCI_SPARES_CATEGORY);
            Setscqty(data.jsonData[0].SCI_QTY);
            //Setpriceperitem(data.jsonData[0].SCI_PRICE);
            SetRateFRN(data.jsonData[0].SCI_FRN_PRICE);
            SetInstalledQty(data.jsonData[0].SCI_INSTALLED_QTY);
            setUMCNODESC(data.jsonData[0].UMC_DESC);
            setMapValue(data.jsonData[0].Verpr);
            SetCharacteristics(data.jsonData[0].SCI_CHARACTERISTICS);
            Setcomposition(data.jsonData[0].SCI_COMPOSITION);
            SetEndUse(data.jsonData[0].SCI_ENDUSE);
            SetfunctionText(data.jsonData[0].SCI_FUNCTION);
            SetPlant(data.jsonData[0].SCI_PLANT_CD);
            SetUMCNO(data.jsonData[0].SCI_MATL_NO);
            setSCItemNo(data.jsonData[0].SCI_ITEM_NO);
            setDesiredVendor(data.jsonData[0].SCI_OA_VENCD);
            setProcCons(data.jsonData[0].SCI_TXT_PROC_CONS);
            setImpplantmachinery(data.jsonData[0].SCI_IMP_PLANT_MACHINERY);
            setRateINR(data.jsonData[0].SCI_PRICE);
            setDocType(data.jsonData[0].SCI_DOC_TYPE);
            setFrnCurrency(data.jsonData[0].SCI_FRN_CURR_CD);
            setFodType(data.jsonData[0].SCI_FOD_TYPE);
            setSapFODItemNo(data.jsonData[0].SCI_FOD_ITEM_NO);
            setsapFODNo(data.jsonData[0].SCI_FOD_NO);
            setsapFODMsg(data.jsonData[0].SCI_SAP_ERR_MSG);
            setsapFODCreatedDT(data.jsonData[0].SCI_FOD_CRT_DT);
            setDept(data.jsonData[0].DEPT);
            setRequesterName(data.jsonData[0].SCI_REQUESTER);
            setCheckedItemId(data.jsonData[0].CSR_COMP);
            fetchMPNDrawingsdetailsList(
              data.jsonData[0].SCI_MATL_NO,
              data.jsonData[0].SCI_MATL_GRP,
              data.jsonData[0].SCI_CART_NO,
              data.jsonData[0].SCI_ITEM_NO
            );
            fetchPurchaseGroupList(
              data.jsonData[0].SCI_PLANT_CD,
              fodtype,
              data.jsonData[0].SCI_REF_OA_NO,
              data.jsonData[0].SCI_MATL_NO
            );

            // DefaultItemMVPValue(
            //   data.jsonData[0].SCI_PRICE,
            //   data.jsonData[0].Verpr
            // );

            Setcsrsubcategorylist([]);
            Setcsrsubactivitylist([]);
            setSelectedOption("None");
            setSubActivitySelectedOption("None");
            setSocialDisplay("none");
            setCsrLocation("");
            setCsrRemarks("");
            fetchCsrDetails(
              data.jsonData[0].SCI_CART_NO,
              data.jsonData[0].SCI_ITEM_NO
            );
            fetchCostAssesmentData(
              data.jsonData[0].SCI_CART_NO,
              data.jsonData[0].SCI_ITEM_NO
            );

            setShoppingCartData((prevItem) =>
              prevItem.map((item) =>
                item.REQ_UMC_NO === data.jsonData[0].SCI_MATL_NO //umcno
                  ? { ...item, SCI_PRICE: data.jsonData[0].SCI_PRICE }
                  : item
              )
            );
            //console.log("choose cost assignment", costCategory)
            // handleItemSelection(data.jsonData[0].SCI_ITEM_NO);
            FetchVendorDetailsList(data.jsonData[0].SCI_OA_VENCD);
            setROVendorSelected(data.jsonData[0].SCI_REF_OA_NO);

            console.log("checkeditem", checkedItemId);
            // if(checkedItemId===null)
            // {
            //   handleItemSelectionForSus(data.jsonData[0].SCI_ITEM_NO)
            // }

            ValidationFunction(data.jsonData);

            console.log(data.jsonData[0].SLOC_DESC, "SLOC_DESC");
            console.log(shoppingCartItemData, "ShoppingCartItemData");
          } else {
            Swal.fire("", "No Data Found", "info");
            setShoppingCartData([]);
            setShoppingCartNo("");
            setIndentDept("");
          }

          ////console.log(data.jsonData[0].INDENT_STATUS,'INDENT_CURRENT_STATUS');
        })
        .catch((error) => {
          //console.log(error);
          prop.hideLoader();
        });
    } else {
      prop.hideLoader();
      Swal.fire("", "No Data Found", "error");
    }
  };

  // Function to add new rows to the table data
  const addNewRows = (newRows) => {
    setShoppingCartItemData((prevData) => {
      // Create a set of existing IDs for quick lookup
      const existingIds = new Set(prevData.map((item) => item.SCI_MATL_NO));

      // Filter out new rows that are not already in the state
      const filteredNewRows = newRows.filter(
        (row) => !existingIds.has(row.SCI_MATL_NO)
      );

      // Add the new rows to the existing data
      return [...prevData, ...filteredNewRows];
    });
  };
  const UpdateTextColorDocumentList = (id, lvl) => {
    // Map over items and update the one with the matching ID
    const updatedItems = DocumentsList.map(
      (item) =>
        item.TEXT_ID === id && item.TXT_LVL === lvl
          ? { ...item, CLASSNAME: "#32CD32" } // Update the matching item
          : item // Keep the item unchanged
    );
    Setdocumentslist(updatedItems); // Update state
    console.log("documentlist", DocumentsList);
  };
  const DefaultItemMVPValue = (price, mvp) => {
    const Price = parseFloat(price) || 0;
    const MVP = parseFloat(mvp) || 0;
    if (Price > 0) {
      setRateINR(Price);
      InputChange(indexTBL, "SCI_PRICE", Price);
    } else {
      setRateINR(MVP.toFixed(2));
      InputChange(indexTBL, "SCI_PRICE", MVP.toFixed(2));
    }
  };

  const ValidationFunction = (jsondata) => {
    setInstalledQtyDisplay(true);
    //SetInstalledQty("0");
    setDesiredVendorDisplay(false);
    setClassificationDisplay(true);
    setOpenImport("none");
    setRODisabled(isDisabled);

    if (jsondata[0].SCI_SPARES_CATEGORY === "Consumables") {
      setInstalledQtyDisplay(false);
      SetInstalledQty("0");
    }
    if (jsondata[0].SCI_FOD_TYPE === "PR") {
      setDesiredVendorDisplay(true);
      setMNPSelected(jsondata[0].SCI_MFRNR);
    }
    if (jsondata[0].SCI_FOD_TYPE === "RO") {
      setInstalledQtyDisplay(false);
      setRODisabled(true);
      setDesiredVendorDisplay(true);
      setOpenImport("none");
      setClassificationDisplay(false);
      fetchROVendorList(
        PurchaseGroup,
        jsondata[0].SCI_MATL_NO,
        jsondata[0].SCI_PLANT_CD
      );
      setROVendorSelected(jsondata[0].SCI_REF_OA_NO);
      InputChange(indexTBL, "SCI_OA_VENCD", jsondata[0].SCI_OA_VENCD);
    }
    if (
      jsondata[0].SCI_ClassificationEnable === false &&
      jsondata[0].SCI_FOD_TYPE === "PR"
    ) {
      setClassificationDisplay(false);
    }
    if (
      jsondata[0].MaterialConsumptionPlanEnble === true &&
      jsondata[0].SCI_FOD_TYPE === "PR"
    ) {
      setOpenImport("");
    }
  };

  const fetchCsrDetails = async (SCNO, ItemNo) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetShoppingCSRDetails?SCNO=${SCNO}&ItemNo=${ItemNo}`,
        { headers }
      );
      const data = response.data;
      if (data.jsonData[0].CSR_COMP == "01") {
        setCheckedItemId(data.jsonData[0].CSR_COMP);
        fetchCsrSubCategoryList();
        isChecked(true);
        setSelectedOption(data.jsonData[0].SCC_SUB_CODE);
        fetchCsrSubActivityList(data.jsonData[0].SCC_SUB_CODE);
        setSubActivitySelectedOption(data.jsonData[0].SCC_SUB_ACTIVITY_CODE);
        setCsrLocation(data.jsonData[0].SCC_LOC_CODE || 0);
        setCsrRemarks(data.jsonData[0].SCC_REMARKS || "");
        setSocialDisplay("");
      } else {
        setCheckedItemId(data.jsonData[0].CSR_COMP);
        Setcsrsubcategorylist([]);
        Setcsrsubactivitylist([]);
        setSelectedOption("None");
        setSubActivitySelectedOption("None");
        setSocialDisplay("none");
      }
    } catch (error) {}
  };

  const fetchCostAssesmentData = async (SCNO, ItemNo) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCostAssesmentData?SCNO=${SCNO}&ItemNo=${ItemNo}`,
        { headers }
      );
      const data = response.data;
      console.log("test cost data", data.jsonData);
      if (data.jsonData[0].saa_cart_no > 0) {
        setCostCategory(data.jsonData[0].saa_category);
        setCostDistribution(data.jsonData[0].saa_distribution_tp);

        console.log("test cost data", data.jsonData[0].saa_category);
      }
    } catch (error) {}
  };

  const isChecked = (value) => selectedOptions.includes(value);
  const handleCheckboxChange = (value) => {
    if (checkedItemId != value) {
      setCheckedItemId(value);
      if (value != "01") {
        setSocialDisplay("none");
      } else {
        setSocialDisplay("");
      }
    } else {
      setCheckedItemId("");
    }
    //debugger;
    console.log(value, "None");
    if (value == "00") {
      Setcsrsubcategorylist([]);
      Setcsrsubactivitylist([]);
      setSelectedOption("None");
      setSubActivitySelectedOption("None");
      isChecked(true);
      setCsrLocation("");
      setCsrRemarks("");
    } else if (value == "01") {
      fetchCsrSubCategoryList();
      isChecked(true);
    } else {
      Setcsrsubcategorylist([]);
      Setcsrsubactivitylist([]);
      setSelectedOption("None");
      setSubActivitySelectedOption("None");
      setCsrLocation("");
      setCsrRemarks("");
    }
    // if (value === "all") {
    //   // console.log("None");
    //   // setSelectedOptions([]);

    //   // Setcsrsubcategorylist([]);
    //   // Setcsrsubactivitylist([]);
    //   if (selectedOptions.length === CsrCategoryList.length) {
    //     setSelectedOptions([]);
    //   } else {
    //     setSelectedOptions(CsrCategoryList.map((option) => option.VALUE));
    //   }
    // } else {
    //   if (selectedOptions.includes(value)) {
    //     setSelectedOptions(
    //       selectedOptions.filter((option) => option !== value)
    //     );
    //   } else {
    //     setSelectedOptions([...selectedOptions, value]);
    //   }
    //   //fetchCsrSubCategoryList();
    // }
  };
  const handleRadioChange = (value) => {
    setSelectedOption(value);
    fetchCsrSubActivityList(value);
  };
  const handleSubActivityRadioChange = (value) => {
    setSubActivitySelectedOption(value);
  };

  // Function to handle input changes
  const handleInputChangePrice = (event) => {
    Setpriceperitem(event.target.value); // Update the state with input value
  };
  const InputChange = (index, field, value) => {
    if (field === "SCI_CHARACTERISTICS") {
      SetCharacteristics(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno
            ? { ...item, SCI_CHARACTERISTICS: value }
            : item
        )
      );
    } else if (field === "SCI_COMPOSITION") {
      Setcomposition(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno
            ? { ...item, SCI_COMPOSITION: value }
            : item
        )
      );
    } else if (field === "SCI_ENDUSE") {
      SetEndUse(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno ? { ...item, SCI_ENDUSE: value } : item
        )
      );
    } else if (field === "SCI_FUNCTION") {
      SetfunctionText(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno ? { ...item, SCI_FUNCTION: value } : item
        )
      );
    } else if (field === "SCI_PRICE") {
      if (regex_price.test(value)) {
        setRateINR(value);
        setShoppingCartItemData((prevItems) =>
          prevItems.map((item) =>
            item.SCI_MATL_NO === umcno ? { ...item, SCI_PRICE: value } : item
          )
        );
        setShoppingCartData((prevItem) =>
          prevItem.map((item) =>
            item.REQ_UMC_NO === umcno ? { ...item, SCI_PRICE: value } : item
          )
        );
        if (frncurrency === "INR") {
          SetRateFRN(value);
          //CurrencyChange(frncurrency, value);
          setShoppingCartItemData((prevItems) =>
            prevItems.map((item) =>
              item.SCI_MATL_NO === umcno
                ? { ...item, SCI_FRN_PRICE: value }
                : item
            )
          );
        }
      }
    } else if (field === "SCI_OA_VENCD") {
      //setDesiredVendor(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno ? { ...item, SCI_OA_VENCD: value } : item
        )
      );
    } else if (field === "SCI_TXT_PROC_CONS") {
      setProcCons(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno
            ? { ...item, SCI_TXT_PROC_CONS: value }
            : item
        )
      );
    } else if (field === "SCI_IMP_PLANT_MACHINERY") {
      setImpplantmachinery(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno
            ? { ...item, SCI_IMP_PLANT_MACHINERY: value }
            : item
        )
      );
    } else if (field === "SCI_FRN_PRICE") {
      if (regex_price.test(value)) {
        SetRateFRN(value);
        CurrencyChange(frncurrency, value);
        setShoppingCartItemData((prevItems) =>
          prevItems.map((item) =>
            item.SCI_MATL_NO === umcno
              ? { ...item, SCI_FRN_PRICE: value }
              : item
          )
        );
      }
    } else if (field === "SCI_INSTALLED_QTY") {
      if (regex.test(value)) {
        SetInstalledQty(value);
        setShoppingCartItemData((prevItems) =>
          prevItems.map((item) =>
            item.SCI_MATL_NO === umcno
              ? { ...item, SCI_INSTALLED_QTY: value }
              : item
          )
        );
      }
    } else if (field === "SCI_EXCHNG_RATE") {
      setExchingRate(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno
            ? { ...item, SCI_EXCHNG_RATE: value }
            : item
        )
      );
    } else if (field === "SCI_FRN_CURR_CD") {
      setFrnCurrency(value);
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno
            ? { ...item, SCI_FRN_CURR_CD: value }
            : item
        )
      );
    } else if (field === "SCI_PUR_GRP") {
      setPurchaseGroup(value);
      const statusdoctype = PurchaseValue.some((str) => str.includes(value));
      if (statusdoctype && fodtype === "PR") {
        setOpenImport("");
        setClassificationDisplay(true);
      } else {
        setOpenImport("none");
        setClassificationDisplay(false);
        SetCharacteristics("");
        Setcomposition("");
        SetEndUse("");
        SetfunctionText("");
        setImpplantmachinery("");
        setProcCons("");
      }
      setShoppingCartItemData((prevItems) =>
        prevItems.map((item) =>
          item.SCI_MATL_NO === umcno ? { ...item, SCI_PUR_GRP: value } : item
        )
      );
    }
    // const newData = [...shoppingCartItemData];
    // newData[index][field] = value;
    // setShoppingCartItemData(newData);

    // debugger;
    // setShoppingCartData((shoppingCartData) =>
    // shoppingCartData.map((item) =>
    //   item.REQ_UMC_NO == "6186A0165"
    //     ? { ...item, ["PRICE_PER_ITEM"]: Number(priceperitem) }
    //     : item
    //)
    //);

    // const newData = [...shoppingCartData];
    // newData[index][field] = value;
    //console.log(newdata);
  };

  const InputChangeUMC = (umc, field, value) => {
    var val = "";
    if (value === "MTRCL") {
      val = "Material consumtion within 33 month of Import";
    } else {
      val = value;
    }
    setShoppingCartItemData((prevItems) =>
      prevItems.map((item) =>
        item.SCI_MATL_NO === umc ? { ...item, SCI_TXT_PROC_CONS: val } : item
      )
    );
    setProcCons(value);
    console.log(shoppingCartItemData, "ShoppingCartItemData");
  };

  const CurrencyChange = async (ForeignCurrency, rateFRN) => {
    if (ForeignCurrency != "") {
      if (ForeignCurrency === "INR") {
        setExchingRate("1");
        setFrnCurrency("INR");
        //SetFRNRateUnit(ForeignCurrency);
        //setRateINR(rateFRN);
        InputChange(indexTBL, "SCI_EXCHNG_RATE", "1");
        InputChange(indexTBL, "SCI_FRN_CURR_CD", "INR");
        InputChange(indexTBL, "SCI_PRICE", rateFRN);
        return;
      }
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetCurrencyRateFromCurrency?Currency=${ForeignCurrency}`,
          { headers }
        )
        .then((response) => {
          const Rate = parseFloat(response.data.jsonData);
          const RateINR = parseFloat(rateFRN) * Rate;
          setExchingRate(Rate);
          setRateINR(RateINR || 0);
          setFrnCurrency(ForeignCurrency);
          //SetFRNRateUnit(ForeignCurrency);
          InputChange(indexTBL, "SCI_EXCHNG_RATE", Rate);
          InputChange(indexTBL, "SCI_FRN_CURR_CD", ForeignCurrency);
          InputChange(indexTBL, "SCI_PRICE", RateINR || 0);
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      setRateINR(parseFloat(rateINR) * 1);
      setExchingRate("1");
    }
  };

  //-------------------------GetApproval Hierarchy-----------------------
  const handleDownload_Appr = (row) => {
    try {
      // Convert Base64 string to Blob (assuming the data is a Base64 encoded PDF)
      const mimeType = "application/pdf"; // Adjust the MIME type as needed
      const blob = base64ToBlob(row.SCP_ATCHMNT, mimeType);

      const blobURL = createBlobURL(blob);
      downloadBlob(blobURL, row.SCP_FILENAME); // Adjust the file extension as needed
    } catch (error) {
      console.error("Download failed:", error);
    }
  };
  const GetApprovalHierarchy = async (SCNO) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      const scApprovalResponse = await axios.get(
        `${BaseUrl}api/ShoppingCart/SCApprovalHierarchy?SCNo=${SCNO}`,
        { headers }
      );
      const scApprovalheiData = scApprovalResponse.data;
      setApprovalHierarchy(scApprovalheiData.jsonData);
      console.log("ApprovalHierarchy", approvalHierarchy);
    } catch (error) {
      console.error("Error fetching shopping cart details", error);
    }
  };

  const handleSubmitForBudgetModal = () => {
    setShowBudgetModalInfo(false);
    setModalApp(!modalApp); 
    setShowModalApp(true) ;     
    //handleSubmit();
  };
  const handleSubmitForInformation = () => { 
    setShowModalApp(true) ; 
    setModalApp(!modalApp);     
    handleSubmit();
  };

  const handleCloseForBudgetModal = () => {
    setFlagBudgetModalInfo(false)
    setShowBudgetModalInfo(false);
  };

  const fetchBudgetDeatils = async (IndentorDept, SCH_CART_NO) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetBudgetDetails?dept=${IndentorDept}&SCH_CART_NO=${SCH_CART_NO}`,
        { headers }
      );
      SetBudgetdetailsList(response.data.jsonData);
      console.log(response.data.jsonData, "GetBudgetDetail");
    } catch (error) {}
  };

  const ChangeDocuments = async (value, TXT_LVL) => {
    setSCDocumentName(value);
    setSCDocumentTxtLvl(TXT_LVL);
    if (value != "") {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      await axios
        .get(
          `${BaseUrl}api/ShoppingCart/GetPRTextDocuments?UMCNo=${umcno}&Plant=${plant}&DocumentName=${value}&SCINO=${shoppingcartno}&ItemNo=${scItemNo}&TxtLvl=${TXT_LVL}`,
          { headers }
        )
        .then((response) => {
          setDocumentTypeText(response.data.jsonData);
          const statusdoctype = DocTextValue.some((str) => str.includes(value));
          if (statusdoctype) {
            setDocTextDisabled(isDisabled || true);
          } else {
            setDocTextDisabled(isDisabled);
          }
        })
        .catch((error) => {
          //console.log(error);
        });
    } else {
      Swal.fire("", "No Data Found", "error");
    }
  };

  const handleCostHeaderTextChange = (e) => {
    const selectedOption =
      e.target.value === "P"
        ? "Percentage"
        : e.target.value === "Q"
        ? "Quantity"
        : e.target.value === "V"
        ? "Value"
        : "Percentage";

    setCostAssesmentHeaderName(selectedOption);
    setCostDistribution(e.target.value);
  };
  const getACMode = (value) => {
    setGLACDisplay("");
    const a = ["K", "F", "Q"];
    let acMode = "VBR"; // Default value
    if (a.includes(value)) {
      // If the value is in the array `a`
      acMode = "VBR";
    } else if (value === "A") {
      // If value is 'A'
      acMode = "";
    } else if (value === "N") {
      // If value is 'N'
      acMode = "ZCN";
    } else {
      acMode = "NA";
      setGLACDisplay("none");
    }

    return acMode;
  };

  const handleItemSelection = (itemNumber) => {
    setItemStatus((prevStatus) => ({
      ...prevStatus,
      [itemNumber]: prevStatus[itemNumber] || false,
    }));
  };

  const handleSaveSuccess = (itemNumber) => {
    setItemStatus((prevStatus) => ({
      ...prevStatus,
      [itemNumber]: true,
    }));
  };

  const handleItemSelectionForSus = (itemNumber) => {
    setItemStatusSus((prevStatus) => ({
      ...prevStatus,
      [itemNumber]: prevStatus[itemNumber] || false,
    }));
  };

  const handleSaveSuccessForSus = (itemNumber) => {
    setItemStatusSus((prevStatus) => ({
      ...prevStatus,
      [itemNumber]: true,
    }));
  };

  const handleCostCategoryChange = async (value) => {
    // console.log("choose cost assignment", value)
    clearFields();
    setCostCategory(value);
    if (value.trim() === "") {
      updateData("1", {});
    }

    setisEnbleActivity(value);
    const ACMode = getACMode(value);
    try {
      if (ACMode != "NA") {
        let token = sessionStorage.getItem("token");
        let headers = {
          "jwt-token": token,
        };
        await axios
          .get(
            `${BaseUrl}api/ShoppingCart/GetGLAccountNo?UMCNO=${umcno}&Plant=${plant}&ACMode=${ACMode}`,
            { headers }
          )
          .then((response) => {
            console.log(response.data, "", response.data.jsonData);
            setGLAccount(response.data.jsonData);
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        //Swal.fire("", "No Data Found", "error");
      }
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  const handleInputChange = (id, field, value) => {
    const updatedRows = rows.map((row) => {
      if (row.SAA_LINE_NO === id) {
        return { ...row, [field]: value };
      }
      return row;
    });
    setRows(updatedRows);
  };

  //---------------------Back To IntelliBuy-------------------------------
  const handleBackToIntelliBuy = async () => {
    navigate("/SIS/IntelliBuySystemChecks");
  };

  const updateData = (key, jsonData) => {
    setErrorData((prevData) => {
      const updatedData = { ...prevData }; // Create a copy of the previous state

      // Check if jsonData is null or empty
      if (!jsonData || Object.keys(jsonData).length === 0) {
        // If jsonData is empty and the key exists, remove it
        if (updatedData[key]) {
          delete updatedData[key];
        }
      } else {
        // If jsonData has a length, check if the key exists
        // If it exists, update the value; if not, add it
        updatedData[key] = jsonData[key]; // Insert or update the key-value pair
      }

      return updatedData; // Return the updated state
    });
  };

  //---------------------Save As Draft-------------------------------
  const handleSaveAsDraft = async () => {
    if (shoppingCartItemData.length === 0) {
      Swal.fire("", "Please select atleast one shopping cart item", "error");
      return;
    }

    // if (bgg === "318" && MNPSelected === 0) {
    //   //Swal.fire("", "Please select atleast one value in MPN/Drawing", "error");
    //   const jData = {
    //     3: ["Please select atleast one value in MPN/Drawing"],
    //   };
    //   updateData("3", jData);
    //   setOpenDoc(true);
    //   return;
    // }
    prop.showLoader();
    var formDetails = {
      ObjShoppingCartHeader: {
        SCH_CART_No: shoppingcartno,
        SCH_TOT_VAL: totalPrice.toFixed(2),
        SCH_VAL_UNIT: "",
        SCH_STATUS: "",
        SCH_UPD_ID: "",
        SCH_INDT_TYP: shoppingCartItemData[0].SCH_INDT_TYP,
        SCH_COMP_CD: "",
        SCH_DEPT: dept,
        SCH_VERSION: "",
        SCH_BUDGET_EXCEEDED_AMT: "",
        SCH_RECOMMENDED_BY: "",
        SCH_GEP_CART_TYPE: "SIS",
        SCH_UPD_ID: user.User_Id,
        SCH_INDENT_NO: indentno
      },
      ObjShoppingCartItemDetails: shoppingCartItemData,
      IsDraft: "Y",
      ObjSustainibilityCSR: {
        SCC_CART_NO: shoppingcartno,
        SCC_ITEM_NO: scItemNo,
        SCC_FOD_TYPE: fodtype,
        SCC_FOD_NO: "",
        SCC_FOD_ITEM_NO: "",
        SCC_DEPT: dept,
        CSR_ACT_TAG: "",
        CSR_COMP: "",
        SCC_CRT_ID: user.User_Id,
        SCC_CRT_DT: "",
        SCC_SUB_CODE: "",
        SCC_SUB_ACTIVITY_CODE: "",
        SCC_LOC_CODE: "",
        SCC_REMARKS: "",
      },
    };
    ////console.log("wfdata", shoppingCartData);

    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertShoppingCartHeadrsAndItemDetails?isBudgetModalOpen=${showBudgetModalInfo}`,
          formDetails,
          { headers }
        )

        .then((response) => {
          if (response.data.Text === "success") {
            // fetchSavedDraftData();
            setisLoading(false);
            const jsonData = response.data.jsonData;
            const allErrorss = [];

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            setErrorList(allErrorss);
            updateData("3", jsonData);
            // updateData("5", jsonData);

            prop.hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
            if (frncurrency !== "INR") {
              hanldeSearchClick(indentno);
            }
          } else if (response.data.Text === "Failed") {
            //const errorMessages = response.data.jsonData["2"].map((error) => `<div style="font-size: 12px">${error}</div>`).join('');
            const jsonData = response.data.jsonData;
            const allErrors = [];
            const allErrorss = [];

            // Gather all errors into a single array with the raw text
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrors.push(error);
              });
            });

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            // Sort the array based on the error number at the beginning of each error string
            // allErrors.sort((a, b) => {
            //   const numA = parseInt(a.match(/^\d+/)[0], 10);
            //   const numB = parseInt(b.match(/^\d+/)[0], 10);
            //   return numA - numB;
            // });

            // Convert sorted errors into HTML format
            const formattedErrors = allErrors.map(
              (error) => `<div style="font-size: 12px">${error}</div>`
            );

            setErrorList(allErrorss);
            const errorMessages = formattedErrors.join("");
            setOpenDoc(true);
            updateData("3", jsonData);
            // updateData("5", jsonData);

            console.log("jsondata", jsonData);
            console.log("jsondata1", allErrorss);
            //debugger;
            Swal.fire({
              title: "Please check errors List Section",
              // html: errorMessages,
              icon: "error",
            });
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  //---------------------Save As Submit-------------------------------
  const handleSubmit = async () => {
    if (shoppingCartItemData.length === 0) {
      Swal.fire("", "Please select atleast one shopping cart item", "error");
      return;
    }

    if (isAnswer === "N") {
      Swal.fire(
        "",
        "Please response to the question asked before submitting the shopping cart for approval",
        "warning"
      );
      return;
    }

    const keys = Object.keys(Errodata);
    if (keys.length > 1 || (keys.length === 1 && keys[0] !== "4")) {
      Swal.fire(
        "",
        "Please resolve all your errors before proceeding",
        "error"
      );
      return;
    }

    console.log("submit", shoppingCartItemData);
    prop.showLoader();
    var formDetails = {
      ObjShoppingCartHeader: {
        SCH_CART_No: shoppingcartno,
        SCH_TOT_VAL: totalPrice.toFixed(2),
        SCH_VAL_UNIT: "",
        SCH_STATUS: "",
        SCH_INDT_TYP: shoppingCartItemData[0].SCH_INDT_TYP,
        SCH_COMP_CD: "",
        SCH_DEPT: dept,
        SCH_VERSION: "",
        SCH_BUDGET_EXCEEDED_AMT: "",
        SCH_RECOMMENDED_BY: "",
        SCH_GEP_CART_TYPE: "SIS",
        SCH_UPD_ID: user.User_Id,
        SCH_INDENT_NO: indentno
      },
      ObjShoppingCartItemDetails: shoppingCartItemData,
      IsDraft: "N",
      ObjSustainibilityCSR: {
        SCC_CART_NO: shoppingcartno,
        SCC_ITEM_NO: scItemNo,
        SCC_FOD_TYPE: fodtype,
        SCC_FOD_NO: "",
        SCC_FOD_ITEM_NO: "",
        SCC_DEPT: dept,
        CSR_ACT_TAG: "",
        CSR_COMP: "",
        SCC_CRT_ID: user.User_Id,
        SCC_CRT_DT: "",
        SCC_SUB_CODE: "",
        SCC_SUB_ACTIVITY_CODE: "",
        SCC_LOC_CODE: "",
        SCC_REMARKS: "",
      },
    };
    console.log("submit", shoppingCartItemData);
    GetApprovalPrompVal(indentno);
    // const allItemsValid = Object.values(itemStatus).every((status) => status);

    // if (!allItemsValid) {
    //     Swal.fire("", "First Save Cost Center data", "error");
    //     return;
    // }

    // const invalidItems = Object.keys(itemStatus).filter(
    //   (itemNumber) => !itemStatus[itemNumber]
    // );
    // console.log("Item status log", itemStatus);
    // if (invalidItems.length > 0) {
    //   Swal.fire(
    //     "",
    //     `First Save Cost Center data for Item Number ${invalidItems.join(
    //       ", "
    //     )}`,
    //     "error"
    //   );
    //   setisLoading(false);
    //   prop.hideLoader();
    //   return;
    // }
    // const invalidItemsForSus = Object.keys(itemStatusSus).filter((itemNumber) => !itemStatusSus[itemNumber]);
    // console.log("Item status log for sus", invalidItemsForSus)
    // if (invalidItemsForSus.length > 0) {

    //     Swal.fire("", `First Save Sustanibility data for Item Number ${invalidItemsForSus.join(', ')}`, "error");
    //     setisLoading(false);
    //     prop.hideLoader();
    //     return;
    // }

    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertShoppingCartHeadrsAndItemDetails?isBudgetModalOpen=${flagBudgetModalInfo}`,
          formDetails,
          { headers }
        )
        .then((response) => {
          console.log(
            response,
            "response",
            response.data.Text,
            "response.Status ",
            response.data.Status,
            " ",
            response.data.jsonData
          );
          if (response.data.Text === "success") {
            FetchSCCurrentStatus(shoppingcartno);
            GetApprovalHierarchy(shoppingcartno);
            setIsDisabledQA(true);
            const jsonData = response.data.jsonData;
            const allErrorss = [];

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });
            updateData("4", jsonData);

            setErrorList(allErrorss);
            setisLoading(false);
            prop.hideLoader();
            setFlagBudgetModalInfo(false);
            Swal.fire(
              "",
              "Shopping cart saved successful, Sent for approval.",
              "success"
            );
          } else if (response.data.Text === "Failed") {
            //const errorMessages = response.data.jsonData["2"].map((error) => `<div style="font-size: 12px">${error}</div>`).join('');
            const jsonData = response.data.jsonData;
            const allErrors = [];
            const allErrorss = [];

            // Gather all errors into a single array with the raw text
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrors.push(error);
              });
            });

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            // Sort the array based on the error number at the beginning of each error string
            // allErrors.sort((a, b) => {
            //   const numA = parseInt(a.match(/^\d+/)[0], 10);
            //   const numB = parseInt(b.match(/^\d+/)[0], 10);
            //   return numA - numB;
            // });

            // Convert sorted errors into HTML format
            const formattedErrors = allErrors.map(
              (error) => `<div style="font-size: 12px">${error}</div>`
            );

            if (
              Object.keys(jsonData).length === 0 &&
              showBudgetModalInfo === false
            ) {
              setShowBudgetModalInfo(true);
              setFlagBudgetModalInfo(true);
              // setShowBudgetModal(true)
              prop.hideLoader();
            } 
          //  else if (
          //     Object.keys(jsonData).length === 0 && showBudgetModalInfo === true
          //    && showmodalApp === false
          //   ) {
          //     setShowModal(true);
          //     // setShowBudgetModal(true)
          //     prop.hideLoader();
          //   }
            else {
              updateData("4", jsonData);
              setErrorList(allErrorss);
              const errorMessages = formattedErrors.join("");
              setOpenDoc(true);
              Swal.fire({
                title: "Please check error list section",
                //html: errorMessages,
                icon: "error",
              });
              prop.hideLoader();
              if (response.data.Status == "18") {
                Swal.fire("", response.data.jsonData, "warning");
              }
              if (response.data.Status == "18") {
                Swal.fire("", response.data.jsonData, "warning");
              }
            }
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  //=========================Change to Save as Draft Stage============>
  const ShowChangeShoppingCartbtn = (isDisabledflag, currentStatus) => {
    var flag = false;
    if (isDisabledflag && currentStatus === "52") {
      flag = true;
    } else if (isDisabledflag && currentStatus === "39") {
      flag = true;
    }

    return flag;
  };

  const handleChangetoSaveAsDraftStage = async () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You want to change this cart ?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.isConfirmed) {
        ChangetoSaveAsDraftStage();

        // User clicked "Yes"
        //Swal.fire('Deleted!', 'Your item has been deleted.', 'success');
        // Place your delete action here
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // User clicked "No"
        //Swal.fire('Cancelled', 'Your item is safe :)', 'error');
      }
    });
  };

  const ChangetoSaveAsDraftStage = async () => {
    var ObjShoppingCartHDR = {
      SCH_CART_NO: shoppingcartno,
      SCH_UPD_ID: user.User_Id,
    };
    console.log(ObjShoppingCartHDR, "ObjShoppingCartHDR");
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      await axios
        .post(
          `${BaseUrl}api/ShoppingCart/ChangeShoppingCartDraftStage`,
          ObjShoppingCartHDR,
          { headers }
        )
        .then((response) => {
          if (response.data.Text === "success") {
            setIsDisabled(false);
            setRODisabled(false);
            setCurrentSCStatus("38");
          } else if (response.data.Text === "Failed") {
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  //---------------------Save Documents --------------------
  const handleSaveDocument = async () => {
    //  setisLoading(true);
    // prop.showLoader();
    var sCDocument = {
      SCD_CART_NO: shoppingcartno,
      SCD_ITEM_NO: scItemNo,
      SCD_TXT_TYPE: scDocumentName,
      SCD_UPD_ID: user.User_Id,
      SCD_TXT: documentTypeText,
      SCD_LVL: scDocumentTxtLvl,
    };
    ////console.log("wfdata", shoppingCartData);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertSCDocumentDetails`,
          sCDocument,
          { headers }
        )

        .then((response) => {
          if (response.statusText === "OK") {
            UpdateTextColorDocumentList(scDocumentName, scDocumentTxtLvl);

            console.log("document list", DocumentsList);
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
          } else {
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  //---------------------Save Sustainibility --------------------
  const handleSaveSustainibility = async () => {
    //  setisLoading(true);
    // prop.showLoader();
    var objSCSustainibilityCSR = {
      SCC_CART_NO: shoppingcartno,
      SCC_ITEM_NO: scItemNo,
      SCC_FOD_TYPE: fodtype,
      SCC_FOD_NO: "",
      SCC_FOD_ITEM_NO: "",
      SCC_DEPT: dept,
      CSR_ACT_TAG: checkedItemId === "00" ? "N" : "Y",
      CSR_COMP: checkedItemId,
      SCC_CRT_ID: user.User_Id,
      SCC_CRT_DT: "",
      SCC_SUB_CODE: selectedOption,
      SCC_SUB_ACTIVITY_CODE: subactivityselectedOption,
      SCC_LOC_CODE: csrLocation,
      SCC_REMARKS: csrRemarks,
    };
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertSustainibilityCsr`,
          objSCSustainibilityCSR,
          { headers }
        )

        .then((response) => {
          if (response.data.Text === "success") {
            //handleSaveSuccessForSus((scItemNo));
            const jsonData = response.data.jsonData;
            const allErrorss = [];

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            setErrorList(allErrorss);
            // fetchSavedDraftData();
            updateData("2", jsonData);
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
          } else if (response.data.Text === "Failed") {
            //const errorMessages = response.data.jsonData["2"].map((error) => `<div style="font-size: 12px">${error}</div>`).join('');
            const jsonData = response.data.jsonData;
            const allErrors = [];
            const allErrorss = [];

            // Gather all errors into a single array with the raw text
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrors.push(error);
              });
            });
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            // Sort the array based on the error number at the beginning of each error string
            // allErrors.sort((a, b) => {
            //   const numA = parseInt(a.match(/^\d+/)[0], 10);
            //   const numB = parseInt(b.match(/^\d+/)[0], 10);
            //   return numA - numB;
            // });

            // Convert sorted errors into HTML format
            const formattedErrors = allErrors.map(
              (error) => `<div style="font-size: 12px">${error}</div>`
            );
            updateData("2", jsonData);
            console.log("dictionaryErrors", Errodata);
            setErrorList(allErrorss);
            const errorMessages = formattedErrors.join("");
            setOpenDoc(true);
            Swal.fire({
              title: "Please check Error List section",
              //html: errorMessages,
              icon: "error",
            });

            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };
  ////<===========================                    ===============>
  // const [query, setQuery] = useState("");
  // const [suggestions, setSuggestions] = useState();
  // const [loading, setLoading] = useState(false);
  // const [error, setError] = useState("");
  // const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  // const inputRef = useRef(null);

  // // API endpoint URL (replace with your actual API endpoint)
  // const apiEndpoint = `${BaseUrl}api/ShoppingCart/GetCostCenterSearch`;

  // // Function to handle input change
  // const handleChange = async (event, id) => {
  //   const value = event.target.value;
  //   setQuery(value);
  //   const updatedRows = rows.map((row) => {
  //     if (row.Line === id) {
  //       return { ...row, ["Assigned"]: value };
  //     }
  //     return row;
  //   });
  //   setRows(updatedRows);

  //   if (value.length >= 10 && /^[0-9]+$/.test(value)) {
  //     setLoading(true);
  //     setError("");
  //     setIsDropdownOpen(true);

  //     try {
  //       const response = await axios.get(apiEndpoint, {
  //         params: { costcenter: value },
  //       });
  //       console.log(response, "DESCRIPTION");
  //       console.log(response.data.jsonData.flat(), "DESCRIPTION1");
  //       const itemss = [response.data.jsonData[0].DESCRIPTION, ""];
  //       console.log(response.data.jsonData[0].DESCRIPTION, "itemss");
  //       setSuggestions(itemss);
  //     } catch (err) {
  //       setError("Failed to fetch suggestions");
  //     } finally {
  //       setLoading(false);
  //     }
  //   } else {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }
  // };

  // // Function to handle suggestion click
  // const handleSuggestionClick = (suggestion) => {
  //   setQuery(suggestion);
  //   setSuggestions([]);
  //   setIsDropdownOpen(false);
  // };

  // // Function to handle clicks outside
  // const handleClickOutside = (event) => {
  //   if (inputRef.current && !inputRef.current.contains(event.target)) {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }
  // };

  // useEffect(() => {
  //   document.addEventListener("mousedown", handleClickOutside);
  //   return () => {
  //     document.removeEventListener("mousedown", handleClickOutside);
  //   };
  // }, []);
  // ////<============================                    ================>

  //  ////<============================  Start code  Cost Center          ================>

  const [rows, setRows] = useState([
    {
      SAA_LINE_NO: "1",
      SAA_DISTRIBUTION_VAL: "100",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "2",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "3",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "4",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
    {
      SAA_LINE_NO: "5",
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    },
  ]);
  const addRow = () => {
    const newRow = {
      SAA_LINE_NO: rows.length + 1,
      SAA_DISTRIBUTION_VAL: "",
      SAA_ASGND_TO: "",
      SAA_ACTIVITY_NUM: "",
    };
    setRows([...rows, newRow]);
  };
  // Function to clear 'name' and 'age' fields
  const clearFields = () => {
    // Map through the current rows and update 'name' and 'age' fields
    const updatedRows = rows.map((row, index) => ({
      ...row,
      SAA_DISTRIBUTION_VAL: index === 0 ? "100" : "", // Clear the name field
      SAA_ASGND_TO: "", // Clear the age field
      SAA_ACTIVITY_NUM: "",
    }));
    setRows(updatedRows);
  };
  const updateCostAssesmentRows = (apiData) => {
    console.log(apiData, "newList");

    if (apiData.length > 0) {
      setCostCategory(apiData[0].SAA_CATEGORY);
      setCostDistribution(apiData[0].saa_distribution_tp);
      // // Create a map from the API data for quick lookup
      // const apiDataMap = new Map(
      //   apiData.map((item) => [item.SAA_LINE_NO, item])
      // );

      // // Update existing rows with the new data from API
      // const updatedRows = rows.map((row) =>
      //   apiDataMap.has(row.SAA_LINE_NO)
      //     ? { ...row, ...apiDataMap.get(row.SAA_LINE_NO) } // Merge existing row with new data
      //     : row
      // );

      // // Add new rows that are in the API data but not in the existing rows
      // const newRows = apiData.filter(
      //   (item) => !rows.some((row) => row.SAA_LINE_NO === item.SAA_LINE_NO)
      // );

      // // Combine updated rows and new rows
      // setRows([...updatedRows, ...newRows]);
      // //setRows([...newRows]);
      // // Log updated rows (for debugging purposes)
      setRows(apiData);
      //console.log("Updated rows:", [...updatedRows, ...newRows]);
    } else {
      //setRows(rows);
    }
  };

  ///============================================Autocomple=========================>
  const handleSelect = (selectedItem, id) => {
    const updatedRows = rows.map((row) => {
      if (row.SAA_LINE_NO === id) {
        return { ...row, ["SAA_ASGND_TO"]: selectedItem };
      }
      return row;
    });
    setRows(updatedRows);
    // const updatedRows = [...rows];
    // updatedRows[index].SAA_ASGND_TO = selectedItem;
    // setRows(updatedRows);
    // console.log(rows,'rows');
  };
  ////<============================    End code Autocomple Cost Center              ================>

  ////<=============================    Start Code Autocomple Vendor Code Search =================>
  const handleSelectVendorName = (selectedItem) => {
    setDesiredVendor(selectedItem);
    setShoppingCartItemData((prevItems) =>
      prevItems.map((item) =>
        item.SCI_MATL_NO === umcno
          ? { ...item, SCI_OA_VENCD: getFirstWord(selectedItem) }
          : item
      )
    );
  };
  ////<================================End Code Autocomple Vendor Code Search ====================>

  ////<====================================  Update MNP Drawing             ==============================>
  // Handle radio button change
  const handleMPNUpdateRadioChange = async (id) => {
    setMNPSelected(id);
    if (MNPSelected === 0) {
      updateData("3", {});
    }

    const rowToUpdate = MPNDrawingsdetailsList.find((row) => row.MFRNR === id);
    console.log(rowToUpdate, "mnp list");
    var ObjShoppingCartItemDetails = {
      SCI_PART_NO: rowToUpdate.PNO,
      SCI_MFRNR: rowToUpdate.MFRNR,
      SCI_MPN_NO: rowToUpdate.NAME1,
      SCI_CART_NO: shoppingcartno,
      SCI_ITEM_NO: scItemNo,
      SCI_UPD_ID: user.User_Id,
    };
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/UpdateMPNDrawing`,
          ObjShoppingCartItemDetails,
          { headers }
        )
        .then((response) => {
          if (response.data.Text === "success") {
            // fetchSavedDraftData();
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "MNP Details Updated.", "success");
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  const handleROVendorRadioChange = async (id) => {
    setROVendorSelected(id);
    const rowToUpdate = ROVendorList.find((row) => row.Contract === id);
    console.log(rowToUpdate, "mnp list");
    var ObjSourceListSet = {
      Contract: rowToUpdate.Contract,
      Item_no: rowToUpdate.Item_no,
      Vendor_code: rowToUpdate.Vendor_code,
      Souce_valid_to: rowToUpdate.Souce_valid_to,
      Contract_valid_to: rowToUpdate.Contract_valid_to,
      Balance: rowToUpdate.Balance,
      SCI_CART_NO: shoppingcartno,
      SCI_ITEM_NO: scItemNo,
      SCI_UPD_ID: user.User_Id,
      SCI_REQD_ON_DT: RequirementDate,
      TotalPrice: (Number(scqty) * Number(rateINR)).toString(),
    };
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(`${BaseUrl}api/ShoppingCart/UpdateROVendor`, ObjSourceListSet, {
          headers,
        })
        .then((response) => {
          if (response.data.Text === "success") {
            handleCheckboxChangeforSelect(shoppingcartno, umcno, indexTBL);
            setisLoading(false);
            updateData("5", response.data.jsonData);

            prop.hideLoader();
            Swal.fire("", "Vendor Details Updated.", "success");
          } else if (response.data.Text === "Failed") {
            updateData("5", response.data.jsonData);
            setOpenDoc(true);
            Swal.fire({
              title: "Please check Error List Section",
              // html: errorMessages,
              icon: "error",
            });
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  ///////<================================ File Download                          ========================>
  const base64ToBlob = (base64, mimeType) => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
  };

  const createBlobURL = (blob) => {
    return URL.createObjectURL(blob);
  };

  const downloadBlob = (blobURL, fileName) => {
    const link = document.createElement("a");
    link.href = blobURL;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownload = async (filesAttach, mimeType, scafileName) => {
    try {
      // Convert Base64 string to Blob (assuming the data is a Base64 encoded PDF)
      // const mimeType = sca_fileType; // Adjust the MIME type as needed
      const blob = base64ToBlob(filesAttach, mimeType);

      const blobURL = createBlobURL(blob);
      downloadBlob(blobURL, scafileName); // Adjust the file extension as needed
    } catch (error) {
      console.error("Download failed:", error);
    }
  };
  const GetSCAttachmentDetails = async (SCNO) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .get(`${BaseUrl}api/ShoppingCart/GetSCAttachmentDetails?SCNO=${SCNO}`, {
          headers,
        })
        .then((response) => {
          if (response.data.Text === "success") {
            setsca_fileAttachmentDetails(response.data.jsonData);
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) ;
    }
    return text;
  };
  ///////<================================ End File Download                     ==========================>

  ////<===================================   End Update MNP Drawing                ===============================>

  // Handler to update the table cell value when a suggestion is selected

  // const updatedRows = rows.map((row) => {
  //   if (row.Line === id) {
  //     return { ...row, ["Assigned"]: selectedItem };
  //   }
  //   return row;
  // });
  // setRows(updatedRows);

  // // <===========================Search Cost Center=====================>
  // // State for input value and suggestions
  // const [query, setQuery] = useState("");
  // const [suggestions, setSuggestions] = useState([]);
  // const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // // Ref to keep track of the input and dropdown
  // const inputRef = useRef(null);

  // // Sample suggestions list
  // const items = ["Apple", "Banana", "Cherry", "Date", "Fig", "Grape", "Kiwi"];
  // //const [items, setitems] = useState([]);

  // // Function to handle input changes
  // const handleChange = async (event, id) => {
  //   const value = event.target.value;
  //   if (value.length >= 10 && /^[0-9]+$/.test(value)) {

  //     setQuery(value);
  //     setIsDropdownOpen(true);
  //     try {
  //       let token = sessionStorage.getItem("token");
  //       let headers = {
  //         "jwt-token": token,
  //       };
  //       await axios
  //         .get(
  //           `${BaseUrl}api/ShoppingCart/GetCostCenterSearch?costcenter=${value}`,
  //           { headers }
  //         )
  //         .then((response) => {
  //           console.log(response.data, "", response.data.jsonData);
  //           setQuery(response.data.jsonData[0].COSTCNTR);
  //           //setitems(response.data.jsonData[0].DESCRIPTION);
  //         })
  //         .catch((error) => {
  //           console.log(error);
  //         });
  //     } catch (error) {
  //       prop.hideLoader();
  //       setisLoading(false);
  //     }
  //   } else {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }

  //   const updatedRows = rows.map((row) => {
  //     if (row.Line === id) {
  //       return { ...row, ["Assigned"]: value };
  //     }
  //     return row;
  //   });
  //   setRows(updatedRows);
  //   if (value) {
  //     const filteredSuggestions = items.filter((item) =>
  //       item.toLowerCase().includes(value.toLowerCase())
  //     );
  //     setSuggestions(filteredSuggestions);
  //     setIsDropdownOpen(true);
  //   } else {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }
  // };

  // // Function to handle suggestion selection
  // const handleSuggestionClick = (suggestion) => {
  //   setQuery(suggestion);
  //   setSuggestions([]);
  //   setIsDropdownOpen(false);
  // };

  // // Close the dropdown when clicking outside
  // const handleClickOutside = (event) => {
  //   if (inputRef.current && !inputRef.current.contains(event.target)) {
  //     setSuggestions([]);
  //     setIsDropdownOpen(false);
  //   }
  // };

  // useEffect(() => {
  //   // Add event listener for outside clicks
  //   document.addEventListener("mousedown", handleClickOutside);
  //   return () => {
  //     document.removeEventListener("mousedown", handleClickOutside);
  //   };
  // }, []);
  // <=========================== End Search Cost Center=====================>
  //---------------------Save Cost Assignment  --------------------
  const getFirstWord = (str) => {
    const parts = str.split(">");
    console.log(parts[0], "Split");
    return parts[0].trim(); // Return the first part
  };
  const handleSaveCostAssignment = async () => {
    if (costCategoryvalue.trim() === "") {
      return;
    }
    const ObjCostAssignment = [];
    console.log(rows, "cost center rows");
    rows.forEach((row) => {
      //  const newData = [...objCostAssignmentList];
      console.log(row[0], "cost center");
      var Assigntext = "";

      if (row.SAA_DISTRIBUTION_VAL != "") {
        if (costCategoryvalue.trim() === "K") {
          Assigntext = getFirstWord(row.SAA_ASGND_TO);
        } else {
          Assigntext = row.SAA_ASGND_TO;
        }
        var objSCCostAssignmentdata = {
          SAA_CART_NO: shoppingcartno,
          SAA_ITEM_NO: scItemNo,
          SAA_LINE_NO: row.SAA_LINE_NO,
          SAA_DISTRIBUTION_TP: costDistribution,
          SAA_CATEGORY: costCategoryvalue,
          SAA_ASGND_TO: Assigntext,
          SAA_UPD_ID: user.User_Id,
          SAA_DISTRIBUTION_VAL: row.SAA_DISTRIBUTION_VAL,
          SAA_ACTIVITY_NUM: row.SAA_ACTIVITY_NUM,
          SAA_Dept: dept,
          ObjShoppingCartItemDetails: {
            SCI_MATL_NO: selectedItemId,
            DEPT: dept,
            SCI_QTY: scqty,
            SCI_PRICE: rateINR,
            SCI_MATL_GRP: BGG,
            SCI_DOC_TYPE: docType,
            SCI_FOD_TYPE: fodtype,
          },
        };
        ObjCostAssignment.push(objSCCostAssignmentdata);
      }
    });
    //setObjCostAssignmentList(objSCCostAssignment);
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      axios
        .post(
          `${BaseUrl}api/ShoppingCart/InsertCostAssesmentList`,
          ObjCostAssignment,
          { headers }
        )
        .then((response) => {
          if (response.data.Text === "success") {
            //handleSaveSuccess(scItemNo);
            const jsonData = response.data.jsonData;
            const allErrorss = [];

            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            setErrorList(allErrorss);
            updateData("1", jsonData);
            // fetchSavedDraftData();
            setisLoading(false);
            prop.hideLoader();
            Swal.fire("", "Items Saved Successfully", "success");
          } else if (response.data.Text === "Failed") {
            //const errorMessages = response.data.jsonData["2"].map((error) => `<div style="font-size: 12px">${error}</div>`).join('');
            const jsonData = response.data.jsonData;
            const allErrors = [];
            const allErrorss = [];
            // Gather all errors into a single array with the raw text
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrors.push(error);
              });
            });
            Object.keys(jsonData).forEach((key) => {
              const errors = jsonData[key];
              errors.forEach((error) => {
                allErrorss.push(error);
              });
            });

            // Sort the array based on the error number at the beginning of each error string
            // allErrors.sort((a, b) => {
            //   const numA = parseInt(a.match(/^\d+/)[0], 10);
            //   const numB = parseInt(b.match(/^\d+/)[0], 10);
            //   return numA - numB;
            // });

            // Convert sorted errors into HTML format
            const formattedErrors = allErrors.map(
              (error) => `<div style="font-size: 12px">${error}</div>`
            );
            const errorMessages = formattedErrors.join("");
            //const descriptions = data.jsonData.map(jsonData);
            setErrorList(allErrorss);
            setOpenDoc(true);
            updateData("1", jsonData);
            console.log("jsondata", jsonData);
            console.log("jsondata", allErrorss);
            Swal.fire({
              title: "Please check Error List Section",
              // html: errorMessages,
              icon: "error",
            });
            prop.hideLoader();
          }
        });
    } catch (error) {
      prop.hideLoader();
      setisLoading(false);
    }
  };

  //-----------------Start make validation For Question & Amswer----------------------------
  const GetAnswerStatus = async (SCId, IndSts) => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const AnswerStatusResponse = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetAnswerStatus?SCNo=${SCId}&UserId=${user.User_Id}`,
        { headers }
      );
      const StatusResponse = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetCurrentSCStatus?SCNO=${shoppingcartno}`,
        { headers }
      );
      const CurrentStatusResponse = StatusResponse.data.jsonData;
      const AnswerStatusData = AnswerStatusResponse.data;
      if (AnswerStatusData.jsonData.length > 0) {
        const IsAnswer = AnswerStatusData.jsonData[0].SCC_IS_ANSWER;
        setIsAnswer(IsAnswer);
        if (IsAnswer === "N") {
          setIsDisabledQA(false);
          setHighlightBlink(true); // Highlight and blink Reply & View Message button
        } else {
          setIsDisabledQA(true);
          setHighlightBlink(false);
          setIsAnswer("");
        }
      } else {
        setIsAnswer("");
        console.log("Niraj-1", CurrentStatusResponse);
        if (CurrentStatusResponse === "52") {
          setIsDisabledQA(false);
        } else {
          setIsDisabledQA(true);
        }
        setHighlightBlink(false);
      }
    } catch (error) {
      console.error("Error fetching Answer status details", error);
    }
  };

  const refreshStatus = async () => {
    GetAnswerStatus(shoppingcartno, currentSCStatus);
    FetchSCCurrentStatus(shoppingcartno);
    console.log("refreshStatus", shoppingcartno, currentSCStatus);
  };

  //-----------------End make validation For Question & Amswer----------------------------

  return (
    <div>
      {/* <Navbar />
      <TabMenu prop={"IntelliBuySystemChecks"} /> */}
      {!state ? (
        <>
          <div
            className="container"
            style={{ marginTop: "8px", maxWidth: "95%" }}
          >
            <div className="card">
              <div className="card-body" style={{ maxWidth: "100%" }}>
                <div className="row">
                  <div className="col-md-6"></div>
                  <div className="col-md-3"></div>
                </div>
                <div className="row w-100 p-3" >
                  <div className="col-md-9 ml-1">
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                        marginRight:"5px"
                      }}
                    >
                      {"    "}
                      Shopping Cart No:
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px",
                      }}
                    >
                      {shoppingcartno} 
                    </label>
                    <label
                      style={{
                        textAlign: "center",
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "black",
                        marginLeft: "20px",
                      }}
                    >
                      {" "}
                      Shopping Cart Name:
                    </label>
                    <label 
                      style={{                       
                        fontSize: "20px",
                        fontWeight: "bold",
                        color: "red",
                        marginLeft: "10px"
                      }}
                    >
                       {truncateText(SCH_CART_NAME,69)}
                    </label>
                  </div>
                 
                  <div className="col-md-3">
                    <input
                      type="text"
                      value={filterText}
                      onChange={handleFilterChange}
                      className="form-control"
                      placeholder="Enter search text"
                    />
                  </div>
                </div>

                <div className="row mt-2" style={{ overflowX: "auto" }}>
                  <div className="table-responsive table-responsive-sm">
                    <table className="tables table-bordered tb">
                      <thead className="table-primary">
                        <tr>
                          <th> Select</th>
                          <th> Sl No</th>
                          <th> UMC No</th>
                          <th> Description </th>
                          <th> BGG</th>
                          <th>Requirement Date</th>
                          <th> SC Qty</th>
                          <th> Rate Per Item </th>
                          <th> Price</th>
                          {isEnbleActivity === "N" && <th>Activity Number</th>}
                          {FRNRateUnit !== "INR" && (
                            <th> Rate Per Item ({FRNRateUnit}) </th>
                          )}
                          {FRNRateUnit !== "INR" && (
                            <th> Price ({FRNRateUnit})</th>
                          )}
                          <th> Document Type</th>
                          <th> Plant </th>
                        </tr>
                      </thead>

                      <tbody>
                        {" "}
                        {currentData.map((row, index) => (
                          <tr
                            key={index}
                            style={{
                              backgroundColor:
                                selectedRow === index ? "#ddd" : "white",
                            }}
                          >
                            <td style={{ display: "none" }}>
                              {row.UMC_INDENT_ID}
                            </td>
                            <td>
                              <input
                                type="checkbox"
                                defaultChecked="false"
                                checked={selectedItemId === row.REQ_UMC_NO}
                                onChange={() =>
                                  handleCheckboxChangeforSelect(
                                    row.SCH_CART_NO,
                                    row.REQ_UMC_NO,
                                    index
                                  )
                                }
                              />
                            </td>

                            <td>{row.SRNO}</td>
                            <td>{row.REQ_UMC_NO}</td>
                            <td>{row.REQ_UMC_DESC}</td>

                            <td>{row.SCI_MATL_GRP}</td>
                            <td>{row.REQUIREMENT_DATE}</td>
                            <td>
                              {row.QTY} {row.SCI_QTY_UNIT}
                            </td>
                            <td>
                              {Number(row.SCI_PRICE).toFixed(2)}{" "}
                              {row.SCI_PRICE_UNIT}
                            </td>

                            <td>
                              {Number(
                                calculatePrice(row.SCI_PRICE, row.QTY)
                              ).toFixed(2)}{" "}
                              {row.SCI_PRICE_UNIT}
                            </td>
                            {FRNRateUnit !== "INR" && (
                              <td>
                                {Number(row.SCI_FRN_PRICE).toFixed(2)}{" "}
                                {row.SCI_FRN_CURR_CD}
                              </td>
                            )}
                            {FRNRateUnit !== "INR" && (
                              <td>
                                {Number(
                                  calculatePrice(row.SCI_FRN_PRICE, row.QTY)
                                ).toFixed(2)}{" "}
                                {row.SCI_FRN_CURR_CD}
                              </td>
                            )}
                            <td> {row.DOCUMENT_TYPE_DESC}</td>
                            <td> {row.INDENTOR_PLANT}</td>
                          </tr>
                        ))}{" "}
                      </tbody>
                      <tfoot>
                        <tr>
                          <td colSpan="6"></td>
                          <td
                            style={{ color: "blue", fontWeight: "bold" }}
                            colSpan="2"
                          >
                            Total
                          </td>
                          {/* <td style={{color:"blue",fontWeight:"bold"}}>{totalRate.toFixed(2)}</td> */}
                          <td style={{ color: "blue", fontWeight: "bold" }}>
                            {totalPrice.toFixed(2)} {rateUnit}
                          </td>
                          <td></td>
                          {FRNRateUnit !== "INR" && (
                            <td style={{ color: "blue", fontWeight: "bold" }}>
                              {totalFRNPrice.toFixed(2)} {FRNRateUnit}
                            </td>
                          )}
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>

                <div className="row mt-2">
                  <div className="col-2">
                    <button
                      color="link"
                      disabled={isApprovalBtnDisabled}
                      onClick={toggleAppHei}
                      type="submit"
                      className="btn btn-danger"
                    >
                      Approval Details
                    </button>
                  </div>

                  <div className="col-3">
                    <div>
                      {!isDisabledQA && (
                        <button
                          onClick={handleShow}
                          className={`btn btn-warning ${
                            highlightBlink ? "blinking" : ""
                          }`}
                          disabled={!isIndentor}
                        >
                          Approval Question
                        </button>
                      )}

                      {/* <button onClick={handleShow} disabled={isDisabledQA} className={`btn btn-warning  ${highlightBlink ? 'blinking' : ''}`}>Approval Question</button> */}
                      {showModal && (
                        <AppQue
                          handleClose={handleClose}
                          shoppingcartno={shoppingcartno}
                          refreshStatus={refreshStatus}
                        />
                      )}
                    </div>
                  </div>

                  <div className="col-3">
                    <div className="pagination">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <button
                          key={index}
                          onClick={() => handlePageChange(index + 1)}
                          className={`page-link ${
                            currentPage === index + 1 ? "active" : ""
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="col-4 d-flex justify-content-end">
                    <button
                      type="button"
                      class="btn btn-outline-primary mx-1"
                      style={{ display: isDisabled ? "none" : "" }}
                      onClick={() => handleSaveAsDraft()}
                    >
                      {" "}
                      Save as Draft
                    </button>
                    <button
                      type="button"
                      class="btn btn-outline-success mx-1"
                      style={{ display: isDisabled ? "none" : "" }}
                      disabled={isDisabled}
                      onClick={() => handleSubmit()}
                    >
                      {" "}
                      Submit
                    </button>

                    <button
                      type="button"
                      class="btn btn-outline-warning mx-1"
                      style={{
                        display: ShowChangeShoppingCartbtn(
                          isDisabled,
                          currentSCStatus
                        )
                          ? ""
                          : "none",
                      }}
                      disabled={!isIndentor}
                      onClick={() => handleChangetoSaveAsDraftStage()}
                    >
                      {" "}
                      Change Shopping Cart
                    </button>
                  </div>
                  {/*
                  <div className="col-2 d-flex justify-content-end">
                    <button
                      type="button"
                      disabled={isDisabled}
                      onClick={() => handleSaveAsDraft()}
                      className="btn btn-primary"

                    >
                      Save as Draft
                    </button>
                  </div>

                  <div className="col-1 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-success"
                      disabled={isDisabled}
                      onClick={() => handleSubmit()}
                    >
                      Submit
                    </button>
                  </div>
                  <div className="col-2 d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-warning"
                      disabled={isDisabled}
                      onClick={() => handleSaveAsDraft()}
                    >
                      Change Shopping Cart
                    </button>
                  </div> */}
                </div>
                <div>
                  <Modal
                    isOpen={modalappHei}
                    toggle={toggleAppHei}
                    className="modal-dialog modal-xl"
                  >
                    <ModalHeader toggle={toggleAppHei}>
                      Approval Heirarchy
                    </ModalHeader>
                    <ModalBody>
                      <Form>
                        <FormGroup>
                          <div className="col-12">
                            <div>
                              <div
                                className="row"
                                style={{ overflowX: "auto" }}
                              >
                                <div className="tables table-responsive">
                                  <table className="table table-bordered">
                                    <thead>
                                      <tr>
                                        <th>Version</th>
                                        <th>Approval Level</th>
                                        <th>Approver Name</th>
                                        <th>Status</th>
                                        <th>Comments</th>
                                        <th>Action Date</th>
                                        <th>Attachment</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {currentapprovalHierarchy.map(
                                        (row, index) => {
                                          const isGreenRow =
                                            row.MAILSEND === "01" &&
                                            (row.APP_STATE === "00" ||
                                              row.APP_STATE === "03");
                                          return (
                                            <tr
                                              key={row.LVL}
                                              style={{
                                                color: isGreenRow
                                                  ? "green"
                                                  : selectedRow === row.LVL
                                                  ? "#ddd"
                                                  : "white",
                                              }}
                                            >
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.VERSION}
                                              </td>
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.LVL}
                                              </td>
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.APPROVER}
                                              </td>
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.STATUS}
                                              </td>
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.REMARKS}
                                              </td>
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.ACTION_DT}
                                              </td>
                                              <td
                                                style={{
                                                  color: isGreenRow
                                                    ? "green"
                                                    : "black",
                                                }}
                                              >
                                                {row.SCP_ATCHMNT ? (
                                                  <a
                                                    key={row.LVL}
                                                    onClick={() =>
                                                      handleDownload_Appr(row)
                                                    }
                                                    style={{
                                                      cursor: "pointer",
                                                    }}
                                                  >
                                                    <i
                                                      className="fa fa-eye"
                                                      style={{ color: "blue" }}
                                                    ></i>
                                                  </a>
                                                ) : (
                                                  "NA"
                                                )}
                                              </td>
                                            </tr>
                                          );
                                        }
                                      )}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                        </FormGroup>
                      </Form>
                    </ModalBody>
                    <ModalFooter>
                      <Button color="secondary" onClick={toggleAppHei}>
                        Close
                      </Button>
                    </ModalFooter>
                  </Modal>
                  {showBudgetModalInfo && (
                    <BudgetConsumptionWarningModal
                      BudgetdetailsList={BudgetdetailsList}
                      handleCloseForBudgetModal={handleCloseForBudgetModal}
                      handleSubmitForBudgetModal={handleSubmitForBudgetModal}
                      totalPrice={totalPrice}
                    />
                  )}
                </div>
                {/*------Approval Conformation Message-------*/}
                <div className="row mt-1">
                  <div className="col-md-12">
                    <div className="App" style={{ width: "700px" }}>
                      <Modal
                        isOpen={modalApp}
                        toggleAsk={toggleApp}                        
                        className="modal-dialog modal-lg"
                      >
                        <ModalHeader toggleAsk={toggleApp} className="center">
                          Information
                        </ModalHeader>
                        <ModalBody>
                          <Form>
                            <FormGroup>
                              <div className="col-12">
                                <div style={{ border: "1px solid blue" }}>
                                  <div
                                    className="row"
                                    style={{ overflowX: "auto" }}
                                  >
                                    <div className="tables table-responsive table-responsive-sm">
                                      <table className="table table-bordered tb">
                                        <thead className="table-primary">
                                          <tr>
                                            <th>Attribute</th>
                                            <th>Details</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <td>{"Shopping Cart No. :"}</td>
                                            <td>{SCH_CART_NO}</td>
                                          </tr>
                                          <tr>
                                            <td>{"Shopping Cart Name :"}</td>
                                            <td>{SCH_CART_NAME}</td>
                                          </tr>
                                          <tr>
                                            <td>{" Dept Code And Desc : "}</td>
                                            <td>{DEPT}</td>
                                          </tr>

                                          <tr>
                                            <td>
                                              {"Purchage Group & Description :"}
                                            </td>
                                            <td>{PURDESC}</td>
                                          </tr>

                                          <tr>
                                            <td>{"DOC Type :"}</td>
                                            <td>{SCI_FOD_TYPE_DESC}</td>
                                          </tr>

                                          <tr>
                                            <td>
                                              {"Initial value of Indent(INR) :"}
                                            </td>
                                            <td>
                                              {formatCurrency(
                                                TOTAL_INITIAL_INDENT_VALUE
                                              )}
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>
                                              {"Final value of Indent(INR) :"}
                                            </td>
                                            <td>
                                              {formatCurrency(
                                                FINAL_INDENT_VALUE
                                              )}
                                            </td>
                                          </tr>

                                          <tr>
                                            <td>{"Saving(in INR) : "}</td>
                                            <td>
                                              {formatCurrency(SAVING_VALUE)}
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </FormGroup>
                          </Form>
                        </ModalBody>
                        <ModalFooter>
                          <Button color="primary" onClick={handleSubmitForInformation}>
                            OK
                          </Button>
                          {/* <Button color="secondary" onClick={toggleApp}>
                            Cancel
                          </Button> */}
                        </ModalFooter>
                      </Modal>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {enablePanel && (
              <div className="panel">
                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    className="card-heading"
                    onClick={togglePanel}
                    style={{ backgroundColor: "#0d6efd", height: "34px" }}
                  >
                    <div>
                      <h6 className="mt-2" style={{ color: "white" }}>
                        &nbsp;{" "}
                        {open ? (
                          <i className="fa fa-minus text-blue"></i>
                        ) : (
                          <i className="fa fa-plus text-blue"></i>
                        )}
                        &nbsp; Indent Item Details &nbsp;{"      "} UMC No :{" "}
                        {umcnodesc}
                      </h6>
                    </div>
                  </div>
                  <Collapse in={open}>
                    <div className="card-body">
                      {/* ----------Start Nav Tab---------- */}
                      <div className="col-12">
                        <Tabs
                          defaultActiveKey="SSA"
                          id="uncontrolled-tab-example"
                          className="my-tab position-relative"
                        >
                          <Tab
                            eventKey="SSA"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                Basic Data
                              </div>
                            }
                            className="act-clr"
                          >
                            <br />
                            <div className="row">
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Storage location
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {StorageLocation}{" "}
                                    </label>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Document type
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {DocumentType}{" "}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Purchase Group
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    {/* <label className="form-label label-font">
                                      {" "}
                                      {PurchaseGroup}
                                    </label> */}
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                      value={PurchaseGroup}
                                      //disabled={isDisabled}
                                      disabled={roDisabled}
                                      onChange={(e) =>
                                        InputChange(
                                          umcno,
                                          "SCI_PUR_GRP",
                                          e.target.value
                                        )
                                      }
                                    >
                                      {roDisabled ? (
                                        ""
                                      ) : (
                                        <option value=""> Select </option>
                                      )}
                                      {purchaseList.map((jsonData, id) => (
                                        <option key={id} value={jsonData.PG_CD}>
                                          {jsonData.PGL}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Shopping Cart Qty
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {scqty}
                                    </label>
                                  </div>
                                </div>
                                <div className="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      UOM
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {scuom}
                                    </label>
                                  </div>
                                </div>
                                {roDisabled ? (
                                  ""
                                ) : (
                                  <div class="row mt-1">
                                    <div class="col-md-4">
                                      <label className="form-label label-font">
                                        Actual Moving Average Price
                                      </label>
                                    </div>
                                    <div className="col-md-1">
                                      {" "}
                                      <label className="form-label label-font">
                                        :
                                      </label>
                                    </div>
                                    <div class="col-md-4 d-flex justify-content-start">
                                      <label className="form-label label-font">
                                        {mapvalue}{" "}
                                      </label>
                                      {/* <input
                                      className="form-control form-control-sm"
                                      value={mapvalue}
                                      // value={priceperitem} // Bind inpu      dfff t value to state variable
                                      // onChange={(e) =>
                                      //   InputChange(indexTBL,"PRICE_PER_ITEM",e.target.value)
                                      // }
                                    ></input> */}
                                    </div>
                                  </div>
                                )}

                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Material Consumption Plan
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                      disabled={isDisabled}
                                      value={ProcCons}
                                      //value={setProcCons( e.target.value)}
                                      onChange={(e) =>
                                        InputChangeUMC(
                                          umcno,
                                          "SCI_TXT_PROC_CONS",
                                          e.target.value
                                        )
                                      }
                                    >
                                      <option Value=""> --Select-- </option>
                                      <option Value="MTRCL">
                                        Material consumtion within 33 month of
                                        Import
                                      </option>
                                      <option Value="O"> Other</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Requester Name
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-4 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {requesterName}
                                    </label>
                                  </div>
                                </div>
                              </div>
                              <div className="col-6">
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Procurement Type
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {ProcurementType}
                                    </label>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Spare Categorization
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {UnderConsumption}
                                    </label>
                                  </div>
                                </div>

                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Requirement Date
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <label className="form-label label-font">
                                      {RequirementDate}
                                    </label>
                                  </div>
                                </div>
                                {installedQtyDisplay ? (
                                  <div
                                    class="row mt-1"
                                    // style={{ display: installedQtyDisplay }}
                                  >
                                    <div class="col-md-4">
                                      <label className="form-label label-font">
                                        Installed Quantity (Nos)
                                      </label>
                                    </div>
                                    <div className="col-md-1">
                                      {" "}
                                      <label className="form-label label-font">
                                        :
                                      </label>
                                    </div>
                                    <div class="col-md-5 d-flex justify-content-start">
                                      <input
                                        className="form-control form-control-sm"
                                        disabled={isDisabled}
                                        //onChange={handleInputChange} // Handle input change
                                        value={installedQty}
                                        onChange={(e) =>
                                          InputChange(
                                            indexTBL,
                                            "SCI_INSTALLED_QTY",
                                            e.target.value
                                          )
                                        }
                                      ></input>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="row mt-1">
                                    <div class="col-md-12">&nbsp;</div>
                                  </div>
                                )}
                                <div class="row mt-1">
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Rate (INR)
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <input
                                      className="form-control form-control-sm"
                                      value={rateINR}
                                      disabled={roDisabled}
                                      //value={priceperitem} // Bind input value to state variable
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_PRICE",
                                          e.target.value
                                        )
                                      }
                                    ></input>
                                  </div>
                                </div>
                                {roDisabled && frncurrency === "INR" ? (
                                  ""
                                ) : (
                                  <div class="row mt-1">
                                    <div class="col-md-4">
                                      <label className="form-label label-font">
                                        Rate (Foreign Curr.)
                                      </label>
                                    </div>
                                    <div className="col-md-1">
                                      {" "}
                                      <label className="form-label label-font">
                                        :
                                      </label>
                                    </div>
                                    <div class="col-md-3">
                                      <input
                                        className="form-control form-control-sm"
                                        value={rateFRN}
                                        disabled={roDisabled}
                                        // onChange={(e) =>
                                        //   Setrateperitem(e.target.value)
                                        // }
                                        onChange={(e) =>
                                          InputChange(
                                            indexTBL,
                                            "SCI_FRN_PRICE",
                                            e.target.value
                                          )
                                        }
                                      ></input>
                                    </div>
                                    <div class="col-md-2 mr-1 pr-1">
                                      <select
                                        name="category"
                                        id="category"
                                        className="form-control form-control-sm"
                                        type="text"
                                        value={frncurrency}
                                        disabled={roDisabled}
                                        onChange={(e) =>
                                          CurrencyChange(
                                            e.target.value,
                                            rateFRN
                                          )
                                        }
                                      >
                                        <option value="INR"> INR </option>
                                        {CurrencyList.map((jsonData, id) => (
                                          <option
                                            key={id}
                                            value={jsonData.FCURR}
                                          >
                                            {jsonData.FCURR}
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                  </div>
                                )}

                                <div
                                  class="row mt-1"
                                  style={{ display: openimport }}
                                >
                                  <div class="col-md-4">
                                    <label className="form-label label-font">
                                      Imported Plant And Machinery
                                    </label>
                                  </div>
                                  <div className="col-md-1">
                                    {" "}
                                    <label className="form-label label-font">
                                      :
                                    </label>
                                  </div>
                                  <div class="col-md-5 d-flex justify-content-start">
                                    <select
                                      name="category"
                                      id="category"
                                      className="form-control form-control-sm"
                                      type="text"
                                      disabled={isDisabled}
                                      value={Impplantmachinery}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_IMP_PLANT_MACHINERY",
                                          e.target.value
                                        )
                                      }
                                    >
                                      <option Value=""> --Select-- </option>
                                      <option Value="Y">Yes</option>
                                      <option Value="N">No</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <p style={{ float: "right" }}>
                              <button
                                type="button"
                                className="btn btn-success mt-2"
                                disabled={isDisabled}
                                onClick={() => handleSaveAsDraft()}
                              >
                                Save
                              </button>
                            </p>
                          </Tab>
                          <Tab
                            eventKey="CRA"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                Cost Assignment
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <label
                                style={{ fontSize: "16px", fontWeight: "bold" }}
                              >
                                You can see who bears the costs and, if
                                necessary, you can distribute the costs to
                                several cost centers.
                              </label>
                              <div className="row mt-3">
                                <div className="col-2">
                                  <label>Category</label>
                                </div>
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    type="text"
                                    value={costCategoryvalue}
                                    onChange={(e) =>
                                      //setCostCategory(e.target.value)
                                      handleCostCategoryChange(e.target.value)
                                    }
                                    disabled={isDisabled}
                                  >
                                    {CostCategoryList.map((jsonData, id) => (
                                      <option
                                        key={id}
                                        value={jsonData.ACCT_ASGNMT_CAT}
                                      >
                                        {jsonData.ACCT_ASGNMT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-2">
                                  <label>Cost Distribution</label>
                                </div>
                                <div className="col-3">
                                  <select
                                    className="form-control form-control-sm"
                                    value={costDistribution}
                                    onChange={(e) =>
                                      handleCostHeaderTextChange(e)
                                    }
                                    disabled={isDisabled}
                                  >
                                    {/* <option Value=""> --Select-- </option> */}
                                    <option Value="P">Percentage </option>
                                    <option Value="Q"> Quantity </option>
                                    <option Value="V"> Value </option>
                                  </select>
                                </div>
                              </div>
                              <div
                                className="row mt-3"
                                style={{ display: GLACDisplay }}
                              >
                                <div className="col-2">
                                  <label>G/L Account No</label>
                                </div>
                                <div className="col-2">{GLAccount}</div>
                              </div>
                              <button
                                className="btn btn-primary mt-2 mb-3"
                                onClick={addRow}
                                disabled={isDisabled}
                              >
                                Add New Row
                              </button>
                              <div className="tables table-responsive">
                                <table className="table table-bordered">
                                  <thead>
                                    <tr>
                                      <th>Line</th>
                                      <th>{costAssesmentHeaderName}</th>
                                      <th>Assigned To</th>
                                      {isEnbleActivity === "N" && (
                                        <th>Activity Number</th>
                                      )}

                                      <th>Delete</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {rows.map((row, index) => (
                                      <tr key={row.SAA_LINE_NO}>
                                        <td>{index + 1}</td>
                                        <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.SAA_DISTRIBUTION_VAL}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.SAA_LINE_NO,
                                                "SAA_DISTRIBUTION_VAL",
                                                e.target.value
                                              )
                                            }
                                            disabled={isDisabled}
                                          />
                                        </td>
                                        <td>
                                          {costCategoryvalue === "K" ? (
                                            <Autocomplete
                                              disabled={isDisabled}
                                              initialValue={row.SAA_ASGND_TO}
                                              Type={costCategoryvalue}
                                              onSelect={(selectedItem) =>
                                                handleSelect(
                                                  selectedItem,
                                                  row.SAA_LINE_NO
                                                )
                                              }
                                            />
                                          ) : (
                                            <input
                                              type="text"
                                              className="form-control form-control sm"
                                              value={row.SAA_ASGND_TO}
                                              onChange={(e) =>
                                                handleInputChange(
                                                  row.SAA_LINE_NO,
                                                  "SAA_ASGND_TO",
                                                  e.target.value
                                                )
                                              }
                                              disabled={isDisabled}
                                            />
                                          )}
                                        </td>

                                        {isEnbleActivity === "N" && (
                                          <td>
                                            <input
                                              type="text"
                                              className="form-control form-control sm"
                                              value={row.SAA_ACTIVITY_NUM}
                                              onChange={(e) =>
                                                handleInputChange(
                                                  row.SAA_LINE_NO,
                                                  "SAA_ACTIVITY_NUM",
                                                  e.target.value
                                                )
                                              }
                                              disabled={isDisabled}
                                            />
                                          </td>
                                        )}

                                        {/* <td>
                                          <input
                                            type="text"
                                            className="form-control form-control sm"
                                            value={row.Assigned}
                                            onChange={(e) =>
                                              handleInputChange(
                                                row.Line,
                                                "Assigned",
                                                e.target.value
                                              )
                                            }
                                            disabled={isDisabled}
                                          />
                                        </td> */}
                                        <td>
                                          <button
                                            onClick={() => {
                                              deleteRow(row.SAA_LINE_NO);
                                            }}
                                            style={{
                                              width: "25px",
                                              height: "25px",
                                              padding: "0px",
                                            }}
                                            class="btn btn-danger btn-sm"
                                            type="button"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            title="Delete"
                                            disabled={isDisabled}
                                          >
                                            <i class="fa fa-trash"></i>
                                          </button>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            <p style={{ float: "right" }}>
                              <button
                                type="button"
                                className="btn btn-success mt-2"
                                onClick={() => handleSaveCostAssignment()}
                                disabled={isDisabled}
                              >
                                Save
                              </button>
                            </p>
                          </Tab>
                          <Tab
                            eventKey="IBCA"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                Documents
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-3">
                                <div className="col-3">
                                  <select
                                    name="category"
                                    id="category"
                                    className="form-control form-control-sm"
                                    onChange={(e) => {
                                      const selectedOption = DocumentsList.find(
                                        (item) =>
                                          item.TXT_DESC.trim() ===
                                          e.target.options[
                                            e.target.selectedIndex
                                          ].text.trim()
                                      );
                                      if (selectedOption) {
                                        ChangeDocuments(
                                          selectedOption.TEXT_ID,
                                          selectedOption.TXT_LVL
                                        );
                                      } else {
                                        ChangeDocuments(e.target.value, "");
                                      }
                                    }}
                                  >
                                    <option value=""> --Select-- </option>
                                    {DocumentsList.map((jsonData) => (
                                      <option
                                        key={jsonData.TEXT_ID} // Use TEXT_ID as key for uniqueness
                                        value={jsonData.TEXT_ID}
                                        style={{ color: jsonData.CLASSNAME }}
                                      >
                                        {jsonData.TXT_DESC}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                <div className="col-9">
                                  <textarea
                                    className="form-control form-control sm"
                                    value={documentTypeText}
                                    onChange={(e) =>
                                      setDocumentTypeText(e.target.value)
                                    }
                                    rows={6}
                                    disabled={DocTextDisabled}
                                    //disabled={isDisabled}
                                    //cols={40}
                                  />
                                </div>
                              </div>
                              <p style={{ float: "right" }}>
                                <button
                                  type="button"
                                  className="btn btn-success mt-2"
                                  onClick={() => handleSaveDocument()}
                                  disabled={isDisabled}
                                >
                                  Save
                                </button>
                              </p>
                            </div>
                          </Tab>
                          <Tab
                            eventKey="SCA"
                            title={
                              <div style={{ padding: "0px 35px 0px 35px" }}>
                                Sustainibility
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div className="row mt-1">
                              <div
                                className="col-4"
                                style={{
                                  height: "320px",
                                  overflowY: "scroll",
                                  // border: '1px solid black',
                                  padding: "10px",
                                  // backgroundColor: '#f0f0f0'
                                }}
                              >
                                <p>
                                  Please check the categories those are
                                  applicable
                                </p>
                                <Form>
                                  {/* <Form.Check type="checkbox" /> */}
                                  {CsrCategoryList.map((option) => (
                                    <Form.Check
                                      key={option.VALUE}
                                      type="checkbox"
                                      label={option.LABEL}
                                      defaultChecked="false"
                                      checked={checkedItemId === option.VALUE}
                                      onChange={() =>
                                        handleCheckboxChange(option.VALUE)
                                      }
                                      disabled={isDisabled}
                                    />
                                  ))}
                                </Form>
                                {/* <p>
                                  {selectedOptions.length} /{" "}
                                  {CsrCategoryList.length} selected
                                </p> */}
                              </div>
                              <div
                                className="col-4"
                                style={{
                                  height: "320px",
                                  overflowY: "scroll",
                                  // border: '1px solid black',
                                  padding: "10px",
                                  // backgroundColor: '#f0f0f0'
                                }}
                              >
                                <Form>
                                  {CsrSubCategoryList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroup"
                                      value={option.VALUE}
                                      checked={selectedOption === option.VALUE}
                                      onChange={() =>
                                        handleRadioChange(option.VALUE)
                                      }
                                      disabled={isDisabled}
                                    />
                                  ))}
                                </Form>
                                {/* <p>Selected option: {selectedOption}</p> */}
                              </div>
                              <div
                                className="col-4"
                                style={{
                                  height: "320px",
                                  overflowY: "scroll",
                                  // border: '1px solid black',
                                  padding: "10px",
                                  // backgroundColor: '#f0f0f0'
                                }}
                              >
                                <Form>
                                  {CsrSubActivityList.map((option, index) => (
                                    <Form.Check
                                      key={index}
                                      type="radio"
                                      label={option.LABEL}
                                      name="radioGroupAct"
                                      value={option.VALUE}
                                      checked={
                                        subactivityselectedOption ===
                                        option.VALUE
                                      }
                                      onChange={() =>
                                        handleSubActivityRadioChange(
                                          option.VALUE
                                        )
                                      }
                                      disabled={isDisabled}
                                    />
                                  ))}
                                </Form>
                                <p>
                                  {/* Selected option: {subactivityselectedOption} */}
                                </p>
                              </div>
                            </div>
                            <div
                              className="row mt-3"
                              style={{ display: socialDisplay }}
                            >
                              <div className="col-2">
                                <label>Location</label>
                              </div>
                              <div className="col-3">
                                <select
                                  name="category"
                                  id="category"
                                  className="form-control form-control-sm"
                                  type="text"
                                  value={csrLocation}
                                  onChange={(e) =>
                                    setCsrLocation(e.target.value)
                                  }
                                >
                                  <option> --Select-- </option>
                                  {csrLocationList.map((jsonData, id) => (
                                    <option
                                      key={id}
                                      value={jsonData.CSR_LOC_CODE}
                                    >
                                      {jsonData.CSR_LOC_DESC}
                                    </option>
                                  ))}
                                </select>
                              </div>
                              <div class="col-md-6">
                                <textarea
                                  className="form-control form-control-sm"
                                  style={{ width: "400", height: "100px" }}
                                  //  onChange={handleRemarksChange}
                                  value={csrRemarks}
                                  onChange={(e) =>
                                    setCsrRemarks(e.target.value)
                                  }
                                  placeholder="Remarks"
                                ></textarea>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-11 d-flex justify-content-end">
                                <button
                                  type="button"
                                  className="btn btn-success mt-2"
                                  onClick={() => handleSaveSustainibility()}
                                  disabled={isDisabled}
                                >
                                  Save
                                </button>
                              </div>
                            </div>
                          </Tab>
                          {ClassificationDisplay ? (
                            <Tab
                              eventKey="CLA"
                              title={
                                <div style={{ padding: "0px 35px 0px 35px" }}>
                                  Classification
                                </div>
                              }
                              className="tab-txt-clr act-clr"
                            >
                              <div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      HSN No.
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <input
                                      className="form-control"
                                      disabled={isDisabled}
                                    ></input>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Characteristics
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={characteristics}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_CHARACTERISTICS",
                                          e.target.value
                                        )
                                      }
                                      // onChange={(e) =>
                                      //   SetCharacteristics(e.target.value)
                                      // }
                                      placeholder="Characteristics"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Composition
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={composition}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_COMPOSITION",
                                          e.target.value
                                        )
                                      }
                                      placeholder="Composition"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      End use :
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={enduse}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_ENDUSE",
                                          e.target.value
                                        )
                                      }
                                      placeholder="   End use :	"
                                    ></textarea>
                                  </div>
                                </div>
                                <div className="row mt-2">
                                  <div className="col-3">
                                    <label className="form-label label-font d-flex justify-content-end">
                                      Function
                                    </label>
                                  </div>
                                  <div className="col-6">
                                    <textarea
                                      className="form-control form-control-sm"
                                      style={{ width: "400", height: "100px" }}
                                      disabled={isDisabled}
                                      value={functionText}
                                      onChange={(e) =>
                                        InputChange(
                                          indexTBL,
                                          "SCI_FUNCTION",
                                          e.target.value
                                        )
                                      }
                                      placeholder="Function"
                                    ></textarea>
                                  </div>
                                </div>
                                <div>
                                  <p style={{ float: "right" }}>
                                    <button
                                      type="button"
                                      className="btn btn-success mt-2"
                                      onClick={() => handleSaveAsDraft()}
                                      disabled={isDisabled}
                                    >
                                      Save
                                    </button>
                                  </p>
                                </div>
                              </div>
                            </Tab>
                          ) : (
                            ""
                          )}
                          {DesiredVendorDisplay ? (
                            <Tab
                              eventKey="DV"
                              title={
                                <div style={{ padding: "0px 10px 0px 10px" }}>
                                  Source of supply/Service Agents
                                </div>
                              }
                              //style={{display:DesiredVendorDisplay}}
                              className="tab-txt-clr act-clr"
                            >
                              {fodtype === "PR" ? (
                                <div className="row mt-2">
                                  {isDisabled === false ? (
                                    <div className="row">
                                      <div class="col-md-3">
                                        <label className="form-label label-font">
                                          Desired Vendor
                                        </label>
                                      </div>
                                      <div class="col-md-3">
                                        <AutocompleteVendorMaster
                                          initialValue={desiredVendor}
                                          onSelect={handleSelectVendorName}
                                        />
                                      </div>
                                      <div>
                                        <p style={{ float: "right" }}>
                                          <button
                                            type="button"
                                            className="btn btn-success mt-2"
                                            onClick={() => handleSaveAsDraft()}
                                            disabled={isDisabled}
                                          >
                                            Save
                                          </button>
                                        </p>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="row">
                                      <div className="row mt-2">
                                        <div className="tables table-responsive">
                                          <table className="table table-bordered">
                                            <thead>
                                              <tr>
                                                <th>Vendor Code</th>
                                                <th>Vendor Name</th>
                                              </tr>
                                            </thead>
                                            {vendordetailsList.map(
                                              (row, index) => (
                                                <tbody>
                                                  <tr>
                                                    <td>{row.VENDOR}</td>
                                                    <td>{row.NAME1}</td>
                                                  </tr>
                                                </tbody>
                                              )
                                            )}
                                          </table>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <div className="row mt-2">
                                  <div className="tables table-responsive">
                                    <table className="table table-bordered">
                                      <thead>
                                        <tr>
                                          <th>Action</th>
                                          <th>Contract</th>
                                          <th>Item No</th>
                                          <th>Vendor Code</th>
                                          <th>Vendor Name</th>
                                          <th>Source Valid From</th>
                                          <th>Source Valid To</th>
                                          <th>Contract Valid From</th>
                                          <th>Contract Valid To</th>
                                          <th>Balance</th>
                                        </tr>
                                      </thead>
                                      {ROVendorList.map((row, index) => (
                                        <tbody>
                                          <tr>
                                            <td>
                                              <Form.Check
                                                key={index}
                                                type="radio"
                                                name="radioGroup"
                                                checked={
                                                  ROVendorSelected ===
                                                  row.Contract
                                                }
                                                onChange={() =>
                                                  handleROVendorRadioChange(
                                                    row.Contract
                                                  )
                                                }
                                                disabled={isDisabled}
                                              />
                                            </td>
                                            <td>{row.Contract}</td>
                                            <td>{row.Item_no}</td>
                                            <td>{row.Vendor_code}</td>
                                            <td>{row.Vendor_name}</td>
                                            <td>{row.Source_valid_from}</td>
                                            <td>{row.Souce_valid_to}</td>
                                            <td>{row.Contract_valid_from}</td>
                                            <td>{row.Contract_valid_to}</td>
                                            <td>{row.Balance}</td>
                                          </tr>
                                        </tbody>
                                      ))}
                                    </table>
                                  </div>
                                </div>
                              )}
                              <p style={{ float: "right" }}></p>
                            </Tab>
                          ) : (
                            ""
                          )}
                          {MPNDrawingsdetailsList.length > 0 ? (
                            <Tab
                              eventKey="NPM"
                              title={
                                <div style={{ padding: "0px 35px 0px 35px" }}>
                                  MPN/Drawing
                                </div>
                              }
                              className="tab-txt-clr act-clr"
                            >
                              <div className="row mt-2">
                                <div className="tables table-responsive">
                                  <table className="table table-bordered">
                                    <thead>
                                      <tr>
                                        {bgg === "318" && <th>Action</th>}
                                        <th>Part No/Drawing</th>
                                        <th>Manufacturer</th>
                                        <th>Manufacturer Name</th>
                                      </tr>
                                    </thead>
                                    {MPNDrawingsdetailsList.map(
                                      (row, index) => (
                                        <tbody>
                                          <tr>
                                            {bgg === "318" && (
                                              <td>
                                                <Form.Check
                                                  key={index}
                                                  type="radio"
                                                  name="radioGroup"
                                                  checked={
                                                    MNPSelected === row.MFRNR
                                                  }
                                                  onChange={() =>
                                                    handleMPNUpdateRadioChange(
                                                      row.MFRNR
                                                    )
                                                  }
                                                  disabled={isDisabled}
                                                />
                                              </td>
                                            )}
                                            <td>{row.PNO}</td>
                                            <td>{row.MFRNR}</td>
                                            <td>{row.NAME1}</td>
                                          </tr>
                                        </tbody>
                                      )
                                    )}
                                  </table>
                                </div>
                              </div>
                              <p style={{ float: "right" }}></p>
                            </Tab>
                          ) : (
                            ""
                          )}
                          <Tab
                            eventKey="FOD"
                            title={
                              <div style={{ padding: "0px 30px 0px 30px" }}>
                                FOD
                              </div>
                            }
                            className="tab-txt-clr act-clr"
                          >
                            <div>
                              <div className="row mt-3">
                                <div className="tables table-responsive">
                                  <table className="table table-bordered">
                                    <thead>
                                      <tr>
                                        <th>FOD Type</th>
                                        <th>Fod No./FOD Item No</th>
                                        <th>FOD Creation Date</th>
                                        <th>FOD SAP Message</th>
                                      </tr>
                                    </thead>
                                    <tbody style={{ textAlign: "center" }}>
                                      <td>{fodtype}</td>
                                      <td>
                                        {sapFODNo}
                                        {" / "}
                                        {sapFODItemNo}
                                      </td>
                                      <td>{sapFODCreatedDT}</td>
                                      <td>{sapFODMsg}</td>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </Tab>
                        </Tabs>
                      </div>
                      {/*----End Nav Tab-----*/}
                    </div>
                  </Collapse>
                </div>
                {/* <div
                  class="card text-white bg-danger mt-3"
                >
                  <div class="card-header">Header</div>
                  <div class="card-body bg-white">
                    <h5 class="card-title">Secondary card title</h5>
                    <p class="card-text">
                      Some quick example text to build on the card title and
                      make up the bulk of the card's content.
                    </p>
                  </div>
                </div> */}
                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    onClick={togglePanelDoc}
                    className="card-heading text-white bg-danger"
                    style={{ maxHeight: "100px" }}
                  >
                    <h6 className="mt-2" style={{ color: "white" }}>
                      &nbsp;{" "}
                      {opendoc ? (
                        <i className="fas fa-angle-down text-blue"></i>
                      ) : (
                        <i className="fas fa-angle-up text-blue"></i>
                      )}
                      &nbsp; &nbsp;Error List
                    </h6>
                  </div>
                  <Collapse in={opendoc}>
                    <div className="card-body">
                      <div className="row mt-2">
                        <ul
                          style={{
                            color: "red",
                            padding: "10px",
                            border: "1px solid red",
                          }}
                        >
                          {/* {errorList.map((message, index) => (
                            <div key={index}>
                              {index + 1}. {message}
                            </div>
                          ))} */}

                          {/*  {Object.values(Errodata).map((valueList, index) => (
                            <div key={index}>
                              {Array.isArray(valueList) ? (
                                valueList.map((value, idx) => <p key={idx}>{value}</p>)
                              ) : (
                                <p>{valueList}</p>
                              )}
                            </div>
                          ))}*/}
                          {
                            // Combine all values from different keys into a single array
                            Object.values(Errodata)
                              .flat() // Flatten the arrays into one array
                              .map((value, idx) => (
                                <p key={idx}>
                                  {idx + 1}. {value}
                                </p>
                              ))
                          }
                        </ul>
                      </div>
                    </div>
                  </Collapse>
                </div>

                {/*----Document Upload Section-----*/}

                <div className="card mt-3" style={{ maxWidth: "100%" }}>
                  <div
                    onClick={togglePanelDoc}
                    className="card-heading"
                    style={{ backgroundColor: "#0d6efd", height: "34px" }}
                  >
                    <h6 className="mt-2" style={{ color: "white" }}>
                      &nbsp;{" "}
                      {opendoc ? (
                        <i className="fas fa-angle-down text-blue"></i>
                      ) : (
                        <i className="fas fa-angle-up text-blue"></i>
                      )}
                      &nbsp; &nbsp;Document Upload Section
                    </h6>
                  </div>
                  <Collapse in={opendoc}>
                    <div className="card-body">
                      <div
                        className="row mt-2"
                        style={{ display: isDisabled ? "none" : "" }}
                      >
                        <div class="col-md-2">
                          <label className="form-label label-font">
                            Select File to Upload
                          </label>
                        </div>
                        <div class="col-md-3">
                          <input
                            type="file"
                            accept=".pdf"
                            onChange={handleFileChange}
                          />

                          <br />
                          <span style={{ color: "Red", fontSize: "14px" }}>
                            Only .pdf
                          </span>
                        </div>
                        <div class="col-md-4">
                          <textarea
                            className="form-control form-control-sm"
                            style={{ width: "400", height: "100px" }}
                            //  onChange={handleRemarksChange}
                            placeholder="Remarks"
                          ></textarea>
                        </div>
                        <div className="col-md-3">
                          <Button
                            className="btn btn-warning"
                            onClick={handleUpload}
                          >
                            Upload
                          </Button>
                        </div>
                      </div>
                      <div className="row mt-2">
                        <table className="table table-bordered">
                          <thead>
                            <tr
                              style={{
                                textAlign: "center",
                                fontWeight: "bold",
                              }}
                            >
                              <th> Sr No</th>
                              <th>File Name</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          {sca_fileAttachmentDetails.map((row, index) => (
                            <tbody style={{ textAlign: "center" }}>
                              <tr>
                                <td>{index + 1}</td>
                                <td>{row.SCA_FILE_NAME}</td>
                                <td>
                                  <button
                                    onClick={() => {
                                      handleDownload(
                                        row.SCA_FILE,
                                        row.SCA_FILE_TYPE,
                                        row.SCA_FILE_NAME
                                      );
                                    }}
                                    style={{
                                      width: "25px",
                                      height: "25px",
                                      padding: "0px",
                                    }}
                                    class="btn btn-danger btn-sm"
                                    type="button"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title="Download"
                                  >
                                    <i class="fa fa-download"></i>
                                  </button>
                                </td>
                              </tr>
                            </tbody>
                          ))}
                        </table>
                      </div>
                    </div>
                  </Collapse>
                </div>
                {/*----Document Upload Section-----*/}
              </div>
            )}
          </div>
        </>
      ) : (
        <ApprovalScreen />
      )}
    </div>
  );
};

export default ShoppingCart;

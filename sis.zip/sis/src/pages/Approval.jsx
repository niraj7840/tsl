import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar/Navbar";
import axios from "axios";
import { BaseUrl } from "../constants/BaseURL";
import { useSelector } from "react-redux";
import $ from "jquery";

const Approval = () => {
  const navigate = useNavigate();
  const [showPanel, setShowPanel] = useState(false);
  const [showPending, setShowPending] = useState(true);
  const [SCworkFlowData, setSCworkFlowData] = useState([]);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [filterText, setFilterText] = useState("");
  const [sortOrder, setSortOrder] = useState("asc"); // Track sort order
  const [sortedColumn, setSortedColumn] = useState("INDENT_ID"); // Track sorted column
  
 //user.User_Id='163402'; //--make sure  remove this line before update onserver

  // useEffect(() => {
  //   getWorkflow();
  // }, []);



  useEffect(() => {
    // Check sessionStorage to decide whether to show the panel
    const showFromSpecificPage = sessionStorage.getItem("fromSpecificPage");

    if (showFromSpecificPage === "true") {
      setShowPanel(true); // Show panel if coming from a specific page
    }

    // Cleanup the sessionStorage after it's used
    sessionStorage.removeItem("fromSpecificPage");

    getWorkflow(); // Load workflow data or other logic

  }, []);


  const getWorkflow = async () => {
    let token = sessionStorage.getItem("token");
    const headers = {
      "jwt-token": token,
    };
debugger;
    try {
     // const response = await axios.get(`${BaseUrl}api/ShoppingCart/SCApprovalPendingList?UserId=${"163402"}`,
      const response = await axios.get(`${BaseUrl}api/ShoppingCart/SCApprovalPendingList?UserId=${user.User_Id}`,
       {
        headers,
        withCredentials: true,
      });
      setSCworkFlowData(response.data.jsonData);
      console.log("approvalPage: ", response.data.jsonData)
    } catch (error) {
      console.log(error);
    }
  };
  
  const handleIndentNo = (e) => {
    sessionStorage.setItem("SC_IndentNo", e.INDENT_ID);
    sessionStorage.setItem("nextApprover", e.NEXT_APPROVER);
    sessionStorage.setItem("AppStatusType", e.NEXT_SCP_APP_STATUS);
    sessionStorage.setItem("Did", e.SCH_DEPT);
    
    navigate("/SIS/SC_Approval");
  };

  const handleFilterChange = (event) => {
    setFilterText(event.target.value);
  };

  // Generic sort handler for any column
  const handleSort = (column) => {
    const newSortOrder = sortedColumn === column && sortOrder === "asc" ? "desc" : "asc";
    setSortOrder(newSortOrder);
    setSortedColumn(column);

    const sortedData = [...SCworkFlowData].sort((a, b) => {
      if (newSortOrder === "asc") {
        return a[column] > b[column] ? 1 : -1;
      } else {
        return a[column] < b[column] ? 1 : -1;
      }
    });

    setSCworkFlowData(sortedData);
  };
debugger;
  // Combined filteredData logic to avoid reassignment
  const filteredData = SCworkFlowData.filter((row) => {
    const status = row.NEXT_SCP_APP_STATUS?.trim() || "";
    const nextApprover = row.NEXT_APPROVER?.trim() || "";
    const currentApprover = row.SCP_APPRVR?.trim() || "";
    const ApprStage = row.NEXT_STATUS?.trim() || "";
debugger;
    const approverMatch = nextApprover === user.User_Id ;
     const currApproverMatch = currentApprover === user.User_Id ;
    if (showPending) {
      return status === "00" && approverMatch 
    } else {
      return ["", "01", "02" ,"03"].includes(status) && currApproverMatch;
    }
  }).filter((row) => { 
    const searchText = filterText.toLowerCase();

    for (const key in row) {
      const value = row[key];
      if (value !== undefined && value !== null) {
        if (typeof value === "string" && value.toLowerCase().includes(searchText)) {
          return true;
        } else if (typeof value === "number" && value.toString().includes(searchText)) {
          return true;
        }
      }
    }
    return false;
  });

  const renderArrow = (column) => {
    if (sortedColumn === column) {
      return sortOrder === "asc" ? "↑" : "↓";
    }
    return "↕"; // Default arrow for unsorted columns
  };

  return (
    <div>
      <Navbar />
      <div className="container" style={{ marginTop: "8px", maxWidth: "100%" }}>
        <div className="card">
          <div className="card-heading" style={{ backgroundColor: "lightgray", height: "44px" }}>
            <h4 className="mt-2">
              &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Pending For My Approval
            </h4>
          </div>
          <div className="card-body">
            <div className="row mt-1">
              <div className="row col-12">
                <div className="col-3"></div>
                <div className="col-4">
                  <button type="button" className="btn btn-primary" onClick={() => navigate(`/SIS/MyAction`)}>
                    Spare Sharing Approval
                  </button>
                </div>
                <div className="col-4">
                  <button type="button" className="btn btn-primary" onClick={() => setShowPanel(!showPanel)}>
                    Shopping Cart Approval
                  </button>
                </div>
                <div className="col-2"></div>
              </div>
              {showPanel && (
                <div className="row col-12 mt-3">
                  <div className="col-12">
                    <div className="card">
                      <div className="card-header">
                        <p style={{ textAlign: "center" }}>
                          <button
                            type="button"
                            className={`btn ${showPending ? "btn-warning" : "btn-outline-secondary"}`}
                            onClick={() => setShowPending(true)}
                          >
                            Pending Approval
                          </button>
                          &nbsp;&nbsp;
                          <button
                            type="button"
                            className={`btn ${!showPending ? "btn-success" : "btn-outline-success"}`}
                            onClick={() => setShowPending(false)}
                          >
                            Complete Approval
                          </button>
                        </p>
                      </div>
                      <div className="row mt-1">
                        <div className="col-md-4">
                          <input
                            style={{ border: "1px solid blue" , marginLeft: "18px" }}
                            type="text"
                            value={filterText}
                            onChange={handleFilterChange}
                            className="form-control"
                            placeholder="Enter Indent No / SC No for search text"
                          />
                        </div>
                      </div>
                      <div className="card-body">
                        <table className="table table-bordered">
                          <thead className="table-primary">
                            <tr style={{ textAlign: "center" }}>
                              <th onClick={() => handleSort("INDENT_ID")}>
                                Indent Number {renderArrow("INDENT_ID")}
                              </th>
                              <th onClick={() => handleSort("SCH_CART_NO")}>
                                Shopping Cart No {renderArrow("SCH_CART_NO")}
                              </th>
                              <th onClick={() => handleSort("DEPT")}>
                                Department {renderArrow("DEPT")}
                              </th>
                              <th onClick={() => handleSort("SCI_FOD_TYPE")}>
                                FOD Type {renderArrow("SCI_FOD_TYPE")}
                              </th>
                              <th onClick={() => handleSort("SCH_TOT_VAL")}>
                                Shopping Total Value {renderArrow("SCH_TOT_VAL")}
                              </th>
                              <th onClick={() => handleSort("NEXT_STATUS")}>
                                Status {renderArrow("NEXT_STATUS")}
                              </th>
                              <th onClick={() => handleSort("PENDINGSINCE")}>
                                Pending Since {renderArrow("PENDINGSINCE")}
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredData.map((row, index) => (
                              <tr key={index}>
                                <td className="tblTd">
                                  <button className="btn btn-sm text-primary" onClick={() => handleIndentNo(row)}>
                                    {row.INDENT_ID}
                                  </button>
                                </td>
                                <td className="tblTd">
                                  <a onClick={() => handleIndentNo(row)} className="text-primary">
                                    {row.SCH_CART_NO}
                                  </a>
                                </td>
                                <td className="tblTd">{row.DEPT}</td>
                                <td className="tblTd">{row.SCI_FOD_TYPE}</td>
                                <td className="tblTd">{row.SCH_TOT_VAL}</td>
                                <td className="tblTd">{row.NEXT_STATUS}</td>
                                <td className="tblTd">{row.PENDINGSINCE}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Approval;

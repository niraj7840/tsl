import React, { useRef } from 'react'
import Navbar from '../components/Navbar/Navbar';
import { FaWpforms } from "react-icons/fa6";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import LoadingBar from 'react-top-loading-bar'
import { BaseUrl } from "../constants/BaseURL";
import "../pages/ViewCapitalRequest.css";
import TabMenu from '../components/TabMenu/TabMenu';

const ViewCapitalRequest = ({ showLoader, hideLoader }) => {

    const [show, setShow] = React.useState(false);
    const [requestData, setRequestData] = React.useState([]);
    const [dataForEachId, setdataForEachId] = React.useState([]);
    const [selectedRequestId, setSelectedRequestId] = React.useState(null);
    const [selectedRequestDetails, setSelectedRequestDetails] = React.useState([]);
    const [remark, setRemark] = React.useState("");
    const [message, setMessage] = React.useState("");
    //const [showSuccessModal, setShowSuccessModal] = React.useState(false);
    const [showNotFoundModal, setShowNotFoundModal] = React.useState(false);
    const [clickedRequestedId, setClickRequestedId] = React.useState(null);
    const [umcSearchTerm, setUmcSearchTerm] = React.useState("");
    const [requestIdSearchTerm, setRequestIdSearchTerm] = React.useState("");
    const [umc, setUmc] = React.useState("");
    const [requestId, setRequestId] = React.useState("");
    const detailsRef = useRef(null);
    const [progress, setProgress] = React.useState(0)
    const [fetchedData, setFetchedData] = React.useState([]);

    const navigate = useNavigate();
    React.useEffect(() => {
        setProgress(20);
        showLoader();
        fetchGetViewScreenData();
        setProgress(100);
    }, []);

    React.useEffect(() => {
        if(show && detailsRef.current)
            {
                detailsRef.current.scrollIntoView({ behavior: 'smooth' });
            }
    }, [show, selectedRequestId]);



    const handleUmcSearchChange = (event) => {
        setShow(false)
        setUmcSearchTerm(event.target.value);
    }

    const handleRequestIdSearchChange = (event) => {
        setShow(false)
        setRequestIdSearchTerm(event.target.value);
    }

    /**const filteredRequestData = searchTerm ?
        requestData.filter(request =>
            request.CUA_UMC.toLowerCase().includes(searchTerm.toLowerCase())
        ):
        requestData;*/

    const filteredRequestData = requestData.filter(request =>
        (umcSearchTerm === "" || request.CUA_UMC.toLowerCase().includes(umcSearchTerm.toLowerCase())) &&
        (requestIdSearchTerm === "" || request.CUA_REQUEST_ID.toString().includes(requestIdSearchTerm))

    )

    const fetchGetViewScreenData = async () => {
        try {

            const response = await axios.get(`${BaseUrl}api/ViewCapReq/GetViewPendingRequest/`);
            const data = response.data.jsonData;

            setdataForEachId(data);

            const uniqueRequests = getUniqueRequests(data);

           // console.log(uniqueRequests)

            setRequestData(uniqueRequests);
            setFetchedData(uniqueRequests);
            hideLoader();

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };



    const getUniqueRequests = (data) => {
        // Create a map to store unique requests by CUA_REQUEST_ID
        const requestMap = new Map();
        data.forEach(request => {
            if (!requestMap.has(request.CUA_REQUEST_ID)) {
                requestMap.set(request.CUA_REQUEST_ID, request);
              //  console.log(requestMap)
            }
        });
        // Convert the map values to an array
        return Array.from(requestMap.values());
    };

    const getStatusDescription = (status) => {
        switch (status) {
            case '1':
                return 'Pending With level 1';
            case '2':
                return 'Pending With level 2';
            case '3':
                return 'pending with bag';
            case '4':
                return 'closed'

        }
    }


    const formatDateFromBackend = (dateString) => {
        // 1. Parse the input date string into a Date object
        const date = new Date(dateString);
      
        // 2. Extract year, month,  hours, minutes, and seconds from the Date object
        const year = date.getFullYear();
        const month = date.toLocaleString('default', { month: 'short' }).toUpperCase();
        let hours = date.getHours();
        const minutes = date.getMinutes();
        const seconds = date.getSeconds();
      
        // 3. Determine AM/PM
        const ampm = hours >= 12 ? 'PM' : 'AM';
      
        // 4. Convert hours to 12-hour format
        hours = hours % 12;
        hours = hours ? hours : 12; // Handle midnight (0 hours)
      
        // 5. Format the components into the desired string
        const formattedDate = `${date.getDate()}-${month}-${year}, ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} ${ampm}`;
      
        // 6. Return the formatted date string
        return formattedDate;
      };






    const handleShowDetails = (requestId) => {
        setShow(true)
        setClickRequestedId(requestId)
        // Filter details of the selected request
        const requestDetails = dataForEachId.filter(request => request.CUA_REQUEST_ID === requestId && request.CUR_RESPONSE!=null);

        requestDetails.sort((a, b) => a.CUR_QUESTION_ID - b.CUR_QUESTION_ID)

        //console.log(requestId)
        //console.log(requestDetails)
        setSelectedRequestId(requestId);
        setSelectedRequestDetails(requestDetails);
        console.log("Question detail", requestDetails)

       /**  if (detailsRef.current) {
            detailsRef.current.scrollIntoView({ behavior: 'smooth' });
        }
        */
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        setShow(false);


        if (!umc && !requestId) {
            fetchGetViewScreenData();

        } else {
            try {
                const response = await axios.get(`${BaseUrl}api/ViewCapReq/GetUmcOrRequestIdInfo?umc=${umc}&requestId=${requestId}`);
                const data = response.data.jsonData;
               // console.log("data", data)
                if (data.length === 0) {
                   // console.log("data", data)
                    setShowNotFoundModal(true);
                } else {
                    setdataForEachId(data);
                    const uniqueRequests = getUniqueRequests(data);
                    setRequestData(uniqueRequests);
                }
            } catch (error) {
                if (error.response && error.response.status === 404) {
                    setShowNotFoundModal(true);
                }
                else {
                    console.error('Error fetching data:', error);
                }

            }
        }
    };

    const handleCloseNotFoundModal = () => {
        setShowNotFoundModal(false);
    };



    return (
        <>
            <LoadingBar
                color='#f11946'
                progress={progress}
                onLoaderFinished={() => setProgress(0)}
            />
            <Navbar />
            {/* <TabMenu prop={"ViewCapitalRequest"}/> */}
            <div
                className="container"
                style={{ marginTop: "8px", marginLeft: "2px", maxWidth: "100%" }}
            >
                <div className="card">
                    <div
                        className="card-heading"
                        style={{
                             backgroundColor: "lightgray",
                            //backgroundImage: "linear-gradient(to right, #62a7c1, #10b6c8, #00c4bd, #00cf9e, #38d771)",
                            height: '48px',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}
                    >
                        <h4 style={{ display: 'flex', alignItems: 'center', gap: '8px', color: "#080808de" }}
                            className="mt-1"><i style={{ fontSize: "30px", marginBottom: "5px" }}><FaWpforms /></i>
                            View Capital Item request</h4>
                    </div>

                    <div className="card-body" style={{paddingTop: "1px"}}>
                   
                        <form onSubmit={handleSubmit}>
                            <div className="row g-0 align-items-center">
                                <div className="col-md-4">
                                    <label htmlFor="umc" className="col-form-label">UMC Number:</label>
                                    <div>
                                        <input
                                            type="text"
                                            id="umc"
                                            value={umc}
                                            onChange={(e) => setUmc(e.target.value)}
                                            className="form-control"
                                            placeholder='Enter UMC Number'
                                        />
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <label htmlFor="requestId" className="col-form-label">Request ID:</label>
                                    <div>
                                        <input
                                            type="text"
                                            id="requestId"
                                            value={requestId}
                                            onChange={(e) => setRequestId(e.target.value)}
                                            className="form-control"
                                            placeholder='Enter RequestID'
                                        />
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <button type="submit" style={{ marginTop: "40px", paddingLeft: "40px",  paddingRight: "40px"}} className="btn btn-primary">Search</button>
                                </div>
                            </div>
                        </form>




                        <section className="requestTable mt-2">
                            <table className="table text-center table-bordered">
                                <thead className="table-primary">
                                    <tr>
                                        <th style={{ fontWeight: 500 }}>Request Number</th>
                                        <th style={{ fontWeight: 500 }}>Status</th>
                                        <th style={{ fontWeight: 500 }}>UMC NO</th>
                                        <th style={{ fontWeight: 500 }}>Request Date</th>
                                        <th style={{ fontWeight: 500 }}>Show Details</th>
                                        <th style={{ fontWeight: 500 }}>Pending With</th>

                                    </tr>
                                </thead>
                                <tbody>

                                    {filteredRequestData.map(request => (

                                        <tr key={request.CUA_REQUEST_ID}>

                                            <td>{request.CUA_REQUEST_ID}</td>
                                            <td>{getStatusDescription(request.CUA_STATUS)}</td>
                                            <td>{request.CUA_UMC}</td>
                                            <td>{formatDateFromBackend(request.CUR_CREATED_ON)}</td>
                                            <td><button onClick={() => handleShowDetails(request.CUA_REQUEST_ID)}
                                                style={{
                                                    color: clickedRequestedId === request.CUA_REQUEST_ID ? 'red' : 'blue',
                                                    textDecoration: "none",
                                                    background: "none",
                                                    border: "none",
                                                    padding: 0,
                                                    cursor: "pointer"
                                                }}>Show Details</button></td>
                                            <td>{getStatusDescription(request.CUA_STATUS)}</td>
                                        </tr>
                                    ))}

                                </tbody>
                            </table>
                        </section>
                        <section ref={detailsRef}>

                            {show && selectedRequestId && (
                                <div>
                                    <h5>Details of Request Id #{selectedRequestId}</h5>
                                    <table className="table text-center table-bordered">
                                        <thead className="table-primary">
                                            <tr>
                                                <th>Question ID</th>
                                                <th>Question Description</th>
                                                <th>Response</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {selectedRequestDetails.map(detail => (
                                                <tr key={detail.CUR_QUESTION_ID}>
                                                    <td>{detail.CUR_QUESTION_ID}</td>
                                                    <td>{detail.CQM_QUES_DESC}</td>
                                                    <td>{detail.CUR_RESPONSE}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}



                            {showNotFoundModal && (
                                <>
                                    <div className="modal-backdrop fade show"></div>
                                    <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <h5 className="modal-title">Sorry!</h5>
                                                    <button type="button" className="btn-close" onClick={handleCloseNotFoundModal} aria-label="Close"></button>
                                                </div>
                                                <div className="modal-body">
                                                    <p>No records found matching the provided UMC number or Request ID.</p>
                                                </div>
                                                <div className="modal-footer">
                                                    <button type="button" className="btn btn-primary" onClick={handleCloseNotFoundModal}>Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )}

                        </section>
                    </div>



                </div>
            </div>



        </>
    );
}

export default ViewCapitalRequest


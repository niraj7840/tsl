import axios from "axios";
import moment from "moment";
import React from "react";
import $, { post } from 'jquery';
import { useState } from "react";
import { useEffect } from "react";
import { Form, FormGroup, } from "react-bootstrap";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import Navbar from "../components/Navbar/Navbar";
import { BaseUrl } from "../constants/BaseURL";
import { Table, Modal, ModalHeader, ModalBody, ModalFooter, Button, Input } from 'reactstrap';

const AddApprover = (prop) => {
    const user = useSelector((state) => JSON.parse(state.auth.userData));
    const [lvl, setLvl] = useState([]);
    const [scDetails, setSCDetails] = useState([]);
    const [modal, setModal] = useState(false);
    const [selectedItem, setSelectedItem] = useState([]);
    const [selectedRow, setSelectedRow] = useState(null);
    const [file, setFile] = useState(null);



    useEffect(() => {

    }, []);

    const fetchApproverLevel = async (_SCNO) => {
        try {
            let token = sessionStorage.getItem('token');
            let headers = {
                'jwt-token': token
            };

            const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetApproverLevel?cartNo=${_SCNO}`, { headers });
            const data = response.data;
            setLvl(data.jsonData);


        } catch (error) {
            console.log(error);
        }
    };

    const fetchShoppingCartList = async () => {
        try {
            let token = sessionStorage.getItem('token');
            let headers = {
                'jwt-token': token
            };

            const SCNo = $("#SCNo").val();
            const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetShoppingCart_ForAddApprover?cartNo=${SCNo}`, { headers });
            const data = response.data;

            setSCDetails(data.jsonData);
            fetchApproverLevel(data.jsonData[0].SCH_CART_NO)

        } catch (error) {
            console.log(error);
        }
    };

    const handleClick = () => {

        fetchShoppingCartList();
    }


    const [selectedCarts, setSelectedCarts] = useState([]);

    // Function to handle selection of individual shopping carts
    const toggleCartSelection = (SCH_CART_NO) => {
        setSelectedCarts((prevSelected) =>
            prevSelected.includes(SCH_CART_NO)
                ? prevSelected.filter((id) => id !== SCH_CART_NO) // Deselect
                : [...prevSelected, SCH_CART_NO] // Select
        );
    };

    // Function to handle select/deselect all
    const toggleSelectAll = () => {
        if (selectedCarts.length === scDetails.length) {
            setSelectedCarts([]); // Deselect all
        } else {
            setSelectedCarts(scDetails.map((cart) => cart.SCH_CART_NO)); // Select all
        }
    };

    // Function to check if a shopping cart is selected
    const isSelected = (SCH_CART_NO) => selectedCarts.includes(SCH_CART_NO);

    // Function to handle modal popup
    const toggleModal = async (item = null) => {
        debugger
        //-------------------------GetApproval Hierarchy-----------------------
        try {

            let token = sessionStorage.getItem("token");
            let headers = {
                "jwt-token": token,
            };


            const scApprovalResponse = await axios.get(
                `${BaseUrl}api/ShoppingCart/SCApprovalHierarchy?SCNo=${item.SCH_CART_NO}`, { headers }
            );
            const scApprovalheiData = scApprovalResponse.data;
            setSelectedItem(scApprovalheiData.jsonData);


        } catch (error) {
            console.error("Error fetching shopping cart details", error);
        }
        // setSelectedItem(item); // Set the selected item (null to close the modal)
        setModal(!modal); // Toggle modal visibility
    };


    const handleAddApproval = async () => {
        const CartNo = $("#SCNo").val();
        const Lvl = $("#LVL").val();
        const PNo = $("#PIN").val();

        if (selectedCarts.length === 0) {
            Swal.fire({
                title: 'No Carts Selected',
                text: 'Please select cart to Add approver.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            return; // Exit function if no carts are selected
        }
        // Validate if PIN is provided
        if (!PNo) {
            Swal.fire({
                title: 'PIN Required',
                text: 'Please enter your PIN.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            return; // Exit function if PIN is missing
        }

        // Validate if a file has been selected
        if (!file) {
            Swal.fire({
                title: 'File Required',
                text: 'Please select a PDF file before proceeding.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            return; // Exit function if no file is selected
        }
        const formData = new FormData();
        formData.append('scp_cart_no', CartNo);
        formData.append('SCP_APP_LVL', Lvl);
        formData.append('SCP_APPRVR', PNo);
        formData.append('SCD_CRT_BY', user.User_Id);

        // Append the file (if selected)
        if (file) {
            formData.append('File', file);
        }

        // Confirmation dialog before proceeding
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to add approver for the selected carts?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, add it!'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    let token = sessionStorage.getItem("token");
                    let headers = {
                        "jwt-token": token,
                        // No need to specify 'Content-Type', Axios will set it automatically for FormData
                    };

                    const response = await axios.post(`${BaseUrl}api/ShoppingCart/SC_AddApprover`, formData, { headers });

                    if (response.data.Text === "Success") {
                        Swal.fire('Added!', 'Approver added successfully.', 'success');
                    } else {
                        console.log('Error:', response);
                        Swal.fire('Error!', 'Failed to add approver.', 'error');
                    }
                } catch (error) {
                    console.error('Error adding approver:', error);
                    Swal.fire('Error!', 'An error occurred while adding approver.', 'error');
                }
            }
        });
    };

    const handleFileChange = (e) => {
        debugger;
        setFile(e.target.files[0]);
        console.log(file);
    };


    const handlePINChange = async (e) => {
        debugger;
        const enteredPIN = e.target.value;
        $("#PIN").val(enteredPIN); // Assuming you're setting the input field value
    
        if (enteredPIN) {
            try {
                let token = sessionStorage.getItem('token');
                let headers = {
                    'jwt-token': token,
                };
    
                // API call to validate the PIN
            //    const response = await axios.get(`${BaseUrl}api/ShoppingCart/ValidatePIN?pin=${enteredPIN}`, { headers });
            const response = await axios.get(`${BaseUrl}api/ShoppingCart/GetValidatePIN?pin=${enteredPIN}`, { headers });
                const data = response.data;

              if (data && data.jsonData && data.jsonData.length > 0 && data.jsonData[0].APR_ID) {
                    // Swal.fire({
                    //     title: 'PIN Validated',
                    //     text: `App ID: ${data.app_id}`,
                    //     icon: 'success',
                    //     confirmButtonText: 'OK'
                    // });
                } else {
                    Swal.fire({
                        title: 'Invalid PIN',
                        text: 'Please entered correct PIN.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            } catch (error) {
                console.error('Error validating PIN:', error);
                Swal.fire('Error!', 'An error occurred during validation.', 'error');
            }
        }
    };

    return (
        <>
            <Navbar />

            <div
                className="container"
                style={{
                    marginTop: "25px",
                    maxWidth: "95.5%",
                }}
            >
                <div className="card" style={{ height: "620px" }}>
                    <div
                        className="card-heading"
                        style={{ backgroundColor: "lightgray", height: "44px" }}
                    ><h4 className="mt-2">
                            <> &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Add Approver</>

                        </h4></div>
                    <div style={{ marginLeft: "15px", marginTop: "5px" }}>
                        <div className="row">
                            <div className="col-md-3" >
                                <label className="labelFont">Shopping Cart No.</label>
                                <input Type="text" id="SCNo" className="form-control  labelFont" />
                            </div>
                            <div className="col-md-1 mt-4 colmd1">
                                <a className="btn btn-primary labelFont" onClick={() => handleClick()}><i className="fas fa-television"></i> &nbsp;View</a>
                            </div>
                        </div>



                        <div className="row mt-2">&nbsp;</div>

                        <div className="row col-md-9" style={{ marginLeft: "4px" }}>
                            {/* Button to select/deselect all */}
                            {/* <button onClick={toggleSelectAll} className=" " >
                                {selectedCarts.length === shoppingCart.length ? 'Deselect All' : 'Select All'}
                            </button> */}

                            {/* Render shopping cart list */}
                            <table className="table table-boarder">
                                <thead>
                                    <tr>
                                        <th>
                                            <input style={{ display: 'none' }}
                                                type="checkbox"
                                                onChange={toggleSelectAll}
                                                checked={scDetails.length > 0 && selectedCarts.length === scDetails.length}
                                                disabled={scDetails.length === 0} // Disable when no data
                                            />
                                            {/* ALL */}
                                        </th>
                                        <th>SC No.</th>
                                        <th>SC Name</th>
                                        <th>Department</th>
                                        <th>Created By</th>
                                        <th>Created On</th>
                                        <th style={{ display: 'none' }}>Total Value</th> {/* Hide this header */}
                                    </tr>
                                </thead>
                                <tbody>
                                    {scDetails.map((cart) => (
                                        <tr key={cart.SCH_CART_NO}>
                                            <td>
                                                <input
                                                    type="checkbox"
                                                    onChange={() => toggleCartSelection(cart.SCH_CART_NO)}
                                                    checked={isSelected(cart.SCH_CART_NO)}
                                                />
                                            </td>
                                            <td
                                                onClick={() => toggleModal(cart)}
                                                style={{ cursor: 'pointer', color: 'blue' }}>{cart.SCH_CART_NO}</td>
                                            <td>{cart.SCH_CART_NAME}</td>
                                            <td>{cart.DEPTDESC}</td>
                                            <td>{cart.SCH_CRT_ID}</td>
                                            <td>{new Date(cart.SCH_CRT_DT).toLocaleDateString('en-GB')}</td>
                                            <td style={{ display: 'none' }}>{cart.SCH_TOT_VAL}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="col-md-12 row">
                            <div className="col-md-2">
                                <label className="labelFont">Level</label>
                                <select id="LVL" className="form-control  labelFont">
                                    {/* <option value="">All</option> */}
                                    {lvl.map((itm, id) => (
                                        <option key={id} value={itm.SCP_APP_LVL}>
                                            {itm.LVLDESC}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md-2">
                                <label className="labelFont">P Number </label>
                                <input Type="text" id="PIN" className="form-control  labelFont" onBlur={handlePINChange} />
                            </div>
                            <div className="col-md-3">
                                <label for="fileUpload"> Select File</label>
                                <Input type="file" name="file" id="fileUpload" accept=".pdf" onChange={handleFileChange} />
                            </div>
                            <div className="col-md-3 Center mt-4 colmd1" style={{ marginLeft: "4px" }}>
                                <a className="btn btn-primary " onClick={() => handleAddApproval()} >&nbsp;Add Approver </a>
                            </div>
                        </div>
                        <br />
                        <br />
                        {/* Modal Section */}
                        <Modal isOpen={modal} toggle={() => toggleModal()} className="modal-dialog modal-lg">
                            <ModalHeader toggle={() => toggleModal()}>Approval Hierarchy</ModalHeader>
                            <ModalBody>
                                <Form>
                                    <FormGroup>
                                        <div className="col-12">
                                            <div style={{ border: "1px solid blue" }}>
                                                <div className="row" style={{ overflowX: "auto" }}>
                                                    <div className="tables table-responsive table-responsive-lg">
                                                        <table className="table table-bordered tb">
                                                            <thead className="table-primary">
                                                                <tr>
                                                                    <th>Version</th>
                                                                    <th>Approval Level</th>
                                                                    <th>Approver Name</th>
                                                                    <th>Status</th>
                                                                    <th>Comments</th>
                                                                    <th>Action Date</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                {selectedItem.map((row, index) => {
                                                                    const isGreenRow = row.MAILSEND === '01' && (row.APP_STATE === '00' || row.APP_STATE === '03');
                                                                    return (
                                                                        <tr
                                                                            key={row.LVL}
                                                                            style={{
                                                                                color: isGreenRow ? "green" : (selectedRow === row.LVL ? "#ddd" : "white")
                                                                            }}
                                                                        >
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.VERSION}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.LVL}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.APPROVER}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.STATUS}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.REMARKS}</td>
                                                                            <td style={{ color: isGreenRow ? "green" : "black" }}>{row.ACTION_DT}</td>

                                                                        </tr>
                                                                    );
                                                                })}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </FormGroup>
                                </Form>
                            </ModalBody>
                            <ModalFooter>
                                <Button color="primary" onClick={() => toggleModal()}>
                                    Close
                                </Button>
                            </ModalFooter>
                        </Modal>


                    </div>
                </div>
            </div>
        </>
    );
};

export default AddApprover;
import React, { useState,useEffect } from "react";
import Navbar from "../components/Navbar/Navbar";
import { Link, useNavigate } from "react-router-dom";
import ApprovalScreen from "./ApprovalScreen";
import { BaseUrl } from "../constants/BaseURL";
import axios from "axios";
import { useSelector } from "react-redux";
import $ from 'jquery';
import DataTable from "datatables.net-dt";
import moment from "moment";
import Swal from "sweetalert2";
import ApprovalList from "../components/ApprovalList/ApprovalList";



const IndentPendingList = (prop) => {
  
  const [state, setstate] = useState(false);
  const[dataTableInstance,setdataTableInstance]=useState(null);
  const [workFlowData, setWorkFlowData] = useState([]);
  const [indentData, setIndentData] = useState([]);
  const [indentDataapp, setindentDataapp] = useState(0);
  const[Department,setDepartment]=useState([]);
  const [workflow, setwrokflow] = useState();
  const [isworkflow, setIsWrokflow] = useState(0);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
 
  const navigate=useNavigate();
  const handldWorkFlow = (e) => {
    //console.log(e);
   // if(e.WF_ID.length>0){
    setstate(true);
    setwrokflow(e);
    sessionStorage.setItem("IndentNo",e.INDENTID);
    navigate("/SIS/IndentApproval");
  //}
}
const handldIndentFlow = (e) => {
  console.log(e);
 // if(e.WF_ID.length>0){
  setstate(true);
  setwrokflow(e);
  sessionStorage.setItem("IndentNo",e.INDENTID);
  navigate("/SIS/IndentDetails");
//}
}


  useEffect(() => {
    //setDate();
    prop.showLoader();
    fetchDepartmentList();
   
    MyPendingIndent(); 
    getPendingIndent(''); 
    
    setTimeout(() => {
      
    setDate();
    }, 1000);
      
  }, []);
  
  const handleClick=async ()=>{
    setWorkFlowData([]);
  await  getPendingIndent('show');
  
  }
  const setDate=()=>{
    $("#DTF").val(moment().subtract(7,'d').format('YYYY-MM-DD'));
    $("#DTT").val(moment().format('YYYY-MM-DD'))
  }
  const  getPendingIndent = async(msg) => {

    prop.showLoader();
    var fliter={
      DTF:$("#DTF").val(),
      DTT:$("#DTT").val(),
      DEPT:$("#DEPT").val(),
      USERNAME:user.User_Id
      
  }
    setstate(false);
    let token = sessionStorage.getItem('token');
    let headers = {
      'jwt-token': token      
    };
    if (dataTableInstance !== null) {
       dataTableInstance.destroy();
    
    }
    
    await axios.post(`${BaseUrl}api/IndentWF/GetPendingIndentAppr`,fliter, {headers}, {
      withCredentials: true
     
    }).then((response) => {
      var data=JSON.parse(response.data);
          setWorkFlowData(data); // Access the data directly
        
          if(msg=='' && data.length>0){
            setIsWrokflow(1);
          }
          setTimeout(() => {
            
           
          
          
          var tbl=  $('#tblApp').DataTable({
                destroy: true,
                info: false,
                search: true,
                paging: false,
                sorting: true,
                "initComplete": function (settings, json) {
                  prop.hideLoader();
              },
                
            });
            setdataTableInstance(tbl);
           
            
           //}
        }, 1000);
         })
         .catch((error) => {
          prop.hideLoader();
           console.log(error);
         });
  };
  const fetchDepartmentList = async () => {
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
      'jwt-token': token      
      };
      
      const response = await axios.get(`${BaseUrl}api/Master/GetDepartment?adid=${user.User_Id}`, {headers});
      const data = response.data;
     
      setDepartment(data);
      
      
    } catch (error) {
      console.log(error);
    }
  };
  const  MyPendingIndent = async() => {
    prop.showLoader();
    setstate(false);
    let token = sessionStorage.getItem('token');
    let headers = {
      'jwt-token': token      
    };
    
    await axios.get(`${BaseUrl}api/IndentWF/GetPendingIndent?USERNAME=${user.User_Id}`, {headers}, {
      withCredentials: true
     
    }).then((response) => {
      setIndentData(JSON.parse(response.data)); // Access the data directly
          setTimeout(() => {
            $('#tblInd').DataTable({
                destroy: true,
                info: false,
                search: true,
                paging: false,
                sorting: true,
               
                
            });
        }, 1000);
         })
         .catch((error) => {
          prop.hideLoader();
           console.log(error);
         });;
  };

  // const getWorkflow = () => {
  //   setstate(false)
  //   fetch(`${BaseUrl}api/Workflow/GetWorkflow?ADID=163402`)   
  //   //fetch("http://localhost:54775/api/Workflow/GetWorkflow?ADID=163402")
  //     .then((response) => response.json())
  //     .then((data) => {
  //       setWorkFlowData(data.jsonData);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };


  return (
    <div>
      <Navbar/>
      <div
          className="container"
                  style={{
                      marginTop: "73px",
                      maxWidth: "95.5%"
                  }}
        >
        <div className="card">
        {((isworkflow==1))?<>
          <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          >
            <h4 className="mt-2">
              {" "}
              &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;
              Approver Action – Indent Awaiting Approval for me
            </h4>
          </div>
          <div className="card-body">
          <div className="row">
             
              <div className="col-md-3 colmd2 mt-2">
                <label className="labelFont">Department</label>
                <select id="DEPT" className="form-control  labelFont">
                  <option value="">All</option>
                  {Department.map((itm, id) => (
                    <option key={id} value={itm.dept}>
                      {itm.deptName}({itm.dept})
                    </option>
                  ))}
                </select>
              </div>  <div className="col-md-3 mt-2">
                <label className="labelFont">Date From</label>
                <input Type="date" id="DTF" className="form-control  labelFont" />
              </div>
              <div className="col-md-3 mt-2">
                <label className="labelFont">Date To</label>
                <input Type="date" id="DTT" className="form-control  labelFont" />
              </div>
              <div className="col-md-2 mt-4 colmd1">
                <a className="btn btn-primary labelFont" onClick={()=>handleClick()}><i className="fas fa-television"></i> &nbsp;View</a>
              </div>
            </div>
            
            <table id="tblApp" className="table table-bordered" style={{width:"100%",fontSize:"12px"}}>
              <thead className="table-primary">
                <tr style={{textAlign:"center"}}>
                  
                  <th className="text-center">Indent Number</th>
                  <th className="text-center">Indent Date</th>
                  <th className="text-center">Department</th>
                  <th className="text-center">Plant</th>
                  <th className="text-center">Location</th>
                  <th className="text-center">Indent Status</th>
                  <th className="text-center" style={{width:"100px"}}>Indent Description</th>
                  <th className="text-center" style={{width:"100px"}}>Indent Remarks</th>
             
                  
                </tr>
              </thead>

              <tbody>
               
                {workFlowData.map((row, index) => (
                  <tr key={index}>
                    

                    <td  className="tblTd">
                     
                      <a className="btn btn-sm text-primary" onClick={()=>{handldWorkFlow(row)}}>{row.INDENTID}</a>
                     </td>
                     <td className="tblTd">{row.DT}</td>
                    <td className="tblTd">{row.DEPT}</td>
                    <td className="tblTd">{row.PLANT}</td>
                    <td className="tblTd">{row.LOC}</td>
                    <td className="tblTd">{row.STAGE}</td>
                    <td className="tblTd" style={{width:"100px"}}>{row.DES}</td>
                    <td className="tblTd" style={{width:"100px"}}>{row.REMARKS}</td>
                   
                    
                  </tr>
                ))}
              </tbody>
            </table>
          </div></>:<></>}
          
          {indentData.length>0 ?<>

          <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          >
            <h4 className="mt-2">
              {" "}
              &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;
              Indentor Action – My Indent List Awaiting Approval
            </h4>
          </div>
          <div className="card-body">
            <table id="tblInd" className="table table-bordered" style={{width:"100%",fontSize:"12px"}}>
              <thead className="table-primary">
                <tr style={{textAlign:"center"}}>
                  
                  <th className="text-center">Indent Number</th>
                  <th className="text-center">Indent Date</th>
                  <th className="text-center">Department</th>
                  <th className="text-center">Plant</th>
                  <th className="text-center">Location</th>
                  <th className="text-center" style={{width:"100px"}}>Indent Description</th>
                  <th className="text-center"  style={{width:"100px"}}>Indent Remarks</th>
                  <th className="text-center">Indent Status</th>
                 
                  <th className="text-center">Pending With</th>
                  
                </tr>
              </thead>

              <tbody>
                
                {indentData.map((row, index) => (
                  <tr key={index}>
                    {/* <td>
                      {" "}
                      <Link
                        to={{
                          pathname: `/SIS/Approve/`,
                          state: { workflowID: row.WF_ID },
                        }}
                      >
                        {row.WF_ID}
                     </Link>
                    </td> */}

                    <td  className="tblTd">
                      
                      <a className="btn btn-sm text-primary" onClick={()=>{handldIndentFlow(row)}}>{row.INDENTID}</a>
                     </td>
                     <td className="tblTd">{row.DT}</td>
                    <td className="tblTd">{row.DEPT}</td>
                    <td className="tblTd">{row.PLANT}</td>
                    <td className="tblTd">{row.LOC}</td>
                    <td className="tblTd" style={{width:"100px"}}>{row.DES}</td>
                    <td className="tblTd" style={{width:"100px"}}>{row.REMARKS}</td>
                    <td className="tblTd">{row.STAGE}</td>
                   
                    <td className="tblTd" style={{width:"110px"}}>  <ApprovalList PLANT={row.INDENTOR_PLANT} DEPT={row.INDENTOR_DEPT} LVL={row.INDENT_LEVEL} TYP="LVL"/>
              </td>
                    
                  </tr>
                ))}
              </tbody>
            </table>
          </div></>:<></>}
        </div>
      </div>
    
  </div>)
};

export default IndentPendingList;

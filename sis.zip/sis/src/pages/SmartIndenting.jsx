import React, { useState, useEffect } from "react";
import TabMenu from "../components/TabMenu/TabMenu";
import IndentMasterStatus from "./IndentMasterStatus";
import IndentStatus from "./IndentStatus";
import IntentUmcCapStatus from "./IntentUmcCapStatus";
import ViewCapitalRequest from "./ViewCapitalRequest";
import ShoppingCart from "./ShoppingCart";
import IntelliBuySystemChecks from "./IntelliBuySystemChecks";
import Navbar from "../components/Navbar/Navbar";
import { useDispatch, useSelector } from "react-redux";
import { BaseUrl } from "../constants/BaseURL";
import axios from "axios";
import Swal from "sweetalert2";
import RaiseCapitalItemRequest from "./RaiseCapitalItemRequest";
import { useNavigate, useLocation } from "react-router-dom";
import { clearIndentId } from "../store/indentSlice";
import RaiseRequest from "./RaiseRequest";
import {AIULPPENDING1, INTRAPENDING1, INTERPENDING1, CAPEXPENDING1, INTELLIBUY1, SHOPPINGCARTCREATION1, SHOPPINGCARTINDRAFT1,ShoppingCartCreatedPendingForApproval1, CLOSED,
  SCRETURNEDFORMODIFICATION1, SCREJECTED1, SCAPPROVEDPENDINGFORFODCREATION1, SCFODCREATION1, SCFODINERROR1, SCUNDERCHANGE1, SPARESHARINGCLOSED1
} from "../constants/CommanConstant"



const SmartIndenting = ({ showLoader, hideLoader, departmentList }) => {
  const [selectedTab, setSelectedTab] = useState("IndentStatus");
  const [INDENTSTATUS, setINDENTSTATUS] = useState("");
  const [componentToShow, setComponentToShow] = useState(false);
  const [showViewCapReq, setShowViewCapReq] = useState(false);
  const [showShoppingCart, setShowShoppingCart] = useState(false);
  const [showIndentUmc, setShowIndentUmc] = useState(false);
  const [dept, setDept] = useState("");
  const [indentStatusCode, setIndentStatusCode] = useState(0);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();

  const indentId = useSelector((state) => state.indent ? state.indent.indentId : '');
  const user = useSelector((state) => JSON.parse(state.auth.userData));

  user.User_Id='163402'


  useEffect(() => {

    console.log("indent number", indentId)
    if (indentId === '') {
      navigate('/SIS/SearchIndent')
    }
    else {
      //fetchWfList();
      console.log("ShowLoader", showLoader)
      handleClick();
    }

  }, [indentId, navigate])


  //  useEffect(()=>{
  //   dispatch(clearIndentId())
  //  },[location])

  useEffect(() => {
    switch (indentStatusCode) {
      case AIULPPENDING1:
      case INTRAPENDING1:
      case INTERPENDING1:
      case SPARESHARINGCLOSED1:
        setSelectedTab("IndentStatus");
        break;
      case CAPEXPENDING1:
      case CLOSED:
        setSelectedTab("IntentUmcCapStatus");
        break;
      case INTELLIBUY1:
        setSelectedTab("IntelliBuySystemChecks");
        break;
      case SHOPPINGCARTCREATION1:
      case SHOPPINGCARTINDRAFT1:
      case ShoppingCartCreatedPendingForApproval1:
      case SCRETURNEDFORMODIFICATION1:
      case SCAPPROVEDPENDINGFORFODCREATION1:
      case SCFODINERROR1:
      case SCFODCREATION1:
      case SCREJECTED1:
      case SCUNDERCHANGE1:
        setSelectedTab("ShoppingCart");
        break;
      default:
        setSelectedTab("IndentStatus");
    }
  }, [indentStatusCode]);

  //  useEffect(() => {
  //   switch (INDENTSTATUS) {
  //     case "Pending for AIULP Spare sharing":
  //     case "Pending for INTRA Spare sharing":
  //     case "Pending for INTER Spare sharing":
  //       setSelectedTab("IndentStatus");
  //       break;
  //     case "Pending for Capex Approval":
  //       setSelectedTab("IntentUmcCapStatus");
  //       break;
  //     case "Pending for Intellibuy Check":
  //       setSelectedTab("IntelliBuySystemChecks");
  //       break;
  //     case "Pending for Shopping Cart Creation":
  //       setSelectedTab("ShoppingCart");
  //       break;
  //     default:
  //       setSelectedTab("IndentStatus");
  //   }
  // }, [INDENTSTATUS]);



  const handleTabSelect = (tabName) => {
    setSelectedTab(tabName);
    setComponentToShow(false);
    setShowViewCapReq(false);
    setShowIndentUmc(false);
  }

  const handleClick = () => {


    let token = sessionStorage.getItem('token');
    const headers = {
      'jwt-token': token
    };

    var fliter = {
      DTF: "",
      DTT: "",
      DEPT: "",
      FOD: "",
      STATUS: "",
      INDENTNO: indentId.toString(),
      DOCTYPE: "",
      USERNAME: user.User_Id
    }
    try {

      axios.post(`${BaseUrl}api/Report/GetIndentStatus`, fliter, { headers }, {
        withCredentials: true

      })

        .then((response) => {
          if (response.data.statusText === "OK") {
            console.log("IndentStatus", response.data.Data)
            const indentStatusData = JSON.parse(response.data.Data);
            // setINDENTSTATUS(response.data.Data.STATUS)
            // setINDENTSTATUS(JSON.parse(response.data.Data.INDENTSTATUS));

            if (Array.isArray(indentStatusData) && indentStatusData.length > 0) {
              const status = indentStatusData[0].STATUS;
              setDept(indentStatusData[0].DEPT)

              // Perform your operations with the status
              console.log("STATUS:", dept);
              console.log("codeId:", indentStatusData[0].CODEID);
              setIndentStatusCode(indentStatusData[0].CODEID)

              // Example: Update state or perform other actions
              setINDENTSTATUS(status);

            }
            hideLoader();

          } else {
            hideLoader();
            //Swal.fire('','No data found','info');
          }
        });
    } catch (error) {
      hideLoader();

    }
  }

  const fetchWfList = async () => {
    try {
      console.log("Indent number 123", indentId)
      if (indentId === '') {
        return;
      }

      let token = sessionStorage.getItem('token');
      const headers = {
        'jwt-token': token
      };
      const response = await axios.get(
        `${BaseUrl}api/Report/GetWFDetails?INDENTNO=${indentId}`, { headers }, {
        withCredentials: true

      }
      );
      if (response.data.statusText === "OK") {
        var dt = JSON.parse(response.data.Data);
        //setSelectedIndentArray(JSON.parse(response.data.Data));
        //setSelindentId(JSON.parse(response.data.Data));
        setINDENTSTATUS(JSON.parse(response.data.Data)[0].INDENTSTATUS);
        //setDEPARTMENT(JSON.parse(response.data.Data)[0].INDENTDEPT);


      } else {

        Swal.fire('', 'No data found', 'info');
      }

    } catch (error) {


    }
  };

  const switchToShoppingCart = () => {
    setSelectedTab("ShoppingCart");
    setINDENTSTATUS("Pending for Shopping Cart Creation")
    setIndentStatusCode(SHOPPINGCARTCREATION1);
  }


  const switchToIntellibuy = () => {
    setSelectedTab("IntelliBuySystemChecks");
     setINDENTSTATUS("Pending for Intellibuy Check")
    setIndentStatusCode(INTELLIBUY1);
  }

  const switchToCapex = () => {
     setINDENTSTATUS("CLOSED")
    setIndentStatusCode(CLOSED);
  }

  const switchToShoppingCartCreatedAndPending=()=>
  {
    setINDENTSTATUS("Shopping Cart Created,Pending for Approval")
    setIndentStatusCode(ShoppingCartCreatedPendingForApproval1);
  }  

  console.log("indentId", indentId);
  console.log("indentStatus", INDENTSTATUS);

  const renderContent = () => {

    if (componentToShow) {
      return <RaiseCapitalItemRequest switchToIntellibuy={switchToIntellibuy} setShowViewCapReq={() => setShowViewCapReq(true)} setComponentToShow={() => setComponentToShow(false)} showLoader={showLoader} hideLoader={hideLoader} departmentList={departmentList} setShowIndentUmc={() => setShowIndentUmc(true)} switchToCapex={switchToCapex}/>;
    }

    if (showViewCapReq) {
      return <ViewCapitalRequest showLoader={showLoader} hideLoader={hideLoader} />;
    }

    if (showShoppingCart) {
      return <ShoppingCart showLoader={showLoader} hideLoader={hideLoader} />;
    }


    if (showIndentUmc) {
      return <IntentUmcCapStatus showLoader={showLoader} hideLoader={hideLoader} setComponentToShow={() => setComponentToShow(true)} setShowViewCapReq={() => setShowViewCapReq(true)} />;

    }

    switch (selectedTab) {
      case "RaiseRequest":
        return <RaiseRequest showLoader={showLoader} hideLoader={hideLoader} indentNo={indentId} />;
      case "SearchIndent":
        return <IndentMasterStatus showLoader={showLoader} hideLoader={hideLoader} />;
      case "IndentStatus":
        return <IndentStatus showLoader={showLoader} hideLoader={hideLoader} />;
      case "IntentUmcCapStatus":
        return <IntentUmcCapStatus showLoader={showLoader} hideLoader={hideLoader} setComponentToShow={() => setComponentToShow(true)} setShowViewCapReq={() => setShowViewCapReq(true)} />;
      case "ViewCapitalRequest":
        return <ViewCapitalRequest showLoader={showLoader} hideLoader={hideLoader} />;
      case "IntelliBuySystemChecks":
        return <IntelliBuySystemChecks showLoader={showLoader} hideLoader={hideLoader} switchToShoppingCart={switchToShoppingCart} />;
      case "ShoppingCart":
        return <ShoppingCart showLoader={showLoader} hideLoader={hideLoader} switchToShoppingCartCreatedAndPending={switchToShoppingCartCreatedAndPending}/>;
      case "CapitalRequest":
        return <RaiseCapitalItemRequest showLoader={showLoader} hideLoader={hideLoader} />
      default:
        return <IndentStatus showLoader={showLoader} hideLoader={hideLoader} />;

    }
  };

  return (

    <div>
      <Navbar />
      <TabMenu prop={selectedTab} onTabSelect={handleTabSelect} indentStatus={indentStatusCode} indentStatusDescription={INDENTSTATUS} dept={dept} />
      <div>
        {renderContent()}

      </div>
    </div>
  );
};

export default SmartIndenting;

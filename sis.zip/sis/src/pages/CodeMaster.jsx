import axios from "axios";
import moment from "moment";
import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import Navbar from "../components/Navbar/Navbar";
import { BaseUrl } from "../constants/BaseURL";

const CodeMaster = (prop) => {
  const [tabList, setTabList] = useState([]);
  const [tabName, setTabName] = useState("");
  const [actName, setActName] = useState("");
  const [colList, setColList] = useState([]);
  const user = useSelector((state) => JSON.parse(state.auth.userData));

  const handleChangeTAB = (e) => {
    setColList([]);
    setTabName(e.target.value);
    setActName("");
  };
  const handleChangeAction = (e) => {
    console.log("");
    setActName(e.target.value);
    setColList([]);
   
    fetchCOLName("COL", tabName);
  };
  const handleChangeValue = (e, inx) => {
    var dt = colList;
    dt[inx]["VAL"] = e.target.value;

    setColList(dt);
  };
  const getData = async (ID) => {
    fetchCOLName("SEL", tabName, ID);
  };
  const actionData=async()=>{
    try {
      let token = sessionStorage.getItem('token');
      let headers = {
      'jwt-token': token      
      };
      const method=actName=="INSERT"?"setTabData":"editTabData";
      axios.post(`${BaseUrl}api/Master/${method}`, colList,{headers})

        .then((response) => {
          if(response.data=="success"){
Swal.fire('','Changes done successfully','success');
setActName("");
setColList([]);
          }
          else{
            Swal.fire('',response.data,'error');
          
          }
         
        });
    } catch (error) {
      prop.hideLoader();
      Swal.fire("", "Something went wrong", "error");
      
    }
  }
 
  const fetchCOLName = async (TYP, COL, ID) => {
    let token = sessionStorage.getItem("token");
    const headers = {
      "jwt-token": token,
    };
    try {
      await fetch(
        `${BaseUrl}api/Master/getTabName?TYP=${TYP}&TAB=${COL}&ID=${ID}`,
        { headers },
        {
          withCredentials: true,
        }
      )
        .then((response) => response.json())
        .then((data) => {
          //
          for (let index = 0; index < data.length; index++) {
            if(data[index].COLUMN_NAME.includes("CREATED_ON")||data[index].COLUMN_NAME.includes("CREATED_DATE")||data[index].COLUMN_NAME.includes("MOD_ON")||data[index].COLUMN_NAME.includes("MOD_DT")||data[index].COLUMN_NAME.includes("CRT_ON")||data[index].COLUMN_NAME.includes("CRT_DT")||data[index].COLUMN_NAME.includes("CRT_DATE"))
            {
              data[index].ACT="N";
              if(data[index].VAL==null||data[index].VAL==""){
                data[index].VAL=moment().format('YYYY-MM-DD');;
              }
            }
           if(data[index].COLUMN_NAME.includes("CRT_BY")||data[index].COLUMN_NAME.includes("CREATED_BY")||data[index].COLUMN_NAME.includes("MOD_BY")||data[index].COLUMN_NAME.includes("MODIFIED_BY"))
           {
            data[index].ACT="N";
            if(data[index].VAL==null||data[index].VAL==""){
              data[index].VAL=user.User_Id;
            }
            
          }}

          //  var data = JSON.parse(data.Response).d.results;
          setColList(data);
        })
        .catch((error) => {
          prop.hideLoader();
          console.log(error);
        });
    } catch (e) {
      prop.hideLoader();
    }
  };

  return (
    <>
      <Navbar />

      <div
        className="container"
        style={{
          marginTop: "73px",
          maxWidth: "95.5%",
        }}
      >
        <div className="card" style={{height:"620px"}}>
          <div
            className="card-heading"
            style={{ backgroundColor: "lightgray", height: "44px" }}
          ><h4 className="mt-2">
          <> &nbsp;&nbsp;<i className="fas fa-copy text-info"></i>&nbsp;Code Master</>
        
          </h4></div>
          <div>
            <div className="row mt-4">
              <div className="col-md-4" style={{marginLeft:"4px"}}>
                <label style={{ fontSize: "16px" }}>
                  TAB NAME
                  <span style={{ fontSize: "16px", color: "red" }}>*</span>{" "}
                </label>
                <select
                  name="TABNAME"
                  onChange={handleChangeTAB}
                  id="TABNAME"
                  className="form-control"
                  type="text"
                >
                  <option value=""> --Select-- </option>
                 <option value="T_SIS_CODE_TYPE">CODE TYPE</option>
                 <option value="T_SIS_CODE_VALUE">CODE VALUE</option>
                </select>
              </div>
              <div className="col-md-4">
                <label style={{ fontSize: "16px" }}>
                  Action Type
                  <span style={{ fontSize: "16px", color: "red" }}>*</span>{" "}
                </label>
                <select
                  name="Action"
                  onChange={handleChangeAction}
                  id="Action"
                  className="form-control"
                  type="text"
                  value={actName}
                >
                  <option value=""> --Select-- </option>
                  <option value="INSERT"> Insert </option>
                  <option value="UPDATE"> Update </option>
                 
                </select>
              </div>
              <div className="col-md-2">
          {colList.length>0? <a className="btn btn-primary mt-4" onClick={actionData}> Execute</a>:<></>}
              </div>
            </div>
            <div className="row mt-4">
              <div className="col-md-12">
              {colList.length>0? 
                <table className="table table-boarder">
                  <thead>
                    <tr>
                      <th>Heading</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {colList.map((row, index) => (
                      <tr>
                        <td>
                          {row.COLUMN_NAME.replace("_", " ")
                            .replace("_", " ")
                            .replace("_", " ")
                            .replace("_", " ")}
                        </td>
                        <td>
                          <div>
                         
                            <input
                              value={row.VAL}
                              onChange={(e) => {
                                handleChangeValue(e, index);
                              }}
                              type={
                                row.DATA_TYPE == "NUMBER"
                                  ? "number"
                                  : row.DATA_TYPE == "VARCHAR2"
                                  ? "text"
                                  : "date"
                              }
                              name={row.COLUMN_NAME}
                              className="form-control"
                              style={{ width: index == 0 ? "92%" : "100%" }}
                              disabled={row.ACT=="N"?true:false}
                            />
                            {index == 0 && actName !=="INSERT" ? (
                              <a
                                className="btn btn-primary"
                                onClick={() => {
                                  getData(row.VAL);
                                }}
                                style={{ float: "right", marginTop: "-40px" }}
                              >
                                Get
                              </a>
                            ) : (
                              <></>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>:<></>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CodeMaster;

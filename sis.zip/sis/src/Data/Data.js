import { IoSettingsSharp } from "react-icons/io5";
import { FaExclamation } from "react-icons/fa";
import { MdPendingActions } from "react-icons/md";
import { RiPassPendingLine } from "react-icons/ri";
 
export const cardsData = [
    {
      value: "20",
      tag: "Nos",
      title: 'Number of UMC Logged',
      color: {
        backGround: "#ed831f",
        boxShadow: "0px 3px 3px 0px #ed831f",
      },
      colorForButon: {
        backGround: "#e06f04"
      },
      iconForCard: <IoSettingsSharp />
 
    },
    {
        value: "5",
        tag: "Nos",
        title: 'Request Approved in AIULP',
        color: {
          backGround: "#488A99",
          boxShadow: "0px 3px 3px 0px #488A99",
        },
        colorForButon: {
            backGround: "#047791"
          },
          iconForCard: <FaExclamation />
    },
    {
        value: "10",
        tag: "Nos",
        title: 'Request pending in Intra location',
        color: {
          backGround: "#8a2be2",
          boxShadow: "0px 3px 3px 0px #8a2be2",
        },
        colorForButon: {
            backGround: "#6402bf"
          },
          iconForCard: <MdPendingActions />
    },
    ,{
        value: "2",
        tag: "Nos",
        title: 'Request pending in Inter location',
        color: {
          backGround: "#D32D41",
          boxShadow: "0px 3px 3px 0px #D32D41",
        },
        colorForButon: {
            backGround: "#a30a1c"
          },
          iconForCard: <RiPassPendingLine />
    }
  ];
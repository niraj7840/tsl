export const AIULP="AIULP";
export const INTRA="INTRA";
export const INTER="INTER";
export const WIP="10";
export const WAIT="11";
export const HOD="2";
export const CHIEF="3";
export const MR="4";
export const AUTOAPPROVE="1";

export const AIULPPENDING="12";
export const INTRAPENDING="13";
export const INTERPENDING="14";
export const CAPEXPENDING="15";
export const INTELLIBUY="16";
export const SHOPPINGCARTCREATION='37';
export const IndentStatusCode="4";
export const DocumentTypeCode="5";
export const FODCode="6";
export const storageList="7";


export const AIULPPENDING1=12;
export const INTRAPENDING1=13;
export const INTERPENDING1=14;
export const SPARESHARINGCLOSED1=17;
export const CAPEXPENDING1=15;
export const INTELLIBUY1=16;
export const SHOPPINGCARTCREATION1=37;
export const CLOSED=5;
export const SHOPPINGCARTINDRAFT1=38;
export const ShoppingCartCreatedPendingForApproval1=39;

export const SCRETURNEDFORMODIFICATION1=52;
export const SCREJECTED1=53;
export const SCAPPROVEDPENDINGFORFODCREATION1=54;
export const SCFODCREATION1=55;
export const SCFODINERROR1=56;
export const SCUNDERCHANGE1=45

export const PendingForL1=41;
export const PendingForL2=42;
export const ReturnByL1=43;
export const ReturnByl2=44;

export const  PendingForL3 = 46;
export const  PendingForL4 = 47;
export const  ReturnByL3 = 48;
export const ReturnByL4 = 49;
export const PendingForL5 = 50;
export const ReturnByL5 = 51;
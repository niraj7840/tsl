import axios from 'axios'
import React from 'react'
import { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { BaseUrl } from '../../constants/BaseURL'
//import "./Card.css"
//import { cardsData } from "../../Data/Data"
import Cards from '../Cards/Cards'
import { IoSettingsSharp } from "react-icons/io5";
import { FaExclamation } from "react-icons/fa";
import { MdPendingActions } from "react-icons/md";
import { RiPassPendingLine } from "react-icons/ri";
import { useState } from 'react'
 
 
const Card = () => {
    const user = useSelector((state) => JSON.parse(state.auth.userData));
const [cardsData,setCardData]=useState([
    {
      value: "0",
      tag: "Nos",
      title: 'Indent Approval Pending',
      color: {
        backGround: "#ed831f",
        boxShadow: "0px 3px 3px 0px #ed831f",
      },
      colorForButon: {
        backGround: "#e06f04"
      },
      iconForCard: <IoSettingsSharp />,
      pagetoRedirect:"IndentPending"
    },
    {
        value: "0",
        tag: "Nos",
        title: 'Spare Sharing Approval Pending',
        color: {
          backGround: "#488A99",
          boxShadow: "0px 3px 3px 0px #488A99",
        },
        colorForButon: {
            backGround: "#047791"
          },
          iconForCard: <FaExclamation />,
          pagetoRedirect:"MyAction"
    },
    {
        value: "0",
        tag: "Nos",
        title: 'Shopping Cart Approval Pending',
        color: {
          backGround: "#8a2be2",
          boxShadow: "0px 3px 3px 0px #8a2be2",
        },
        colorForButon: {
            backGround: "#6402bf"
          },
          iconForCard: <MdPendingActions />,
          pagetoRedirect:""
    }
    ,{
        value: "0",
        tag: "Nos",
        title: 'My Open Indent List',
        color: {
          backGround: "#D32D41",
          boxShadow: "0px 3px 3px 0px #D32D41",
        },
        colorForButon: {
            backGround: "#a30a1c"
          },
          iconForCard: <RiPassPendingLine />,
          pagetoRedirect:"IndentApproval"
    }]);
    useEffect(() => {
        MyPendingIndent();
    }, [])

   
        const  MyPendingIndent = async() => {
          var  cardsDatalist = [
            {
              value: "0",
              tag: "Nos",
              title: 'Indent Approval Pending',
              color: {
                backGround: "#ed831f",
                boxShadow: "0px 3px 3px 0px #ed831f",
              },
              colorForButon: {
                backGround: "#e06f04"
              },
              iconForCard: <IoSettingsSharp />,
              pagetoRedirect:"IndentPending"
            },
            {
                value: "0",
                tag: "Nos",
                title: 'Spare Sharing Approval Pending',
                color: {
                  backGround: "#488A99",
                  boxShadow: "0px 3px 3px 0px #488A99",
                },
                colorForButon: {
                    backGround: "#047791"
                  },
                  iconForCard: <FaExclamation />,
                  pagetoRedirect:"MyAction"
            },
            {
                value: "0",
                tag: "Nos",
                title: 'Shopping Cart Approval Pending',
                color: {
                  backGround: "#8a2be2",
                  boxShadow: "0px 3px 3px 0px #8a2be2",
                },
                colorForButon: {
                    backGround: "#6402bf"
                  },
                  iconForCard: <MdPendingActions />,
                  pagetoRedirect:""
            }
            ,{
                value: "0",
                tag: "Nos",
                title: 'My Open Indent List',
                color: {
                  backGround: "#D32D41",
                  boxShadow: "0px 3px 3px 0px #D32D41",
                },
                colorForButon: {
                    backGround: "#a30a1c"
                  },
                  iconForCard: <RiPassPendingLine />,
                  pagetoRedirect:"IndentPending"
            }]
            //setstate(false);
            let token = sessionStorage.getItem('token');
            let headers = {
              'jwt-token': token      
            };
            
            await axios.get(`${BaseUrl}api/Master/GetDashboardCount?USERNAME=${user.User_Id}`, {headers}, {
              withCredentials: true
             
            }).then((response) => {
            var cnt=  JSON.parse(response.data); 
            for (let index = 0; index < cardsDatalist.length; index++) {
                cardsDatalist[index]["value"]=cnt[index]["CNT"].toString();
                
            }
            
                setCardData(cardsDatalist);
            
            // Access the data directly
                  
               
                 })
                 .catch((error) => {
                   console.log(error);
                 });;
          };
    
    //const[cardData,setCardData]=useState([]);
    return (
        <div className="row" style={{width:'100%'}}>
            {cardsData.map((card, id) => {
                return (
                    <div className="col-md-3" key={id}>
                        <Cards
                            title={card.title}
                            color={card.color}
                            value={card.value}
                            tag={card.tag}
                            colorForButton={card.colorForButon}
                            iconForCard={card.iconForCard}
                            pagetoRedirect={card.pagetoRedirect}
                        />
                    </div>
                );
            })}
        </div>
 
    )
}
 
export default Card
import React from "react";
import { useSelector } from "react-redux";
import "./TabMenu.css";

import {AIULPPENDING1, INTRAPENDING1, INTERPENDING1, CAPEXPENDING1, INTELLIBUY1, SHOPPINGCARTCREATION1, SHOPPINGCARTINDRAFT1,ShoppingCartCreatedPendingForApproval1, CLOSED,
  SCRETURNEDFORMODIFICATION1, SCREJECTED1, SCAPPROVEDPENDINGFORFODCREATION1, SCFODCREATION1, SCFODINERROR1, SCUNDERCHANGE1, SPARESHARINGCLOSED1
} from "../../constants/CommanConstant"

const TabMenu = ({ prop, onTabSelect, indentStatus, indentStatusDescription, dept }) => {

  const indentId = useSelector((state) =>
    state.indent ? state.indent.indentId : ""
  );

  const tabNames = {
    RaiseRequest: "Raise Indent",
    IndentStatus: "Spares Sharing",
    IntentUmcCapStatus: "Capital Governance",
    IntelliBuySystemChecks: "Intellibuy",
    ShoppingCart: "Shopping Cart",
  };
  const getStatusClass = (tabName) => {
    switch (indentStatus) {
      case AIULPPENDING1:
      case INTRAPENDING1:
      case INTERPENDING1:
        if (tabName === "RaiseRequest") return "green";
        if (tabName === "IndentStatus") return "yellow";

        if (tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
        break;
      case CAPEXPENDING1:
        if (tabName === "IntentUmcCapStatus") return "yellow";
        if (tabName === "RaiseRequest" || tabName === "IndentStatus") return "green";
        if (tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
        break;
      case INTELLIBUY1:
        if (tabName === "IntelliBuySystemChecks") return "yellow";
        if (tabName === "RaiseRequest" || tabName === "IndentStatus" || tabName === "IntentUmcCapStatus") return "green";
        if (tabName === "ShoppingCart") return "disabled blue";
        break;
      case SHOPPINGCARTCREATION1:
      case SHOPPINGCARTINDRAFT1:
      case ShoppingCartCreatedPendingForApproval1:
      case SCRETURNEDFORMODIFICATION1:
      case SCAPPROVEDPENDINGFORFODCREATION1:
      case SCFODINERROR1:
        if (tabName === "ShoppingCart") return "yellow";
        if (tabName === "RaiseRequest" || tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks") return "green";
        //if (tabName === "ShoppingCart") return "disabled blue";
        break;
      case CLOSED:
        if (tabName === "IntentUmcCapStatus") return "green";
        if (tabName === "RaiseRequest" || tabName === "IndentStatus") return "green";
        if (tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
        break;

      case SCFODCREATION1:
      case SCUNDERCHANGE1:
        if (tabName === "ShoppingCart") return "green";
        if (tabName === "RaiseRequest" || tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks") return "green";
        break;
      
      case SCREJECTED1:
        if (tabName === "ShoppingCart") return "red";
        if (tabName === "RaiseRequest" || tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks") return "green";
        break;

      case SPARESHARINGCLOSED1:
        if (tabName === "RaiseRequest") return "green";
        if (tabName === "IndentStatus") return "green";
        if (tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
        break;
      
      default:
        return "";
    }
  };
  // const getStatusClass = (tabName) => {
  //   switch (indentStatus) {
  //     case "Pending for AIULP Spare sharing":
  //     case "Pending for INTRA Spare sharing":
  //     case "Pending for INTER Spare sharing":
  //       if (tabName === "RaiseRequest") return "green";
  //       if (tabName === "IndentStatus") return "yellow";

  //       if (tabName === "IndentStatus"||tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
  //       break;
  //     case "Pending for Capex Approval":
  //       if (tabName === "IntentUmcCapStatus") return "yellow";
  //       if (tabName === "RaiseRequest" ||tabName === "IndentStatus") return "green";
  //       if (tabName === "IntelliBuySystemChecks" || tabName === "ShoppingCart") return "disabled blue";
  //       break;
  //     case "Pending for Intellibuy Check":
  //       if (tabName === "IntelliBuySystemChecks") return "yellow";
  //       if (tabName === "RaiseRequest"||tabName === "IndentStatus" || tabName === "IntentUmcCapStatus") return "green";
  //       if (tabName === "ShoppingCart") return "disabled blue";
  //       break;
  //       case "Pending for Shopping Cart Creation":
  //       if (tabName === "ShoppingCart") return "yellow";
  //       if (tabName === "RaiseRequest"||tabName === "IndentStatus" || tabName === "IntentUmcCapStatus" || tabName === "IntelliBuySystemChecks") return "green";
  //       //if (tabName === "ShoppingCart") return "disabled blue";
  //       break;
  //     default:
  //       return "";
  //   }
  // };

  return (
    <div>
      <div style={{ margin: "6% 0% 0% 7%" }}>
        <div className="arrow-steps clearfix">
          {Object.keys(tabNames).map((tab) => (
            <div
              key={tab}
              className={`step ${prop === tab ? "current" : ""} ${getStatusClass(tab)}`}
              onClick={() => getStatusClass(tab).includes("disabled") ? null : onTabSelect(tab)}
            >
              <span id="span_bold">{tabNames[tab]}</span>
            </div>
          ))}
        </div>
        <br />
      </div>
      <div id="box">
        <div className="row" id="row1">
          <div className="col-md-3" style={{ fontSize: "13px" }}>
            <lable>
              <b>
                Indent Number :
                <span style={{ color: "blue" }}>
                  <b> &nbsp;{indentId}</b>
                </span>
              </b>
            </lable>
          </div>

          <div className="col-md-4" style={{ fontSize: "13px" }}>
            <lable>
              <b>
                Department :
                <span style={{ color: "blue" }}>
                  {/* <b> &nbsp;{tabNames[prop]} </b> */}
                  <b> &nbsp;{dept} </b>

                </span>
              </b>
            </lable>
          </div>
          <div className="col-md-5" style={{ fontSize: "13px" }}>
            <label>
              <b>
                Indent Status :
                <span style={{ color: "blue" }}>
                  {/* <b> &nbsp;{tabNames[prop]} </b> */}
                  <b> &nbsp;{indentStatusDescription} </b>

                </span>
              </b>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TabMenu;

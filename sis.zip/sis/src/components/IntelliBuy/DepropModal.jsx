import React, { useState } from "react";
import "./Modal.css";

const DepropModal = ({ handleClose, DepropData, OnDeleteRow }) => {
  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Deprop Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div className="table-responsive table-responsive-sm" style={{overflowX:"auto",maxHeight:"600px"}}>
                <table className="tables table-bordered tb">
                  <thead className="table-primary" style={{ whiteSpace: "nowrap" }}>
                    <tr>
                      <th> Sl No</th>
                      <th>UMC No</th>
                      <th> Description </th>
                      <th>
                        {" "}
                        Document type for shopping cart
                      </th>
                      {/* <th> Prop/Deprop case</th> */}

                      <th> Smart Nudges</th>
                      <th> Status </th>
                      <th> Delete</th>
                    </tr>
                  </thead>
                  <tbody style={{ whiteSpace: "nowrap" }}>
                    {" "}
                    {DepropData.filter((item) => item.ISACTIVE === "Y").map(
                      (row, index) => (
                        <tr key={index}>
                          <td>{row.SRNO}</td>
                          <td>{row.REQ_UMC_NO}</td>
                          <td>{row.REQ_UMC_DESC}</td>
                          <td>
                            {row.DOCUMENT_TYPE_DESC.trim() === "-"
                              ? "Others"
                              : row.DOCUMENT_TYPE_DESC}
                          </td>
                          {/* <td>{row.PropDeprop}</td>  */}
                          <td
                            style={{
                              backgroundColor:
                                row.DOCUMENT_TYPE === "NP" ? "orange" : "",
                                padding: "0px",
                                margin: "0px",    fontSize: "12px",whiteSpace: "normal"
                            }}
                          >
                            {row.DOCUMENT_TYPE === "NP"
                              ? "This UMC (Spare/Item) is being procured through the properietary route, and may have adverse impact on SRM cost and working capital both; you are requested to review your requirement and procure it through the non prop route."
                              : ""}
                          </td>
                          <td
                            style={{
                              backgroundColor:
                                row.DOCUMENT_TYPE === "NP" ? "red" : "green",
                            }}
                          ></td>
                          <td>
                            {" "}
                            <button
                              onClick={() => {
                                OnDeleteRow(row.UMC_INDENT_ID);
                              }}
                              style={{
                                width: "25px",
                                height: "25px",
                                padding: "0px",
                              }}
                              class="btn btn-danger btn-sm"
                              type="button"
                              data-toggle="tooltip"
                              data-placement="top"
                              title="Delete"
                            >
                              <i class="fa fa-trash"></i>
                            </button>
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="modal-footer">
              {/* <button type="button" class="btn btn-primary">Save</button> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DepropModal;

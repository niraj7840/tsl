import React, { useState } from "react";
import { DateInput } from "react-aria-components";
import "./Modal.css";

import * as moment from "moment";

const SC_RequirmentConsumptionModal = ({
  handleClose,
  requirmentConsumptionData,
  handleCellChange
}) => {
  // const fetchChangeQty=requirmentConsumptionData.ChangedQty;

  const [changedDate, setChangedQty] = useState({});


  const handleCellChanges = (index, field, SysReqDTT, SysConsumDTT, ChangeReqDTT, changeConsumDTT, userjustification) => {
    handleCellChange(index, field, SysReqDTT, SysConsumDTT, ChangeReqDTT, changeConsumDTT, userjustification);
  };


  // Helper function to format date to YYYY-MM-DD
  function formatDateToInput(date) {
    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    const year = d.getFullYear();
    return `${year}-${month}-${day}`;
  }
  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"

      >
        <div class="modal-dialog modal-xl">
          <div class="modal-content" >
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Requirement & Consumption date check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div className="table-responsive" style={{ overflowX: "auto", maxHeight: "550px" }}>
                <table
                  className="tables">
                  <thead
                    className="table-primary"
                    style={{ whiteSpace: "nowrap" }}
                  >
                    <tr>
                      <th>Sl No</th>
                      <th>UMC No</th>
                      <th>Description</th>
                      {/* <th>Tagged UMC</th> */}
                      <th>Sys Requi Dt</th>
                      <th>Sys Consum Dt</th>

                      <th>Indent Requi Dt</th>
                      <th>Indent Consum Dt</th>
                      <th>Status</th>
                      <th>Smart Nudges</th>                      
                      <th>User Justification</th>

                    </tr>
                  </thead>
                  <tbody style={{ whiteSpace: "nowrap" }}>
                    {requirmentConsumptionData.map((row, index) => {
                      console.log("row.RCM_STATUS", row.RCM_STATUS)
                      const statusColor = row.RCM_STATUS === 'true' ? "green" : "red";
                      const smartNudgesText = row.RCM_STATUS === 'true' ? "User has accepted the system-based consumption date/requirement date of requirement for this UMC,  you may approve the SC."
                        : "User has not accepted the system-based consumption date/ requirement date of requirement for this UMC,  it may impact the working capital and you are requested to scrutinize and approve the SC only after due diligence in this regard.";

                      return (
                        <tr key={index}>
                          <td>{row.SRNO}</td>
                          <td>{row.EXISTING_UMC}</td>
                          <td>{row.EXISTING_UMC_DESC}</td>
                          <td>{moment(row.SYS_REQ_DATE).format("DD/MM/YYYY")}</td>
                          <td>{moment(row.SYS_CONSUMP_DT).format("DD/MM/YYYY")}</td>
                          <td>
                            <input readOnly
                              value={
                                row.SCI_REQD_ON_DT
                                  ? moment(row.SCI_REQD_ON_DT).format(
                                    "YYYY-MM-DD"
                                  )
                                  : ""

                              }
                            />
                          </td>

                          <td>
                            <input readOnly
                              value={
                                row.CONSUMP_DT
                                  ? moment(row.CONSUMP_DT).format("YYYY-MM-DD")
                                  : ""
                              }
                            />
                          </td>
                          <td style={{ backgroundColor: statusColor }}></td>
                          <td>
                            <textarea
                              rows="1"
                              readOnly
                              style={{ width: "200px", height: "35px" }}
                              value={smartNudgesText}
                              type="text"
                            />
                          </td>  
                          <td >
                            <textarea rows="1" readOnly style={{ width: "300px" }} type="text" className="form-control form-control-sm"
                              value={row.USER_REMARKS_RCM}

                            />
                          </td>

                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="modal-footer ml-0">
              <span
                className="me-auto"
                style={{
                  color: "orangered",
                  marginLeft: "0px",
                  whiteSpace: "pre-line",
                }}
              >
                <b>Escalate when </b>
                <br></br>
                User Requirement Date - System requirement date is &gt;=3 months
                <br></br>
                User Requirement Date - System requirement date &lt; = 0.
              </span>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SC_RequirmentConsumptionModal;

import React, { useState } from "react";
import "./Modal.css";
const SC_RefurshibilityModal = ({
  handleClose,
  details,
  requirmentConsumptionData,
  handleDeleteRows,
}) => {
  // const fetchChangeQty=requirmentConsumptionData.ChangedQty;
  
  const [changedDate, setChangedQty] = useState({});

  const handleDeleteRow = (SLNo) => {
    handleDeleteRows(SLNo);
  };
  const handleCellChange = (id, value) => {
    console.log(id, value, "Test");
    setChangedQty((prevState) => ({
      ...prevState,
      [id]: value,
    }));
  };

  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl" >
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Refurshibility Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body ">
              <div className="table-responsive table-responsive-sm" style={{overflowX:"auto",maxHeight:"600px"}}>
                <table className="tables table-bordered tb">
                  <thead className="table-primary">
                    <tr>
                      <th> Sl No</th>
                      <th>UMC No</th>
                      <th> Description </th>
                      <th> Refurbishable  /Non Refurbishable  </th>
                      <th > Smart Nudges</th>
                      <th> Status </th>
                    
                    </tr>
                  </thead>
                  <tbody style={{ padding: "0px",whiteSpace:"nowrap" }}>
                    {requirmentConsumptionData.map((row, index) => (
                      <tr key={index}>
                       <td>{row.SRNO}</td>
                        <td>{row.EXISTING_UMC}</td>
                        <td>{row.EXISTING_UMC_DESC}</td>
                        <td>
                          {row.IS_REFURBISHABLE}
                        </td>
                        <td
                          style={{
                            backgroundColor:
                              row.REFURSHIBILITY_STATUS === "true" ? "" : "",
                            padding: "0px",
                            margin: "0px",fontSize:"12px",whiteSpace: "normal"
                          }}
                        >
                          {row.REFURSHIBILITY_STATUS === "true" //---R
                            ? "This UMC (Spare/item) is refurbishable in nature; however, indenter/dept. is trying to procure a new one; requesting you to review the requirement."
                            : row.REFURSHIBILITY_STATUS === "false" //--N
                            ? ""
                            :row.IS_REFURBISHABLE}
                        </td>
                        <td
                          style={{
                            backgroundColor:
                              row.REFURSHIBILITY_STATUS = "true" ? "green" : "red",
                            padding: "0px",
                          }}
                        ></td>
                        
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SC_RefurshibilityModal;

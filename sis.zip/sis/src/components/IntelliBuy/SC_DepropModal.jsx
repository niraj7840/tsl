import React, { useState } from "react";
import "./Modal.css";

const SC_DepropModal = ({ handleClose, DepropData, OnDeleteRow }) => {
console.log("DepropData",DepropData)
  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Deprop Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div className="table-responsive table-responsive-sm" style={{overflowX:"auto",maxHeight:"600px"}}>
                <table className="tables table-bordered tb">
                  <thead className="table-primary" style={{ whiteSpace: "nowrap" }}>
                    <tr>
                      <th> Sl No</th>
                      <th>UMC No</th>
                      <th> Description </th>
                      <th>
                        {" "}
                        Document type for shopping cart
                      </th>
                      {/* <th> Prop/Deprop case</th> */}

                      <th> Smart Nudges</th>
                      <th> Status </th>
                     
                    </tr>
                  </thead>
                  <tbody style={{ whiteSpace: "nowrap" }}>
                    {" "}
                    {DepropData.map(
                    
                      (row, index) => (
                      
                        <tr key={index}>
                          <td>{row.SRNO}</td>
                          <td>{row.EXISTING_UMC}</td>
                          <td>{row.EXISTING_UMC_DESC}</td>
                          <td>
                            {row.DOCUMENT_TYPE_DESC === "-"
                              ? "Others"
                              : row.DOCUMENT_TYPE_DESC}
                          </td>
                          {/* <td>{row.PropDeprop}</td>  */}
                          <td
                            style={{
                              backgroundColor:
                                row.DOCUMENT_TYPE === "NP" ? "orange" : "",
                                padding: "0px",
                                margin: "0px",    fontSize: "12px",whiteSpace: "normal"
                            }}
                          >
                            {row.DEPROP_STATUS === "false"
                              ? "The UMC is of proprietary nature; value and lead time of this UMC may be higher and may impact working capital adversely. You may approve this SC after due diligence."
                              : "The UMC is of non-proprietary nature. You may approve this SC"}
                          </td>
                          <td
                            style={{
                              backgroundColor: row.DEPROP_STATUS === "false" ? "red" : "green",
                               // row.DOCUMENT_TYPE === "NP" ? "red" : "green",
                            }}
                          ></td>
                          
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="modal-footer">
              {/* <button type="button" class="btn btn-primary">Save</button> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SC_DepropModal;

import React, { useState } from "react";
import "bootstrap-select";
import "bootstrap-select/dist/css/bootstrap-select.min.css";
import "./Modal.css";

const SC_MaxQtyModal = ({
  handleClose,
  updateQtyData,
  handleCellChange 
}) => {

  console.log('getMaxQtyData_SC',updateQtyData);
  const calculateQuantity = (row) => {
    const maxQty = parseFloat(row.MaxQty) || 0;
    const pipelineQty = parseFloat(row.PipelineQty) || 0;
    const refurQty = parseFloat(row.RefurQty) || 0;
    const chargeQty = parseFloat(row.ChargeQty) || 0;
  
    let quantity = maxQty - (pipelineQty + refurQty + chargeQty);
    if(quantity<0)
      {
        quantity=0.000
      }
    return quantity.toFixed(3);
  };


  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl" >
          <div class="modal-content" >
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Max Qty Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body ">
              {/* <table className="table table-bordered table-responsive-sm table-sm tb"> */}
              <div className="table-responsive table-responsive-sm" style={{overflowX:"auto", maxWidth:"1400px",  maxHeight:"600px"}}>
              <table className="tables">
  <thead className="table-primary" style={{ whiteSpace: "nowrap" }}>
    <tr>
      <th>Sl No</th>
      <th>UMC No</th>
      <th>Description</th>
      <th>Qty in pipeline</th>
      <th>Qty Refurbished</th>
      <th>Qty Charged out</th>
      <th>Plant</th>
      <th>Max Qty</th>
      <th>Allowed Qty</th>
      <th>Status</th>
      <th>Smart Nudges</th>
      <th style={{ whiteSpace: "nowrap" }}>SC Qty</th>
      <th>User Justification</th>
    </tr>
  </thead>
  <tbody style={{ whiteSpace: "nowrap", padding: "0px" }}>
    {updateQtyData.map((row, index) => {    
      debugger;  
       const statusColor = row.MAXQTY_STATUS === 'false' ? "red" : "green";       
       const smartNudgesText = row.MAXQTY_STATUS === 'false' ? "Users wants to indent more than the allowed qty for this UMC. Hence, it has violated max qty logic, and may impact working capital adversely. You may approve SC after due diligence." : "Users wants to indent this UMC as per the max qty recommendation. You may approve this SC";
          
      return (
        <tr key={index}>
          <td>{row.SRNO}</td>
          <td>{row.EXISTING_UMC}</td>
          <td>{row.EXISTING_UMC_DESC}</td>
          <td>{row.PIPELINE_QTY}</td>
          <td>{row.REFURBISHED_QTY}</td>
          <td>{row.CHARGEDOUT_QTY}</td>
          <td>{row.SCI_PLANT_CD}</td>
          <td>{row.MAX_QTY}</td>
          <td>{row.ALLOWED_QTY}</td>
          <td style={{ backgroundColor: statusColor }}></td>
          <td>
            <textarea
              rows="1"
              readOnly
              style={{ width: "200px" , height: "35px"}}
              value={smartNudgesText}
              type="text"
            />
          </td>
          <td>
            <input
              value={row.SCI_QTY}
              readOnly           
              type="text"
              className="form-control form-control-sm"
            />
          </td>
          <td>
            <textarea
              rows="1"
              readOnly
              style={{ width: "200px", height: "35px" }}
              className="form-control form-control-sm"
              value={row.USER_REMARKS_MAXQTY}           
              type="text"
            />
          </td>
        </tr>
      );
    })}
  </tbody>
</table>

              </div>
            </div>
            <div class="modal-footer ml-0">
              <span
                className="me-auto"
                style={{ color: "orangered", marginLeft: "0px" }}
              >
                Max Quantity =Consumption w.r.t. (New & Tagged UMCs)/Count of
                Yrs.+(Lead time in months*Avg. consumption in months):-(min
                qty/safety stock)
              </span>
              <span
                className="me-auto mt-0 mp-0"
                style={{ color: "orangered", marginLeft: "0px" }}
              >
                Allowed Qty= Max Qty- (pipeline PR/RO)-Charged out for a dept.-
                Refurbished qty. for a location
              </span>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SC_MaxQtyModal;

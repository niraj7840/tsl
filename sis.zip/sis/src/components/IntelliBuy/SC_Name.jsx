import React, { useState } from "react";
import { DateInput } from "react-aria-components";
import Swal from "sweetalert2";
import $ from "jquery";
import "./Modal.css";

import * as moment from "moment";

const SC_Name = ({ handleClose, handleSubmitScName, SCName, setSCName }) => {
  const handleSubmit = async () => {
    if ($("SCName").val() === "") {
      Swal.fire("", "Please enter Shopping Cart Name", "info");
      return;
    }
   await handleSubmitScName();
  }
  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div
          class="modal-dialog modal-xl"
          style={{
            width: "700px",
            height: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div class="modal-content" id="" style={{ paddingBottomm: "510px" }}>
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                ShoppingCart
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div className=""></div>
              <div className="row">
                <div className="col-md-6">
                  <label style={{ fontSize: "16px" }}>
                    Name of the shopping cart
                    <span style={{ fontSize: "16px", color: "red" }}>*</span>
                  </label>
                </div>

                <div className="col-md-6">
                  <textarea
                    id="SCName"
                    className="form-control"
                    type="text"
                    maxlength="100"
                    value={SCName}
                    onChange={(event) => {
                      setSCName(event.target.value);
                    }}
                  />
                </div>
              </div>
              <br />
              <div
                className="row"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <button
                  id="submitScName"
                  type="submit"
                  className="btn btn-primary"
                  onClick={handleSubmit}
                  style={{ width: "320px" }}
                >
                  Please Submit to Create Shopping Cart 
                </button>
              </div>
            </div>

            <div class="modal-footer ml-0"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SC_Name;

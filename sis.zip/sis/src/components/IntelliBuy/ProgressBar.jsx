import React from 'react';
import './Modal.css'; // Import CSS for styling

const ProgressBar = ({ percentage }) => {
  // Function to calculate the width and background color of the progress bar
  const getProgressStyle = (percent) => {

    let width = `${percent}%`;
    if(parseInt(percent)>100)
      {
        width='100%'
      }
      if(parseInt(percent)===0)
        {
          width='10%'
        }
    let backgroundColor = '#4CAF50'; // Default color for progress

    if (percent <= 30) {
      backgroundColor = '#4CAF50'; // Green for percentages <= 30
    } else if (percent > 30 && percent <= 50) {
      backgroundColor = '#FFEB3B'; // Yellow for percentages > 30 and <= 50
    } else if (percent > 50 && percent <= 80) {
      backgroundColor = '#FF9800'; // Orange for percentages > 50 and <= 80
    } else if (percent > 80) {
      backgroundColor = '#F44336'; // Red for percentages > 80
    }

    return {
      width,
      backgroundColor,
    };
  };

  // Apply the dynamic styles
  const progressStyle = getProgressStyle(percentage);

  return (
    <div className="progress-container">
      <div className="progress-bar" style={progressStyle}>
        <span className="progress-text">{`${percentage}%`}</span>
      </div>
    </div>
  );
};

export default ProgressBar;

import React, { useEffect, useState } from "react";
import "bootstrap-select";
import "bootstrap-select/dist/css/bootstrap-select.min.css";
import "./Modal.css";

const MaxQtyModal = ({
  handleClose,
  updateQtyData,
  handleCellChange,
  OnDeleteRow,
  OnSaveData,
  IsDisabled
}) => {

  const calculateQuantity = (row) => {
    const maxQty = parseFloat(row.MaxQty) || 0;
    const pipelineQty = parseFloat(row.PipelineQty) || 0;
    const refurQty = parseFloat(row.RefurQty) || 0;
    const chargeQty = parseFloat(row.ChargeQty) || 0;
  
    let quantity = maxQty - (pipelineQty + refurQty + chargeQty);
    if(quantity<0)
      {
        quantity=0.000
      }
    return quantity.toFixed(3);
  };
  

  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl" >
          <div class="modal-content" >
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Max Qty Check
              </h5>
              <button
                onClick={handleClose}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body ">
              {/* <table className="table table-bordered table-responsive-sm table-sm tb"> */}
              <div className="table-responsive table-responsive-sm" style={{overflowX:"auto", maxWidth:"1400px",  maxHeight:"600px"}}>
                <table className="tables">
                  <thead className="table-primary"
                       style={{ whiteSpace: "nowrap" }} >
                    <tr>
                      <th>Sl No</th>
                      <th>UMC No</th>
                      <th>Description</th>
                      {/* <th>Tagged UMC</th> */}
                      <th>Qty in pipeline</th>
                      {/* <th>Stock</th> */}
                      <th>Qty Refurbished</th>
                      <th>Qty Charged out</th>
                      <th>Plant</th>
                      <th>Max Qty</th>
                      <th>Allowed Qty</th>
                      <th>Status</th>
                      <th style={{ whiteSpace: "nowrap" }}>SC Qty</th>
                      {/* <th>Check</th> */}
                      <th>User Justification</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody style={{ whiteSpace: "nowrap",padding:"0px" }}>
                    {updateQtyData
                      .filter((item) => item.ISACTIVE === "Y")
                      .map((row, index) => (
                        <tr key={index}>
                       <td>{row.SRNO}</td>
                          <td>{row.REQ_UMC_NO}</td>
                          <td>{row.REQ_UMC_DESC}</td>
                          {/* <td>{row.TAGGEDUMC}</td> */}
                          <td>{row.PipelineQty}</td>
                          {/* <td></td> */}
                          <td>{row.RefurQty}</td>
                          <td>{row.ChargeQty}</td>
                          <td>{row.INDENTOR_PLANT}</td>
                          <td>{row.MaxQty}</td>
                          {/* <td>{row.ALLOWEDQTY}</td> */}
                          <td>{calculateQuantity(row)}</td>
                          <td
                            style={{
                              backgroundColor:
                              parseFloat(calculateQuantity(row)) < parseFloat(row.SC_QTY)
                                  ? "red"
                                  : "green",
                            }}
                          ></td>
                          <td>
                            <input
                              //value={changedQty[row.SLNo] || ''}
                              value={row.SC_QTY}
                              name={`changeqtys_${row.SLNo}`}
                              type="text"
                              className="form-control form-control-sm"
                              style={{width:'50px'}}
                              onChange={(event) =>
                                handleCellChange(
                                  index,
                                  "SC_QTY",
                                  event.target.value
                                )
                              }
                            />
                          </td>
                          <td>
                          <textarea rows="1" style={{width:"200px"}}  className="form-control form-control-sm"
                          value={row.USER_REMARKS_MAXQTY}
                          name={`changeqtys_${row.SLNo}`}
                          type="text"
                         onChange={(event) =>
                            handleCellChange(
                              index,
                              "USER_REMARKS_MAXQTY",
                              event.target.value
                            )
                          }
                          />
                          </td>
                          <td>
                            {" "}
                            <button
                              onClick={() => {
                                OnDeleteRow(row.UMC_INDENT_ID);
                              }}
                              style={{
                                width: "25px",
                                height: "25px",
                                padding: "0px",
                              }}
                              class="btn btn-danger btn-sm"
                              type="button"
                              data-toggle="tooltip"
                              data-placement="top"
                              title="Delete"
                              disabled={IsDisabled}
                            >
                              <i class="fa fa-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="modal-footer ml-0">
              <span
                className="me-auto"
                style={{ color: "orangered", marginLeft: "0px" }}
              >
                Max Quantity =Consumption w.r.t. (New & Tagged UMCs)/Count of
                Yrs.+(Lead time in months*Avg. consumption in months):-(min
                qty/safety stock)
              </span>
              <span
                className="me-auto mt-0 mp-0"
                style={{ color: "orangered", marginLeft: "0px" }}
              >
                Allowed Qty= Max Qty- (pipeline PR/RO)-Charged out for a dept.-
                Refurbished qty. for a location
              </span>
              <button type="button" class="btn btn-primary"
               onClick={() => OnSaveData()}
               disabled={IsDisabled}
               style={{display:IsDisabled?'none':''}}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MaxQtyModal;

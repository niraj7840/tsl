import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FaHome,FaChevronUp,FaChevronDown,FaFileAlt } from "react-icons/fa";
import { NavLink } from "react-router-dom";
import { FaRegSquarePlus} from "react-icons/fa6";
import tataLogo from "../../Data/IMG/tata_logo.png";
import tataSteelLogo from "../../Data/IMG/tata-steel-logo.png";
import { useSelector, useDispatch } from "react-redux";
import { FaBars } from "react-icons/fa";
import { isOpen } from "../../store/menuSlice";
import { GrStatusInfo } from "react-icons/gr";
import { MdCallToAction } from "react-icons/md";
import { Tooltip } from 'react-tooltip';
import "react-tooltip/dist/react-tooltip.css"; // Ensure CSS is imported
import { RiAddBoxFill } from "react-icons/ri";
import { CiViewBoard } from "react-icons/ci";
import { SiTicktick } from "react-icons/si";
import { FaSearch } from "react-icons/fa";
import "./Menu.css";
import axios from "axios";
import { BaseUrl } from "../../constants/BaseURL";
import { useEffect } from "react";

const Menu = ({ IsSuperAdmin, children, IsSCAdmin }) => {
  const dispatch = useDispatch();
  const [openSubMenu, setOpenSubMenu] = useState(null); // Handles top-level menus
  const [openNestedSubMenu, setOpenNestedSubMenu] = useState(null); // Handles nested submenus
  const [hoveringReports, setHoveringReports] = useState(false);
  const [hoveringITAdmin, setHoveringITAdmin] = useState(false);
  const [routes, setRoutes] = useState([
    {
      path: "/SIS/",
      name: "Home Page",
      icon: <FaHome />,
      tooltip: "Go to Home Page"
    },
    {
      path: "/SIS/RaiseIndent",
      name: "Raise Indent",
      icon: <FaRegSquarePlus />,
      tooltip: "Raise Indent"
    },
    {
      path: "/SIS/SearchIndent",
      name: "Search Indent",
      icon: <FaSearch />,
    },
    {
      path: "/SIS/Approval",
      name: "My Action",
      icon: <MdCallToAction />,
      tooltip: "View my actions"
    },
    {
      path: "/SIS/IndentPending",
      name: "Indent Pending",
      icon: <MdCallToAction />,
      tooltip: "Indent Pending"
    },
    {
      name: "Reports",
      icon: <FaFileAlt  />,
      tooltip: "View Reports",
      subRoutes: [
        {
          name: "SAP Report",
          icon: <FaFileAlt/>,
          subRoutes: [
            {
              path: "/SIS/CMBGGMapping",
              name: "CM BGG Mapping",
              icon: <FaFileAlt/>,
              tooltip: "View CM BGG Mapping",
            },
          ],
        },
      ],
    },
  ]);

  const isAuthenticated = true;
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const open = useSelector((state) => state.menu.status);
  const [hover, setHover] = useState(false);

  const toggle = () => {
    dispatch(isOpen());
  };

  const toggleSubMenu = (index) => {
    setOpenSubMenu(openSubMenu === index ? null : index);
  };

  useEffect(() => {
    userValidate();
}, [routes])


  const toggleNestedSubMenu = (index) => {
    setOpenNestedSubMenu(openNestedSubMenu === index ? null : index);
  };

  const handleMouseEnterReports = () => {
    setHoveringReports(true);
    toggleSubMenu(5); // Assuming "Reports" is at index 5
  };

  const handleMouseLeaveReports = () => {
    setHoveringReports(false);
  };

  const handleMouseEnter = () => {
    setHover(true);
    if (!open) {
      dispatch(isOpen());
    }
  };

  const handleMouseLeave = () => {
    setHover(false);
    if (open) {
      dispatch(isOpen());
    }
  };

  const userValidate = async () => {

    try {

        if (IsSuperAdmin == "true") {
            const newData = routes.filter(x => x.path != "/SIS/CodeMasterAdmin");
            const oldData = routes.filter(x => x.path == "/SIS/CodeMasterAdmin");
            if (oldData.length == 0) {
                setRoutes((prvState) => [...newData, {

                    path: "/SIS/CodeMasterAdmin",
                    name: "Code Master",
                    icon: <MdCallToAction />,
                    tooltip: "Code Master"
                }])
            }
        }


        if (IsSCAdmin == "true") {
            const newScData = routes.filter(x => x.path != "/SIS/RegenerateHierarchy");
            const oldScData = routes.filter(x => x.path == "/SIS/RegenerateHierarchy");
            if (oldScData.length == 0) {
                setRoutes((prvState) => [...newScData, {
                    path: "/SIS/RegenerateHierarchy",
                    name: "Reset Approver",
                    icon: <MdCallToAction />,
                    tooltip: "Reset Approver"
                }
                , {
                  path: "/SIS/AddApprover",
                  name: "Add Approver",
                  icon: <MdCallToAction />,
                  tooltip: "Add Approver"
              }])
            }
        }

    } catch (error) {
        console.log(error);
    }
};


  const showAnimation = {
    hidden: {
      width: 0,
      opacity: 0,
      transition: {
        duration: 0.5,
      },
    },
    show: {
      width: "auto",
      opacity: 1,
      transition: {
        duration: 0.2,
      },
    },
  };
  
  return (
    <div className="main-container">
      {isAuthenticated && (<motion.div
          animate={{
            width: open ? "240px" : "60px",
            transition: {
              duration: 0.5,
              type: "spring",
              damping: 11,
            },
          }}
          className="menu"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          <div className="top_section">
            <div className="tata_logo">
              <img src={tataLogo} alt="Tata Logo" />
            </div>
            <AnimatePresence>
              {open && (
                <motion.h1
                  className="tata_steel_logo"
                  variants={showAnimation}
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                >
                  <img src={tataSteelLogo} alt="Tata Steel Logo" />
                </motion.h1>
              )}
            </AnimatePresence>
          </div>

          <section className="routes">
            <div style={{ marginLeft: open ? "200px" : "20px" }} className="fabar" onClick={toggle}>
              <FaBars />
            </div>

            {routes.map((route, index) => (
              <div key={route.name}>
                <NavLink
                  activeclassname="active"
                  to={route.path || "#"}
                  className="link"
                  onMouseEnter={() => {
                    if (route.name === "Reports") {
                      handleMouseEnterReports();
                    }
                  }}
                  onMouseLeave={() => {
                    if (route.name === "Reports") {
                      handleMouseLeaveReports();
                    }
                  }}
                >
                  <div className="icon">{route.icon}</div>
                  <AnimatePresence>
                    {open && (
                      <motion.div
                        variants={showAnimation}
                        initial="hidden"
                        animate="show"
                        exit="hidden"
                        className="link-text"
                      >
                        {route.name}
                        {route.subRoutes && (
                          <span className="submenu-arrow">
                            {openSubMenu === index ? <FaChevronUp /> : <FaChevronDown />}
                          </span>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <Tooltip id={`tooltip-${route.name}`} />
                </NavLink>

                {/* Render Submenu */}
                {openSubMenu === index && route.subRoutes && (
                  <motion.div
                  >
                    {route.subRoutes.map((subRoute, subIndex) => (
                      <div key={subRoute.name}>
                        <NavLink
                          activeclassname="active"
                          to={subRoute.path || "#"}
                          className="submenu-link"
                          onClick={() => toggleNestedSubMenu(subIndex)}
                        >
                             <div className=" submenu-link-text icon">{subRoute.icon}</div> {/* Added icons for submenus */}
                          <div> {subRoute.name}</div>
                          {subRoute.subRoutes && (
                            <span className="submenu-arrow">
                              {openNestedSubMenu === subIndex ? <FaChevronUp /> : <FaChevronDown />}
                            </span>
                          )}
                        </NavLink>

                        {/* Render Nested Submenu */}
                        {openNestedSubMenu === subIndex && subRoute.subRoutes && (
                          <motion.div
                           
                          >
                            
                            {subRoute.subRoutes.map((nestedRoute) => (
                              <NavLink
                                activeclassname="active"
                                to={nestedRoute.path}
                                key={nestedRoute.name}
                                className="submenu-link "
                              >
                                 <div className=" submenu-link-text icon">{nestedRoute.icon}</div> {/* Nested submenu icon */}
                                {nestedRoute.name}
                              </NavLink>
                            ))}
                          </motion.div>
                        )}
                      </div>
                    ))}
                  </motion.div>
                )}
              </div>
            ))}
          </section>
        </motion.div>
      )}
      <main>{children}</main>
    </div>
  );
};

export default Menu;

import axios from 'axios';
import React from 'react'
import { useState } from 'react';
import { BaseUrl } from '../../constants/BaseURL';
import { useEffect } from 'react';
import $ from 'jquery';
import DataTable from "datatables.net-dt";

const ApprovalList = (prop) => {

 const[details,setdetails]=useState([])
  const [modal, setModal] = useState(false);
 const[approverList,setapproverList]=useState([]);
  const toggle = () => setModal(!modal);
 
  useEffect(() => {
    GetApproverList();
  }, [])
  const  GetApproverList = async() => {

    let token = sessionStorage.getItem('token');
    let headers = {
      'jwt-token': token      
    };
    
    
    await axios.get(`${BaseUrl}api/IndentWF/GetApproverList?ID=${prop.indentNo}`, {headers}, {
      withCredentials: true
     
    }).then((response) => {
        setapproverList(JSON.parse(response.data)); // Access the data directly
        
         
         })
         .catch((error) => {
           console.log(error);
         });
  };

  return (
<>
                          <b color="link" onClick={toggle} className="btn btn-primary btn-sm text-light">Approval Hierarchy</b>
                          
                          {modal && 
                  (
                  <ModalDesc
                  handleClose={toggle}
                    UMCDesc="List"
                    approverList={approverList}
                  />
                )}
  </>
                       
  )
}
const ModalDesc = ({ handleClose, UMCDesc,approverList }) => {
    return (
      <div className="modal display-block">
        <section className="modal-main" style={{width:"600px",height:"400px"}}>
          <div className="App">
            <div class="card">
              <div className="card-footer">
              <a onClick={handleClose} style={{float:"right"}} className="fas fa-times-circle fa-2x text-danger  mt-2">
            
          </a>
  <h6 className='mt-2 text-right' style={{textAlign:"left"}}><span className='fas fa-users text-primary'></span> &nbsp;&nbsp;Approver List</h6>
              </div>
              <div className="card-body" style={{height:"380px"}}>
              <div className="col-12">
                                    <div>
                                      <div className="row" style={{ overflowX: "auto",height:"350px" }}>
                                        <div>
                                          <table style={{width:"100% !important"}} id="tblInd" className="table table-bordered tb tblcomman">
                                            <thead className="table-primary">
                                              <tr>
                                                <th>Approvel Level</th>
                                                <th>Approver Name</th>
                                                {/* <th>Status</th>
                                                <th>Comments</th>
                                                <th>Action Date</th>
                                                <th>Attachement</th> */}
                                              </tr>
                                            </thead>
                                            <tbody>
                                              {approverList.map((row, index) => (
                                                <tr key={index}>
                                                  <td>{row.APP_LVL}</td>
                                                  <td>{row.APP_NAME}</td>
                                                 {/* <td>{row.STATUS}</td>
                                                  <td>{row.REMARKS}</td>
                                                  <td>{row.ACTION_DT}</td>
                                                   <td>--</td> */}
                                                </tr>
                                              ))}
                                            </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
              </div>
            
            </div>
          
          </div>
  
         
        </section>
      </div>
    );
  };

export default ApprovalList

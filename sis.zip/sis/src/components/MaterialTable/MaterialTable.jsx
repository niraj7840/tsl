import React from 'react'
import './MaterialTable.css'

const MaterialTable = ({selectedMaterialArray}) => {
   console.log(selectedMaterialArray)
  return (
    <div className="selected_umc">
            <h2 className="table-heading">
              Selected Material List
            </h2>
            {selectedMaterialArray.length === 0 && (
              <div className="no-material">No Materials to show</div>
            )}
            {selectedMaterialArray.length !== 0 && (
              <table className="material-table">
                <thead>
                  <tr>
                    <th>UMC No</th>
                    <th>Material Code</th>
                    <th>Unit Of Measure</th>
                    <th>Material Name</th>
                    <th>Material Description</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedMaterialArray.map((item, index) => {
                    return (
                      <tr key={index}>
                        <td>{item.umc_no}</td>
                        <td>{item.materialCode}</td>
                        <td>{item.uom}</td>
                        <td>{item.material_name}</td>
                        <td>{item.material_description}</td>
                        
                        {/* <td className="py-2 text-center">
                            <div
                              className="lordiconscopy size-7 cursor-pointer"
                              onClick={() => {
                                deletePassword(item.id);
                              }}
                            >
                            </div>
                        </td> */}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
  )
}

export default MaterialTable
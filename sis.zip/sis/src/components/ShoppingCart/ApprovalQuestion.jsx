import React, { useState, useEffect } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import { BaseUrl } from "../../constants/BaseURL";
import "bootstrap/dist/css/bootstrap.css";
import { Form, FormGroup } from "react-bootstrap";
import { Button, Modal } from "react-bootstrap";
import { useSelector } from "react-redux";

const ApprovalQuestion = ({ SCNo }) => {
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  user.User_Id = "163402"; //--make sure to remove this line before updating on the server
  console.log("SCNo-", SCNo);

  const [modalViewMsg, setModalViewMsg] = useState(true); // true to open modal initially
  const [shoppingcartno, setShoppingCartNo] = useState(SCNo);
  const [communications, setCommunications] = useState([]);
  const [communications2, setCommunications2] = useState([]);
  const [message_c, setMessage_c] = useState("");
  const [notificationType_c, setNotificationType_c] = useState("Question");
  const [selectedRecipient_c, setSelectedRecipient_c] = useState("");
  const [returnCart_c, setReturnCart_c] = useState(true);
  const [confidential_c, setConfidential_c] = useState(false);
  const [error, setError] = useState("");

  // Load data when component mounts or SCNo changes
  useEffect(() => {
    toggleViewMsg();
  }, [SCNo]);

  const toggleViewMsg = async () => {
    try {
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };

      const scResponse = await axios.post(
        `${BaseUrl}api/ShoppingCart/SC_GetReplayCommunications?sno=${SCNo}&userId=${user.User_Id}`,
        { headers }
      );
      const scData = scResponse.data;
      setCommunications(scData.jsonData);
      setCommunications2(scData.jsonData);
      setSelectedRecipient_c(scData.jsonData[0].SCC_FROM_ID);
      setConfidential_c(scData.jsonData[0].SCC_IS_CONFIDENTIAL);
    } catch (error) {
      console.error("Error fetching communication details", error);
    }
  };

  const handleSendMessage2 = async () => {
    try {
      if (message_c.length === 0) {
        throw new Error("Please enter a message");
      }
      if (message_c.length >= 497) {
        throw new Error("Please enter a message with less than 500 characters");
      }

      const communication = {
        SCC_CART_NO: shoppingcartno,
        SCC_SEQ_NO: 0,
        SCC_TYPE: returnCart_c
          ? `${notificationType_c} (With Return Shopping Cart)`
          : notificationType_c,
        SCC_TEXT: message_c,
        SCC_FROM_ID: user.User_Id,
        SCC_TO_ID: selectedRecipient_c,
        SCC_ACTIVE_FLAG: "A",
        SCC_STATUS: "01",
        SCC_CRT_BY: user.User_Id,
        SCC_IS_CONFIDENTIAL: confidential_c ? "Y" : "N",
      };

      await insertCommunication(communication);
      await intimateMailCommunication(
        selectedRecipient_c,
        "SISAdmin@tatasteel.com",
        message_c,
        shoppingcartno,
        notificationType_c
      );

      Swal.fire("", "Message has been sent successfully", "info");
      setModalViewMsg(false); // Close modal after sending
    } catch (error) {
      setError(error.message);
    }
  };

  const insertCommunication = async (communication) => {
    let token = sessionStorage.getItem("token");
    let headers = {
      "jwt-token": token,
    };
    const response = await axios.post(
      `${BaseUrl}api/ShoppingCart/insertCommunication`,
      communication,
      { headers }
    );
    return response.data;
  };

  const intimateMailCommunication = async (
    commTo,
    commFrom,
    textMessage,
    scNo,
    commType
  ) => {
    try {
      let token = sessionStorage.getItem("token");
      const headers = {
        "jwt-token": token,
      };

      const toDtResponse = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetUserEmailId_SC?UserId=${commTo}`,
        { headers }
      );
      const toDtData = toDtResponse.data.jsonData[0];
      const mToUserName = toDtData.UM_USR_NAME;
      const mToUser = toDtData.UM_EMAIL_ID;
      const mFromUser = "SISAdmin@tatasteel.com";
      const mSubject = `Communication for Shopping Cart No: ${scNo}`;
      const mBody = `Dear ${mToUserName}, Please respond to the following ${commType} for the Shopping Cart No: ${scNo}. Message: ${textMessage}`;

      const emailData = {
        from: mFromUser,
        to: mToUser,
        subject: mSubject,
        body: mBody,
      };

      fetch(
        `${BaseUrl}api/Email/sendEmail?from=${emailData.from}&to=${emailData.to}&subject=${emailData.subject}&body=${emailData.body}`
      )
        .then((response) => {
          if (!response.ok)
            throw new Error(`HTTP error! Status: ${response.status}`);
          return response.json();
        })
        .then((data) => console.log("Email sent:", data.message))
        .catch((error) => console.error("Error sending email:", error));
    } catch (error) {
      console.error("Error occurred while sending email:", error);
    }
  };

  const handleClose = () => setModalViewMsg(false);

  return (
    <div>
      <Modal
        show={modalViewMsg} // Use show instead of isOpen
        onHide={handleClose} // Use onHide to handle modal close
        size="lg"
      >
        <Modal.Header style={{ backgroundColor: "#e8eefa" }} closeButton>
          <Modal.Title style={{ color: "gray" }}>Reply And View Message</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form>
            <FormGroup>
              <div className="col-12">
                <div style={{ border: "1px solid blue" }}>
                  <div className="row" style={{ overflowX: "auto" }}>
                    <div className="table-responsive-sm">
                      <table className="table table-bordered" style={{ backgroundColor: "#e8eefa" }}>
                        <tbody>
                          <tr>
                            <td align="center" colSpan={6}>
                              <table style={{ backgroundColor: "#e8eefa", width: "100%" }}>
                                <tbody>
                                  <tr>
                                    <td colSpan="2"><b>Action Type:</b></td>
                                    <td colSpan="3">
                                      <select disabled>
                                        <option value="Answer">Answer</option>
                                      </select>
                                    </td>
                                    <td colSpan="2"><b>Question From</b></td>
                                    <td>
                                      <select disabled value={selectedRecipient_c}>
                                        {communications2
                                          .filter((comm) => comm.SCC_IS_ANSWER === "N")
                                          .map((comm, index) => (
                                            <option key={index} value={comm.SCC_FROM_ID}>
                                              {comm.SCC_FROM_ID}
                                            </option>
                                          ))}
                                      </select>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td>Question</td>
                                    <td colSpan="9">
                                      <textarea
                                        disabled
                                        value={
                                          communications2.find(
                                            (comm) => comm.SCC_IS_ANSWER === "N"
                                          )?.SCC_TEXT || ""
                                        }
                                        style={{ width: "97%", height: "60px" }}
                                      />
                                    </td>
                                  </tr>
                                  <tr>
                                    <td>Response</td>
                                    <td colSpan="9">
                                      <textarea
                                        onChange={(e) => setMessage_c(e.target.value)}
                                        style={{ width: "97%", height: "60px" }}
                                        placeholder="Enter your message"
                                      />
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </FormGroup>
          </Form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="primary" size="sm" onClick={handleSendMessage2}>
            Send
          </Button>
          <Button variant="danger" size="sm" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ApprovalQuestion;

import React from 'react'

const BudgetConsumptionWarningModal = ({ BudgetdetailsList, handleSubmitForBudgetModal, handleCloseForBudgetModal, totalPrice }) => {

  console.log("BudgetDetails9876", BudgetdetailsList)
  const budgetDetailsArray = [BudgetdetailsList];
  const budgetPercentage = budgetDetailsArray[0].BudgetPercentage;
   
  const fisYr = budgetDetailsArray[0].FisYr;

  let rowColor = '';
  let message = '';
  let messageColor = '';

  if (budgetPercentage <= 50) {
    rowColor = '#0dcf0ded';
    message = `You have committed <b>${budgetPercentage}% </b>of your budget for FY ${fisYr}. Please be conscious and create Shopping Cart based on business priority.`;
    messageColor = 'blue';
  } else if (budgetPercentage > 50 && budgetPercentage <= 80) {
    rowColor = 'yellow';
    message = `You have committed <b>${budgetPercentage}% </b> of your budget for FY ${fisYr}. Please be conscious and create Shopping Cart based on business priority.`;
    messageColor = 'blue';
  } else if (budgetPercentage > 80 && budgetPercentage < 100) {
    rowColor = '#ff0a0ade';
    message = `You have committed <b>${budgetPercentage}%</b> of your budget for FY ${fisYr}. Please review the pipeline (pending PRs/ROs/POs) and release budget for procurement by deleting/reducing qty or deferring the same.`;
    messageColor = 'red';
  } else if (budgetPercentage >= 100) {
    rowColor = '#ff0a0ade';
    message = `You have committed <b>${budgetPercentage}%</b> of your budget for FY ${fisYr}. Please review the pipeline (pending PRs/ROs/POs) and release budget for procurement by deleting/reducing qty or deferring the same. The Shopping Cart will escalate to your VP for final approval.`;
    messageColor = 'red';
  }

  return (
    <div>
      <div
        className="modal display-block"
        id="MyModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div
          class="modal-dialog modal-xl"
          style={{
            width: "1000px",
            height: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div class="modal-content" id="" style={{ paddingBottomm: "510px" }}>
            <div class="modal-header">

              <h5 class="modal-title" id="exampleModalLabel">
                &nbsp;&nbsp;<i style={{ color: "#ff8100" }} className="fa-solid fa-triangle-exclamation"></i>&nbsp;WARNING!
              </h5>
              <button
                onClick={handleCloseForBudgetModal}
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <div className="row">
                <div className="col-md-6">

                  <label style={{ fontSize: "16px" }}>
                    Budget Information
                    <span style={{ fontSize: "16px", color: "red" }}>*</span>
                  </label>
                </div>
              </div>

              <br />

              <div className="table-responsive table-responsive-sm" style={{ overflowX: "auto", maxHeight: "600px" }}>
                <table className="tables table-bordered tb">
                  <thead className="table-primary">
                    <tr>
                      <th>Fin. Year</th>
                      <th>Spare Budget</th>
                      <th> Committed Expenditure </th>
                      <th>SC Value</th>
                      <th>Diff. Amt.</th>
                    </tr>
                  </thead>
                  <tbody style={{ padding: "0px", whiteSpace: "nowrap" }}>
                    {budgetDetailsArray.map((row, index) => (

                      <tr key={index} style={{ backgroundColor: rowColor, fontWeight: 'bold', fontSize: '16px' }}>
                        <td style={{ fontSize: "17px" }}><b>{row.FisYr}</b></td>
                        <td style={{ fontSize: "17px" }}><b>{Number(row.spareValue).toFixed(0)}</b></td>
                        <td style={{ fontSize: "17px" }}><b>{Number(row.CommittedExpenditure).toFixed(0)}</b></td>
                        <td style={{ fontSize: "17px" }}><b>{Number(totalPrice).toFixed(0)}</b></td>
                        <td style={{ fontSize: "17px" }}><b>{Number(row.spareValue - (row.CommittedExpenditure + totalPrice)).toFixed(0)}</b></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div style={{ color: messageColor, marginTop: "20px" }}>
                {/* <p>{message}</p> */}
                <p dangerouslySetInnerHTML={{__html: message}}></p>
                <p style={{ marginBottom: "2px" }}><b>Do you still want to proceed?</b></p>
              </div>
              <div
                className="row"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <div className="col mt-3" style={{ display: "flex", justifyContent: "center" }}>
                  <button
                    id="submitScName"
                    type="submit"
                    className="btn btn-primary"
                    onClick={handleSubmitForBudgetModal}
                    style={{ width: "70px" }}
                  >
                    Yes
                  </button>
                </div>

                <div className="col mt-3" style={{ display: "flex", justifyContent: "center" }}>
                  <button
                    id="submitScName"
                    type="submit"
                    className="btn btn-primary"
                    onClick={handleCloseForBudgetModal}
                    style={{ width: "70px" }}
                  >
                    No
                  </button>
                </div>

              </div>
            </div>

            <div class="modal-footer ml-0"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BudgetConsumptionWarningModal

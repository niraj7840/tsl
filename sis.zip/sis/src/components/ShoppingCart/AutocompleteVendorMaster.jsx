import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import { BaseUrl } from "../../constants/BaseURL";
import "bootstrap/dist/css/bootstrap.css";

const AutocompleteVendorMaster = ({ onSelect,initialValue = "" }) => {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    setQuery(initialValue);
  }, [initialValue]);
  
  // API endpoint URL (replace with your actual API endpoint)
  //const apiEndpoint = `${BaseUrl}api/ShoppingCart/GetVendorMasterDetails`;
  // Function to handle input change
  const handleChange = async (event) => {

    const value = event.target.value;
    setQuery(value);
if(value.length>2){
    setLoading(true);
    setError("");
    setIsDropdownOpen(true);

    try {
      
      let token = sessionStorage.getItem("token");
      let headers = {
        "jwt-token": token,
      };
      const response = await axios.get(
        `${BaseUrl}api/ShoppingCart/GetVendorMasterDetails?VendorCode=${value}`,
        { headers }
      );
      const descriptions = response.data.jsonData.map(
        (item) => item.Description
      );
      console.log(descriptions, " flatSuggestions");
      setSuggestions(descriptions);
    } catch (err) {
      setError("Failed to fetch suggestions");
      setSuggestions([]);
      setIsDropdownOpen(false);
    } finally {
      setLoading(false);
    }
}
  };

  // Function to handle suggestion click
  const handleSuggestionClick = (suggestion) => {
    setQuery(suggestion);
    setSuggestions([]);
    setIsDropdownOpen(false);
    if (onSelect) onSelect(suggestion);
  };

  // Function to handle clicks outside
  const handleClickOutside = (event) => {
    if (inputRef.current && !inputRef.current.contains(event.target)) {
      setSuggestions([]);
      setIsDropdownOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div ref={inputRef} style={{ position: "relative" }}>
      <input
        type="text"
        value={query}
        onChange={handleChange}
        className="form-control form-control sm"
        //placeholder="Type at least 10 digits..."
        //style={{ width: '100%', padding: '8px' }}
      />
      {loading && <div>Loading...</div>}
      {error && <div style={{ color: "red" }}>{error}</div>}
      {isDropdownOpen && suggestions.length > 0 && (
        <ul
          style={{
            position: "absolute",
            top: "100%",
            left: 0,
            width: "100%",
            margin: 0,
            padding: 0,
            border: "1px solid #ddd",
            borderRadius: "4px",
            backgroundColor: "white",
            boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
            listStyleType: "none",
            zIndex: 1,
          }}
        >
          {suggestions.map((suggestion, index) => (
            <li
              key={index}
              onClick={() => handleSuggestionClick(suggestion)}
              style={{
                padding: "8px",
                cursor: "pointer",
                borderBottom: "1px solid #ddd",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.backgroundColor = "#f0f0f0")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.backgroundColor = "white")
              }
            >
              {suggestion}
            </li>
          ))}
          {suggestions.length === 0 && (
            <li style={{ padding: "8px" }}>No results found</li>
          )}
        </ul>
      )}
    </div>
  );
};

export default AutocompleteVendorMaster;

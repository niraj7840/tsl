import React from "react";
import "./Navbar.css";
import { FaCircleUser } from "react-icons/fa6";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { logout } from "../../store/authSlice";
import { useState } from "react";
import axios from "axios";
import { BaseUrl } from "../../constants/BaseURL";
import Swal from "sweetalert2";

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isAuthenticated = useSelector((state) => state.auth.status);
  const user = useSelector((state) => JSON.parse(state.auth.userData));
  const [UserName,setUserName]=useState(user);
  //const userData = JSON.parse(user);
const [deptList,setDeptList]=useState([]);
  const [show, setShow] = React.useState(false);
const [getDeptList,setDeptLst]=useState( sessionStorage.getItem("DeptList")==null?{
  dept:"",
  plant:"",
  deptName:"",
  location : "",
}: {
  dept:sessionStorage.getItem("Dept"),
  plant:sessionStorage.getItem("Plant"),
  deptName:sessionStorage.getItem("DeptName"),
  location : sessionStorage.getItem("Location"),
});

  const toggleSubMenu = () => {
    setShow(!show);
  };
  React.useEffect(() => {
    
    fetchDepartmentList();
  },[]);
  React.useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        show &&
        !event.target.closest(".sub-menu-wrap") &&
        !event.target.classList.contains("userName")
      ) {
        setShow(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [show]);

  // const GoToLogin = (e) => {
  //   e.preventDefault();
  //   navigate("/SIS/Login");
  // };

  const handleLogout = () => {
    dispatch(logout());
    sessionStorage.clear(); // Clear session storage
   // navigate("/SIS/Login");
  };
  const handleChangeDept=(e)=>{
    debugger;
    const { name, value } = e.target;
  
    
   
     const plant= deptList.filter(x=>x.dept==value);
     if(plant[0].LOC_CD !== ''){
      setDeptLst({
        dept:plant[0].dept,
        plant:plant[0].plant,
        deptName:plant[0].deptName,
        location:plant[0].LOC_CD,
      });
       sessionStorage.setItem("Dept",plant[0].dept);
      sessionStorage.setItem("DeptList",plant[0]);
      sessionStorage.setItem("DeptName",plant[0].deptName);
      sessionStorage.setItem("Plant",plant[0].plant);
      sessionStorage.setItem("PNAME",plant[0].PNAME);
      sessionStorage.setItem("Location",plant[0].LOC_CD);
      
      navigate("/SIS/");
     }else{
      Swal.fire(
        {title:"",
        text: "Plant code ("+plant[0].plant+") mapped with selected department ("+plant[0].dept+") is not permissible for raising indent. \nPlease contact your system administrator.",
        icon: "warning",
        confirmButtonText:"Ok"}
        ).then(()=>{
        navigate("/SIS/");
        
        }).catch((error) => {
        console.log(error);
        });
     }
    
  }
  const fetchDepartmentList = async () => {
    try {

      let token = sessionStorage.getItem('token');
      let headers = {
      'jwt-token': token      
      };

      const response = await axios.get(`${BaseUrl}api/Master/GetDepartment?adid=${user.User_Id}`, {headers});
      const data = response.data;
      setDeptList(data);
      //setDeptShow(true);
      //setIsLoading(false);
      
    } catch (error) {
      console.log(error);
    }
  };

  return (
   
    <nav className="navbar" id="navbar">
      <div className="center">
        <h1 className="heading">Smart Indenting System</h1>
      </div>
      <div className="userName" onClick={toggleSubMenu}>
        <span className="userIcon">
          <FaCircleUser />
        </span>
       
        {isAuthenticated ? (
        user.User_Name
        ) : (''
          // <button
          //   onClick={GoToLogin}
          //   className=" btn btn-warning"
          //   style={{
          //     height: "35px",
          //     backgroundColor: "#171237",
          //     color: "white",
          //   }}
          // >
          //   Login
          // </button>
        )}
      </div>
      <div className={`sub-menu-wrap ${show ? "open-menu" : ""}`} style={{zIndex:"999"}}>
        <div className="sub-menu text-right">
          {isAuthenticated &&  (
            <>
           
            <label>Department</label>
            <select
            id="destinationDepartment"
            name="destinationDepartment"
            className="form-control"
            type="text"
            value={getDeptList["dept"]}
           style={{backgroundColor:"transparent",cursor:"pointer",fontSize:"15px",width:"105%",color:"#36c230"}}
            onChange={(e) => handleChangeDept(e)}
          >
           <option value="">NA</option>
            {deptList.map((department, id) => (
              <option key={id} value={department.dept}>
                 {department.deptName}({department.dept})
              </option>
            ))}
            </select>
           
            {/* <a
              onClick={handleLogout}
              className="btn btn-light mt-2"
              style={{marginLeft:"102px"}}
            >
             Logout 
            </a> */}
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

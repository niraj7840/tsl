
import { createSlice } from "@reduxjs/toolkit";
 
// Initial state for the IndentId slice

const initialState = {

    indentId: ""

};
 
// Create a slice for the IndentId

const indentSlice = createSlice({

    name: "indent",

    initialState,

    reducers: {

        setIndentId: (state, action) => {

            state.indentId = action.payload;

        },

        clearIndentId: (state) => {

            state.indentId = "";

        }

    }

});
 
// Export the action creators

export const { setIndentId, clearIndentId } = indentSlice.actions;
 
// Export the reducer

export default indentSlice.reducer;

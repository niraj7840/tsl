import {configureStore} from '@reduxjs/toolkit'
import menuSlice from './menuSlice'; 
import authSlice from './authSlice';
import indentSlice from './indentSlice';

const store =  configureStore({
    reducer : {
        menu : menuSlice,
        auth : authSlice,
        indent:indentSlice
    }
});

export default store;
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    status : false
}

const menuSlice = createSlice({
    name : "menu",
    initialState,
    reducers : {
       isOpen : (state,action) => {
        state.status = !state.status
       }
    }
})

export const {isOpen} = menuSlice.actions;

export default menuSlice.reducer;
import React from 'react'
import { Link } from 'react-router-dom';

const SidebarMenuItem = (props) => {
   
    return (
        <Link to={props.link} className="nav_link"> 
            {/* <i className="bx bx-grid-alt nav_icon" />  */}
            {props.children}
            <span className="nav_name">{props.title}</span> 
        </Link> 
    )
}

export default SidebarMenuItem

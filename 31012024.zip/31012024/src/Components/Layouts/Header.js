// Author : Lakhan Mardi
import React from 'react';
import { Link } from 'react-router-dom';
import HeaderMenuItem from './Helper/HeaderMenuItem';
import { Dropdown } from 'react-bootstrap';

const Header = (props) => {
    // const {userType} = props.userType;
    // console.log(props);
    return (
        <header className="header" id="header" >
            <div className="header_toggle">
                <i className="bx bx-menu" id="header-toggle" />
            </div>


            <Dropdown >
                <Dropdown.Toggle id="dropdown-basic">
                    <b>Welcome {props.userName}</b>


                </Dropdown.Toggle>

                <Dropdown.Menu>


                    {/* <HeaderMenuItem
                        title={'My Pending'}
                        link={'/mypending'}
                    />
                    <div className="dropdown-divider" />
                    <HeaderMenuItem
                        title={'My Request'}
                        link={'/myrequest'}
                    />

                    <div className="dropdown-divider" /> */}
                    <HeaderMenuItem
                        title={'Logout'}
                        link={'/logout'}
                    />

                </Dropdown.Menu>
            </Dropdown>



        </header>

    )
}

export default Header

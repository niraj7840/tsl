import React from 'react'
import {
    Nav,
    Navbar,
    NavDropdown,
    Container
} from 'react-bootstrap'

import image from '../../assets/tsl_logo.png'
import {Link} from 'react-router-dom';


const TopNavbar = () => {
    return (
        <div>
            <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Container>
  <Navbar.Brand href="#home">
      <div className="logotext">
              <p>
              <img src={image} className="brand-image img-circle elevation-3"/>
                        <span className="nav_logo-name"><b>TATA </b> STEEL</span>
                  
              </p>
            </div>
  </Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="me-auto">
      {/* <Nav.Link href="#features">Features</Nav.Link> */}
      {/* <Nav.Link href="#pricing">Pricing</Nav.Link> */}
      
    </Nav>
    <Nav>
      {/* <Nav.Link href="#deets">More deets</Nav.Link>
      <Nav.Link eventKey={2} href="#memes">
        Dank memes
      </Nav.Link> */}
      <NavDropdown title="Dropdown" id="collasible-nav-dropdown">
        <NavDropdown.Item>
            <Link to="/mypending" > 
                My Pending
            </Link>
        </NavDropdown.Item>
        <NavDropdown.Item >      
            <Link to="/myrequest" > 
                My Request
            </Link>
        </NavDropdown.Item>
        {/* <NavDropdown.Divider />
        <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item> */}
      </NavDropdown>
    </Nav>
  </Navbar.Collapse>
  </Container>
</Navbar>
        </div>
    )
}

export default TopNavbar

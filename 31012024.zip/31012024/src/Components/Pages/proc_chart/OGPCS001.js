//Author : Niraj Kumar

import React, { useState, useEffect } from 'react'
import './../table.css'; // Make sure to update the path based on your file structure
// import { Autocomplete, TextField, Button } from '@mui/material';
//import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import { blueGrey } from '@mui/material/colors';
import { Checkbox } from '@mui/material';
import { json, Link } from 'react-router-dom';
import { isVisible } from '@testing-library/user-event/dist/utils';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

const OGPCS001 = () => {

  const [isVisible, setIsVisible] = useState(false);
  const option = [{id : '1', value : 'C' , label : ' Copy to Create '},
                  {id : '1', value : 'N' ,  label : ' Create New  '}];

  const [selectOption , setSelectOption]=useState();
  const handleOptionChange = (event)=>{
    setSelectOption(event.target.value);  
   
    let val =event.target.value;
    if(val==='C')
    {    
    setIsVisible(true);    
    } 
    else
    {
      setIsVisible(false);
    }
    }    
   
  const [Pdata, setdata] = useState([]);
  const [PglData, setPglData] = useState([]);
  const [isTableVisible, setIsTableVisible] = useState(false)
  const [isPglTableVisible, setIsPglTableVisible] = useState(false)


  const [PCNo, setPCNo] = useState('');
  const [QualityCode, setQualityCode] = useState('');
  const [TDCNo, setTDCNo] = useState('');
  const [ProductGroup, setProductGroup] = useState('');
  const [GradeDesc, setGradeDesc] = useState('');


  const [PCNoCopy, setPCNoCopy] = useState('');
  const [QualityCodeCopy, setQualityCodeCopy] = useState('');
  const [TDCNoCopy, setTDCNoCopy] = useState('');
  const [ProductGroupCopy, setProductGroupCopy] = useState('');
  const [GradeDescCopy, setGradeDescCopy] = useState('');

  // const[formData , setFormData]= useState(
  //   {
  //     ProcessChartNo : '',
  //     "VersionNo": '',
  //     "QualityCode": '',
  //     "TdcNo": '',
  //     "ProductGroup": '',
  //     "ProductGroupDesc": '',
  //     "ProductSubGroup": '',
  //     "productCategory": '',
  //     "productApplication": '',
  //     "gradeDesc": '',
  //     "Status": '',
  //     "ReasonForChange": '',
  //     "ProductVersion": '',
  //     "UserId": '',
  //     "Flag": ''
  //   })

  //---------Function to handle input change
  // const handleSubmit = async event =>{
  //   event.PreventDefault();

  //   try{
  //     const response = await fetch('http://localhost:59063/api/ProcessChartMaintenance/SaveOrUpdateProcessChartDetails', {
  //       method: 'POST',
  //       headers : {'Content-Type' : 'application/json',
  //     },
  //     body  : JSON.stringify(FormData)

  //     });
  //     if(!response.ok)
  //     {
  //       throw new console.error('Fail to Post Data');

  //     }


  //   }catch(error)
  //   {

  //   }

  // }



  const UID = sessionStorage.getItem("UID");

  const handlerbtnSearch = async () => {
    try {
      setIsTableVisible(!isTableVisible);
      setPglData([]);
      setIsPglTableVisible(false);
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetProcessChartDetails', {

        UserId: UID,
        ProcessChartNo: PCNo,
        TdcNo: TDCNo,
        QualityCode: QualityCode,
        ProductGroup: ProductGroup,
        gradeDesc: GradeDesc,
        Flag: 'GET',

      });


      setdata(response.data); // Assuming the API returns data in a property called 'data'
    } catch (error) {
      console.error('Error fetching data:', error);
    }

  }


  const handlerBulkApprove = async () => {
    try {
      setIsTableVisible(!isTableVisible);
      setPglData([]);
      setIsPglTableVisible(false);
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetProcessChartDetails', {

        UserId: UID,
        ProcessChartNo: PCNoCopy,
        TdcNo: TDCNoCopy,
        QualityCode: QualityCodeCopy,
        ProductGroup: ProductGroupCopy,
        gradeDesc: GradeDescCopy,
        Flag: 'GET',

      });


      setdata(response.data); // Assuming the API returns data in a property called 'data'
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }


  const handlerPGList = async () => {
    try {
      setIsPglTableVisible(!isPglTableVisible);
      setdata([]);
      setIsTableVisible(false);
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetList', {});

      setPglData(response.data.ProductGroupList); // Assuming the API returns data in a property called 'data'
    } catch (error) {
      console.error('Error fetching data:', error);
    }

  }

 

  return (
    <div className="main-data">
      <div className="data-upload">
        <h3>Create/Display/Modify Process Chart</h3>
      </div>
      <table>

        <tbody>
          <tr>
            
            <td colSpan={8} style={{ textAlign: 'center' }}>
             {option.map((option) =>(
             <label key={option.id}>
             <input type="radio" 
             value={option.value}
             checked={selectOption===option.value} 
             onChange={handleOptionChange} 
             />
            {option.label}
            </label>
           ))}
            </td>
            </tr>
          <tr>
            <td>Process Chart No.</td>
            <td>
              <input type="text" id="txtPCNo" name="txtPCNo" value={PCNo} onChange={(e) => setPCNo(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>Version </td>
            <td>
              <input type="text" id="txtVersion" name="txtVersion" style={{ width: '80px' }} />
            </td>
            <td>Quality Code </td>
            <td>
              <input type="text" id="txtQualityCode" name="txtQualityCode" value={QualityCode} onChange={(e) => setQualityCode(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>TDC No </td>
            <td>
              <input type="text" id="txtTDCNo" name="txtTDCNo" value={TDCNo} onChange={(e) => setTDCNo(e.target.value)} style={{ width: '80px' }} />
            </td>
          </tr>

          <tr>
            <td>Product Group</td>
            <td>
              <input type="text" id="txtProductGroup" name="txtProductGroup" value={ProductGroup} onChange={(e) => setProductGroup(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>Product Group Description </td>
            <td>
              <input type="text" id="txtProductGroupDesc" name="txtProductGroupDesc" style={{ width: '80px' }} />
            </td>
            <td>Product Category </td>
            <td>
              <select className="selection-value"></select>
            </td>
            <td>Product Application </td>
            <td>
              <textarea
                type="text"
                rows={2}
                id="txtProductApplication"
                name="txtProductApplication"
                style={{ width: '80px' }}
              />
            </td>
          </tr>

          <tr>
            <td>Grade Description</td>
            <td colSpan={2}>
              <textarea type="text" id="txtGradeDesc" name="txtGradeDesc" value={GradeDesc} onChange={(e) => setGradeDesc(e.target.value)} style={{ width: '380px', height: '35px' }} />
            </td>
            <td colSpan={2} className="td-center">
              <Link onClick={() => handlerPGList()} > Product Group List</Link>
            </td>
            <td className="td-center">
              <button className="btn btn-warning" onClick={() => handlerbtnSearch()}>
                <img src="/logo/search-12-16.ico" alt="my image" />
              </button>
            </td>
            <td colSpan={2} className="td-right">
              <button id="Save" className="btn btn-primary">
                Save
              </button>
            </td>
          </tr>
          <tr>
            <td colSpan={8} className="td-center">
              <button id="Create" className="btn btn-success">
                Create
              </button>
              &nbsp;
              <button id="Modify" className="btn btn-secondary">
                Modify
              </button>
              &nbsp;
              <button id="Disply" className="btn btn-warning">
                Disply
              </button>
              &nbsp;
              <button id="Exit" className="btn btn-dark">
                Exit
              </button>
              &nbsp;
              <button id="Deactive" className="btn btn-danger">
                Deactive
              </button>
              &nbsp;
              <button id="Reactive" className="btn btn-info">
                Reactive
              </button>
              &nbsp;
            </td>
          </tr>
        </tbody>

      </table>
      {isVisible && (
        <div className='Panel'>
          <div className="data-upload">
            <h3>Copy From</h3>
          </div>
          <table className="copy-tble">
            <tbody>
              <tr>
                <td>
                  Process Chart No. : <input type="text" id="txtPCNoCopy" name="txtPCNoCopy" value={PCNoCopy} onChange={(e) => setPCNoCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  Quality Code : <input type="text" id="txtQualityCodeCopy" name="txtQualityCodeCopy" value={QualityCodeCopy} onChange={(e) => setQualityCodeCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  TDC No. : <input type="text" id="txtTDCNoCopy" name="txtTDCNoCopy" value={TDCNoCopy} onChange={(e) => setTDCNoCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  Product Group: <input type="text" id="txtProductGroupCopy" name="txtProductGroupCopy" value={ProductGroupCopy} onChange={(e) => setProductGroupCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  Grade Desc: <input type="text" id="txtGradeDescCopy" name="txtGradeDescCopy" value={GradeDescCopy} onChange={(e) => setGradeDescCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td colSpan={3}>
                  <button className="btn btn-warning" onClick={() => handlerBulkApprove()}>
                    <img src="/logo/search-12-16.ico" alt="my image" />
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
{/* ----------Start Nav Tab---------- */}
<div class="col-12">
    <Tabs
      defaultActiveKey="profile"
      id="uncontrolled-tab-example"
     className='my-tab '
    >
     
      <Tab eventKey="ChemicalComposition" title="Chemical Composition" className='tab-txt-clr'>
        Tab content for Chemical Composition
      </Tab>
    
      <Tab eventKey="ProductDimension" title="Product Dimension" className='tab-txt-clr'>
        Tab content for Product Dimension
      </Tab>
      <Tab eventKey="PrimarySteelMaking" title="Primary Steel Making" className='tab-txt-clr'>
        Tab content for Primary Steel Making
      </Tab>


      <Tab eventKey="SecondaryMetallurgy" title="Secondary Metallurgy" className='tab-txt-clr'>
        Tab content for Secondary Metallurgy
      </Tab>
      <Tab eventKey="Casting" title="Casting" className='tab-txt-clr'>
        Tab content for Casting
      </Tab>
      <Tab eventKey="Rolling" title="Rolling" className='tab-txt-clr'>
        Tab content for Rolling
      </Tab>
      <Tab eventKey="ProductProperties" title="Product Properties" className='tab-txt-clr'>
        Tab content for Product Properties
      </Tab>
      <Tab eventKey="ProductSamplingandTesting" title="Product Sampling and Testing" className='tab-txt-clr'>
        Tab content for Product Sampling and Testing
      </Tab>

    </Tabs>
    </div>

  {/*----End Nav Tab-----*/}

      <div class="container text-center">
        <div class="row justify-content-start">
          <div class="col-12">
            {isTableVisible && (
              <table className="table_request">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>Process Chart No</th>
                    <th>Version</th>
                    <th>Quality Code</th>
                    <th>TDC No</th>
                    <th>Product Group</th>
                    <th>product Category</th>
                    <th>Product Group Description</th>
                    <th>Grade Appl</th>
                    <th>Grade Description</th>
                    <th>Status</th>

                  </tr>
                </thead>
                <tbody>
                  {Array.isArray(Pdata) && Pdata.map((row, index) =>
                    <tr key={row.ProcessChartNo + Math.random()}>
                      <td><Checkbox name={row.ProcessChartNo} /></td>
                      <td>{row.ProcessChartNo}</td>
                      <td>{row.VersionNo}</td>
                      <td>{row.QualityCode}</td>
                      <td>{row.TdcNo}</td>
                      <td>{row.ProductGroup}</td>
                      <td>{row.ProductGroupDesc}</td>
                      <td>{row.productCategory}</td>
                      <td>{row.productApplication}</td>
                      <td>{row.gradeDesc}</td>
                      <td>{row.Status}</td>

                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>

        </div>
      </div>


      <div class="container text-center">
        <div class="row justify-content-start">
          <div class="col-4"></div>

          <div class="col-4">
            {isPglTableVisible && (
              <table className="table_request">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>GroupName</th>
                    <th>SubGroup</th>
                    <th>Description</th>

                  </tr>
                </thead>
                <tbody>
                  {PglData.map((row, index) =>
                    <tr key={row.GroupName + Math.random()}>
                      <td><Checkbox name={row.GroupName} /></td>
                      <td>{row.GroupName}</td>
                      <td>{row.SubGroup}</td>
                      <td>{row.Description}</td>

                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>

        </div>
      </div>



    </div>
  );
};

export default OGPCS001;

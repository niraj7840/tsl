//Author : Niraj Kumar

import React, { useState, useEffect } from 'react'
import './../table.css'; // Make sure to update the path based on your file structure
// import { Autocomplete, TextField, Button } from '@mui/material';
//import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import { blueGrey } from '@mui/material/colors';
import { Checkbox } from '@mui/material';
import { json, Link } from 'react-router-dom';
import { isVisible } from '@testing-library/user-event/dist/utils';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

const OGPCM003 = () => {

  const UID = sessionStorage.getItem("UID");

  return (
    <div className="main-data">
     <br></br>
      <div className="data-upload">
        <h3>Create/Display/Modify Process Chart</h3>
      </div>
      <table>
        <tbody>   
          <tr>
            <td>Process Chart No.</td>
            <td>
              <input type="text" id="txtPCNo" name="txtPCNo"  style={{ width: '80px' }} />
            </td>
            <td>Version </td>
            <td>
              <input type="text" id="txtVersion" name="txtVersion" style={{ width: '80px' }} />
            </td>
            <td>Quality Code </td>
            <td>
              <input type="text" id="txtQualityCode" name="txtQualityCode"  style={{ width: '80px' }} />
            </td>
            <td>TDC No </td>
            <td>
              <input type="text" id="txtTDCNo" name="txtTDCNo"  style={{ width: '80px' }} />
            </td>
          </tr>

          <tr>
            <td>Product Group</td>
            <td>
              <input type="text" id="txtProductGroup" name="txtProductGroup"  style={{ width: '80px' }} />
            </td>
            <td>Product Group Description </td>
            <td>
              <input type="text" id="txtProductGroupDesc" name="txtProductGroupDesc" style={{ width: '80px' }} />
            </td>
            <td>Product Category </td>
            <td>
              <select className="selection-value"></select>
            </td>
            <td>Product Application </td>
            <td>
              <textarea
                type="text"
                rows={2}
                id="txtProductApplication"
                name="txtProductApplication"
                style={{ width: '80px' }}
              />
            </td>
          </tr>

          <tr>
            <td>Grade Description</td>
            <td colSpan={2}>
              <textarea type="text" id="txtGradeDesc" name="txtGradeDesc" style={{ width: '380px', height: '35px' }} />
            </td>
            <td colSpan={2} className="td-center">
             
            </td>
            <td className="td-center">
             
            </td>
            <td colSpan={2} className="td-right">
              
            </td>
          </tr>
          
        </tbody>

      </table>
      
{/* ----------Start Nav Tab---------- */}
<div class="col-12">
    <Tabs
      defaultActiveKey="profile"
      id="uncontrolled-tab-example"
     className='my-tab '
    >
     
      <Tab eventKey="ChemicalComposition" title="Chemical Composition" className='tab-txt-clr'>
        Tab content for Chemical Composition
      </Tab>
    
      <Tab eventKey="ProductDimension" title="Product Dimension" className='tab-txt-clr'>
        Tab content for Product Dimension
      </Tab>
      <Tab eventKey="PrimarySteelMaking" title="Primary Steel Making" className='tab-txt-clr'>
        Tab content for Primary Steel Making
      </Tab>


      <Tab eventKey="SecondaryMetallurgy" title="Secondary Metallurgy" className='tab-txt-clr'>
        Tab content for Secondary Metallurgy
      </Tab>
      <Tab eventKey="Casting" title="Casting" className='tab-txt-clr'>
        Tab content for Casting
      </Tab>
      <Tab eventKey="Rolling" title="Rolling" className='tab-txt-clr'>
        Tab content for Rolling
      </Tab>
      <Tab eventKey="ProductProperties" title="Product Properties" className='tab-txt-clr'>
        Tab content for Product Properties
      </Tab>
      <Tab eventKey="ProductSamplingandTesting" title="Product Sampling and Testing" className='tab-txt-clr'>
        Tab content for Product Sampling and Testing
      </Tab>

    </Tabs>
    </div>

  {/*----End Nav Tab-----*/}

    </div>
  );
};

export default OGPCM003;

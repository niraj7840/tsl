//Author : Niraj Kumar

import OGPCS001 from "./OGPCS001";
import React , { useContext } from 'react';
import { UserContext } from '../../../App';


const SingleUploadHelper  = () => {
 
    const user = useContext(UserContext);

    return (
            <>            
            <br/>
            <OGPCS001 userDetail={user.user}/>
        </>
    );
}

export default SingleUploadHelper;
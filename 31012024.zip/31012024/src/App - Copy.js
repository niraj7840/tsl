
import React, { useState, Component, createContext } from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';
import logo from "./assets/tata_logo.png";
import ClipLoader from "react-spinners/ClipLoader";
import Header from './Components/Layouts/Header';
import Sidebar from './Components/Layouts/Sidebar';
import Dashboard from './Components/Pages/Dashboard';
import OGPCS001 from './Components/Pages/proc_chart/OGPCS001';
import OGPCS001Helper from './Components/Pages/proc_chart/OGPCS001Helper';
import axios from 'axios';


export const UserContext = createContext();
 
function App() {



 const [state, setState] = useState({
   UserID: "",
   Password: "",
   DBName: "",
   userAuth: "",
   userType: "",
   loading: false,
   buttonClicked: false
 });
 
 async function login() {
   setState({
     ...state,
     loading: true,
     buttonClicked: !state.buttonClicked,
   });
 
   const data = {
     UserID: state.UserID,
     Password: state.Password,
     DBName: state.DBName
   };
 
   try {
     const res = await axios.post("http://localhost:59063/api/Login/SignIn", data, {
       headers: {
         'Content-Type': 'application/json',
       }
     });
 
     setState({
       ...state,
       UserID: res.data.UserID,
       Password: res.data.Password,
       DBName: res.data.DBName,
       userAuth: res.data.Result,
       loading: false,
       userType: 1,
       buttonClicked: !state.buttonClicked
     });
 
     if (res.data.Result !== "AUTHENTICATED") {
       alert("Invalid Credentials");
       setState({
         ...state,
       });
     }
   } catch (error) {
     console.error("Error during login:", error);
     setState({
       ...state,
       loading: false,
       buttonClicked: !state.buttonClicked
     });
   }
 }
 
 function updateUserId(evt) {
   const val = evt.target.value;
   setState({
     ...state,
     UserID: val,
   });
 }
 
 function updatePassword(evt) {
   const val = evt.target.value;
   setState({
     ...state,
     Password: val,
   });
 }
 
 function updateDBName(evt) {
   const val = evt.target.value;
   setState({
     ...state,
     DBName: val,
   });
 }
 

 return (
   <>
     {state.userType !== 0 && state.userAuth === "Authenticated" ?
       <div className="App">
         <UserContext.Provider value={state}>
         <Header userName={state.UserID} />
              <Sidebar userType={state.userType} />
              {/*Container Main start*/}
              <div className="height-100 bg-light">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/OGPCS001" element={<OGPCS001Helper />}/>              
              </Routes>
              </div>
         </UserContext.Provider>
       </div>
       :
       <div className="login">
        <center><img src={logo} alt="logo" class="avatar" /><br /></center>
          <label><p><b>User Name</b></p></label>
          <input type="text" name="UserID" id="UserID" placeholder="Username" value={state.UserID} onChange={(evt) => updateUserId(evt)} />
          <br />
          <label><p><b>Password</b></p></label>
          <input type="Password" name="Password" id="Password" placeholder="Password" value={state.Password} onChange={(evt) => updatePassword(evt)} />
          <br />
          <label><p><b>Database</b></p></label>
          <input type="text" name="DBName" id="DBName" placeholder="Database" value={state.DBName} onChange={(evt) => updateDBName(evt)} />
          <div class="txt-pwd">
            <label> Change Password? </label>
          </div>
          <center>
          <center><button disabled={state.loading} onClick={() => login()} name="log" id="log"><p style={{marginRight:"10px",color:"white"}} >Login</p> {state.buttonClicked? <ClipLoader color="white" loading={state.loading}  size={25} />:null}</button></center>           
          </center>
       </div>
     }
     <div className="Cont-dtls">
     <table class='tbl'>
              <thead>
                <tr > Contact Details</tr>
                <tr><td> <b class="footer-txt-colour">LPCIS :</b> Phone No. 0657-21-47075 / 0657-21-47096 ,Email ID: lpcis@tatasteel.com , <b class="footer-txt-colour"> IBM Helpdesk : </b> Phone No. 0657-21-47070, Email ID: ibmhelpdesk@tatasteel.com</td></tr>
              </thead>
            </table>
     </div>
   </>
 );
}
 
export default App;
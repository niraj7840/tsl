﻿using Newtonsoft.Json.Linq;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Controllers.BatchProgram;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using System.Net.Mail;

namespace SIS_BACKEND_API.App_Code.DAL.BatchProgramDAL
{
    public class IntraBatchInterCheck
    {
    }
}
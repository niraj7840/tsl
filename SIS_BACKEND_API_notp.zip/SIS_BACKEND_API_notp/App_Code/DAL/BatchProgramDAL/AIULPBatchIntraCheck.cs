﻿using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL;
using SIS_BACKEND_API.Controllers.BatchProgram;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Results;
using System.Windows.Input;

namespace SIS_BACKEND_API.App_Code.DAL.BatchProgramDAL
{
    public class AIULPBatchIntraCheck
    {
    }
}
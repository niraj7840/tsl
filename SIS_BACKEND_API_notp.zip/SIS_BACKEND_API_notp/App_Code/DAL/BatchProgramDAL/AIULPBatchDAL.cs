﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Data;
using System.Data.Common;
using System.Collections.ObjectModel;
using System.Data.Odbc;

namespace SIS_BACKEND_API.App_Code.DAL.BatchProgramDAL
{
    public class AIULPBatchDAL
    {
    }
}
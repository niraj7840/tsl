﻿using Microsoft.IdentityModel.Tokens;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Mail;

namespace SIS_BACKEND_API.App_Code.DAL.BatchProgramDAL
{
    public class IntraBatchDAL
    {
    }
}
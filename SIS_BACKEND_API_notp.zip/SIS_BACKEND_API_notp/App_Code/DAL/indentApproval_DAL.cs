﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls.WebParts;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class indentApproval_DAL
    {
        indentApproval_QRY qry = new indentApproval_QRY();
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        HRServices.Service objHRService = new HRServices.Service();

        HRServices.EmpDetails[] objEmpDetails;

        UtilityDAL objUtilityDAL = new UtilityDAL();

        string SISLink = ConfigurationManager.AppSettings["WebURL"];

        public string GetPendingIndentDetails(string UserName)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getPendingIndentList;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("USERNAME", UserName));
                        
                        //command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return JsonConvert.SerializeObject(dt);

        }
        public string GetMAXLevelIndent(string ID)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getIndetMax;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("ID", ID));

                        //command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return dt.Rows[0][0].ToString();

        }

        public string getIndentDOPRemarks(string ID)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getIndentDOPRemarks;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("ID", ID));

                        //command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return JsonConvert.SerializeObject(dt);

        }
        public string getIndentApproverList(string PLANT,string DEPT,string LVL,string TYP)
        {
            DataTable dt = new DataTable();
            try
            {
                string lvlcount = "";

                if (TYP == "UPTO")
                {
                    int lvl = int.Parse(LVL);
                    for (int i = 1; i <= lvl; i++)
                    {
                        lvlcount = lvlcount.Length > 0 ? lvlcount+"," + i.ToString() : i.ToString();
                    } }
                else {
                    lvlcount = LVL;
                }
                
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetApproverList.Replace("@LVL", lvlcount);
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("PLANT", PLANT));
                        command.Parameters.Add(new OracleParameter("DEPT", DEPT));

                        //command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return JsonConvert.SerializeObject(dt);

        }
        public string UpdateIndentbyL1(SaveIndent obj)
        {
            int attachInsertCount;
            string CLVL = "";
            string MaxLVL = GetMAXLevelIndent(obj.T_SII_INDENT_DETAILS.IndentId);
            int indentId = 0;
            OracleConnection connection = new OracleConnection(connectionString);
            
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                
                try
                {
                    command.CommandText = qry.UpdateIndentForL1.Replace("@LVL", obj.T_SII_INDENT_DETAILS.LEVEL);
                    command.Parameters.Clear();
                    command.Parameters.Add(":USERNAME", obj.T_SII_INDENT_DETAILS.UserName);
                    command.Parameters.Add(":REMARKS", obj.T_SII_INDENT_DETAILS.IndentRemarks);
                int ApproverLevel = 0;
                bool isReturn = false;
                   
                    if (obj.T_SII_INDENT_DETAILS.IndentDesc == "A")
                    {
                      
                        if (obj.T_SII_INDENT_DETAILS.LEVEL == "L1")
                        {
                        obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.PendingForL2;
                        obj.T_SII_INDENT_DETAILS.NEXTLEVEL = "L2";
                        ApproverLevel = 2;

                        }
                        else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L2")
                        {
                        obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.PendingForL3;
                        obj.T_SII_INDENT_DETAILS.NEXTLEVEL = "L3";
                        ApproverLevel = 3;
                        
                        }
                        else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L3")
                        {
                        obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.PendingForL4;
                        obj.T_SII_INDENT_DETAILS.NEXTLEVEL = "L4";
                        ApproverLevel = 4;

                    }
                       else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L4")
                        {
                        obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.PendingForL5;
                        obj.T_SII_INDENT_DETAILS.NEXTLEVEL = "L5";
                        ApproverLevel = 5;

                    }
                    else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L5")
                    {
                        obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.PendingForL6;
                        obj.T_SII_INDENT_DETAILS.NEXTLEVEL = "L6";

                    }
                    command.Parameters.Add(":STATUS", obj.T_SII_INDENT_DETAILS.DOPSTATUS);
                        command.Parameters.Add(":CSTATUS", obj.T_SII_INDENT_DETAILS.NEXTLEVEL);
                    }
                    else if (obj.T_SII_INDENT_DETAILS.IndentDesc == "R")
                    {
                    isReturn = true;
                        if (obj.T_SII_INDENT_DETAILS.LEVEL == "L1")
                        {
                            obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.ReturnByL1
;
                        }
                        else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L2")
                        {
                            obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.ReturnByL2
;
                        }
                        else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L3")
                        {
                            obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.ReturnByL3
;
                        }
                        else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L4")
                        {
                            obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.ReturnByL4
;
                        }
                        else if (obj.T_SII_INDENT_DETAILS.LEVEL == "L5")
                        {
                            obj.T_SII_INDENT_DETAILS.DOPSTATUS = CommonConstants.ReturnByL5
;
                        }
                        command.Parameters.Add(":STATUS", obj.T_SII_INDENT_DETAILS.DOPSTATUS);
                        command.Parameters.Add(":CSTATUS", "R"+ obj.T_SII_INDENT_DETAILS.LEVEL);
                    }
                    command.Parameters.Add(":INDENT_ID", obj.T_SII_INDENT_DETAILS.IndentId);
                  
                    attachInsertCount = command.ExecuteNonQuery();
                     CLVL = obj.T_SII_INDENT_DETAILS.LEVEL;
                    if (MaxLVL == CLVL && obj.T_SII_INDENT_DETAILS.IndentDesc == "A")
                    {
                        Indent_DAL objInd = new Indent_DAL();
                        indentId = objInd.CreateIndentForDOP(obj, ref connection, ref transaction);
                    }
                    transaction.Commit();

                if (MaxLVL == CLVL && obj.T_SII_INDENT_DETAILS.IndentDesc == "A" && indentId != 0)
                {
                    List<AIULPWorkflow> workflows = GetLatestWorkflow(indentId);
                        foreach(var workflow in workflows)
                    {
                        TriggerEmailToHead(workflow, connection);
                    }
                }


                    if (!isReturn && MaxLVL != CLVL)
                {
                  if(ApproverLevel != 0)  TriggerEmailToApprover(connection, obj.T_SII_INDENT_DETAILS.IndentId, ApproverLevel, obj.T_SII_INDENT_DETAILS.UserName);
                }
                else if(isReturn)
                {
                    TriggerEmailToIndeterOnReturn(connection, obj.T_SII_INDENT_DETAILS.IndentId, obj.T_SII_INDENT_DETAILS.UserName);
                }
                   
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
            }
            finally
            {
                connection.Close();
            }
            if (attachInsertCount > 0)
            {
                if (MaxLVL == CLVL && obj.T_SII_INDENT_DETAILS.IndentDesc == "A")
                {
                    return "Indent";
                }
                else
                {
                    return "Processed";
                }
            }
            else
            {
                return "error";
            }
                
        }

        public void TriggerEmailToHead(AIULPWorkflow workflow, OracleConnection connection)
        {
            if (connection.State == ConnectionState.Closed) connection.Open();

            try
            {
                string srcDept = workflow.SrcDeptId;
                string srcPlant = workflow.SrcPlantId;
                int umcIndentId = Convert.ToInt32(workflow.UmcIndentId);


                BodyContent bodyRequiredDetails = new BodyContent();

                bodyRequiredDetails.UMCIndentId = umcIndentId;
                bodyRequiredDetails.RequestedQuantity = Convert.ToInt32(workflow.Quantity);
                bodyRequiredDetails.WFExpiryDate = workflow.WFExpiryDate;
                objUtilityDAL.UpdateBodyRequirement(bodyRequiredDetails, connection);


                string subject = "Requesting for approval of spare sharing request for material - " + bodyRequiredDetails.MaterialName + " of Indent Id(" + bodyRequiredDetails.IndentId + ")";

                string body = "Dear Sir/Ma'am,<br><br>" +
              "A spare sharing request has been raised for the material - " + bodyRequiredDetails.MaterialName +
              " currently available in your department on " + DateTime.Now.ToString("dd-MMM-yyyy") +
              ". This request is pending with you. Please approve or reject the request by " + DateTime.Parse(bodyRequiredDetails.WFExpiryDate.ToString("dd-MMM-yyyy")).AddDays(-2).ToString("dd-MMM-yyyy") +
              "; failing to do so will result in workflow escalation to chief of the department.<br><br>" +
              "Request Details :<br>" +
              "Requested Quantity : " + bodyRequiredDetails.RequestedQuantity + "<br>" +
              "Material Name : " + bodyRequiredDetails.MaterialName + "<br>" +
              "Workflow ID : " + workflow.WfID + "<br>" +
              "Link of the Smart Indenting System : " + SISLink + "<br>" +
              "Raised by Department : " + bodyRequiredDetails.IndenterDept + "<br>" +
              "Raised by : " + bodyRequiredDetails.IndenterName + "(" + bodyRequiredDetails.IndeterADID + ")" + "<br><br>" +
              "Best Regards,<br>" +
              "SIS Admin<br>";


                MailFormat mailFormat = new MailFormat();
                mailFormat.Mail_To = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, 2);
                mailFormat.Mail_Subject = subject;
                mailFormat.Mail_Body = body;
                mailFormat.Mail_CC = new List<string> { bodyRequiredDetails.IndenterEmail };


                objUtilityDAL.SendMail(mailFormat,connection);
                MailDetails mailDetails = new MailDetails();

                mailDetails.INDENT_ID = bodyRequiredDetails.IndentId;
                mailDetails.Mail_To = String.Join(", ", mailFormat.Mail_To);
                mailDetails.Mail_Subject = subject;
                mailDetails.Mail_Body = body;
                mailDetails.WF_ID = workflow.WfID;
                mailDetails.UMCIndentId = umcIndentId;
                mailDetails.MAIL_CC = bodyRequiredDetails.IndenterEmail;

                objUtilityDAL.UpdateMailTable(mailDetails, connection);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while sending mail to head while creating workflow", ex.ToString());

            }
        }

        public List<AIULPWorkflow> GetLatestWorkflow(int indentId)
        {
           List<AIULPWorkflow> workflows = new List<AIULPWorkflow>();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                using (var command = new OracleCommand(indentApproval_QRY.GetWorkflowDetails, connection))
                {
                    command.Parameters.Add(new OracleParameter("INDENT_ID", indentId));
                    command.Parameters.Add(new OracleParameter("PENDING_WITH_HOD", CommonConstants.PendingWithHOD));
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            workflows.Add(new AIULPWorkflow
                            {
                                WfID = Convert.ToInt32(reader["WF_ID"]),
                                UmcIndentId = Convert.ToInt32(reader["UMC_INDENT_ID"]),
                                Quantity = Convert.ToInt32(reader["REQ_QUANTITY"]),
                                WFExpiryDate = Convert.ToDateTime(reader["WF_EXPIRY_DT"]),
                                SrcPlantId = reader["SRC_PLANT_ID"].ToString(),
                                SrcDeptId = reader["SRC_DEPT_ID"].ToString()
                            });

                        }
                    }
                }

            }

            catch (Exception ex)
            {

                Console.Error.WriteLine("Error getting UMC workflows: ", ex.Message);
            }
    return workflows;
        }

        public void TriggerEmailToApprover(OracleConnection connection, string IndentId, int ApproverLevel, string PreviousApprover)
        {
            try
            {

                IndenterDetails indenterDetails = new IndenterDetails();
                objUtilityDAL.GetIndenterDetails(indenterDetails, connection, Convert.ToInt32(IndentId));
                string srcDept = indenterDetails.IndenterDept;
                string srcPlant = indenterDetails.IndenterPlant;



                string PreviousApproverMail = null;
                string PreviousApproverName = null;
                if (PreviousApprover != null)
                {

                    if (PreviousApprover != null)
                    {
                        objEmpDetails = objHRService.getDetails(new string[] { PreviousApprover });
                        if (objEmpDetails.Length > 0)
                        {
                            string UserName = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                            PreviousApproverName = String.IsNullOrEmpty(UserName) ? PreviousApprover : UserName;
                            PreviousApproverMail = objEmpDetails[0].getsetEmailId;
                        }
                    }
                }


                string subject = "Indent (" + IndentId + ") is submitted for Approval";

                string body = "Dear Sir/Ma'am" + ",<br><br>" +
          "A spare sharing request has been raised in Smart Indenting System by  " + indenterDetails.IndenterName + "(" + indenterDetails.IndeterADID + ") from department("+indenterDetails.IndenterDept +") on " + indenterDetails.IndentCrtDate + (PreviousApprover != null ? ". Request has been approved by " + PreviousApproverName : "") + ". This request is pending for your action. Please approve or return the request as per the details mentioned below.<br><br>" +
          "Request Details :<br>" +
          "Indent Id : " + IndentId + "<br>" +
          "Link of Smart Indenting System : " + SISLink + "<br>" +
          "Request Type : Indent Approval" + "<br>" +
          "Indent Current Status : Pending with Level "+ ApproverLevel.ToString()+ "<br><br>" +
          "Best Regards,<br>" +
          "SIS Admin<br>";

                MailFormat mailFormat = new MailFormat();
                mailFormat.Mail_To = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, ApproverLevel);
                mailFormat.Mail_Subject = subject;
                mailFormat.Mail_Body = body;
                mailFormat.Mail_CC = new List<string> { indenterDetails.IndenterEmail };
                if (PreviousApprover != null) mailFormat.Mail_CC.Add(PreviousApproverMail);


                objUtilityDAL.SendMail(mailFormat, connection);
                MailDetails mailDetails = new MailDetails();

                mailDetails.INDENT_ID = Convert.ToInt32(IndentId);
                mailDetails.Mail_To = String.Join(", ", mailFormat.Mail_To);
                mailDetails.Mail_Subject = subject;
                mailDetails.Mail_Body = body;
                mailDetails.MAIL_CC = indenterDetails.IndenterEmail;
                if (PreviousApprover != null) mailDetails.MAIL_CC += ", " + PreviousApproverMail;


                objUtilityDAL.UpdateMailTable(mailDetails, connection);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in sending mail ", ex.ToString());
            }

        }

        public void TriggerEmailToIndeterOnReturn(OracleConnection connection, string IndentId, string ReturningUsername)
        {
            try
            {
                IndenterDetails indenterDetails = new IndenterDetails();
                objUtilityDAL.GetIndenterDetails(indenterDetails, connection, Convert.ToInt32(IndentId));
                string srcDept = indenterDetails.IndenterDept;
                string srcPlant = indenterDetails.IndenterPlant;


                string ReturningEmail = null;
                string ReturningName = null;

                objEmpDetails = objHRService.getDetails(new string[] { ReturningUsername });
                if (objEmpDetails.Length > 0)
                {
                    string UserName = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                    ReturningName = String.IsNullOrEmpty(UserName) ? ReturningUsername : UserName;
                    ReturningEmail = objEmpDetails[0].getsetEmailId;
                }


                string subject = "Indent having (" + IndentId + ") has been returned ";

                string body = "Dear Sir/Ma'am" + ",<br><br>" +
          "The Indent request of indent id (" + IndentId + ") rasied on " + indenterDetails.IndentCrtDate + " in Smart Indenting System has been returned by " + ReturningName + " with remarks.  Please address the remarks provided by the approver and resubmit the Spare Sharing Request accordingly for the Indent Approval.<br><br>" +
         "Link of Smart Indenting System : " + SISLink + "<br>" +
         "Indent Current Status : Request Returned" +
           "<br><br>" +
          "Best Regards,<br>" +
          "SIS Admin<br>";
                MailFormat mailFormat = new MailFormat();
                mailFormat.Mail_To = new List<string> { indenterDetails.IndenterEmail };
                mailFormat.Mail_Subject = subject;
                mailFormat.Mail_Body = body;
                mailFormat.Mail_CC = new List<string> { ReturningEmail };

                objUtilityDAL.SendMail(mailFormat, connection);

                MailDetails mailDetails = new MailDetails();
                mailDetails.INDENT_ID = Convert.ToInt32(IndentId);
                mailDetails.Mail_To = indenterDetails.IndenterEmail;
                mailDetails.Mail_Subject = subject;
                mailDetails.Mail_Body = body;
                mailDetails.MAIL_CC = ReturningEmail;

                objUtilityDAL.UpdateMailTable(mailDetails, connection);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in sending mail while approval", ex.ToString());
            }

        }
        public int UpdateIndentbyL2(T_SII_INDENT_DETAILS obj)
        {
            int attachInsertCount;

            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;

           
                try
                {
                    command.CommandText = qry.UpdateIndentForL2;
                    command.Parameters.Clear();
                    command.Parameters.Add(":USERNAME", obj.UserName);
                    command.Parameters.Add(":REMARKS", obj.IndentRemarks);
                    if (obj.IndentDesc == "A")
                    {
                        command.Parameters.Add(":CSTATUS", "");
                    }
                    else if (obj.IndentDesc == "R")
                    {
                        command.Parameters.Add(":CSTATUS", "RL2");
                        
                    }
                    command.Parameters.Add(":STATUS", obj.STATUS);
                    command.Parameters.Add(":INDENT_ID", obj.IndentId);

                    attachInsertCount = command.ExecuteNonQuery();

                    transaction.Commit();

                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }

        public string GetPendingIndentApprDetails(IndentStatusModel obj)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    //string query = qry.getPendingIndentAppr;
                    string dtFlt = string.IsNullOrEmpty( obj.DTF) ?"": "AND trim(INDENT_CRT_DT) BETWEEN TO_DATE(:DTF,'YYYY-MM-DD') AND  TO_DATE(:DTT,'YYYY-MM-DD')";
                    string query = qry.getPendingIndentAppr.Replace("@DATEFLT", dtFlt);
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));
                        if(!string.IsNullOrEmpty(obj.DTF))
                        {
                            command.Parameters.Add(new OracleParameter("DTF", obj.DTF));
                            command.Parameters.Add(new OracleParameter("DTT", obj.DTT));
                        }
                        command.Parameters.Add(new OracleParameter("DEPT", obj.DEPT));

                        //command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return JsonConvert.SerializeObject(dt);

        }
    }
    public class indentApproval_QRY
    {
        public string getPendingIndentAppr = @"SELECT distinct
INDENT_ID INDENTID,
INDENTOR_LOC LOC,
(SELECT NAME1 FROM SAPSUR.t_s_plant WHERE PLANT=INDENTOR_PLANT)||'('||INDENTOR_PLANT ||')' PLANT ,
(SELECT DEPTDESC FROM SAPSUR.t_s_dept_mst WHERE DEPTNO=INDENTOR_DEPT)||'('||INDENTOR_DEPT ||')' DEPT,
INDENT_DESC DES,
INDENT_REMARKS REMARKS,
INDENT_CRT_BY INDENTOR,
(SELECT CODE_VAL_DESC FROM  T_SIS_CODE_VALUE WHERE TO_CHAR(ID)=TO_CHAR(INDENT_CURRENT_STATUS)) STAGE,
TO_CHAR(INDENT_CRT_DT,'DD-MON-YYYY') DT ,
INDENT_MOD_BY ,
INDENT_MOD_DT ,
INDENT_STATUS ,
ISACTIVE ,
INDENT_CURRENT_STATUS ,

INDENT_WF_STATUS ,
INDENT_L1_BY ,
INDENT_L1_ON ,
INDENT_L1_REMARKS ,
INDENT_L2_BY ,
INDENT_L2_ON ,
INDENT_L2_REMARKS,
INDENT_L3_BY ,
INDENT_L3_ON ,
INDENT_L3_REMARKS ,
INDENT_L4_BY ,
INDENT_L4_ON ,
INDENT_L4_REMARKS,
INDENT_L5_BY ,
INDENT_L5_ON ,
INDENT_L5_REMARKS FROM T_SIS_INDENT_DETAILS
INNER join SAPSUR.t_approver appr 
on INDENTOR_PLANT= appr.apr_plant  and INDENTOR_DEPT= appr.apr_dept 
WHERE  appr.APR_ID=:USERNAME and appr.APR_LEVEL IN(1,2,3,4,5)
@DATEFLT
AND INDENTOR_DEPT=nvl(:DEPT,INDENTOR_DEPT)
AND ISACTIVE='Y'
 AND appr.APR_LEVEL  =decode(INDENT_STATUS,'L1',1,'L2',2,'L3',3,'L4',4,'L5',5)
and UPPER(INDENT_STATUS) NOT IN ('DRAFT','CMPLT') order by INDENT_ID desc";

        public string getPendingIndentList = @"

SELECT 
INDENT_ID INDENTID,
INDENTOR_LOC LOC,INDENTOR_PLANT,INDENTOR_DEPT,
(SELECT NAME1 FROM SAPSUR.t_s_plant WHERE PLANT=INDENTOR_PLANT)||'('||INDENTOR_PLANT ||')' PLANT ,
(SELECT DEPTDESC FROM SAPSUR.t_s_dept_mst WHERE DEPTNO=INDENTOR_DEPT)||'('||INDENTOR_DEPT ||')' DEPT,
(SELECT CODE_VAL_DESC FROM  T_SIS_CODE_VALUE WHERE TO_CHAR(ID)=TO_CHAR(INDENT_CURRENT_STATUS)) STAGE,
INDENT_DESC DES,
INDENT_REMARKS REMARKS,
INDENT_CRT_BY INDENTOR,
TO_CHAR(INDENT_CRT_DT,'DD-MON-YYYY') DT ,

INDENT_STATUS ,
ISACTIVE ,
INDENT_CURRENT_STATUS ,
INDENT_WF_STATUS,
decode(INDENT_STATUS,'L1',1,'L2',2,'L3',3,'L4',4,'L5',5,0) INDENT_LEVEL
 FROM T_SIS_INDENT_DETAILS

WHERE INDENT_CRT_BY=:USERNAME
and  INDENT_STATUS NOT IN ('CMPLT','DRAFT')
and ISACTIVE='Y'
order by INDENTID desc";

        public string UpdateIndentForL1 = @"UPDATE T_sis_Indent_details SET INDENT_@LVL_BY=:USERNAME,INDENT_@LVL_ON=SYSDATE,INDENT_@LVL_REMARKS=:REMARKS,INDENT_CURRENT_STATUS=:STATUS,INDENT_STATUS=:CSTATUS
WHERE INDENT_ID=:INDENT_ID";
        public string UpdateIndentForL2 = @"UPDATE T_sis_Indent_details SET INDENT_L2_BY=:USERNAME,INDENT_L2_ON=SYSDATE,INDENT_L2_REMARKS=:REMARKS,INDENT_STATUS=:CSTATUS,INDENT_CURRENT_STATUS=:STATUS
WHERE INDENT_ID=:INDENT_ID";

        public string getIndetMax="select 'L'||nvl(UMCP.INDENT_LEVEL,'1') LVL From T_SIS_INDENT_DETAILS UMCP where  UMCP.INDENT_ID=:ID";

        public string getIndentDOPRemarks = @"SELECT STAGE,(select distinct UM_USR_NAME from SAPSUR.t_user_master where UM_USR_ID=APPROVER)||' ('||APPROVER ||' )'APPROVER,to_char(""APPROVE ON"",'DD-MON-YYYY') APPROVE_ON,REMARKS,SL FROM(
SELECT
'L1' STAGE,
UMCP.INDENT_L1_BY APPROVER,
UMCP.INDENT_L1_ON ""APPROVE ON"",
UMCP.INDENT_L1_REMARKS REMARKS,
1 SL
  FROM T_SIS_INDENT_DETAILS UMCP WHERE INDENT_ID =:ID
   UNION
  SELECT
'L2' STAGE,
UMCP.INDENT_L2_BY APPROVER,
UMCP.INDENT_L2_ON ""APPROVE ON"",
UMCP.INDENT_L2_REMARKS REMARKS,
2 SL
  FROM T_SIS_INDENT_DETAILS UMCP WHERE INDENT_ID =:ID
     UNION
  SELECT
'L3' STAGE,
UMCP.INDENT_L3_BY APPROVER,
UMCP.INDENT_L3_ON ""APPROVE ON"",
UMCP.INDENT_L3_REMARKS REMARKS,
3 SL
  FROM T_SIS_INDENT_DETAILS UMCP WHERE INDENT_ID =:ID
     UNION
  SELECT
'L4' STAGE,
UMCP.INDENT_L4_BY APPROVER,
UMCP.INDENT_L4_ON ""APPROVE ON"",
UMCP.INDENT_L4_REMARKS REMARKS,
4 SL
  FROM T_SIS_INDENT_DETAILS UMCP WHERE INDENT_ID =:ID
     UNION
  SELECT
'L5' STAGE,
UMCP.INDENT_L5_BY APPROVER,
UMCP.INDENT_L5_ON ""APPROVE ON"",
UMCP.INDENT_L5_REMARKS REMARKS,
5 SL
  FROM T_SIS_INDENT_DETAILS UMCP WHERE INDENT_ID =:ID)
  WHERE SL<=(SELECT INDENT_LEVEL FROM  T_SIS_INDENT_DETAILS UMCP WHERE INDENT_ID =:ID)
and APPROVER IS NOT NULL";

        public string GetApproverList = @"select distinct t1.APR_LEVEL as APP_LVL, t2.UM_USR_NAME || '(' || t1.APR_ID || ')' as APP_NAME ,t1.apr_plant , t1.apr_dept
  from SAPSUR.t_approver t1,SAPSUR.t_user_master t2
Where t1.apr_id = t2.UM_USR_ID and t1.apr_plant = :PLANT and
t1.apr_dept = :DEPT and t1.APR_LEVEL IN(@LVL)
and t1.APR_LEVEL in (1,2,3,4,5) order by t1.APR_LEVEL";

        public const string GetWorkflowDetails = @"Select * from T_SIs_Work_flow W JOIN t_sis_umc_indent_details u ON W.UMC_INDENT_ID = U.UMC_INDENT_ID WHERE U.INDENT_ID = :INDENT_ID AND W.WF_STATUS = :PENDING_WITH_HOD";
    }
}
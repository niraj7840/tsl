﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class MasterDAL
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        MASTER_QRY qry = new MASTER_QRY();
        public List<SaveDraft> GetDraftedList(string DEPT, string USERNAME)
        {
            var draftedList = new List<SaveDraft>();
            DataTable draftedTable = new DataTable();

            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getIndentDraftList;
                        using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("DEPT", DEPT));
                        command.Parameters.Add(new OracleParameter("USERNAME", USERNAME));
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            draftedTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in draftedTable.Rows)
                {
                    var drafted = new SaveDraft
                    {
                        umcNo = row["REQ_UMC_NO"].ToString(),
                        materialDescription = row["REQ_UMC_DESC"].ToString(),
                        procurementType = row["PROC_TYPE"].ToString(),
                        intraInventory = "0",
                        interInventory = "0",
                        aiulpInventory = "0",
                        quantity = row["QTY"].ToString(),
                        unitOfMeasurement = row["UOM"].ToString(),
                        destinationStorage = row["DEST_SLOC"].ToString(),
                        existingUmcNo = row["EXISTING_UMC"].ToString(),
                        existingMaterialDescription = row["EXIS_UMC_DESC"].ToString(),
                        UMC_INDENT_ID = row["UMC_INDENT_ID"].ToString(),
                        REQ_UMC_NO = row["REQ_UMC_NO"].ToString(),
                        INDENT_ID = row["INDENT_ID"].ToString(),
                        REQ_UMC_DESC = row["REQ_UMC_DESC"].ToString(),
                        EXISTING_UMC = row["EXISTING_UMC"].ToString(),
                        EXIS_UMC_DESC = row["EXIS_UMC_DESC"].ToString(),
                        DEST_SLOC = row["DEST_SLOC"].ToString(),
                        UOM = row["UOM"].ToString(),
                        QTY = row["QTY"].ToString(),
                        IS_REFURBISHABLE = row["IS_REFURBISHABLE"].ToString(),
                        IS_CRITICAL = row["IS_CRITICAL"].ToString(),
                        IS_PERISHABLE = row["IS_PERISHABLE"].ToString(),
                        REQ_DT = row["REQ_DT"].ToString(),
                        consumptionDate = row["CONSUMP_DT"].ToString(),
                        PROC_TYPE = row["PROC_TYPE"].ToString(),
                        SRC_DEPT_ID = row["INDENTOR_DEPT"].ToString(),
                        SRC_DEPT_DESC = row["DEST_SLOC"].ToString(),
                        SRC_LOC_DESC = row["INDENTOR_LOC"].ToString(),
                        SRC_PLANT_ID = row["INDENTOR_PLANT"].ToString(),
                        INDENT_DESC = row["INDENT_DESC"].ToString(),
                        INDENT_REMARKS = row["INDENT_REMARKS"].ToString(),
                        REQ_QUANTITY = row["QTY"].ToString(),
                        OperationalConsumable = row["OPERATIONAL_CONSUMABLE"].ToString() == "Y",
                        docType = row["DOCUMENT_TYPE"].ToString(),
                        fodType = row["FOD_TYPE"].ToString(),
                        currency = row["CURRENCY"].ToString(),
                        materialBGG = row["REQ_UMC_BGG"].ToString(),
                        rate = row["PRICE_PER_ITEM"].ToString(),
                        requestedOn = row["REQUIREMENT_DATE"].ToString(),

                        WF_STATUS = "2",
                        WF_TYPE = "INTRA",
                        purchaseGroup = row["PUR_GRP"].ToString(),
                        delPoint = row["DEL_POINT"].ToString(),
                        ISCONSUMABLE=row["IS_CONSUMABLE"].ToString(),
                        INDENTOR_DEPT = row["INDENTOR_DEPT"].ToString(),
                        INDENTOR_PLANT = row["INDENTOR_PLANT"].ToString(),
                        INDENTOR_LOC = row["INDENTOR_LOC"].ToString(),
                        INDENT_LEVEL = row["INDENT_LEVEL"].ToString(),
                        CONTRACTNUMBER = row["CONTRACTNUMBER"].ToString(),
                        ITEMNO = row["ITEMNO"].ToString(),
                    };
                    draftedList.Add(drafted);
                }
            }
            catch (Exception ex)
            {
               
            }

            return draftedList;
        }
        public List<SaveDraft> GetIndentList(string INDENTID)
        {
            var draftedList = new List<SaveDraft>();
            DataTable draftedTable = new DataTable();

            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getIndentList;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("INDENTID", INDENTID));
                        
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            draftedTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in draftedTable.Rows)
                {
                    var drafted = new SaveDraft
                    {
                        umcNo = row["REQ_UMC_NO"].ToString(),
                        materialDescription = row["REQ_UMC_DESC"].ToString(),
                        procurementType = row["PROC_TYPE"].ToString(),
                        intraInventory = "0",
                        interInventory = "0",
                        aiulpInventory = "0",
                        quantity = row["QTY"].ToString(),
                        unitOfMeasurement = row["UOM"].ToString(),
                        destinationStorage = row["DEST_SLOC"].ToString(),
                        existingUmcNo = row["EXISTING_UMC"].ToString(),
                        existingMaterialDescription = row["EXIS_UMC_DESC"].ToString(),
                        UMC_INDENT_ID = row["UMC_INDENT_ID"].ToString(),
                        REQ_UMC_NO = row["REQ_UMC_NO"].ToString(),
                        INDENT_ID = row["INDENT_ID"].ToString(),
                        REQ_UMC_DESC = row["REQ_UMC_DESC"].ToString(),
                        EXISTING_UMC = row["EXISTING_UMC"].ToString(),
                        EXIS_UMC_DESC = row["EXIS_UMC_DESC"].ToString(),
                        DEST_SLOC = row["DEST_SLOC"].ToString(),
                        UOM = row["UOM"].ToString(),
                        BUOM = row["UOM"].ToString(),
                        QTY = row["QTY"].ToString(),
                        IS_REFURBISHABLE = row["IS_REFURBISHABLE"].ToString(),
                        IS_CRITICAL = row["IS_CRITICAL"].ToString(),
                        IS_PERISHABLE = row["IS_PERISHABLE"].ToString(),
                        REQ_DT = row["REQ_DT"].ToString(),
                        consumptionDate = row["CONSUMP_DT"].ToString(),
                        PROC_TYPE = row["PROC_TYPE"].ToString(),
                        SRC_DEPT_ID = row["INDENTOR_DEPT"].ToString(),
                        SRC_DEPT_DESC = row["DEST_SLOC"].ToString(),
                        SRC_LOC_DESC = row["INDENTOR_LOC"].ToString(),
                        SRC_PLANT_ID = row["INDENTOR_PLANT"].ToString(),
                        INDENT_DESC = row["INDENT_DESC"].ToString(),
                        INDENT_REMARKS = row["INDENT_REMARKS"].ToString(),
                        REQ_QUANTITY = row["QTY"].ToString(),
                        OperationalConsumable = row["OPERATIONAL_CONSUMABLE"].ToString() == "Y",
                        docType = row["DOCUMENT_TYPE"].ToString(),
                        fodType = row["FOD_TYPE"].ToString(),
                        currency = row["CURRENCY"].ToString(),
                        materialBGG = row["REQ_UMC_BGG"].ToString(),
                        rate = row["PRICE_PER_ITEM"].ToString(),
                        requestedOn = row["REQUIREMENT_DATE"].ToString(),

                        WF_STATUS = "2",
                        WF_TYPE = "INTRA",
                        purchaseGroup = row["PUR_GRP"].ToString(),
                        delPoint = row["DEL_POINT"].ToString(),
                        INDENTOR_DEPT = row["INDENTOR_DEPT"].ToString(),
                        INDENTOR_PLANT = row["INDENTOR_PLANT"].ToString(),
                        INDENTOR_LOC = row["INDENTOR_LOC"].ToString(),
                        INDENTOR = row["INDENTOR"].ToString(),
                        DT = row["DT"].ToString(),
                        DELPOINT_DESC= row["DELPOINT"].ToString(),
                        FODTYPE_DESC = row["FODTYPE"].ToString(),
                        DOCTYPE_DESC = row["DOCUMENTTYPE"].ToString(),
                        PURGROUP_DESC = row["PURGRP"].ToString(),
                        INDENT_CURRENT_STATUS = row["INDENT_CURRENT_STATUS"].ToString(),
                        INDENT_L1_REMARKS = row["INDENT_L1_REMARKS"].ToString(),
                        INDENT_L2_REMARKS = row["INDENT_L2_REMARKS"].ToString(),
                        INDDEPT = row["INDDEPT"].ToString(),
                        INDPLANT = row["INDPLANT"].ToString(),
                        INDENT_STATUS = row["INDENT_STATUS"].ToString(),
                        TOTALMAP = row["INDENT_TOTAL_MAP"].ToString(),
                        ISCONSUMABLE = row["IS_CONSUMABLE"].ToString(),
                        
                        CSTATUS = row["CSTATUS"].ToString(),
                        INDENT_LEVEL = row["INDENT_LEVEL"].ToString(),
                        CONTRACTNUMBER = row["CONTRACTNUMBER"].ToString(),
                        ITEMNO = row["ITEMNO"].ToString(),

                    };
                    draftedList.Add(drafted);
                }
            }
            catch (Exception ex)
            {

            }

            return draftedList;
        }
        public List<Department> GetDepartment(string adid)
        {
            var deptList = new List<Department>();
            DataTable deptTable = new DataTable();

            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetDepartment;
                        using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("adid", adid));
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            deptTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in deptTable.Rows)
                {
                    var department = new Department
                    {
                        dept = row["ROV_FOR_DEPT_CD"].ToString(),
                        deptName = row["DEPTDESC"].ToString(),
                        plant = row["PLANT"].ToString(),
                        PNAME = row["PNAME"].ToString(),
                        LOC_CD = row["LOC_CD"].ToString()
                    };
                    deptList.Add(department);
                }
            }
            catch (Exception ex)
            {
                
            }
            return deptList;

        }
        public bool IsBlockedUMC(string Plant, string Req_UMC_NO)
        {
            bool mmstr = false;
            bool mstae = false;
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.IsBlocked;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("UMC_CD", Req_UMC_NO.ToString()));
                        command.Parameters.Add(new OracleParameter("PLANT_CD", Plant.ToString()));

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            if(reader.HasRows)
                            {
                                mmstr = true;
                                mstae = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            if (mmstr || mstae) return true;
            return false;
        }


        public string GetMaterial(string Plant, string UMC, string dept,string TYP,bool isOper)
        {
            DataTable dt = new DataTable();
            if (!string.IsNullOrEmpty(Plant) && !string.IsNullOrEmpty(dept))
            {
                var connection = new OracleConnection(connectionString);
                try
                {
                    string query = "";
                    if (isOper)
                    {
                        query = qry.GetUmcOper;
                    }
                    else
                    {
                        query = TYP == "ALL" ? qry.GetUmc : qry.GetUmcById;
                    }
                  

                    connection.Open();
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("Plant", Plant.ToString()));
                        if(!isOper) command.Parameters.Add(new OracleParameter("deptcode", dept));
                        command.Parameters.Add(new OracleParameter("UMC", UMC.ToUpper()));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);
                        

                    }

                }


                catch (Exception ex)
                {

                }
                finally
                {
                    connection.Close();
                } }
            
            return JsonConvert.SerializeObject(dt);

        }
        public string GetUMCLongDescription(string Plant, string UMC)
        {
            DataTable dt = new DataTable();
            if (!string.IsNullOrEmpty(Plant))
            {



                try
                {

                    string query = qry.GetUMCLongDescription;
                    using (var connection = new OracleConnection(connectionString))
                    {
                        using (var command = new OracleCommand(query, connection))
                        {
                            command.Parameters.Add(new OracleParameter("UMC", UMC));
                            command.Parameters.Add(new OracleParameter("PLANT",Plant));
                            OracleDataAdapter sda = new OracleDataAdapter(command);
                            sda.Fill(dt);

                        }
                    }
                }


                catch (Exception ex)
                {

                }
            }
            return JsonConvert.SerializeObject(dt);

        }
        public List<CODEVAL> GetCodeValueList(string CODE)
        {
            var codeVal = new List<CODEVAL>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = "";
                    if (CODE == "4")
                    {
                        query = qry.getCodeIdWithValue;
                    }
                    else
                    {
                        query = qry.getCodeValue;

                    }
                    
                        using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("CODE", CODE);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new CODEVAL
                    {
                        ID = row["ID"].ToString(),
                        VAL = row["VAL"].ToString(),

                    };
                    codeVal.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
            }
            return codeVal;

        }

        public List<CODEVAL> GetDocTypeList(string CODE,string MCODE)
        {
            var codeVal = new List<CODEVAL>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = query = qry.getDocTypeValue;






                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("CODE", CODE);
                        command.Parameters.Add("MCODE", MCODE);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new CODEVAL
                    {
                        ID = row["ID"].ToString(),
                        VAL = row["VAL"].ToString(),

                    };
                    codeVal.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
            }
            return codeVal;

        }
        public List<Plant> GetPlantList(string DEPT, string ADID)
        {
            var plantList = new List<Plant>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetPlant;
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("DEPT", DEPT);
                        command.Parameters.Add("ADID", ADID);
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new Plant
                    {
                        plant = row["LOC"].ToString(),

                    };
                    plantList.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
                
            }
            return plantList;

        }

        public List<CODEVAL> GetPurchaseGroupList(string PNAME)
        {
            var codeVal = new List<CODEVAL>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetPurchaseGroup;
                   

                    using (var command = new OracleCommand(query, connection))
                    {
                       

                        connection.Open();
                        command.Parameters.Add("PLANT", PNAME);
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new CODEVAL
                    {
                        ID = row["ID"].ToString(),
                        VAL = row["VAL"].ToString(),

                    };
                    codeVal.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
            }
            return codeVal;

        }

        public List<CODEVAL> GetDelPointList(string PLANT)
        {
            var codeVal = new List<CODEVAL>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetDelPoint;
                    

                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("PLANT", PLANT);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new CODEVAL
                    {
                        ID = row["ID"].ToString(),
                        VAL = row["VAL"].ToString(),

                    };
                    codeVal.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
            }
            return codeVal;

        }
        public List<CODEVAL> GetStorageList(string PLANT, string UMC, string dept, bool isOper)
        {
            var codeVal = new List<CODEVAL>();
            DataTable plantTable = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = "";

                    if (isOper)
                    {
                        query = qry.getStorageLocationOper;
                    }
                    else
                    {
                        query = qry.getStorageLocation;
                    }
                   

                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add("PLANT", PLANT);
                        command.Parameters.Add("UMC", UMC);
                        if(!isOper)command.Parameters.Add("DEPT", dept);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            plantTable.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }

                foreach (DataRow row in plantTable.Rows)
                {
                    var plantDetails = new CODEVAL
                    {
                        ID = row["ID"].ToString(),
                        VAL = row["VAL"].ToString(),

                    };
                    codeVal.Add(plantDetails);
                }
            }
            catch (Exception ex)
            {
            }
            return codeVal;

        }
    

    public string GetDashboardCount(string USERNAME)
        {
            DataTable dt = new DataTable();
            if (!string.IsNullOrEmpty(USERNAME))
            {



                try
                {

                    string query = qry.GetDashboardCount;
                    using (var connection = new OracleConnection(connectionString))
                    {
                        using (var command = new OracleCommand(query, connection))
                        {
                            command.Parameters.Add(new OracleParameter("USERNAME", USERNAME.ToString()));
                            

                            OracleDataAdapter sda = new OracleDataAdapter(command);
                            sda.Fill(dt);

                        }
                    }
                }


                catch (Exception ex)
                {

                }
            }
            return JsonConvert.SerializeObject(dt);

        }
       
        public DataTable GetColName(string TAB)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetCOLName;
                    using (var command = new OracleCommand(query, connection))
                    {

                        command.Parameters.Add("TAB", TAB);
                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return dt;

        }

        public DataTable GetColValue(string TAB,string ID)
        {
            DataTable dt = new DataTable();
            DataTable dtCol = GetColName(TAB);
            try
            {
               
                string qry = "select ";
                for (int i = 0; i < dtCol.Rows.Count; i++)
                {
                    string ColName = dtCol.Rows[i]["DATA_TYPE"].ToString() == "DATE" ? "TO_CHAR(" + dtCol.Rows[i]["COLUMN_NAME"].ToString() + ",'YYYY-MM-DD') " + dtCol.Rows[i]["COLUMN_NAME"].ToString() : dtCol.Rows[i]["COLUMN_NAME"].ToString();
                    qry =i== dtCol.Rows.Count-1? qry + ColName : qry + ColName + ",";
                }
                qry = qry + " from " + TAB + " where "+ dtCol.Rows[0]["COLUMN_NAME"].ToString() +" = '"+ID+"'";
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry;
                    using (var command = new OracleCommand(query, connection))
                    {

                        command.Parameters.Add("TAB", TAB);
                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
                for (int i = 0; i < dtCol.Rows.Count; i++)
                {
                    dtCol.Rows[i]["VAL"] = dt.Rows[0][dtCol.Rows[i]["COLUMN_NAME"].ToString()].ToString();

                }
            }
            catch (Exception ex)
            {

            }
            return dtCol;

        }


        public string TabAction(string TAB,string TYP, List<TabList> obj)
        {
            DataTable dt = new DataTable();
            DataTable dtCol = GetColName(TAB);
            try
            {
                string qry = "";
                if (TYP == "INSERT")
                {
                    qry = "insert into "+ TAB+ " ( ";
                    for (int i = 0; i < dtCol.Rows.Count; i++)
                    {
                        string ColName = dtCol.Rows[i]["COLUMN_NAME"].ToString();
                        qry = i == dtCol.Rows.Count - 1 ? qry + ColName : qry + ColName + ",";
                    }
                    qry = qry + ") values (";
                    for (int i = 0; i < dtCol.Rows.Count; i++)
                    {
                       
                        
                        string ColName = dtCol.Rows[i]["DATA_TYPE"].ToString() == "DATE" ? "TO_DATE(:" + dtCol.Rows[i]["COLUMN_NAME"].ToString() + ",'YYYY-MM-DD') " : ":"+dtCol.Rows[i]["COLUMN_NAME"].ToString();
                        qry = i == dtCol.Rows.Count - 1 ? qry + ColName : qry + ColName + ",";
                       
                    }
                    qry = qry + ")";
                }
                if (TYP == "UPDATE")
                {
                    qry = "update " + TAB + " set ";
                   
                   
                    for (int i = 1; i < dtCol.Rows.Count; i++)
                    {
                        

                        string ColName = dtCol.Rows[i]["DATA_TYPE"].ToString() == "DATE" ? dtCol.Rows[i]["COLUMN_NAME"].ToString()+"=TO_DATE(:" + dtCol.Rows[i]["COLUMN_NAME"].ToString() + ",'YYYY-MM-DD') " : dtCol.Rows[i]["COLUMN_NAME"].ToString()+"=:" +dtCol.Rows[i]["COLUMN_NAME"].ToString();
                        qry = i == dtCol.Rows.Count - 1 ? qry + ColName : qry + ColName + ",";

                    }
                   
                    qry = qry + " where  " + dtCol.Rows[0]["COLUMN_NAME"].ToString() + "='" + obj[0].VAL+"'";
                }
                using (var connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    string query = qry;
                    using (var command = new OracleCommand(query, connection))
                    {
                        int strinx = TYP == "INSERT" ? 0 : 1;
                        for (int i = strinx; i < dtCol.Rows.Count; i++)
                        {

                            string objValue = obj[i].VAL;

                            command.Parameters.Add(dtCol.Rows[i]["COLUMN_NAME"].ToString(), objValue);

                        }
                        command.ExecuteNonQuery();
                        return "success";
                    }
                }
               
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            

        }

        public DataTable GetALLUMC(string ADID)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetAllUMC;
                    using (var command = new OracleCommand(query, connection))
                    {

                        command.Parameters.Add("ADID", ADID);
                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return dt;

        }
    }
    public class MASTER_QRY
    {
        public string getIndentDraftList = @"select 
t1.INDENT_ID INDENT_ID,
INDENTOR_LOC,
INDENTOR_PLANT,
INDENTOR_DEPT,
INDENT_DESC,
INDENT_REMARKS,
OPERATIONAL_CONSUMABLE,
INDENT_STATUS,

INDENT_CURRENT_STATUS,
INDENT_WF_STATUS,
REQ_UMC_NO,
UMC_INDENT_ID,
REQ_UMC_DESC,
EXISTING_UMC,
EXIS_UMC_DESC,
DEST_SLOC,
UOM,
QTY,
IS_REFURBISHABLE,
IS_CRITICAL,
IS_PERISHABLE,
IS_CONSUMABLE,
REQ_DT,
to_char(CONSUMP_DT,'YYYY-MM-DD')CONSUMP_DT,
PROC_TYPE,
AIULP_INVENTORY,
INTRA_INVENTORY,
INTER_INVENTORY,
UMC_STATUS,
TOTAL_SAP_DOC_QTY,
PRICE_PER_ITEM,
to_char(REQUIREMENT_DATE,'YYYY-MM-DD')REQUIREMENT_DATE,
REQ_UMC_BGG,
FOD_TYPE,
DOCUMENT_TYPE,
CURRENCY,PUR_GRP,nvl(CONTRACT_NUMBER,'ARC Not Available') CONTRACTNUMBER,
ITEMNO,
DEL_POINT,nvl(INDENT_LEVEL,0)INDENT_LEVEL
from T_SIS_Indent_details t1 JOIN T_SIS_umc_indent_details t2 ON t1.indent_id = t2.indent_id WHERE t1.indent_status = 'DRAFT' AND t2.isactive = 'Y' AND t1.INDENT_ID = (select max(INDENT_ID) from T_SIS_Indent_details where INDENTOR_DEPT=:DEPT and INDENT_CRT_BY=:USERNAME AND  indent_status = 'DRAFT')";
        public string IsBlocked = @"
Select CROS_PLNT_MAT_STAT as mmstr ,PLNT_MAT_STAT mstae,UMC_CD,PLANT_CD from SAPSUR.T_UMC_PROD Where UMC_CD = :UMC_CD AND PLANT_CD = :PLANT_CD AND ((CROS_PLNT_MAT_STAT IS NOT NULL
and CROS_PLNT_MAT_STAT in ('01','03','M2','M3','MD','Z1','Z4','ZV')) OR (PLNT_MAT_STAT IS NOT NULL AND PLNT_MAT_STAT in ('01','03','M2','M3','MD','Z1','Z4','ZV')))";
       public string GetDepartment= @"select T1.rov_for_dept_cd, T2.PLANT,(SELECT LOC_CODE from T_SIS_plant_loc_map where PLANT_CODE =T2.PLANT AND ACTIVE_FLAG = 'Y' )LOC_CD,(select distinct Name1  from SAPSUR.t_s_plant where client = '600' and plant = T2.PLANT)PNAME, t2.deptdesc from (
select distinct rov_for_dept_cd from SAPSUR.t_role_obj_val where rov_role_id
in (select tru_role_id from SAPSUR.t_role_user where tru_udr_id =:adid AND   rov_object = 'OBJ_DEPT' AND rov_create = 'Y'))T1,SAPSUR.t_s_dept_mst T2 where T1.rov_for_dept_cd = T2.DEPTNO and T2.smart_ind_tag = 'X'";
        public string GetUmc = @"SELECT 
   distinct t1.UMC_CD AS UMCNO,
    t1.SHT_DESC AS MATDESC,
    t1.BUOM AS UOM,
    t1.BGG_CD AS BGG,
    t1.CURR AS CUR,
    COALESCE(t1.chap_id, '') AS HSN,
    t1.BUOM AS BUOM,
t1.plant_cd PLANT,
t3.dept_code DEPT
FROM 
    SAPSUR.T_UMC_PROD t1
JOIN 
    SAPSUR.t_s_umc_sloc t2 ON t1.umc_cd = t2.umc_cd AND t1.plant_cd = t2.plant
JOIN 
    T_SIS_sapbi_map t3 ON t1.plant_cd = t3.plantcd AND t2.sloc = t3.sloc
WHERE 
    t1.plant_cd = :Plant_cd 
    AND t3.dept_code = :deptcode 
    AND UPPER(t1.UMC_CD || ' - ' || t1.SHT_DESC) LIKE '%' || :UMC || '%'";

        public string GetUmcOper = @"SELECT 
   distinct UMC_CD AS UMCNO,
    SHT_DESC AS MATDESC,
    BUOM AS UOM,
    BGG_CD AS BGG,
    CURR AS CUR,
    COALESCE(chap_id, '') AS HSN,
    BUOM AS BUOM
FROM 
    SAPSUR.T_UMC_PROD 
WHERE 
    plant_cd = :Plant_cd 
    AND UPPER(UMC_CD || ' - ' || SHT_DESC) LIKE '%' || :UMC || '%'";

        public string GetUmcById = @"SELECT 
   distinct t1.UMC_CD AS UMCNO,
    t1.SHT_DESC AS MATDESC,
    t1.BUOM AS UOM,
    t1.BGG_CD AS BGG,
    t1.CURR AS CUR,
    NVL(t1.chap_id, '') AS HSN,
    t1.BUOM AS BUOM
FROM 
    SAPSUR.T_UMC_PROD t1
JOIN 
    SAPSUR.t_s_umc_sloc t2 ON t1.umc_cd = t2.umc_cd AND t1.plant_cd = t2.plant
JOIN 
    T_SIS_sapbi_map t3 ON t1.plant_cd = t3.plantcd AND t2.sloc = t3.sloc
WHERE 
    t1.plant_cd = :Plant_cd 
    AND t3.dept_code = :deptcode 
    AND UPPER(t1.UMC_CD)=:UMC";
        public string getCodeValue = @"SELECT  CODE_VALUE ID,CODE_VAL_DESC VAL FROM T_SIS_CODE_VALUE WHERE CODETYPE_ID =:CODE AND ACTIVE_FLG='Y' ORDER BY ID";
        public string getCodeIdWithValue = @"SELECT  ID,CODE_VAL_DESC VAL FROM T_SIS_CODE_VALUE WHERE (CODETYPE_ID =:CODE OR ID='5') AND ACTIVE_FLG='Y' ORDER BY ID";
        public string GetPlant = @"select UM_PLANT_CD LOC from SAPSUR.t_user_master where um_dept_cd=:DEPT and um_usr_id=:ADID";
        public string GetPurchaseGroup = @"select distinct t1.ekgrp ID, t2.description VAL from SAPSUR.t_plant_purgrp t1 , SAPSUR.t_s_purgrp t2  where t1.werks =:PLANT  and t2.PURGRP = t1.ekgrp
 and CLIENT='600' and t2.PURGRP not in (Select pam_param_desc From sapsur.t_parameter_master Where pam_type_cd='PURGRP_EXCL' and pam_param_cd='01')
order by t1.ekgrp";
        public string GetDelPoint = @"select DELPOINT ID,DESCRIPTION VAL from SAPSUR.t_s_del_point where plant =:PLANT order by DELPOINT";
        public string getStorageLocation = @"SELECT DISTINCT 
    T1.SLOC ID, 
    T1.SLOC VAL
FROM 
    SAPSUR.t_s_umc_sloc T1
INNER JOIN 
    T_SIS_SAPBI_MAP T2 
    ON T1.sloc = T2.sloc
WHERE 
    T1.plant = :PLANT 
    AND T1.umc_cd = :UMC 
    AND T2.dept_code = :DEPT
    AND T1.Mat_del_flag_sloc != 'X'";
        public string getStorageLocationOper = @"    SELECT DISTINCT 
    SLOC ID, 
    SLOC VAL
FROM 
    SAPSUR.t_s_umc_sloc
WHERE 
    plant = :PLANT 
    AND umc_cd = :UMC
    AND Mat_del_flag_sloc != 'X'";
        public string getDocTypeValue = @"SELECT  CODE_VALUE ID,CODE_VAL_DESC VAL FROM T_SIS_CODE_VALUE WHERE CODETYPE_ID =:CODE AND MAPPED_CODE=:MCODE AND ACTIVE_FLG='Y' ORDER BY ID";
        public string getIndentList = @"select 
t1.INDENT_ID INDENT_ID,
INDENTOR_LOC,
(select distinct Name1  from SAPSUR.t_s_plant where client = '600' and plant = INDENTOR_PLANT)||'('|| INDENTOR_PLANT||')' INDENTOR_PLANT,
(select DEPTDESC from SAPSUR.t_s_dept_mst where DEPTNO=INDENTOR_DEPT)||'('||INDENTOR_DEPT||')' INDENTOR_DEPT,INDENTOR_DEPT INDDEPT,
INDENT_DESC,
INDENT_REMARKS,
INDENTOR_PLANT INDPLANT,
IS_CONSUMABLE,
INDENT_STATUS,
INDENT_CRT_BY INDENTOR,
TO_CHAR(INDENT_CRT_DT,'DD-MON-YYYY') DT ,
INDENT_CURRENT_STATUS,
OPERATIONAL_CONSUMABLE,
INDENT_WF_STATUS,
REQ_UMC_NO,
UMC_INDENT_ID,
REQ_UMC_DESC,
EXISTING_UMC,
EXIS_UMC_DESC,
DEST_SLOC,
UOM,
QTY,
IS_REFURBISHABLE,
IS_CRITICAL,
IS_PERISHABLE,
REQ_DT,
to_char(CONSUMP_DT,'YYYY-MM-DD')CONSUMP_DT,
PROC_TYPE,
AIULP_INVENTORY,
INTRA_INVENTORY,
INTER_INVENTORY,
UMC_STATUS,
TOTAL_SAP_DOC_QTY,
PRICE_PER_ITEM,
to_char(REQUIREMENT_DATE,'YYYY-MM-DD')REQUIREMENT_DATE,
REQ_UMC_BGG,
FOD_TYPE,
DOCUMENT_TYPE,
CURRENCY,PUR_GRP,
 DEL_POINT,INDENT_CURRENT_STATUS,nvl(CONTRACT_NUMBER,'ARC Not Available') CONTRACTNUMBER,
ITEMNO,
(select CODE_VAL_DESC from  T_SIS_CODE_VALUE where ID=INDENT_CURRENT_STATUS) CSTATUS,
INDENT_L1_REMARKS,INDENT_TOTAL_MAP,
INDENT_L2_REMARKS,nvl(INDENT_LEVEL,0)INDENT_LEVEL,
(SELECT  CODE_VAL_DESC||'('||TO_CHAR(CODE_VALUE)||')' FROM T_SIS_CODE_VALUE WHERE TO_CHAR(CODE_VALUE) =TO_CHAR(FOD_TYPE) AND ACTIVE_FLG='Y' and CODETYPE_ID='6')FODTYPE,
(SELECT  CODE_VAL_DESC||'('||TO_CHAR(CODE_VALUE)||')' FROM T_SIS_CODE_VALUE WHERE TO_CHAR(CODE_VALUE) =TO_CHAR(DOCUMENT_TYPE) AND ACTIVE_FLG='Y' and CODETYPE_ID='5')DOCUMENTTYPE,
(select distinct t2.description||'('|| t1.ekgrp||')' from SAPSUR.t_plant_purgrp t1 , SAPSUR.t_s_purgrp t2  where t1.werks =INDENTOR_PLANT AND t1.ekgrp=PUR_GRP  and t2.PURGRP = t1.ekgrp)PURGRP,
(select DESCRIPTION||'('||DELPOINT||')' from SAPSUR.t_s_del_point where plant =INDENTOR_PLANT AND DELPOINT=DEL_POINT) DELPOINT
from T_SIS_Indent_details t1 JOIN T_SIS_umc_indent_details t2 ON t1.indent_id = t2.indent_id WHERE t2.isactive = 'Y' AND t1.INDENT_ID =:INDENTID";

        public string GetUMCLongDescription = @"select LNG_DESC From sapsur.T_UMC_PROD UMCP where UMCP.UMC_CD= :UMC and UMCP.PLANT_CD=:PLANT";

        public string GetDashboardCount = @"SELECT CNT,SL,HEAD FROM(
SELECT COUNT(WF_ID)  CNT ,2 SL
,'SPARE_COUNT' HEAD FROM
 T_SIS_work_flow WF INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.UMC_INDENT_ID= WF.UMC_INDENT_ID inner join T_SIS_INDENT_DETAILS IND 
on IND.INDENT_ID=UMC.INDENT_ID  INNER join SAPSUR.t_approver appr on WF.SRC_PLANT_ID= appr.apr_plant  and wf.src_dept_id= appr.apr_dept where
    appr.APR_ID=:USERNAME and appr.APR_LEVEL IN (2,3) and  WF.WF_STATUS in (2,3) and WF.wf_expiry_dt>=sysdate
And IND.ISACTIVE='Y'
    UNION
    SELECT 
COUNT(INDENT_ID) INDENT_APPROVAL_COUNT ,1
,'INDENT_APPROVAL_COUNT' FROM T_SIS_INDENT_DETAILS IND
INNER join SAPSUR.t_approver appr 
on INDENTOR_PLANT= appr.apr_plant  and INDENTOR_DEPT= appr.apr_dept 
WHERE  appr.APR_ID=:USERNAME and appr.APR_LEVEL IN(1,2,3,4,5)

 AND appr.APR_LEVEL  =decode(INDENT_STATUS,'L1',1,'L2',2,'L3',3,'L4',4,'L5',5)
and UPPER(INDENT_STATUS) NOT IN ('DRAFT','CMPLT')
And IND.ISACTIVE='Y'
UNION
SELECT COUNT(SCH_CART_NO)SC_COUNT,3,'SC_COUNT' FROM(
WITH RankedData AS (
    SELECT
        sc_h.sch_cart_no,
        ic_h.indent_id,
        deptdesc || '(' || sc_h.SCH_DEPT || ')' AS dept,
        sc_i.sci_fod_type,
        sc_h.sch_tot_val,
        CASE
            WHEN sc_a.scp_app_status = '00' THEN 'Awaiting'
            WHEN sc_a.scp_app_status = '01' THEN 'Approved'
            WHEN sc_a.scp_app_status = '02' THEN 'Reject'
            WHEN sc_a.scp_app_status = '03' THEN 'Return'           
        END AS status,
        sc_a.scp_app_status,
        sc_a.scp_APPRVR,
        sc_a.scp_upd_dt AS pendingsince,
        ROW_NUMBER() OVER (PARTITION BY sc_h.sch_cart_no ORDER BY sc_a.scp_upd_dt DESC) AS rn
    FROM
        T_SIS_shopping_cart_hdr sc_h
        INNER JOIN T_SIS_intellibuy_check_header ic_h ON sc_h.sch_cart_no = ic_h.sch_cart_no
        INNER JOIN T_SIS_shopping_cart_item sc_i ON sc_i.sci_cart_no = ic_h.sch_cart_no   
        INNER JOIN SAPSUR.t_s_dept_mst d ON d.deptno = sc_h.SCH_DEPT
        INNER JOIN T_SIS_sc_approval sc_a ON sc_a.scp_cart_no = sc_h.sch_cart_no
),
NextApproval AS (
    SELECT 
        scp_cart_no,
        scp_app_lvl,
        scp_apprvr,
        SCP_APP_STATUS        
    FROM 
        T_SIS_sc_approval
    WHERE 
        SCP_APP_STATUS = 0
        AND SCP_APP_LVL = (
            SELECT MIN(SCP_APP_LVL)
            FROM T_SIS_sc_approval
            WHERE SCP_APP_STATUS = 0            
        )
        AND scp_apprvr=:USERNAME
)
SELECT 
    rd.*,
    na.scp_app_lvl AS next_approval_level,
    na.scp_apprvr AS next_approver,
    na.SCP_APP_STATUS as NEXT_SCP_APP_STATUS,
  
     CASE
            WHEN na.SCP_APP_STATUS  = '00' THEN 'Awaiting'
            WHEN  na.SCP_APP_STATUS  = '01' THEN 'Approved'
            WHEN   na.SCP_APP_STATUS  = '02' THEN 'Reject'
            WHEN  na.SCP_APP_STATUS  = '03' THEN 'Return'
             WHEN  na.SCP_APP_STATUS  is null THEN 'Complete'
            ELSE   na.SCP_APP_STATUS 
        END AS NEXT_STATUS
  
FROM 
    RankedData rd
LEFT JOIN 
    NextApproval na ON rd.sch_cart_no = na.scp_cart_no
WHERE 
    rd.rn = 1
    AND STATUS='Awaiting'
   --And NEXT_STATUS='Awaiting'

ORDER BY 
    rd.sch_cart_no, na.scp_app_lvl, na.scp_apprvr)
    WHERE NEXT_STATUS='Awaiting'
    UNION
    SELECT COUNT(INDENT_ID)INDENT_COUNT ,4,'INDENT_COUNT' FROM (
SELECT DISTINCT(INDENT_ID) INDENT_ID FROM T_SIS_INDENT_DETAILS IND
LEFT JOIN SAPSUR.T_APPROVER
  ON APR_DEPT    =INDENTOR_DEPT
  AND APR_PLANT  =INDENTOR_PLANT
  AND APR_LEVEL  =decode(INDENT_STATUS,'L1',1,'L2',2,'L3',3,'L4',4,'L5',5)
  AND APR_LEVEL IN(1,2,3,4,5)
WHERE INDENT_CRT_BY=:USERNAME
And IND.ISACTIVE='Y'
and  INDENT_STATUS NOT IN ('CMPLT','DRAFT')))
ORDER BY SL";

      

        public string GetCOLName = @"SELECT distinct table_name, column_name, data_type, data_length,column_id,nullable,'' VAL,'Y' ACT
FROM ALL_TAB_COLUMNS
WHERE TABLE_NAME = :TAB
order by column_id";

        public string GetAllUMC = @"SELECT 
   distinct t1.UMC_CD AS UMCNO,
    t1.SHT_DESC AS MATDESC,
    t1.BUOM AS UOM,
    t1.BGG_CD AS BGG,
    t1.CURR AS CUR,
    NVL(t1.chap_id, '') AS HSN,
    t1.BUOM AS BUOM
FROM 
    SAPSUR.T_UMC_PROD t1
JOIN 
    SAPSUR.t_s_umc_sloc t2 ON t1.umc_cd = t2.umc_cd AND t1.plant_cd = t2.plant
JOIN 
    T_SIS_sapbi_map t3 ON t1.plant_cd = t3.plantcd AND t2.sloc = t3.sloc
WHERE 
    t1.plant_cd||t3.dept_code in(
    select T2.PLANT||T1.rov_for_dept_cd  from (
select distinct rov_for_dept_cd from SAPSUR.t_role_obj_val where rov_role_id
in (select tru_role_id from SAPSUR.t_role_user where tru_udr_id =:ADID AND   rov_object = 'OBJ_DEPT' AND rov_create = 'Y'))T1,SAPSUR.t_s_dept_mst T2 where T1.rov_for_dept_cd = T2.DEPTNO and T2.smart_ind_tag = 'X')";


    }
}
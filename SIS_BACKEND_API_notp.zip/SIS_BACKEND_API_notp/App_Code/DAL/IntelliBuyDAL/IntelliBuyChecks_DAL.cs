﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using SIS_BACKEND_API.Models.IntelliBuyModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Web;
using SIS_BACKEND_API.Controllers.IntelliBuy;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;
using SIS_BACKEND_API.App_Code.DAL.ShoppingCart;
using System.Diagnostics.Eventing.Reader;
//using SIS_BACKEND_API.SI_OS_FetchBudgtbreakup;
using System.Security.Cryptography;
using System.Runtime.Remoting.Messaging;
using System.Collections;
using System.Globalization;


namespace SIS_BACKEND_API.App_Code.DAL.IntelliBuyDAL
{
    public class IntelliBuyChecks_DAL
    {

        ShoppingCartDAL objShoppingCartDAL = new ShoppingCartDAL();
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        private ConnectionOracleDB objConn;
        private DataTable dtResult;
        public int GetFinancialYear(DateTime date)
        {
            int year = date.Year;

            // Assuming financial year starts on April 1
            if (date.Month < 4)
            {
                year--; // If before April, it's the previous financial year
            }
            else
            {
                year++;
            }

            return year;
        }

        public string GETCurrentFYPercentage(int fy, List<BBPRList> bBPRLists)
        {
            string Percentege = "";
            try
            {
                if (bBPRLists != null)
                {
                    var bBPRListsItem = bBPRLists.FirstOrDefault(p => p.FY == fy);
                    if (bBPRListsItem != null)
                    {
                        Percentege = bBPRListsItem.PERCENTAGE;
                    }
                    else
                    {
                        Percentege = bBPRLists[0].PERCENTAGE;
                    }
                }
               

            }
            catch (Exception ex)
            {

                Percentege = "";
            }
            return Percentege;
        }
        public async Task<List<IntelliBuyIndentDetails>> GetIntelliBuyChecksDetails(string IndentId)
        {
            List<BBPRList> bBPRList = new List<BBPRList>();
            int Currentfy = GetFinancialYear(DateTime.Now);
            int flag = 0;
            var ObjIndentDetails = new List<IntelliBuyIndentDetails>();
            double SpareBudget = 0;
            double CommittedExpenditure = 0;
            string percentBudgetConsumption = "0";
            double percent = 0;
            string FY = "";
            try
            {
                IntelliBuyChecksController controller = new IntelliBuyChecksController();
                DataTable dtTable = new DataTable();
                dtTable = GetIntelliBuyChecksHeaderAndItem(IndentId);
                if (dtTable.Rows.Count == 0)
                {
                    flag++;
                    dtTable = GetIntelliBuyChecksDetailsFromId(IndentId);
                }



                DataTable budgetDeptCountdt = getbudgetDeptCount(dtTable.Rows[0]["INDENTOR_DEPT"].ToString());
                string budgetCountOfDept = budgetDeptCountdt.Rows[0][0].ToString();
                double Budget_EBUY = Get_budgetConsumptionFormDept_EBuy(dtTable.Rows[0]["INDENTOR_DEPT"].ToString());
                double Budget_SIS = Get_budgetConsumptionFormDept_SIS(dtTable.Rows[0]["INDENTOR_DEPT"].ToString());
                string responseData = await Get_budgetConsumptionFormDept_ODATA(dtTable.Rows[0]["INDENTOR_DEPT"].ToString(), Budget_EBUY, 0);
                var bbprlist = new BBPRList();
                foreach (DataRow row in dtTable.Rows)
                {

                    //int ReqDatefy = Convert.ToDateTime(row["requirement_date"].ToString()).Year;
                    int ReqDatefy = GetFinancialYear(Convert.ToDateTime(row["requirement_date"].ToString()));
                    int FinYear = 0;
                    if (ReqDatefy > Currentfy) { FinYear = ReqDatefy; }
                    else { FinYear = Currentfy; }



                    if (!String.IsNullOrEmpty(responseData))
                    {
                        dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                        if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                        {
                            string StrPOValue = "0";
                            string StrPRValue = "0";
                            string StrSpareValue = "0";
                            string StrTotBudget = "0";

                            foreach (var result in responseObject.d.results)
                            {

                                // Check the DocType and assign the values accordingly
                                if (result.DocType == "PO" && result.FisYr == FinYear)
                                {
                                    StrPOValue = result.Value;
                                }
                                else if (result.DocType == "PR" && result.FisYr == FinYear)
                                {
                                    StrPRValue = result.Value;
                                }
                                else if (result.DocType == "TOTAL" && result.FisYr == FinYear)
                                {
                                    StrSpareValue = result.Value;
                                    StrTotBudget = result.TotBudget;
                                }

                                if (result.FisYr == FinYear && result.DocType == "TOTAL")
                                {
                                    double spareValue = double.Parse(StrTotBudget) * 105 / 100;
                                    double PRValue = double.Parse(StrPRValue);
                                    double POValue = double.Parse(StrPOValue);
                                    if (FinYear == Currentfy)
                                    {
                                        CommittedExpenditure = Math.Round(Budget_EBUY + POValue + PRValue + Budget_SIS);
                                    }
                                    else
                                    {
                                        CommittedExpenditure = Math.Round( POValue + PRValue);
                                    }
                                   
                                    bbprlist.FY = FinYear;
                                    bbprlist.COMMITTEDEXPENDITURE = Convert.ToInt32(Math.Round(CommittedExpenditure));
                                    bbprlist.SPAREBUDGET = Convert.ToInt32(Math.Round(spareValue));
                                    if (!bBPRList.Any(e => e.FY == bbprlist.FY))
                                    {
                                        bbprlist.PERCENTAGE = Math.Round((100 * CommittedExpenditure) / spareValue).ToString();
                                        bBPRList.Add(new BBPRList { FY = bbprlist.FY, COMMITTEDEXPENDITURE = bbprlist.COMMITTEDEXPENDITURE, SPAREBUDGET = bbprlist.SPAREBUDGET, PERCENTAGE = bbprlist.PERCENTAGE });
                                    }

                                }
                            }

                            //bBPRList.Add(bbprlist);
                            //bbprlist.FY = FinYear;

                        }
                    }

                }



                //ODATA CALLING

                string reqDateStr = "";
                string ConsDateStr = "";
                string arc_vmiStr = "";

                string pipelineQtyStr = "0";
                string refurQtyStr = "0";
                string chargeQtyStr = "0";
                string maxQtyStr = "0";

                foreach (DataRow item in dtTable.Rows)
                {

                    if (item["INDENT_CURRENT_STATUS_CODE"].ToString() == "39" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "52"
                        || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "53" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "54"
                        || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "55" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "56"
                        || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "45" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "40")
                    {
                        DateTime dateTime = DateTime.Parse(item["SYS_REQ_DATE"].ToString());
                        reqDateStr = dateTime.ToString("yyyy-MM-dd");

                        DateTime dateTimeCons = DateTime.Parse(item["SYS_CONSUMP_DT"].ToString());
                        ConsDateStr = dateTimeCons.ToString("yyyy-MM-dd");

                        arc_vmiStr = item["VMIARC_STATUS"].ToString();
                    }
                    else
                    {
                        string responseContent = "";
                        //RCM Odata calling
                        responseContent = await Get_ReqConsum_ODATA(item["REQ_UMC_NO"].ToString(), item["PUR_GRP"].ToString(), item["INDENTOR_PLANT"].ToString()).ConfigureAwait(false);
                        if (!String.IsNullOrEmpty(responseContent))
                        {
                            dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseContent);
                            if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                            {
                                if (responseObject.d.results.Count > 0)
                                {
                                    reqDateStr = responseObject.d.results[0].ReqDate;
                                    ConsDateStr = responseObject.d.results[0].ConsDate;
                                    arc_vmiStr = responseObject.d.results[0].ARC_VMI;
                                }
                            }
                        }
                    }

                    //maxQty Odata calling

                    if (item["INDENT_CURRENT_STATUS_CODE"].ToString() == "39" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "52"
                        || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "53" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "54"
                        || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "55" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "56"
                        || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "45" || item["INDENT_CURRENT_STATUS_CODE"].ToString() == "40")
                    {
                        pipelineQtyStr = item["PIPELINE_QTY"].ToString();
                        refurQtyStr = item["REFURBISHED_QTY"].ToString();
                        chargeQtyStr = item["CHARGEDOUT_QTY"].ToString();
                        maxQtyStr = item["MAX_QTY"].ToString();
                    }
                    else
                    {
                        string responseContentMaxQty = "";
                        responseContentMaxQty = await Get_MaxQtyConsume_ODATA(item["REQ_UMC_NO"].ToString(), item["PUR_GRP"].ToString(), item["INDENTOR_PLANT"].ToString(), item["INDENTOR_DEPT"].ToString()).ConfigureAwait(false);
                        if (!String.IsNullOrEmpty(responseContentMaxQty))
                        {
                            dynamic responseObjectMax = JsonConvert.DeserializeObject<dynamic>(responseContentMaxQty);
                            if (responseObjectMax != null && responseObjectMax.d != null && responseObjectMax.d.results != null)
                            {
                                if (responseObjectMax.d.results.Count > 0)
                                {
                                    pipelineQtyStr = responseObjectMax.d.results[0].PipelineQty;
                                    refurQtyStr = responseObjectMax.d.results[0].RefurQty;
                                    chargeQtyStr = responseObjectMax.d.results[0].ChargeQty;
                                    maxQtyStr = responseObjectMax.d.results[0].MaxQty;
                                }
                            }
                        }
                    }
                    // var percentage = bBPRList.FirstOrDefault(p => p.FY == Currentfy).PERCENTAGE.ToString() ?? "";

                    var newItem = new IntelliBuyIndentDetails
                    {
                        SRNO = Convert.ToInt32(item["srno"].ToString()),
                        INDENT_ID = Convert.ToInt32(item["INDENT_ID"].ToString()),
                        INDENTOR_PLANT = item["INDENTOR_PLANT"].ToString(),
                        INDENT_CRT_BY = item["INDENT_CRT_BY"].ToString(),
                        REQ_UMC_NO = item["REQ_UMC_NO"].ToString(),
                        REQ_UMC_BGG = item["REQ_UMC_BGG"].ToString(),
                        REQUIREMENT_DATE = item["REQUIREMENT_DATE"].ToString(),
                        IND_REQUIREMENT_DATE = item["IND_requirement_date"].ToString(),
                        PRICE_PER_ITEM = item["PRICE_PER_ITEM"].ToString(),
                        DOCUMENT_TYPE = item["DOCUMENT_TYPE"].ToString(),
                        FOD_TYPE = item["FOD_TYPE"].ToString(),
                        REQ_UMC_DESC = item["REQ_UMC_DESC"].ToString(),
                        UOM = item["UOM"].ToString(),
                        INDENT_CURRENT_STATUS = item["INDENT_CURRENT_STATUS"].ToString(),
                        INDENT_CURRENT_STATUS_CODE = item["INDENT_CURRENT_STATUS_CODE"].ToString(),
                        //EXISTING_UMC = item["EXISTING_UMC"].ToString(),
                        TAGGEDUMC = item["TAGGEDUMC"].ToString(),
                        TOTAL_SAP_DOC_QTY = Convert.ToInt32(item["TOTAL_SAP_DOC_QTY"].ToString()),
                        ALLOWEDQTY = Convert.ToInt32(item["ALLOWEDQTY"].ToString()),
                        UMC_INDENT_ID = Convert.ToInt32(item["UMC_INDENT_ID"].ToString()),
                        INDENTOR_DEPT = item["INDENTOR_DEPT"].ToString(),
                        INDENT_DESC = item["INDENT_DESC"].ToString(),
                        INDENT_REMARKS = item["INDENT_REMARKS"].ToString(),
                        ISACTIVE = item["ISACTIVE"].ToString(),
                        IS_REFURBISHABLE = item["IS_REFURBISHABLE"].ToString(),
                        ITEM_ID = Convert.ToInt32(item["ITEM_ID"].ToString()),
                        QTY = item["QTY"].ToString(),
                        SYS_REQ_DATE = item["SYS_REQ_ON_DATE"].ToString(),
                        DOCUMENT_TYPE_DESC = item["DOCUMENT_TYPE_DESC"].ToString(),
                        DEPT = item["DEPT"].ToString(),
                        CONSUMP_DT = Convert.ToDateTime(item["CONSUMP_DT"].ToString()).ToString("dd-MMM-yyyy"),
                        SCH_CART_NO = item["SCH_CART_NO"].ToString(),
                        ReqDate = reqDateStr,
                        ConsDate = ConsDateStr,
                        ARC_VMI = arc_vmiStr,
                        PipelineQty = Convert.ToDouble(String.IsNullOrEmpty(pipelineQtyStr) ? "0" : pipelineQtyStr),
                        RefurQty = Convert.ToDouble(String.IsNullOrEmpty(refurQtyStr) ? "0" : refurQtyStr),
                        ChargeQty = Convert.ToDouble(String.IsNullOrEmpty(chargeQtyStr) ? "0" : chargeQtyStr),
                        MaxQty = Convert.ToDouble(String.IsNullOrEmpty(maxQtyStr) ? "0" : maxQtyStr),
                        CURRENCY = item["CURRENCY"].ToString(),
                        RCM_Checks_Status = "",
                        RCM_SmartNudges = "",
                        USER_REMARKS_MAXQTY = item["USER_REMARKS_MAXQTY"].ToString(),
                        USER_REMARKS_RCM = item["USER_REMARKS_RCM"].ToString(),
                        //DeptBudgetConsumption = percentBudgetConsumption,
                        DeptBudgetConsumption = GETCurrentFYPercentage(Currentfy,bBPRList),
                        //DeptBudgetConsumption = percentage,
                        SC_QTY = CheckSCQty(Convert.ToDouble(item["QTY"]), Convert.ToDouble(item["TOTAL_SAP_DOC_QTY"]), Convert.ToDouble(item["SCI_QTY"]), flag),
                        // RCM_Checks_Status = RcmChecks(reqDateStr, ConsDateStr, item["REQUIREMENT_DATE"].ToString(), item["CONSUMP_DT"].ToString())
                        INDENTER_LOC = item["INDENTOR_LOC"].ToString(),
                        PUR_GROUP = item["PUR_GRP"].ToString(),
                        COMMITTEDEXPENDITURE = CommittedExpenditure,
                        SPAREBUDGET = SpareBudget,
                        FY_YEAR = Currentfy.ToString(),
                        budgetCountOfDept = budgetCountOfDept,
                        BBPRList = bBPRList,
                        SCI_REMARKS = item["SCI_REMARKS"].ToString(),
                        //INDENT_QTY= Convert.ToDouble(item["INDENT_QTY"].ToString()),
                    };

                    newItem.SC_NAME = GetSCName(newItem.INDENT_ID);

                    ObjIndentDetails.Add(newItem);


                }
            }
            catch (Exception ex)
            {


            }

            return ObjIndentDetails;

        }

        public int UpdateShoppinCartName(string indentNo, string scName)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.ora_UpdateShoppinCartName;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add(":SCName", OracleDbType.Varchar2).Value = scName;
                    command.Parameters.Add(":INDENT_ID", OracleDbType.Int32).Value = Convert.ToInt32(indentNo);

                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public string GetSCName(int IndentId)
        {
            string SCName = null;
            OracleConnection connection = new OracleConnection(strConnSISDB);
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
            try
            {
                using (var command = new OracleCommand(DBConst.GetSCName, connection))
                {
                    command.Parameters.Add(new OracleParameter("INDENT_ID", IndentId));
                    using (var reader = command.ExecuteReader())
                    {

                        if (reader.Read())
                        {
                            SCName = reader["SCH_CART_NAME"] != DBNull.Value ? reader["SCH_CART_NAME"].ToString() : "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("Error in getting SC Name " + ex.Message.ToString());
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
            }

            return SCName;
        }

        public double CheckSCQty(double IndentQty, double SAP_DOC_QTY, double SC_QTY, int flag)
        {
            double ret = 0;
            if (flag > 0)
            {
                ret = IndentQty - SAP_DOC_QTY;
                if (ret < 0)
                { ret = 0; }
            }
            else { ret = SC_QTY; }
            return ret;
        }

        private double Get_budgetConsumptionFormDept_SIS(string dept)
        {
            double str = 0;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGet_budgetConsumptionFormDept_SIS, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            

                objConn.AddParameters(":sch_dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
                if (dtResult != null)
                {
                    str = Convert.ToDouble(dtResult.Rows[0]["TOTVAL"].ToString());
                }
            }
            catch { }

            return str;
        }

        private double Get_budgetConsumptionFormDept_EBuy(string dept)
        {
            double str = 0;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGet_budgetConsumptionFormDept_EBuy, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                //objConn.AddParameters(":sch_cart_no", sCNo);
                objConn.AddParameters(":sch_dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult != null)
                {
                    str = Convert.ToDouble(dtResult.Rows[0]["TOTVAL"].ToString());
                }

            }
            catch (Exception) { }

            return str;
        }

        //public string budgetConsumptionForDept(string dept)
        //{
        //    var client = new SIS_BACKEND_API.SI_OS_FetchBudgtbreakup.SI_OS_FetchBudgtbreakupService();

        //    client.Credentials = new System.Net.NetworkCredential("eprocpi", "sap@1234");

        //    var req = new List<DT_FetchBudgtbreakup_RequestRow>();
        //    var singleRec = new DT_FetchBudgtbreakup_RequestRow
        //    {
        //        DEPARTMENT = dept
        //    };
        //    req.Add(singleRec);

        //    // Call the service method
        //    DT_FetchBudgtbreakup_ResponseRecord[] response = client.SI_OS_FetchBudgtbreakup(req.ToArray());
        //    //var newlist = response.GroupBy(x => x.FIS_YR).Select(x => x.First()).ToList();
        //    //var newlist1 = response.GroupBy(x => x.DOC_TYPE == "PO").ToList();

        //    if (response.Length == 0)
        //    {
        //        return "0";
        //    }

        //    Dictionary<string, string> budgetBreakupDictionary = new Dictionary<string, string>();
        //    foreach (DT_FetchBudgtbreakup_ResponseRecord record in response)
        //    {
        //        string fetchBudValue = record.VALUE.ToString();
        //        string docTypeValue = record.DOC_TYPE;
        //        budgetBreakupDictionary.Add(docTypeValue, fetchBudValue);
        //    }
        //    double poValue = double.Parse(budgetBreakupDictionary["PO"]);
        //    double totalValue = double.Parse(budgetBreakupDictionary["TOTAL"]);
        //    double spareValue = double.Parse(budgetBreakupDictionary["SPAREBUDGT"]);

        //    double percent = (totalValue * 100) / spareValue;

        //    string budgetConsmptionPO = percent.ToString("0.000");
        //    return budgetConsmptionPO;
        //}

        public string RcmChecks(string SysReqDTT, string SysConsumDTT, string ChangeReqDTT, string changeConsumDTT)
        {
            bool SysReqcolor = false;
            bool SysConscolor = false;
            string ReturnColor = "";
            if (!String.IsNullOrEmpty(SysReqDTT) && !String.IsNullOrEmpty(SysConsumDTT))
            {
                DateTime ChangeReqDT = DateTime.Parse(ChangeReqDTT);
                DateTime SysReqDT = DateTime.Parse(SysReqDTT);
                DateTime changeConsumDT = DateTime.Parse(changeConsumDTT);
                DateTime SysConsumDT = DateTime.Parse(SysConsumDTT);
                DateTime changeReqDTThreeMnth = SysReqDT.AddDays(90);

                if (SysReqDT > ChangeReqDT) { SysReqcolor = false; }//false
                //else if (changeReqDTThreeMnth > ChangeReqDT) { Retrncolor = false; }//red
                if (SysReqDT < ChangeReqDT) { SysReqcolor = false; }//red
                if (SysReqDT == ChangeReqDT) { SysReqcolor = true; }//green

                if (SysConsumDT > changeConsumDT) { SysConscolor = true; }//green               
                if (SysConsumDT < changeConsumDT) { SysConscolor = false; }//red
                if (SysConsumDT == changeConsumDT) { SysConscolor = true; }//green

                if (SysReqcolor == false && SysConscolor == false) { ReturnColor = "TRUE"; }
                if (SysReqcolor == true && SysConscolor == false) { ReturnColor = "FALSE"; }
                if (SysReqcolor == false && SysConscolor == true) { ReturnColor = "FALSE"; }
                if (SysReqcolor == true && SysConscolor == true) { ReturnColor = "FALSE"; }
            }
            return ReturnColor;
        }

        public DataTable getbudgetDeptCount(string dept)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getbudgetDeptCount, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetIntelliBuyChecksDetailsFromId(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksDetailsFromId, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public DataTable GetIntelliBuyChecksHeaderAndItem(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksHeaderAndItem, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public int GetIntelliBuyChecksDetailsFromIndentId(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksDetailsFromINDENT_ID, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            if (dtResult.Rows.Count > 0) { return Convert.ToInt32(dtResult.Rows[0]["HEADER_ID"].ToString()); }
            else { return 0; }

        }

        #region GenrateShoppingCartAndInsertIntellibuy Func
        internal long SaveIntelliBuyDetailsAndGenrateSC(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            long returnresponse = 0;

            if (GetIntelliBuyChecksDetailsFromIndentId(header.INDENT_ID) > 0)
            {
                returnresponse = UpdateIntelliBuyCheckItemAndGenSC(header, items);
            }
            else
            {
                returnresponse = InsertIntelliBuyCheckItemAndGenSC(header, items);
            }
            return returnresponse;
        }


        internal long InsertIntelliBuyCheckItemAndGenSC(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int attachInsertCount = 0;
            long SCNO = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                string HeaderID = "0";

                try
                {
                    if (String.IsNullOrEmpty(header.SCH_CART_NO))
                    {
                        header.SCH_CART_NO = InserShoppingCart(header, items, transaction).ToString();
                        SCNO = Convert.ToInt64(header.SCH_CART_NO);
                    }
                    command.CommandText = DBConst.oraInsertIntelliBuyCheckHeader;
                    command.Parameters.Clear();

                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    command.Parameters.Add(":INDENTER_LOC", String.IsNullOrEmpty(header.INDENTER_LOC) ? String.Empty : header.INDENTER_LOC);
                    command.Parameters.Add(":INDENTOR_PLANT", header.INDENTOR_PLANT);
                    command.Parameters.Add(":INDENTER_DEPT", String.IsNullOrEmpty(header.INDENTER_DEPT) ? String.Empty : header.INDENTER_DEPT);
                    command.Parameters.Add(":INDENT_DESC", header.INDENT_DESC);
                    command.Parameters.Add(":INDENT_REMARKS", header.INDENT_REMARKS);
                    command.Parameters.Add(":CRT_BY", String.IsNullOrEmpty(header.INDENT_CRT_BY) ? String.Empty : header.INDENT_CRT_BY);
                    command.Parameters.Add(":INDENT_STATUS", String.IsNullOrEmpty(header.INDENT_STATUS) ? String.Empty : header.INDENT_STATUS);
                    command.Parameters.Add(":SCH_USR_NAME", header.SCH_USR_NAME);
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.Parameters.Add(":MAX_QTY_CHK", header.MAX_QTY_CHK);
                    command.Parameters.Add(":CONS_REQ_CHK", header.CONS_REQ_CHK);
                    command.Parameters.Add(":ARC_VMI_CHK", header.ARC_VMI_CHK);
                    command.Parameters.Add(":DEPROP_CHK", header.DEPROP_CHK);
                    command.Parameters.Add(":REF_CHK", header.REF_CHK);
                    command.Parameters.Add(":BBPR", header.BBPR);
                    command.ExecuteNonQuery();

                    HeaderID = GetMaxHeaderId().ToString();
                    if (HeaderID.All(char.IsDigit))
                    {
                        foreach (var objintelliBuyChecksItems in items)
                        {
                            if (!String.IsNullOrEmpty(header.HEADER_ID.ToString()))
                            {
                                command.Parameters.Clear();
                                command.CommandText = DBConst.oraInsertIntelliBuyCheckItem;
                                //command.Parameters.Add(":ITEM_ID", objintelliBuyChecksItems); 27
                                command.Parameters.Add(":HEADERID", HeaderID);
                                command.Parameters.Add(":INDENT_ID", objintelliBuyChecksItems.INDENT_ID);
                                command.Parameters.Add(":SCI_MATL_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":EXISTING_UMC", objintelliBuyChecksItems.REQ_UMC_NO);
                                command.Parameters.Add(":EXISTING_UMC_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":SCI_MATL_GROUP", "");
                                command.Parameters.Add(":SCI_PROD_TYPE", "01");
                                command.Parameters.Add(":SCI_PLANT_CD", objintelliBuyChecksItems.INDENTOR_PLANT);
                                command.Parameters.Add(":SCI_STRG_LOC", "");
                                command.Parameters.Add(":SCI_PUR_GROUP", objintelliBuyChecksItems.PUR_GROUP);
                                command.Parameters.Add(":SCI_DOC_TYPE", objintelliBuyChecksItems.DOCUMENT_TYPE);
                                command.Parameters.Add(":SCI_QTY", objintelliBuyChecksItems.SC_QTY);
                                command.Parameters.Add(":SCI_QTY_UNIT", objintelliBuyChecksItems.UOM);
                                command.Parameters.Add(":SCI_PRICE", objintelliBuyChecksItems.PRICE_PER_ITEM);
                                command.Parameters.Add(":SCI_FRN_CURR_CD", objintelliBuyChecksItems.CURRENCY);
                                command.Parameters.Add(":SCI_REQD_ON_DT", Convert.ToDateTime(objintelliBuyChecksItems.REQUIREMENT_DATE).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.CONSUMP_DT).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SCI_STATUS", "");
                                command.Parameters.Add(":SCI_DEL_IND", "");
                                command.Parameters.Add(":SCI_SAP_ERR_MSG", "");
                                command.Parameters.Add(":SCI_PROP_TAG", "");
                                command.Parameters.Add(":SCI_REFFB_TAG", "");
                                command.Parameters.Add(":SCI_PERISIBL_TAG", "");
                                command.Parameters.Add(":SCI_SPARE_CAT", "");
                                command.Parameters.Add(":SCI_REMARKS", objintelliBuyChecksItems.SCI_REMARKS);
                                command.Parameters.Add(":IS_ACTIVE", "Y");
                                command.Parameters.Add(":CRT_BY", header.INDENT_CRT_BY);
                                //command.Parameters.Add(":MOD_BY", "");
                                command.Parameters.Add(":MAX_QTY", objintelliBuyChecksItems.MaxQty);
                                command.Parameters.Add(":USER_REMARKS_MAXQTY", objintelliBuyChecksItems.USER_REMARKS_MAXQTY);
                                command.Parameters.Add(":USER_REMARKS_RCM", objintelliBuyChecksItems.USER_REMARKS_RCM);
                                command.Parameters.Add(":SYS_CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.ConsDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SYS_REQ_DATE", Convert.ToDateTime(objintelliBuyChecksItems.ReqDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":RCM_STATUS", objintelliBuyChecksItems.RCM_STATUS);
                                command.Parameters.Add(":MAXQTY_STATUS", MAXQTY_Status(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty, objintelliBuyChecksItems.SC_QTY));
                                command.Parameters.Add(":PIPELINE_QTY", objintelliBuyChecksItems.PipelineQty);
                                command.Parameters.Add(":REFURBISHED_QTY", objintelliBuyChecksItems.RefurQty);
                                command.Parameters.Add(":CHARGEDOUT_QTY", objintelliBuyChecksItems.ChargeQty);
                                command.Parameters.Add(":ALLOWED_QTY", calculateAllowedQuantity(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty));
                                command.Parameters.Add(":VMIARC_STATUS", (objintelliBuyChecksItems.ARC_VMI == "FALSE" || objintelliBuyChecksItems.DOCUMENT_TYPE == "RO" ? "true" : "false"));// objintelliBuyChecksItems.VMIARC_STATUS);
                                command.Parameters.Add(":REFURSHIBILITY_STATUS", (objintelliBuyChecksItems.IS_REFURBISHABLE == "R" ? "false" : "true"));// objintelliBuyChecksItems.REFURSHIBILITY_STATUS);
                                command.Parameters.Add(":DEPROP_STATUS", (objintelliBuyChecksItems.DOCUMENT_TYPE == "NP" ? "false" : "true")); //objintelliBuyChecksItems.DEPROP_STATUS);

                                attachInsertCount = command.ExecuteNonQuery();
                            }
                        }
                    }
                    command.CommandText = DBConst.UpdateStatus;
                    command.Parameters.Clear();
                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    command.ExecuteNonQuery();
                    //else { attachInsertCount = BasicId; }




                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return SCNO;
        }

        internal int UpdateIntelliBuyCheckItemAndGenSC(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int attachInsertCount = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                string HeaderID = "0";
                try
                {
                    if (String.IsNullOrEmpty(header.SCH_CART_NO))
                    {
                        header.SCH_CART_NO = InserShoppingCart(header, items, transaction).ToString();
                    }
                    command.CommandText = DBConst.oraUpdateIntelliBuyCheckHeader;
                    command.Parameters.Clear();


                    command.Parameters.Add(":INDENTER_LOC", String.IsNullOrEmpty(header.INDENTER_LOC) ? String.Empty : header.INDENTER_LOC);
                    command.Parameters.Add(":INDENTOR_PLANT", Convert.ToInt64(header.INDENTOR_PLANT));
                    command.Parameters.Add(":INDENTER_DEPT", String.IsNullOrEmpty(header.INDENTER_DEPT) ? String.Empty : header.INDENTER_DEPT);
                    command.Parameters.Add(":INDENT_DESC", header.INDENT_DESC);
                    command.Parameters.Add(":INDENT_REMARKS", header.INDENT_REMARKS);
                    command.Parameters.Add(":CRT_BY", String.IsNullOrEmpty(header.INDENT_CRT_BY) ? String.Empty : header.INDENT_CRT_BY);
                    command.Parameters.Add(":INDENT_STATUS", String.IsNullOrEmpty(header.INDENT_STATUS) ? String.Empty : header.INDENT_STATUS);
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.Parameters.Add(":SCH_USR_NAME", header.SCH_USR_NAME);
                    command.Parameters.Add(":ISACTIVE", header.ISACTIVE);
                    command.Parameters.Add(":MAX_QTY_CHK", header.MAX_QTY_CHK);
                    command.Parameters.Add(":CONS_REQ_CHK", header.CONS_REQ_CHK);
                    command.Parameters.Add(":ARC_VMI_CHK", header.ARC_VMI_CHK);
                    command.Parameters.Add(":DEPROP_CHK", header.DEPROP_CHK);
                    command.Parameters.Add(":REF_CHK", header.REF_CHK);
                    command.Parameters.Add(":BBPR", header.BBPR);
                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    int i = command.ExecuteNonQuery();

                    HeaderID = GetIntelliBuyChecksDetailsFromIndentId(header.INDENT_ID).ToString();
                    if (HeaderID.All(char.IsDigit))
                    {
                        foreach (var objintelliBuyChecksItems in items)
                        {
                            if (!String.IsNullOrEmpty(header.HEADER_ID.ToString()))
                            {
                                command.Parameters.Clear();
                                command.CommandText = DBConst.oraUpdateIntelliBuyCheckItem;

                                //command.Parameters.Add(":HEADERID", HeaderID);                          
                                command.Parameters.Add(":SCI_MATL_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":EXISTING_UMC_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":SCI_MATL_GROUP", "");
                                command.Parameters.Add(":SCI_PROD_TYPE", "");
                                command.Parameters.Add(":SCI_PLANT_CD",
                                objintelliBuyChecksItems.INDENTOR_PLANT);
                                command.Parameters.Add(":SCI_STRG_LOC", "");
                                command.Parameters.Add(":SCI_PUR_GROUP", objintelliBuyChecksItems.PUR_GROUP);
                                command.Parameters.Add(":SCI_DOC_TYPE", objintelliBuyChecksItems.DOCUMENT_TYPE);
                                command.Parameters.Add(":SCI_QTY", objintelliBuyChecksItems.SC_QTY);
                                command.Parameters.Add(":SCI_QTY_UNIT", objintelliBuyChecksItems.UOM);
                                command.Parameters.Add(":SCI_PRICE", objintelliBuyChecksItems.PRICE_PER_ITEM);
                                command.Parameters.Add(":SCI_FRN_CURR_CD", objintelliBuyChecksItems.CURRENCY);
                                command.Parameters.Add(":SCI_REQD_ON_DT", Convert.ToDateTime(objintelliBuyChecksItems.REQUIREMENT_DATE).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.CONSUMP_DT).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SCI_STATUS", "");
                                command.Parameters.Add(":SCI_DEL_IND", "");
                                command.Parameters.Add(":SCI_SAP_ERR_MSG", "");
                                command.Parameters.Add(":SCI_PROP_TAG", "");
                                command.Parameters.Add(":SCI_REFFB_TAG", "");
                                command.Parameters.Add(":SCI_PERISIBL_TAG", "");
                                command.Parameters.Add(":SCI_SPARE_CAT", "");
                                command.Parameters.Add(":SCI_REMARKS", objintelliBuyChecksItems.SCI_REMARKS);
                                command.Parameters.Add(":IS_ACTIVE", objintelliBuyChecksItems.ISACTIVE);
                                command.Parameters.Add(":CRT_BY", header.INDENT_CRT_BY);
                                command.Parameters.Add(":MAX_QTY", objintelliBuyChecksItems.MaxQty);
                                command.Parameters.Add(":USER_REMARKS_MAXQTY", objintelliBuyChecksItems.USER_REMARKS_MAXQTY);
                                command.Parameters.Add(":USER_REMARKS_RCM", objintelliBuyChecksItems.USER_REMARKS_RCM);
                                command.Parameters.Add(":SYS_CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.ConsDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SYS_REQ_DATE", Convert.ToDateTime(objintelliBuyChecksItems.ReqDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":RCM_STATUS", objintelliBuyChecksItems.RCM_STATUS);
                                command.Parameters.Add(":MAXQTY_STATUS", MAXQTY_Status(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty, objintelliBuyChecksItems.SC_QTY));
                                command.Parameters.Add(":PIPELINE_QTY", objintelliBuyChecksItems.PipelineQty);
                                command.Parameters.Add(":REFURBISHED_QTY", objintelliBuyChecksItems.RefurQty);
                                command.Parameters.Add(":CHARGEDOUT_QTY", objintelliBuyChecksItems.ChargeQty);
                                command.Parameters.Add(":ALLOWED_QTY", calculateAllowedQuantity(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty));
                                command.Parameters.Add(":VMIARC_STATUS", (objintelliBuyChecksItems.ARC_VMI == "FALSE" || objintelliBuyChecksItems.DOCUMENT_TYPE == "RO" ? "true" : "false"));// objintelliBuyChecksItems.VMIARC_STATUS);
                                command.Parameters.Add(":REFURSHIBILITY_STATUS", (objintelliBuyChecksItems.IS_REFURBISHABLE == "R" ? "false" : "true"));// objintelliBuyChecksItems.REFURSHIBILITY_STATUS);
                                command.Parameters.Add(":DEPROP_STATUS", (objintelliBuyChecksItems.DOCUMENT_TYPE == "NP" ? "false" : "true")); //objintelliBuyChecksItems.DEPROP_STATUS);

                                command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                                command.Parameters.Add(":EXISTING_UMC", objintelliBuyChecksItems.REQ_UMC_NO);
                                attachInsertCount = command.ExecuteNonQuery();

                            }
                        }
                    }
                    command.CommandText = DBConst.UpdateStatus;
                    command.Parameters.Clear();
                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    command.ExecuteNonQuery();
                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }
        #endregion

        #region SaveIntelliBuy Func
        internal int SaveIntelliBuyDetails(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int returnresponse = 0;

            if (GetIntelliBuyChecksDetailsFromIndentId(header.INDENT_ID) > 0)
            {
                returnresponse = UpdateIntelliBuyCheckItem(header, items);
            }
            else
            {
                returnresponse = InsertIntelliBuyCheckItem(header, items);
            }
            DataTable dt = GetIntelliBuyItem(header.INDENT_ID);
            if (dt.Rows.Count == 0)
            {
                UpdateIndentStatus(header.INDENT_ID, "45", header.INDENT_CRT_BY);
                returnresponse = 45;
            }

            return returnresponse;
        }
        internal int InsertIntelliBuyCheckItem(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int attachInsertCount = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                string HeaderID = "0";
                long SCNO = 0;
                try
                {

                    command.CommandText = DBConst.oraInsertIntelliBuyCheckHeader;
                    command.Parameters.Clear();

                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    command.Parameters.Add(":INDENTER_LOC", String.IsNullOrEmpty(header.INDENTER_LOC) ? String.Empty : header.INDENTER_LOC);
                    command.Parameters.Add(":INDENTOR_PLANT", header.INDENTOR_PLANT);
                    command.Parameters.Add(":INDENTER_DEPT", String.IsNullOrEmpty(header.INDENTER_DEPT) ? String.Empty : header.INDENTER_DEPT);
                    command.Parameters.Add(":INDENT_DESC", header.INDENT_DESC);
                    command.Parameters.Add(":INDENT_REMARKS", header.INDENT_REMARKS);
                    command.Parameters.Add(":CRT_BY", String.IsNullOrEmpty(header.INDENT_CRT_BY) ? String.Empty : header.INDENT_CRT_BY);
                    command.Parameters.Add(":INDENT_STATUS", String.IsNullOrEmpty(header.INDENT_STATUS) ? String.Empty : header.INDENT_STATUS);
                    command.Parameters.Add(":SCH_USR_NAME", header.SCH_USR_NAME);
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.Parameters.Add(":MAX_QTY_CHK", header.MAX_QTY_CHK);
                    command.Parameters.Add(":CONS_REQ_CHK", header.CONS_REQ_CHK);
                    command.Parameters.Add(":ARC_VMI_CHK", header.ARC_VMI_CHK);
                    command.Parameters.Add(":DEPROP_CHK", header.DEPROP_CHK);
                    command.Parameters.Add(":REF_CHK", header.REF_CHK);
                    command.Parameters.Add(":BBPR", header.BBPR);
                    command.ExecuteNonQuery();

                    HeaderID = GetMaxHeaderId().ToString();
                    if (HeaderID.All(char.IsDigit))
                    {
                        foreach (var objintelliBuyChecksItems in items)
                        {
                            if (!String.IsNullOrEmpty(header.HEADER_ID.ToString()))
                            {
                                command.Parameters.Clear();
                                command.CommandText = DBConst.oraInsertIntelliBuyCheckItem;
                                //command.Parameters.Add(":ITEM_ID", objintelliBuyChecksItems); 27
                                command.Parameters.Add(":HEADERID", HeaderID);
                                command.Parameters.Add(":INDENT_ID", objintelliBuyChecksItems.INDENT_ID);
                                command.Parameters.Add(":SCI_MATL_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":EXISTING_UMC", objintelliBuyChecksItems.REQ_UMC_NO);
                                command.Parameters.Add(":EXISTING_UMC_DESC", "");
                                command.Parameters.Add(":SCI_MATL_GROUP", "");
                                command.Parameters.Add(":SCI_PROD_TYPE", "");
                                command.Parameters.Add(":SCI_PLANT_CD", objintelliBuyChecksItems.INDENTOR_PLANT);
                                command.Parameters.Add(":SCI_STRG_LOC", "");
                                command.Parameters.Add(":SCI_PUR_GROUP", objintelliBuyChecksItems.PUR_GROUP);
                                command.Parameters.Add(":SCI_DOC_TYPE", objintelliBuyChecksItems.DOCUMENT_TYPE);
                                command.Parameters.Add(":SCI_QTY", objintelliBuyChecksItems.SC_QTY);
                                command.Parameters.Add(":SCI_QTY_UNIT", objintelliBuyChecksItems.UOM);
                                command.Parameters.Add(":SCI_PRICE", objintelliBuyChecksItems.PRICE_PER_ITEM);
                                command.Parameters.Add(":SCI_FRN_CURR_CD", objintelliBuyChecksItems.CURRENCY);
                                command.Parameters.Add(":SCI_REQD_ON_DT", Convert.ToDateTime(objintelliBuyChecksItems.REQUIREMENT_DATE).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.CONSUMP_DT).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SCI_STATUS", "");
                                command.Parameters.Add(":SCI_DEL_IND", "");
                                command.Parameters.Add(":SCI_SAP_ERR_MSG", "");
                                command.Parameters.Add(":SCI_PROP_TAG", "");
                                command.Parameters.Add(":SCI_REFFB_TAG", "");
                                command.Parameters.Add(":SCI_PERISIBL_TAG", "");
                                command.Parameters.Add(":SCI_SPARE_CAT", "");
                                command.Parameters.Add(":SCI_REMARKS", objintelliBuyChecksItems.SCI_REMARKS);
                                command.Parameters.Add(":IS_ACTIVE", objintelliBuyChecksItems.ISACTIVE);
                                command.Parameters.Add(":CRT_BY", header.INDENT_CRT_BY);
                                //command.Parameters.Add(":MOD_BY", "");
                                command.Parameters.Add(":MAX_QTY", objintelliBuyChecksItems.MaxQty);
                                command.Parameters.Add(":USER_REMARKS_MAXQTY", objintelliBuyChecksItems.USER_REMARKS_MAXQTY);
                                command.Parameters.Add(":USER_REMARKS_RCM", objintelliBuyChecksItems.USER_REMARKS_RCM);
                                command.Parameters.Add(":SYS_CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.ConsDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SYS_REQ_DATE", Convert.ToDateTime(objintelliBuyChecksItems.ReqDate).ToString("dd-MMM-yyyy"));

                                command.Parameters.Add(":RCM_STATUS", objintelliBuyChecksItems.RCM_STATUS);
                                command.Parameters.Add(":MAXQTY_STATUS", MAXQTY_Status(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty, objintelliBuyChecksItems.SC_QTY));
                                command.Parameters.Add(":PIPELINE_QTY", objintelliBuyChecksItems.PipelineQty);
                                command.Parameters.Add(":REFURBISHED_QTY", objintelliBuyChecksItems.RefurQty);
                                command.Parameters.Add(":CHARGEDOUT_QTY", objintelliBuyChecksItems.ChargeQty);
                                command.Parameters.Add(":ALLOWED_QTY", calculateAllowedQuantity(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty));
                                command.Parameters.Add(":VMIARC_STATUS", (objintelliBuyChecksItems.ARC_VMI == "FALSE" || objintelliBuyChecksItems.DOCUMENT_TYPE == "RO" ? "true" : "false"));// objintelliBuyChecksItems.VMIARC_STATUS);
                                command.Parameters.Add(":REFURSHIBILITY_STATUS", (objintelliBuyChecksItems.IS_REFURBISHABLE == "R" ? "false" : "true"));// objintelliBuyChecksItems.REFURSHIBILITY_STATUS);
                                command.Parameters.Add(":DEPROP_STATUS", (objintelliBuyChecksItems.DOCUMENT_TYPE == "NP" ? "false" : "true")); //objintelliBuyChecksItems.DEPROP_STATUS);


                                attachInsertCount = command.ExecuteNonQuery();
                            }
                        }
                    }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }

        internal int UpdateIntelliBuyCheckItem(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items)
        {
            int attachInsertCount = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                string HeaderID = "0";
                try
                {
                    command.CommandText = DBConst.oraUpdateIntelliBuyCheckHeader;
                    command.Parameters.Clear();


                    command.Parameters.Add(":INDENTER_LOC", String.IsNullOrEmpty(header.INDENTER_LOC) ? String.Empty : header.INDENTER_LOC);
                    command.Parameters.Add(":INDENTOR_PLANT", Convert.ToInt64(header.INDENTOR_PLANT));
                    command.Parameters.Add(":INDENTER_DEPT", String.IsNullOrEmpty(header.INDENTER_DEPT) ? String.Empty : header.INDENTER_DEPT);
                    command.Parameters.Add(":INDENT_DESC", header.INDENT_DESC);
                    command.Parameters.Add(":INDENT_REMARKS", header.INDENT_REMARKS);
                    command.Parameters.Add(":CRT_BY", String.IsNullOrEmpty(header.INDENT_CRT_BY) ? String.Empty : header.INDENT_CRT_BY);
                    command.Parameters.Add(":INDENT_STATUS", String.IsNullOrEmpty(header.INDENT_STATUS) ? String.Empty : header.INDENT_STATUS);
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.Parameters.Add(":SCH_USR_NAME", header.SCH_USR_NAME);
                    command.Parameters.Add(":ISACTIVE", header.ISACTIVE);
                    command.Parameters.Add(":MAX_QTY_CHK", header.MAX_QTY_CHK);
                    command.Parameters.Add(":CONS_REQ_CHK", header.CONS_REQ_CHK);
                    command.Parameters.Add(":ARC_VMI_CHK", header.ARC_VMI_CHK);
                    command.Parameters.Add(":DEPROP_CHK", header.DEPROP_CHK);
                    command.Parameters.Add(":REF_CHK", header.REF_CHK);
                    command.Parameters.Add(":BBPR", header.BBPR);
                    command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                    int i = command.ExecuteNonQuery();

                    HeaderID = GetIntelliBuyChecksDetailsFromIndentId(header.INDENT_ID).ToString();
                    if (HeaderID.All(char.IsDigit))
                    {
                        foreach (var objintelliBuyChecksItems in items)
                        {
                            if (!String.IsNullOrEmpty(header.HEADER_ID.ToString()))
                            {
                                command.Parameters.Clear();
                                command.CommandText = DBConst.oraUpdateIntelliBuyCheckItem;

                                //command.Parameters.Add(":HEADERID", HeaderID);                          
                                command.Parameters.Add(":SCI_MATL_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);

                                command.Parameters.Add(":EXISTING_UMC_DESC", objintelliBuyChecksItems.REQ_UMC_DESC);
                                command.Parameters.Add(":SCI_MATL_GROUP", "");
                                command.Parameters.Add(":SCI_PROD_TYPE", "");
                                command.Parameters.Add(":SCI_PLANT_CD",
                                objintelliBuyChecksItems.INDENTOR_PLANT);
                                command.Parameters.Add(":SCI_STRG_LOC", "");
                                command.Parameters.Add(":SCI_PUR_GROUP", objintelliBuyChecksItems.PUR_GROUP);
                                command.Parameters.Add(":SCI_DOC_TYPE", objintelliBuyChecksItems.DOCUMENT_TYPE);
                                command.Parameters.Add(":SCI_QTY", objintelliBuyChecksItems.SC_QTY);
                                command.Parameters.Add(":SCI_QTY_UNIT", objintelliBuyChecksItems.UOM);
                                command.Parameters.Add(":SCI_PRICE", objintelliBuyChecksItems.PRICE_PER_ITEM);
                                command.Parameters.Add(":SCI_FRN_CURR_CD", objintelliBuyChecksItems.CURRENCY);
                                command.Parameters.Add(":SCI_REQD_ON_DT", Convert.ToDateTime(objintelliBuyChecksItems.REQUIREMENT_DATE).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.CONSUMP_DT).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SCI_STATUS", "");
                                command.Parameters.Add(":SCI_DEL_IND", "");
                                command.Parameters.Add(":SCI_SAP_ERR_MSG", "");
                                command.Parameters.Add(":SCI_PROP_TAG", "");
                                command.Parameters.Add(":SCI_REFFB_TAG", "");
                                command.Parameters.Add(":SCI_PERISIBL_TAG", "");
                                command.Parameters.Add(":SCI_SPARE_CAT", "");
                                command.Parameters.Add(":SCI_REMARKS", objintelliBuyChecksItems.SCI_REMARKS);
                                command.Parameters.Add(":IS_ACTIVE", objintelliBuyChecksItems.ISACTIVE);
                                command.Parameters.Add(":CRT_BY", header.INDENT_CRT_BY);
                                command.Parameters.Add(":MAX_QTY", objintelliBuyChecksItems.MaxQty);
                                command.Parameters.Add(":USER_REMARKS_MAXQTY", objintelliBuyChecksItems.USER_REMARKS_MAXQTY);
                                command.Parameters.Add(":USER_REMARKS_RCM", objintelliBuyChecksItems.USER_REMARKS_RCM);
                                command.Parameters.Add(":SYS_CONSUMP_DT", Convert.ToDateTime(objintelliBuyChecksItems.ConsDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":SYS_REQ_DATE", Convert.ToDateTime(objintelliBuyChecksItems.ReqDate).ToString("dd-MMM-yyyy"));
                                command.Parameters.Add(":RCM_STATUS", objintelliBuyChecksItems.RCM_STATUS);
                                command.Parameters.Add(":MAXQTY_STATUS", MAXQTY_Status(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty, objintelliBuyChecksItems.SC_QTY));
                                command.Parameters.Add(":PIPELINE_QTY", objintelliBuyChecksItems.PipelineQty);
                                command.Parameters.Add(":REFURBISHED_QTY", objintelliBuyChecksItems.RefurQty);
                                command.Parameters.Add(":CHARGEDOUT_QTY", objintelliBuyChecksItems.ChargeQty);
                                command.Parameters.Add(":ALLOWED_QTY", calculateAllowedQuantity(objintelliBuyChecksItems.MaxQty, objintelliBuyChecksItems.PipelineQty, objintelliBuyChecksItems.RefurQty, objintelliBuyChecksItems.ChargeQty));
                                command.Parameters.Add(":VMIARC_STATUS", (objintelliBuyChecksItems.ARC_VMI == "FALSE" || objintelliBuyChecksItems.DOCUMENT_TYPE == "RO" ? "true" : "false"));// objintelliBuyChecksItems.VMIARC_STATUS);
                                command.Parameters.Add(":REFURSHIBILITY_STATUS", (objintelliBuyChecksItems.IS_REFURBISHABLE == "R" ? "false" : "true"));// objintelliBuyChecksItems.REFURSHIBILITY_STATUS);
                                command.Parameters.Add(":DEPROP_STATUS", (objintelliBuyChecksItems.DOCUMENT_TYPE == "NP" ? "false" : "true")); //objintelliBuyChecksItems.DEPROP_STATUS);
                                command.Parameters.Add(":INDENT_ID", header.INDENT_ID);
                                command.Parameters.Add(":EXISTING_UMC", objintelliBuyChecksItems.REQ_UMC_NO);



                                attachInsertCount = command.ExecuteNonQuery();
                            }
                        }
                    }
                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }
        #endregion

        public int calculateAllowedQuantity(double maxQty, double pipelineQty, double refurQty, double chargeQty)
        {
            int quantity = Convert.ToInt32(maxQty - (pipelineQty + refurQty + chargeQty));
            if (quantity < 0)
            {
                quantity = 0;
            }
            return quantity;
        }

        public int GetMaxHeaderId()
        {
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                int RntVal = 0;
                try
                {
                    using (OracleCommand command = new OracleCommand(DBConst.oraGetMaxHeaderID, connection))
                    {

                        int maxId = Convert.ToInt32(command.ExecuteScalar());


                        RntVal = maxId;

                    }


                    return RntVal;
                }
                catch (Exception ex)
                {
                    return RntVal;
                }
            }

            // Check the number of rows affected

        }



        public void UpdateStatusForIndId(string indId, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            string query = DBConst.UpdateStatus;

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":INDENT_ID", indId);



                command.ExecuteNonQuery();
            }
        }





        public string MAXQTY_Status(double maxQty, double pipelineQty, double refurQty, double chargeQty, double SC_QTY)
        {
            double quantity = maxQty - (pipelineQty + refurQty + chargeQty);
            string FlagStatus = (quantity < SC_QTY) ? "false" : "true";
            return FlagStatus;
        }


        public int DeleteIntellibuyItem(string indentNo, string umcno)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.ora_DeleteIntellibuyItem;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add(":INDENT_ID", OracleDbType.Varchar2).Value = indentNo;
                    command.Parameters.Add(":EXISTING_UMC", OracleDbType.Varchar2).Value = umcno;

                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public int DeleteShoppingCartItem(string indentNo, string umcno)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.CommandText = DBConst.ora_UpdateSCItemDeleteStatus;
                    command.Parameters.Clear();
                    command.Parameters.Add(":INDENT_ID", indentNo);
                    command.Parameters.Add(":SCI_MATL_NO", umcno);
                    command.ExecuteNonQuery();
                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }


        public DataTable GetIntelliBuyItem(string indentNo)
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetIntelliBuyItemStatus, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", indentNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int UpdateIndentStatus(string indentNo, string satus, string userid)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.UpdateIndentStatus;
                    command.CommandType = CommandType.Text;
                    // Input parameters

                    command.Parameters.Add(":INDENT_CURRENT_STATUS", satus);
                    command.Parameters.Add(":MODBY", userid);
                    command.Parameters.Add(":INDENT_ID", indentNo);

                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }


        #region ODATA 
        public async Task<string> Get_ReqConsum_ODATA(string UMCNO, string PurGrp, string Plant)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            string apiUrl = BaseURL + "opu/odata/sap/YMPI_INDENT_ARC_VMI_SRV/GetReqDateSet?$filter=( Material eq '" + UMCNO + "' and PurGrp eq '" + PurGrp + "' and Plant eq '" + Plant + "' )&$format=json";
            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }

        public async Task<string> Get_budgetConsumptionFormDept_ODATA(string Dept, double Budget_SIS, double Budget_Ebuy)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            string apiUrl = BaseURL + "opu/odata/sap/YMPI_BUDGET_DETAILS_SRV/BUDGET_detailSet?$filter=( Department eq '" + Dept + "' )&$format=json";
            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();

                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }


        public async Task<string> Get_MaxQtyConsume_ODATA(string UMCNO, string PurGrp, string Plant, string dept)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];

            string apiUrl = BaseURL + "opu/odata/sap/YMPI_MAX_QNTY_SRV/HeaderSet?$filter=(InputMaterial eq '" + UMCNO + "' and Department eq '" + dept + "' and PurGrp eq '" + PurGrp + "' and Plant eq '" + Plant + "' )&$expand=HeaderToItem&$format=json";


            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }

        public string GetCurrentIndentStatus(string indentNo)
        {
            string Status = "0";
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetCurrentIndentStatus, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                objConn.AddParameters(":INDENT_ID", indentNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult.Rows.Count > 0)
                {
                    Status = dtResult.Rows[0]["INDENT_STATUS"].ToString();
                }


            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return Status;
        }

        #endregion

        #region ShoppingCart

        public long InserShoppingCart(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items, OracleTransaction transaction)
        {
            int attachInsertCount = 0;
            long SCCartNo = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                int Count = 0;

                try
                {
                    SCCartNo = GetMaxSCCARTNO();
                    command.Parameters.Clear();
                    command.CommandText = "pkg_crt_sc_sis.pcs_insert_sc_hdr";
                    command.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    command.Parameters.Add("v_sch_cart_no", OracleDbType.Int64).Value = SCCartNo;
                    command.Parameters.Add("V_SCH_CART_NAME", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_CRT_ID", OracleDbType.Varchar2).Value = header.SCH_USR_NAME;
                    command.Parameters.Add("N_SCH_TOT_VAL", OracleDbType.Int32).Value = "0";
                    command.Parameters.Add("V_SCH_VAL_UNIT", OracleDbType.Varchar2).Value = "INR";
                    command.Parameters.Add("V_SCH_STATUS", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_NOTE_APP", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("v_sch_upd_id", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_INDT_TYP", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_COMP_CD", OracleDbType.Varchar2).Value = "1000";
                    command.Parameters.Add("N_SCH_APPR_LVL", OracleDbType.Int32).Value = "1";
                    command.Parameters.Add("v_sch_dept", OracleDbType.Varchar2).Value = header.INDENTER_DEPT;
                    // Output parameter
                    OracleParameter outputParam = new OracleParameter("err_msg", OracleDbType.Varchar2);
                    outputParam.Direction = ParameterDirection.Output;
                    outputParam.Size = 500; // Adjust size as per your requirement
                    command.Parameters.Add(outputParam);
                    int i = command.ExecuteNonQuery();
                    string result = command.Parameters["err_msg"].Value.ToString();

                    var activeItems = items.Where(item => item.ISACTIVE == "Y").ToList();

                    foreach (var objintelliBuyChecksItems in activeItems)
                    {
                        Count++;
                        if (!String.IsNullOrEmpty(SCCartNo.ToString()))
                        {
                            command.Parameters.Clear();

                            command.CommandText = "pkg_crt_sc_sis.pcs_insert_sc_item_mat";
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.Add("n_sci_cart_no", OracleDbType.Int64).Value = SCCartNo;
                            command.Parameters.Add("N_SCI_ITEM_NO", OracleDbType.Int32).Value = Count;
                            command.Parameters.Add("V_SCI_ITEM_DESC", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.REQ_UMC_DESC;
                            command.Parameters.Add("V_SCI_PROD_TYPE", OracleDbType.Varchar2).Value = "Goods";
                            command.Parameters.Add("V_SCI_MATL_NO", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.REQ_UMC_NO;
                            command.Parameters.Add("V_SCI_MATL_GRP", OracleDbType.Varchar2).Value = "";
                            command.Parameters.Add("V_SCI_PLANT_CD", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.INDENTOR_PLANT;
                            command.Parameters.Add("N_SCI_QTY", OracleDbType.Int32).Value = objintelliBuyChecksItems.QTY;
                            command.Parameters.Add("V_SCI_QTY_UNIT", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.UOM;
                            command.Parameters.Add("d_rqdt_on", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.REQUIREMENT_DATE;
                            //command.Parameters.Add("err_msg", OracleDbType.Varchar2, 32000).Direction = ParameterDirection.Output;
                            // Output parameter
                            OracleParameter outputParamitem = new OracleParameter("err_msg", OracleDbType.Varchar2);
                            outputParamitem.Direction = ParameterDirection.Output;
                            outputParamitem.Size = 500; // Adjust size as per your requirement
                            command.Parameters.Add(outputParamitem);
                            attachInsertCount = command.ExecuteNonQuery();
                        }
                    }

                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return SCCartNo;
        }
        public long UpdateShoppingCart(IntelliBuyChecksHeader header, List<IntelliBuyIndentDetails> items, OracleTransaction transaction)
        {
            int attachInsertCount = 0;
            long SCCartNo = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                int Count = 0;

                try
                {

                    command.Parameters.Clear();
                    command.CommandText = "pkg_crt_sc_sis.pcs_update_sc_hdr";
                    command.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    command.Parameters.Add("v_sch_cart_no", OracleDbType.Int64).Value = SCCartNo;
                    command.Parameters.Add("V_SCH_CART_NAME", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_CRT_ID", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("N_SCH_TOT_VAL", OracleDbType.Int32).Value = "0";
                    command.Parameters.Add("V_SCH_VAL_UNIT", OracleDbType.Varchar2).Value = "INR";
                    command.Parameters.Add("V_SCH_STATUS", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_NOTE_APP", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("v_sch_upd_id", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_INDT_TYP", OracleDbType.Varchar2).Value = "";
                    command.Parameters.Add("V_SCH_COMP_CD", OracleDbType.Varchar2).Value = "1000";
                    command.Parameters.Add("N_SCH_APPR_LVL", OracleDbType.Int32).Value = "1";
                    command.Parameters.Add("v_sch_dept", OracleDbType.Varchar2).Value = "";
                    // Output parameter
                    OracleParameter outputParam = new OracleParameter("err_msg", OracleDbType.Varchar2);
                    outputParam.Direction = ParameterDirection.Output;
                    outputParam.Size = 500; // Adjust size as per your requirement
                    command.Parameters.Add(outputParam);
                    int i = command.ExecuteNonQuery();
                    string result = command.Parameters["err_msg"].Value.ToString();
                    var activeItems = items.Where(item => item.ISACTIVE == "Y").ToList();
                    foreach (var objintelliBuyChecksItems in activeItems)
                    {
                        Count++;
                        if (!String.IsNullOrEmpty(SCCartNo.ToString()))
                        {
                            command.Parameters.Clear();

                            command.CommandText = "pkg_crt_sc_sis.pcs_update_sc_item";
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.Add("n_sci_cart_no", OracleDbType.Int64).Value = SCCartNo;
                            command.Parameters.Add("N_SCI_ITEM_NO", OracleDbType.Int32).Value = Count;
                            command.Parameters.Add("V_SCI_ITEM_DESC", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.INDENT_DESC;
                            command.Parameters.Add("V_SCI_PROD_TYPE", OracleDbType.Varchar2).Value = "Goods";
                            command.Parameters.Add("V_SCI_MATL_NO", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.REQ_UMC_NO;
                            command.Parameters.Add("V_SCI_MATL_GRP", OracleDbType.Varchar2).Value = "";
                            command.Parameters.Add("V_SCI_PLANT_CD", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.INDENTOR_PLANT;
                            command.Parameters.Add("N_SCI_QTY", OracleDbType.Int32).Value = objintelliBuyChecksItems.QTY;
                            command.Parameters.Add("V_SCI_QTY_UNIT", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.UOM;
                            command.Parameters.Add("d_rqdt_on", OracleDbType.Varchar2).Value = objintelliBuyChecksItems.REQUIREMENT_DATE;
                            command.Parameters.Add("err_msg", OracleDbType.Varchar2, 32000).Direction = ParameterDirection.Output;

                            attachInsertCount = command.ExecuteNonQuery();
                        }
                    }

                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return SCCartNo;
        }

        public long GetMaxSCCARTNO()
        {
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                long RntVal = 0;
                try
                {
                    using (OracleCommand command = new OracleCommand(DBConst.ora_Get_MAX_SCCARTNO, connection))
                    {

                        long maxId = Convert.ToInt64(command.ExecuteScalar());


                        RntVal = maxId;

                    }


                    return RntVal;
                }
                catch (Exception ex)
                {
                    return RntVal;
                }
            }

            // Check the number of rows affected

        }

        #endregion



        #region comented code
        //internal DataTable GetWorkFlowDetailsFromID(string workFlowID)
        //{
        //    //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
        //    //Instantiate the connection object.
        //    objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectWorkFlow_WithID, CommandType.Text, true);

        //    try
        //    {
        //        //Open the connection.
        //        objConn.OpenConnection();

        //        //Bind the parameters.                
        //        objConn.AddParameters(":WF_ID", workFlowID);
        //        //Execute the query and assign the resultant table.
        //        objConn.FillDataTable();
        //        dtResult = objConn.ResultantTable;

        //        //Close the connection
        //        objConn.CloseConnection();
        //    }
        //    catch (Exception excp)
        //    {
        //        throw excp;
        //    }

        //    //return the final Data Table.
        //    return dtResult;
        //}

        //internal DataTable GetApprover(string DEPT, string PLANT)
        //{
        //    //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
        //    //Instantiate the connection object.
        //    objConn = new ConnectionOracleDB(strConnSISDB, DBConst.getApprover, CommandType.Text, true);

        //    try
        //    {
        //        //Open the connection.
        //        objConn.OpenConnection();
        //        objConn.AddParameters(":DEPT", DEPT);
        //        objConn.AddParameters(":PLANT", PLANT);
        //        //Bind the parameters.                

        //        //Execute the query and assign the resultant table.
        //        objConn.FillDataTable();
        //        dtResult = objConn.ResultantTable;

        //        //Close the connection
        //        objConn.CloseConnection();
        //    }
        //    catch (Exception excp)
        //    {
        //        throw excp;
        //    }

        //    //return the final Data Table.
        //    return dtResult;
        //}

        //internal int UpdateWorkFlowDetailsFromID(WorkFlowModel workflowmodel)
        //{
        //    int attachInsertCount;

        //    using (OracleConnection connection = new OracleConnection(strConnSISDB))
        //    {
        //        connection.Open();

        //        OracleCommand command = connection.CreateCommand();
        //        OracleTransaction transaction;

        //        transaction = connection.BeginTransaction();
        //        command.Transaction = transaction;

        //        try
        //        {
        //            command.CommandText = DBConst.oraUpdateWorkFlow_WithID;
        //            command.Parameters.Clear();
        //            command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);
        //            command.Parameters.Add(":MOD_BY", workflowmodel.MOD_BY);
        //            command.Parameters.Add(":APPROVED_QTY", workflowmodel.APPROVED_QTY);
        //            command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
        //            command.Parameters.Add(":APP_BY", workflowmodel.MOD_BY);
        //            command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);


        //            attachInsertCount = command.ExecuteNonQuery();

        //            if (attachInsertCount > 0)
        //            {

        //                command.Parameters.Clear();
        //                command.CommandText = DBConst.oraInsertWorkFlowAudit;
        //                command.Parameters.Clear();
        //                command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);
        //                command.Parameters.Add(":WF_TYPE", workflowmodel.WF_TYPE);
        //                command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);

        //                command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
        //                command.Parameters.Add(":CRT_BY", workflowmodel.MOD_BY);
        //                attachInsertCount = command.ExecuteNonQuery();

        //            }
        //            transaction.Commit();
        //        }
        //        catch (OracleException excp)
        //        {
        //            transaction.Rollback();
        //            throw excp;
        //        }
        //        catch (Exception excp)
        //        {
        //            transaction.Rollback();
        //            throw excp;
        //        }
        //    }
        //    return attachInsertCount;
        //}

        #endregion
        public class DBConst
        {
            #region IntelliBuyChecks

            public const string GetSCName = @"SELECT SCH_CART_NAME FROM T_SIS_INTELLIBUY_CHECK_HEADER WHERE INDENT_ID = :INDENT_ID";
            //added by Animesh

            public const string oraGetIntelliBuyChecksDetailsFromId = @"SELECT ROW_NUMBER() OVER (ORDER BY UMC.UMC_INDENT_ID) AS srno , IND.INDENT_ID,IND.INDENTOR_PLANT,IND.INDENT_CRT_BY,UMC.REQ_UMC_NO,  bgg.MATLGRP||'-'|| bgg.DESCRIPTION as REQ_UMC_BGG,
to_char(umc.requirement_date, 'DD-MON-YYYY') as requirement_date,to_char(umc.requirement_date, 'DD-MON-YYYY') as IND_requirement_date,umc.requirement_date SYS_REQ_ON_DATE,INTBUY_H.SCH_CART_NO,UMC.PRICE_PER_ITEM,
umc.document_type,
umc.fod_type,umc.req_umc_desc,umc.qty ,UMC.UOM,INTBUY_H.INDENT_STATUS,scv.code_val_desc INDENT_CURRENT_STATUS,INDENT_CURRENT_STATUS 
INDENT_CURRENT_STATUS_CODE , EXISTING_UMC || '-' || EXIS_UMC_DESC as TaggedUMC,UMC.TOTAL_SAP_DOC_QTY,(QTY-TOTAL_SAP_DOC_QTY)
as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,UMC.ISACTIVE,umcp.refurbishable IS_REFURBISHABLE,SCVCode.code_value 
||' - '|| SCVCode.CODE_VAL_DESC document_type_DESC,DEPTDESC||'('||ind.indentor_dept||')' DEPT,'0' ITEM_ID,to_char(umc.CONSUMP_DT, 'DD-MON-YYYY') as CONSUMP_DT,UMC.PUR_GRP,'' USER_REMARKS_MAXQTY,'' USER_REMARKS_RCM,IND.INDENTOR_LOC,UMC.CURRENCY,UMC.QTY SCI_QTY,'' SCI_REMARKS
  
   FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID
            left join T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H
            on INTBUY_H.INDENT_ID= IND.INDENT_ID 
inner join T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS 
left join T_SIS_CODE_VALUE SCVCode on SCVCode.CODE_VALUE= umc.DOCUMENT_TYPE and SCVCode.CODETYPE_ID=5
 INNER JOIN sapsur.t_s_dept_mst ON DEPTNO= ind.indentor_dept 
 left join sapsur.T_UMC_PROD UMCP on UMCP.UMC_CD=UMC.REQ_UMC_NO and UMCP.PLANT_CD=IND.INDENTOR_PLANT 
 left join T_SIS_CAP_REV_UMC  UMCC on UMCC.CRU_UMC=UMCP.UMC_CD and UMCC.CRU_REQUEST_ID=IND.INDENT_ID 
 left join  sapsur.T_S_MATL_GRP bgg on bgg.MATLGRP =UMC.REQ_UMC_BGG
  
where UMC.ISACTIVE= 'Y'  AND UMC.qty > UMC.total_sap_doc_qty and IND.ISACTIVE= 'Y' and IND.INDENT_ID= :INDENT_ID and IND.INDENT_CURRENT_STATUS= '16'    and SCVCode.ACTIVE_FLG='Y'  
and (UMCP.CAPITAL_IND <> 'C' OR UMCP.CAPITAL_IND is null) and (UMCC.CRU_TAG <> 'C' OR UMCC.CRU_TAG is null) 
 and IND.INDENT_STATUS='CMPLT' order by IND.INDENT_ID ASC";
            public const string oraGetIntelliBuyChecksHeadersDetailsFromId = @"DECLARE
  INDENTCURSTATUS number := 0;  
BEGIN
  select INDENT_CURRENT_STATUS into INDENTCURSTATUS from T_SIS_INDENT_DETAILS where ISACTIVE='Y' and INDENT_CURRENT_STATUS= '16' and INDENT_ID=:INDENT_ID
  IF (INDENTCURSTATUS = 16) 
    THEN
     SELECT IND.INDENT_ID,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO, UMC.REQ_UMC_BGG, to_char(umc.requirement_date, 'DD-MON-YYYY') as requirement_date,UMC.PRICE_PER_ITEM,umc.document_type,
umc.fod_type,umc.req_umc_desc,umc.qty ,UMC.UOM,INTBUY_H.INDENT_STATUS,scv.code_val_desc INDENT_CURRENT_STATUS, EXISTING_UMC || '-' || EXIS_UMC_DESC as TaggedUMC,UMC.TOTAL_SAP_DOC_QTY,(QTY-TOTAL_SAP_DOC_QTY) as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,UMC.ISACTIVE
            FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID
            left join T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H
            on INTBUY_H.INDENT_ID= IND.INDENT_ID inner join T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS where UMC.ISACTIVE= 'Y' and IND.ISACTIVE= 'Y' and IND.INDENT_ID= :INDENT_ID and IND.INDENT_CURRENT_STATUS= '16' order by IND.INDENT_ID ASC
    ELSE
     select * from T_SIS_INTELLIBUY_CHECK_HEADER INTE_CH inner join T_SIS_INTELLIBUY_CHECK_ITEM INTE_CI on INTE_CI.HEADER_ID = INTE_CH.HEADER_ID and INTE_CI.INDENT_ID = INTE_CH.INDENT_ID where INTE_CH.INDENT_ID=:INDENT_ID and INTE_CI.ISACTIVE='Y' 
  END IF;
END;";

            public const string oraInsertIntelliBuyCheckHeader = @"insert into T_SIS_INTELLIBUY_CHECK_HEADER (HEADER_ID ,INDENT_ID ,INDENTER_LOC ,INDENTOR_PLANT ,INDENTER_DEPT ,INDENT_DESC ,INDENT_REMARKS ,CRT_BY ,
CRT_DT ,INDENT_STATUS  ,SCH_CRT_DT ,SCH_USR_NAME ,SCH_CART_NO,ISACTIVE,MAX_QTY_CHK,CONS_REQ_CHK,ARC_VMI_CHK,DEPROP_CHK,REF_CHK,BBPR) values ((SELECT coalesce(MAX(HEADER_ID),0) + 1 FROM T_SIS_INTELLIBUY_CHECK_HEADER) ,
:INDENT_ID ,:INDENTER_LOC ,:INDENTOR_PLANT ,:INDENTER_DEPT ,:INDENT_DESC ,:INDENT_REMARKS ,:CRT_BY ,
sysdate  ,:INDENT_STATUS  ,sysdate ,:SCH_USR_NAME ,:SCH_CART_NO,'Y',:MAX_QTY_CHK,:CONS_REQ_CHK,:ARC_VMI_CHK,:DEPROP_CHK,:REF_CHK,:BBPR)";
            public const string oraInsertIntelliBuyCheckItem = @"insert into T_SIS_INTELLIBUY_CHECK_ITEM (ITEM_ID,HEADER_ID,INDENT_ID,SCI_MATL_DESC,EXISTING_UMC,EXISTING_UMC_DESC,SCI_MATL_GROUP,SCI_PROD_TYPE,SCI_PLANT_CD,SCI_STRG_LOC ,SCI_PUR_GROUP ,SCI_DOC_TYPE ,SCI_QTY ,SCI_QTY_UNIT ,SCI_PRICE ,SCI_FRN_CURR_CD ,SCI_REQD_ON_DT ,CONSUMP_DT ,SCI_STATUS ,SCI_DEL_IND ,SCI_SAP_ERR_MSG ,SCI_PROP_TAG ,SCI_REFFB_TAG ,SCI_PERISIBL_TAG ,SCI_SPARE_CAT ,SCI_REMARKS ,ISACTIVE ,CRT_BY,MAX_QTY,USER_REMARKS_MAXQTY,USER_REMARKS_RCM,SYS_CONSUMP_DT,SYS_REQ_DATE,RCM_STATUS,MAXQTY_STATUS,PIPELINE_QTY,REFURBISHED_QTY,CHARGEDOUT_QTY,ALLOWED_QTY,VMIARC_STATUS,REFURSHIBILITY_STATUS,DEPROP_STATUS ,CRT_DT ) values 
((SELECT coalesce(MAX(ITEM_ID),0) + 1 FROM T_SIS_INTELLIBUY_CHECK_ITEM) ,:HEADER_ID ,:INDENT_ID,:SCI_MATL_DESC ,:EXISTING_UMC ,:EXISTING_UMC_DESC ,:SCI_MATL_GROUP ,:SCI_PROD_TYPE ,:SCI_PLANT_CD ,:SCI_STRG_LOC ,:SCI_PUR_GROUP ,:SCI_DOC_TYPE ,:SCI_QTY ,:SCI_QTY_UNIT ,:SCI_PRICE ,:SCI_FRN_CURR_CD ,:SCI_REQD_ON_DT ,:SCI_REQD_ON_DT ,:SCI_STATUS ,:SCI_DEL_IND ,:SCI_SAP_ERR_MSG ,:SCI_PROP_TAG ,:SCI_REFFB_TAG ,:SCI_PERISIBL_TAG ,:SCI_SPARE_CAT ,:SCI_REMARKS ,:ISACTIVE ,:CRT_BY ,:MAX_QTY,:USER_REMARKS_MAXQTY,:USER_REMARKS_RCM,:SYS_CONSUMP_DT,:SYS_REQ_DATE,:RCM_STATUS,:MAXQTY_STATUS,:PIPELINE_QTY,:REFURBISHED_QTY,:CHARGEDOUT_QTY,:ALLOWED_QTY,:VMIARC_STATUS,:REFURSHIBILITY_STATUS,:DEPROP_STATUS ,sysdate )";

            public const string oraGetMaxHeaderID = @"(SELECT coalesce(MAX(HEADER_ID),0) + 1 as HEADER_ID FROM T_SIS_INTELLIBUY_CHECK_HEADER)";

            public const string oraUpdateIntelliBuyCheckHeader = @"  UPDATE T_SIS_INTELLIBUY_CHECK_HEADER SET  INDENTER_LOC=:INDENTER_LOC ,INDENTOR_PLANT=:INDENTOR_PLANT ,INDENTER_DEPT=:INDENTER_DEPT ,INDENT_DESC=:INDENT_DESC ,INDENT_REMARKS=:INDENT_REMARKS ,MOD_BY=:CRT_BY ,INDENT_STATUS=:INDENT_STATUS ,SCH_CART_NO=:SCH_CART_NO  ,SCH_USR_NAME=:SCH_USR_NAME ,ISACTIVE=:ISACTIVE,MOD_DT=sysdate,MAX_QTY_CHK=:MAX_QTY_CHK,CONS_REQ_CHK=:CONS_REQ_CHK,ARC_VMI_CHK=:ARC_VMI_CHK,DEPROP_CHK=:DEPROP_CHK,REF_CHK=:REF_CHK,BBPR=:BBPR where INDENT_ID=:INDENT_ID ";

            public const string oraUpdateIntelliBuyCheckItem = @"update T_SIS_INTELLIBUY_CHECK_ITEM set SCI_MATL_DESC=:SCI_MATL_DESC  ,EXISTING_UMC_DESC=:EXISTING_UMC_DESC 
            ,SCI_MATL_GROUP=:SCI_MATL_GROUP ,SCI_PROD_TYPE=:SCI_PROD_TYPE ,SCI_PLANT_CD=:SCI_PLANT_CD ,SCI_STRG_LOC=:SCI_STRG_LOC ,SCI_PUR_GROUP=:SCI_PUR_GROUP ,SCI_DOC_TYPE=:SCI_DOC_TYPE ,SCI_QTY=:SCI_QTY ,SCI_QTY_UNIT=:SCI_QTY_UNIT ,SCI_PRICE=:SCI_PRICE ,
            SCI_FRN_CURR_CD=:SCI_FRN_CURR_CD ,SCI_REQD_ON_DT=:SCI_REQD_ON_DT ,CONSUMP_DT=:CONSUMP_DT ,SCI_STATUS=:SCI_STATUS ,SCI_DEL_IND=:SCI_DEL_IND ,           SCI_SAP_ERR_MSG=:SCI_SAP_ERR_MSG ,SCI_PROP_TAG=:SCI_PROP_TAG ,SCI_REFFB_TAG=:SCI_REFFB_TAG ,SCI_PERISIBL_TAG=:SCI_PERISIBL_TAG ,SCI_SPARE_CAT=:SCI_SPARE_CAT ,SCI_REMARKS=:SCI_REMARKS ,ISACTIVE=:IS_ACTIVE ,MOD_BY=:CRT_BY ,MAX_QTY=:MAX_QTY,USER_REMARKS_MAXQTY=:USER_REMARKS_MAXQTY,USER_REMARKS_RCM=:USER_REMARKS_RCM, 
MOD_DT=SYSDATE,  SYS_CONSUMP_DT=:SYS_CONSUMP_DT,SYS_REQ_DATE=:SYS_REQ_DATE,RCM_STATUS=:RCM_STATUS,MAXQTY_STATUS=:MAXQTY_STATUS,PIPELINE_QTY=:PIPELINE_QTY,REFURBISHED_QTY=:REFURBISHED_QTY,CHARGEDOUT_QTY=:CHARGEDOUT_QTY
,ALLOWED_QTY=:ALLOWED_QTY,VMIARC_STATUS=:VMIARC_STATUS,REFURSHIBILITY_STATUS=:REFURSHIBILITY_STATUS,DEPROP_STATUS=:DEPROP_STATUS
            where  INDENT_ID=:INDENT_ID and EXISTING_UMC=:EXISTING_UMC";
            //to_char(HEADER_ID)=:HEADER_ID and
            public const string oraGetIntelliBuyChecksDetailsFromINDENT_ID = @"Select * from T_SIS_INTELLIBUY_CHECK_HEADER where INDENT_ID=:INDENT_ID";
            public const string oraGetIntelliBuyChecksHeaderAndItem = @"SELECT ROW_NUMBER() OVER (ORDER BY INTBUY_I.ITEM_ID) AS srno ,
  IND.INDENT_ID,
  IND.INDENTOR_PLANT,
  IND.INDENT_CRT_BY,
  UMC.REQ_UMC_NO,
  bgg.MATLGRP
  ||'-'
  || bgg.DESCRIPTION                              AS REQ_UMC_BGG,
  TO_CHAR(umc.requirement_date, 'DD-MON-YYYY')    AS IND_requirement_date,
  TO_CHAR(INTBUY_I.SCI_REQD_ON_DT, 'DD-MON-YYYY') AS requirement_date,
  UMC.PRICE_PER_ITEM,
  umc.document_type,
  umc.fod_type,
  umc.req_umc_desc ,
  UMC.UOM,
  scv.code_val_desc INDENT_CURRENT_STATUS,
  ind.INDENT_CURRENT_STATUS INDENT_CURRENT_STATUS_CODE ,
  umc.EXISTING_UMC
  || '-'
  || umc.EXIS_UMC_DESC AS TaggedUMC,
  UMC.TOTAL_SAP_DOC_QTY,
  (QTY-TOTAL_SAP_DOC_QTY) AS AllowedQty,
  UMC.UMC_INDENT_ID,
  IND.INDENTOR_DEPT,
  IND.INDENT_DESC,
  IND.INDENT_REMARKS,
  UMC.ISACTIVE ,
  INTBUY_I.item_id,
  INTBUY_I.SCI_QTY,
  INTBUY_I.PIPELINE_QTY,
  INTBUY_I.REFURBISHED_QTY,
  INTBUY_I.CHARGEDOUT_QTY,
  INTBUY_I.MAX_QTY,
  INTBUY_I.SYS_REQ_DATE,
  INTBUY_I.SYS_CONSUMP_DT,
  INTBUY_I.VMIARC_STATUS,
  umc.qty QTY,
  TO_CHAR(INTBUY_I.SCI_REQD_ON_DT, 'DD-MON-YYYY') SYS_REQ_ON_DATE,
  SCVCode.code_value
  ||' - '
  || SCVCode.CODE_VAL_DESC document_type_DESC,
  DEPTDESC
  ||'('
  ||ind.indentor_dept
  ||')' DEPT,
  TO_CHAR(INTBUY_I.CONSUMP_DT, 'DD-MON-YYYY') AS CONSUMP_DT,
  INTBUY_H.SCH_CART_NO,
  umcp.refurbishable IS_REFURBISHABLE,
  UMC.PUR_GRP,
  INTBUY_I.USER_REMARKS_MAXQTY,
  INTBUY_I.USER_REMARKS_RCM,
  IND.INDENTOR_LOC,
  UMC.CURRENCY,
INTBUY_I.SCI_REMARKS

FROM T_SIS_INDENT_DETAILS IND
INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC
ON UMC.INDENT_ID= IND.INDENT_ID
INNER JOIN T_SIS_CODE_VALUE SCV
ON scv.id= ind.INDENT_CURRENT_STATUS
LEFT JOIN T_SIS_CODE_VALUE SCVCode
ON SCVCode.CODE_VALUE  = umc.DOCUMENT_TYPE
AND SCVCode.CODETYPE_ID=5
LEFT JOIN T_SIS_INTELLIBUY_CHECK_ITEM INTBUY_I
ON INTBUY_I.INDENT_ID    = IND.INDENT_ID
AND INTBUY_I.EXISTING_UMC=umc.REQ_UMC_NO
LEFT JOIN T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H
ON INTBUY_H.INDENT_ID= IND.INDENT_ID
INNER JOIN sapsur.t_s_dept_mst
ON DEPTNO= ind.indentor_dept
INNER JOIN sapsur.T_UMC_PROD UMCP
ON UMCP.UMC_CD   =UMC.REQ_UMC_NO
AND UMCP.PLANT_CD=IND.INDENTOR_PLANT
LEFT JOIN sapsur.T_S_MATL_GRP bgg
ON bgg.MATLGRP                 =UMC.REQ_UMC_BGG
WHERE INTBUY_I.ISACTIVE        = 'Y'
AND IND.INDENT_CURRENT_STATUS >= '16'
  AND UMC.qty > UMC.total_sap_doc_qty
AND IND.INDENT_ID              = :INDENT_ID
AND SCVCode.ACTIVE_FLG         ='Y'
ORDER BY IND.INDENT_ID ASC";
            public const string UpdateStatus = @"update T_SIS_INDENT_DETAILS set INDENT_CURRENT_STATUS = '37'  where INDENT_ID=:INDENT_ID";
            public const string ora_Get_MAX_SCCARTNO = @"select sccart_seq_sis.nextval from dual";
            public const string oraGet_budgetConsumptionFormDept_EBuy = @"select fy, sum( totalvalue) Totval from  
(select case when (to_number(to_char(add_months(trunc(sysdate), 9), 'YYYY')) 
- to_number(to_char(add_months(nvl(sci_reqd_on_dt,trunc(sysdate)),9),'YYYY'))) >= 0  then to_char(add_months(trunc(sysdate), 9), 'YYYY')
else to_char(add_months(nvl(sci_reqd_on_dt, trunc(sysdate)), 9), 'YYYY') end as FY,sci_qty * sci_price totalvalue 
From sapsur.t_shopping_cart_hdr, sapsur.t_shopping_cart_item , sapsur.t_umc_prod where sch_dept = :sch_dept  and sch_status = '04' 
and sch_cart_no = sci_cart_no  and sci_prod_type ='01' and nvl(sci_del_ind, 'Y') <> 'X'  and sci_fod_type in ('RO', 'PR') 
and sci_matl_grp <> '320' and ( nvl(sci_aa_cat,' ') = ' ' or  nvl(sci_aa_cat,'L')  ='L') and nvl(sci_status,'X') <> '06'   
and SCI_MATL_NO = UMC_CD   and SCI_PLANT_CD=PLANT_CD and  MAT_TYP in  ('ERSA','HIBE')  )  group by fy
";
            public const string oraGet_budgetConsumptionFormDept_SIS = @"select fy, sum( totalvalue) Totval from  
(select case when (to_number(to_char(add_months(trunc(sysdate), 9), 'YYYY')) 
- to_number(to_char(add_months(nvl(sci_reqd_on_dt,trunc(sysdate)),9),'YYYY'))) >= 0  then to_char(add_months(trunc(sysdate), 9), 'YYYY')
else to_char(add_months(nvl(sci_reqd_on_dt, trunc(sysdate)), 9), 'YYYY') end as FY,sci_qty * sci_price totalvalue 
From t_sis_shopping_cart_hdr, t_sis_shopping_cart_item , sapsur.t_umc_prod where sch_dept = :sch_dept  and sch_status = '04' 
and sch_cart_no = sci_cart_no  and sci_prod_type ='01' and nvl(sci_del_ind, 'Y') <> 'X'  and sci_fod_type in ('RO', 'PR') 
and sci_matl_grp <> '320' and ( nvl(sci_aa_cat,' ') = ' ' or  nvl(sci_aa_cat,'L')  ='L') and nvl(sci_status,'X') <> '06'   
and SCI_MATL_NO = UMC_CD   and SCI_PLANT_CD=PLANT_CD and  MAT_TYP in  ('ERSA','HIBE')  )  group by fy ";

            public const string ora_UpdateShoppinCartName = @"UPDATE T_SIS_INTELLIBUY_CHECK_HEADER SET SCH_CART_NAME = :SCName WHERE INDENT_ID = :INDENT_ID";

            public const string ora_getbudgetDeptCount = @"SELECT COUNT(1)
FROM SAPSUR.t_s_dept_mst
WHERE NVL(BUDGTCHK, 'N') <> 'N'
AND client = '600'
AND deptno = :dept";

            public const string ora_DeleteIntellibuyItem = "update  T_SIS_INTELLIBUY_CHECK_ITEM set ISACTIVE ='N' where INDENT_ID =:INDENT_ID and EXISTING_UMC=:EXISTING_UMC";
            public const string ora_UpdateSCItemDeleteStatus = "update T_SIS_SHOPPING_CART_ITEM set SCI_DEL_IND='X' , SCI_ITM_SAVED_STAT='Y' where SCI_CART_NO in (select SCH_CART_NO from T_SIS_INTELLIBUY_CHECK_HEADER where INDENT_ID=:INDENT_ID) and SCI_MATL_NO=:SCI_MATL_NO";
            public const string ora_GetIntelliBuyItemStatus = "select * from T_SIS_INTELLIBUY_CHECK_ITEM where INDENT_ID =:INDENT_ID and   ISACTIVE <>'N' ";
            public const string UpdateIndentStatus = @"update T_SIS_INDENT_DETAILS set INDENT_CURRENT_STATUS = :INDENT_CURRENT_STATUS,INDENT_MOD_BY=:MODBY,INDENT_MOD_DT=sysdate where INDENT_ID=:INDENT_ID";
            public const string oraGetCurrentIndentStatus = @"  select IND.INDENT_CURRENT_STATUS INDENT_STATUS from T_SIS_INDENT_DETAILS IND where IND.INDENT_ID=:INDENT_ID";
            #endregion


        }
    }
}
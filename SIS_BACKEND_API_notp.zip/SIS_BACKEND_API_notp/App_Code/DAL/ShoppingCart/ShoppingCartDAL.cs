﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models.IntelliBuyModel;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Runtime.Remoting.Messaging;
using Newtonsoft.Json.Linq;
using Microsoft.Win32;
using SIS_BACKEND_API.Models;
using System.Drawing;
using System.Collections;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.Net.NetworkInformation;
using System.Web.DynamicData;
using Microsoft.SqlServer.Server;
using System.Security.Cryptography;

namespace SIS_BACKEND_API.App_Code.DAL.ShoppingCart
{
    public class ScItemErrorCnt
    {
        public int errCntScItem { get; set; }
    }
    public class ShoppingCartDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        SC_ApprovalDAL objCommonDAL = new SC_ApprovalDAL();
        ApprovalSection approvalSection = new ApprovalSection();
        private ConnectionOracleDB objConn;
        private DataTable dtResult;
        int err_cnt = 0;
        public int GetFinancialYear(DateTime date)
        {
            int year = date.Year;

            // Assuming financial year starts on April 1
            if (date.Month < 4)
            {
                year--; // If before April, it's the previous financial year
            }
            else
            {
                year++;
            }

            return year;
        }
        public DataTable Get_CSR_Category()
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_CSR_Category, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return dtResult;

        }

        public DataTable Get_CSR_CODE_SUB_MASTER()
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_CSR_CODE_SUB_MASTER, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return dtResult;

        }
        public DataTable Get_CSR_SUB_CODE_ACTIVITY(string CSR_SUB_CODE)
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_CSR_SUB_CODE_ACTIVITY, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.AddParameters(":CSR_SUB_CODE", CSR_SUB_CODE);
                objConn.FillDataTable();

                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return dtResult;

        }

        public DataTable GetIntelliBuyChecksHeaderAndItem(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetIntelliBuyChecksHeaderAndItem, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetCostCategory(string DeptType, string FODType, string bgg, string contract)
        {
            string strSqlCat = "";
            if (FODType == "PR" && DeptType == "O")
            {
                objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_Cost_CategoryDeptType, CommandType.Text, true);
            }
            else if (FODType == "PR" && DeptType == "O")
            {

                objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_Cost_CategoryDeptType, CommandType.Text, true);
            }
            else if (FODType == "RO")
            {
                if (bgg.Trim() == "320")
                {
                    strSqlCat = "select acct_asgnmt_cat,acct_asgnmt_desc from sapsur.t_acct_asgnmt where  acct_asgnmt_cat in ('N','Q') and acct_applicable in ('S','B')";
                }

                else
                {
                    if (contract != null && contract.StartsWith("48"))
                    {
                        strSqlCat = "SELECT acct_asgnmt_cat,acct_asgnmt_desc FROM sapsur.t_acct_asgnmt where acct_asgnmt_cat not in ('U') and acct_applicable in ('S','B')";
                    }

                    else if (DeptType == "O")
                    {
                        strSqlCat = "SELECT acct_asgnmt_cat,acct_asgnmt_desc FROM sapsur.t_acct_asgnmt where acct_asgnmt_cat not in ('U') and acct_applicable in ('S','B')";
                    }
                    else
                    {
                        strSqlCat = "SELECT acct_asgnmt_cat,acct_asgnmt_desc FROM sapsur.t_acct_asgnmt where acct_asgnmt_cat in (' ','N','Q') and acct_applicable in ('S','B')";
                    }
                }
                objConn = new ConnectionOracleDB(strConnSISDB, strSqlCat, CommandType.Text, true);
            }


            else
            {

                objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_Get_Cost_Category, CommandType.Text, true);
            }

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetDocumentsText(string FODType)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetDocumentsText, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.AddParameters(":FODTYPE", FODType);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public DataTable GetCurrencyCode()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetCurrencyCode, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetCSRLocation()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetCSRLocation, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetCurrencyRateFromCurrency(string CurrencyName)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetCurrencyRateFromCurrency, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.AddParameters(":FROM_CURR", CurrencyName);

                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetPRTextDocuments(string UMCNo, string Plant)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetPRTextDocuments, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.AddParameters(":UMC_CD", UMCNo);
                objConn.AddParameters(":PLANT_CD", Plant);

                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetSCDocuments(string SCNo, string ItemNo, string DocName, string txt_lvl)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetSCDocuments, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.              
                objConn.AddParameters(":scd_cart_no", SCNo);
                objConn.AddParameters(":scd_item_no", ItemNo);
                objConn.AddParameters(":scd_txt_type", DocName);
                objConn.AddParameters(":scd_lvl", txt_lvl);

                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public async Task<long> UpdateShoppingCart(ShoppingCartHeader header, List<ShoppingCartItem> items, SustainibilityCSR sustainibilityCSR, Dictionary<string, List<string>> validation)
        {
            int attachInsertCount = 0;
            long SCCartNo = 0;
            double SpareBudget = 0;
            double CommittedExpenditure = 0;
            double percent = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                dynamic responseObject = null;
                int Count = 0;
                header.SCH_BUDGET_EXCEEDED_AMT = "0";
                header.SCH_CRT_FY = "";
                try
                {
                    double Budget_EBUY = Get_budgetConsumptionFormDept_EBuy(header.SCH_DEPT);
                    double Budget_SIS = Get_budgetConsumptionFormDept_SIS(header.SCH_DEPT);
                    string responseData = await Get_budgetConsumptionFormDept_ODATA(header.SCH_DEPT);
                    if (!String.IsNullOrEmpty(responseData))
                    {
                        responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                        if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                        {
                            string StrPOValue = "0";
                            string StrPRValue = "0";
                            string StrSpareValue = "0";
                            string StrTotBudget = "0";

                            foreach (var result in responseObject.d.results)
                            {
                                // Check the DocType and assign the values accordingly
                                if (result.DocType == "PO")
                                {
                                    StrPOValue = result.Value;
                                }
                                else if (result.DocType == "PR")
                                {
                                    StrPRValue = result.Value;
                                }
                                else if (result.DocType == "TOTAL")
                                {
                                    StrSpareValue = result.Value;
                                    StrTotBudget = result.TotBudget;
                                }
                                header.SCH_CRT_FY = result.FisYr;
                            }

                            double poValue = double.Parse(StrPOValue);
                            double totalValue = double.Parse(StrSpareValue);
                            double spareValue = double.Parse(StrTotBudget) * 105 / 100;
                            //header.SCH_BUDGET_EXCEEDED_AMT = Math.Round((spareValue - totalValue));
                            CommittedExpenditure = Budget_EBUY + totalValue + Budget_SIS;
                            SpareBudget = Math.Round(spareValue);
                            if (spareValue != 0)
                            {
                                percent = (100 * CommittedExpenditure) / spareValue;
                            }
                            else { percent = 0; }
                            header.SCH_BUDGET_EXCEEDED_AMT = percent.ToString("0.000");

                        }
                    }

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraUpdateShoppingCartHDR;
                    command.CommandType = CommandType.Text;

                    // Input parameters

                    command.Parameters.Add(":SCH_UPD_ID", OracleDbType.Varchar2).Value = header.SCH_UPD_ID;
                    command.Parameters.Add(":SCH_DEPT", OracleDbType.Varchar2).Value = header.SCH_DEPT;
                    command.Parameters.Add(":SCH_CRT_FY", OracleDbType.Varchar2).Value = header.SCH_CRT_FY;
                    command.Parameters.Add(":SCH_STATUS", OracleDbType.Varchar2).Value = "03";
                    command.Parameters.Add(":SCH_TOT_VAL", OracleDbType.Decimal).Value = header.SCH_TOT_VAL;
                    command.Parameters.Add(":SCH_INDT_TYP", OracleDbType.Varchar2).Value = header.SCH_INDT_TYP;
                    command.Parameters.Add(":SCH_BUDGET_EXCEEDED_AMT", OracleDbType.Varchar2).Value = header.SCH_BUDGET_EXCEEDED_AMT;
                    command.Parameters.Add(":SCH_CART_NO", OracleDbType.Int64).Value = header.SCH_CART_NO;
                    int i = command.ExecuteNonQuery();
                    ScItemErrorCnt ScItemErrCntState = new ScItemErrorCnt();
                    foreach (var objSCItems in items)
                    {

                        ScItemErrCntState.errCntScItem = 0;
                        await validateScItem(objSCItems, responseObject, validation, ScItemErrCntState, items, header);

                        if (ScItemErrCntState.errCntScItem > 0)
                        {
                            continue;
                        }

                        Count++;
                        if (!String.IsNullOrEmpty(header.SCH_CART_NO.ToString()))
                        {
                            command.Parameters.Clear();
                            command.CommandText = DBConst.oraUpdateShoppingCartItem;
                            command.CommandType = CommandType.Text;
                            if (objSCItems.SCI_FRN_PRICE == "0")
                            {
                                objSCItems.SCI_FRN_PRICE = objSCItems.SCI_PRICE;
                                objSCItems.SCI_FRN_CURR_CD = "INR";
                                objSCItems.SCI_EXCHNG_RATE = "1";
                            }
                            if (objSCItems.SCI_TXT_PROC_CONS == "MTRCL")
                            {
                                objSCItems.SCI_TXT_PROC_CONS = "Material consumtion within 33 month of Import";
                            }
                            command.Parameters.Add(":SCI_PLANT_CD", OracleDbType.Varchar2).Value = objSCItems.SCI_PLANT_CD;
                            command.Parameters.Add(":SCI_PUR_GRP", OracleDbType.Varchar2).Value = objSCItems.SCI_PUR_GRP;
                            command.Parameters.Add(":SCI_DOC_TYPE", OracleDbType.Varchar2).Value = objSCItems.SCI_DOC_TYPE;
                            command.Parameters.Add(":SCI_QTY", OracleDbType.Varchar2).Value = objSCItems.SCI_QTY;
                            command.Parameters.Add(":SCI_QTY_UNIT", OracleDbType.Varchar2).Value = objSCItems.SCI_QTY_UNIT;
                            command.Parameters.Add(":SCI_PRICE", OracleDbType.Varchar2).Value = objSCItems.SCI_PRICE;
                            command.Parameters.Add(":SCI_REQD_ON_DT", OracleDbType.Varchar2).Value = objSCItems.SCI_REQD_ON_DT;
                            command.Parameters.Add(":SCI_FOD_TYPE", OracleDbType.Varchar2).Value = objSCItems.SCI_FOD_TYPE;
                            command.Parameters.Add(":SCI_OA_VENCD", OracleDbType.Varchar2).Value = objSCItems.SCI_OA_VENCD;
                            command.Parameters.Add(":SCI_UPD_ID", OracleDbType.Varchar2).Value = header.SCH_UPD_ID;
                            command.Parameters.Add(":SCI_CHARACTERISTICS", OracleDbType.Varchar2).Value = objSCItems.SCI_CHARACTERISTICS;
                            command.Parameters.Add(":SCI_COMPOSITION", OracleDbType.Varchar2).Value = objSCItems.SCI_COMPOSITION;
                            command.Parameters.Add(":SCI_ENDUSE", OracleDbType.Varchar2).Value = objSCItems.SCI_ENDUSE;
                            command.Parameters.Add(":SCI_FUNCTION", OracleDbType.Varchar2).Value = objSCItems.SCI_FUNCTION;
                            command.Parameters.Add(":SCI_TXT_PROC_CONS", OracleDbType.Varchar2).Value = objSCItems.SCI_TXT_PROC_CONS;
                            command.Parameters.Add(":SCI_IMP_PLANT_MACHINERY", OracleDbType.Varchar2).Value = objSCItems.SCI_IMP_PLANT_MACHINERY;
                            command.Parameters.Add(":SCI_INSTALLED_QTY", OracleDbType.Varchar2).Value = objSCItems.SCI_INSTALLED_QTY;
                            command.Parameters.Add(":SCI_REQUESTER", OracleDbType.Varchar2).Value = objSCItems.SCI_REQUESTER;
                            command.Parameters.Add(":SCI_FRN_PRICE", OracleDbType.Varchar2).Value = objSCItems.SCI_FRN_PRICE;
                            command.Parameters.Add(":SCI_FRN_CURR_CD", OracleDbType.Varchar2).Value = objSCItems.SCI_FRN_CURR_CD;
                            command.Parameters.Add(":SCI_EXCHNG_RATE", OracleDbType.Varchar2).Value = objSCItems.SCI_EXCHNG_RATE;
                            command.Parameters.Add(":SCI_MATL_GRP", OracleDbType.Varchar2).Value = objSCItems.SCI_MATL_GRP;
                            command.Parameters.Add(":SCI_STRG_LOC", OracleDbType.Varchar2).Value = objSCItems.SCI_STRG_LOC;
                            command.Parameters.Add(":SCI_PROC_TYP", OracleDbType.Varchar2).Value = objSCItems.SCI_PROC_TYP;
                            command.Parameters.Add(":SCI_SPARES_CATEGORY", OracleDbType.Varchar2).Value = objSCItems.SCI_SPARES_CATEGORY;
                            command.Parameters.Add(":SCI_DLV_POINT", OracleDbType.Varchar2).Value = objSCItems.SCI_DLV_POINT;



                            command.Parameters.Add(":SCI_CART_NO", OracleDbType.Int64).Value = objSCItems.SCI_CART_NO;
                            command.Parameters.Add(":SCI_MATL_NO", OracleDbType.Varchar2).Value = objSCItems.SCI_MATL_NO;
                            //command.Parameters.Add("err_msg", OracleDbType.Varchar2, 32000).Direction = ParameterDirection.Output;

                            attachInsertCount = command.ExecuteNonQuery();
                            InsertClasificationDocument(objSCItems);

                        }
                    }



                    command.CommandText = DBConst.IndentUpdateStatus;
                    command.Parameters.Clear();
                    command.Parameters.Add(":STATUS", "38");
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    command.ExecuteNonQuery();
                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            if (validation.Count() > 0)
            {
                return 0;
            }
            return attachInsertCount;
        }

        public async Task<long> SubmitShoppingCart(ShoppingCartHeader header, List<ShoppingCartItem> items, Dictionary<string, List<string>> validation, bool isBudgetModalOpen)
        {
            //bool isBudgetModalOpen = false;
            int Currentfy = GetFinancialYear(DateTime.Now);
            double SpareBudget = 0;
            double CommittedExpenditure = 0;
            int attachInsertCount = 0;
            long SCCartNo = 0;
            double percent = 0;
            await MastervalidationsOfCheck(header, items, validation);
            if (validation.Count() > 0)
            {
                return attachInsertCount;
            }
            DataTable budgetDeptCountdt = getbudgetDeptCount(header.SCH_CART_NO);
            if (validation.Count() == 0 && budgetDeptCountdt.Rows.Count > 0 && budgetDeptCountdt.Rows[0][0].ToString() != "0" && isBudgetModalOpen == false)
            {
                return attachInsertCount;
            }
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();
                command.Transaction = transaction;

                int Count = 0;
                header.SCH_BUDGET_EXCEEDED_AMT = "0";
                header.SCH_CRT_FY = "";
                try
                {
                    double Budget_EBUY = Get_budgetConsumptionFormDept_EBuy(header.SCH_DEPT);
                    double Budget_SIS = Get_budgetConsumptionFormDept_SIS(header.SCH_DEPT);
                    string responseData = await Get_budgetConsumptionFormDept_ODATA(header.SCH_DEPT);
                    if (!String.IsNullOrEmpty(responseData))
                    {
                        dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                        if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                        {
                            string StrPOValue = "0";
                            string StrPRValue = "0";
                            string StrSpareValue = "0";
                            string StrTotBudget = "0";

                            foreach (var result in responseObject.d.results)
                            {
                                // Check the DocType and assign the values accordingly
                                if (result.DocType == "PO" && result.FisYr == Currentfy)
                                {
                                    StrPOValue = result.Value;
                                }
                                else if (result.DocType == "PR" && result.FisYr == Currentfy)
                                {
                                    StrPRValue = result.Value;
                                }
                                else if (result.DocType == "TOTAL" && result.FisYr == Currentfy)
                                {
                                    StrSpareValue = result.Value;
                                    StrTotBudget = result.TotBudget;
                                }
                                header.SCH_CRT_FY = result.FisYr;

                            }

                            double poValue = double.Parse(StrPOValue);
                            double totalValue = double.Parse(StrSpareValue);
                            double spareValue = double.Parse(StrTotBudget) * 105 / 100;
                            //header.SCH_BUDGET_EXCEEDED_AMT = Math.Round((spareValue - totalValue));
                            double PRValue = double.Parse(StrPRValue);
                            double POValue = double.Parse(StrPOValue);
                            CommittedExpenditure = Math.Round(Budget_EBUY + POValue + PRValue + Budget_SIS);
                            SpareBudget = Math.Round(spareValue);
                            if (spareValue != 0)
                            {
                                percent = (100 * CommittedExpenditure) / spareValue;
                            }
                            else { percent = 0; }
                            header.SCH_BUDGET_EXCEEDED_AMT = Math.Round(percent).ToString();

                        }
                    }
                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraUpdateShoppingCartHDR;
                    command.CommandType = CommandType.Text;

                    // Input parameters

                    command.Parameters.Add(":SCH_UPD_ID", OracleDbType.Varchar2).Value = header.SCH_UPD_ID;
                    command.Parameters.Add(":SCH_DEPT", OracleDbType.Varchar2).Value = header.SCH_DEPT;
                    command.Parameters.Add(":SCH_CRT_FY", OracleDbType.Varchar2).Value = header.SCH_CRT_FY;
                    command.Parameters.Add(":SCH_STATUS", OracleDbType.Varchar2).Value = "03";
                    command.Parameters.Add(":SCH_TOT_VAL", OracleDbType.Decimal).Value = header.SCH_TOT_VAL;
                    command.Parameters.Add(":SCH_INDT_TYP", OracleDbType.Varchar2).Value = header.SCH_INDT_TYP;
                    command.Parameters.Add(":SCH_BUDGET_EXCEEDED_AMT", OracleDbType.Varchar2).Value = header.SCH_BUDGET_EXCEEDED_AMT;
                    command.Parameters.Add(":SCH_CART_NO", OracleDbType.Int64).Value = header.SCH_CART_NO;
                    int i = command.ExecuteNonQuery();

                    foreach (var objSCItems in items)
                    {
                        Count++;
                        if (!String.IsNullOrEmpty(header.SCH_CART_NO.ToString()))
                        {
                            command.Parameters.Clear();

                            command.CommandText = DBConst.oraSubmitShoppingCartItem;
                            command.CommandType = CommandType.Text;
                            if (objSCItems.SCI_FRN_PRICE == "0")
                            {
                                objSCItems.SCI_FRN_PRICE = objSCItems.SCI_PRICE;
                                objSCItems.SCI_FRN_CURR_CD = "INR";
                                objSCItems.SCI_EXCHNG_RATE = "1";
                            }
                            if (objSCItems.SCI_TXT_PROC_CONS == "MTRCL")
                            {
                                objSCItems.SCI_TXT_PROC_CONS = "Material consumtion within 33 month of Import";
                            }

                            command.Parameters.Add(":SCI_PLANT_CD", OracleDbType.Varchar2).Value = objSCItems.SCI_PLANT_CD;
                            //command.Parameters.Add(":SCI_STRG_LOC", OracleDbType.Varchar2).Value = objSCItems.SCI_STRG_LOC;
                            command.Parameters.Add(":SCI_PUR_GRP", OracleDbType.Varchar2).Value = objSCItems.SCI_PUR_GRP;
                            command.Parameters.Add(":SCI_DOC_TYPE", OracleDbType.Varchar2).Value = objSCItems.SCI_DOC_TYPE;
                            command.Parameters.Add(":SCI_QTY", OracleDbType.Varchar2).Value = objSCItems.SCI_QTY;
                            command.Parameters.Add(":SCI_QTY_UNIT", OracleDbType.Varchar2).Value = objSCItems.SCI_QTY_UNIT;
                            command.Parameters.Add(":SCI_PRICE", OracleDbType.Varchar2).Value = objSCItems.SCI_PRICE;
                            command.Parameters.Add(":SCI_REQD_ON_DT", OracleDbType.Varchar2).Value = objSCItems.SCI_REQD_ON_DT;
                            command.Parameters.Add(":SCI_FOD_TYPE", OracleDbType.Varchar2).Value = objSCItems.SCI_FOD_TYPE;
                            command.Parameters.Add(":SCI_OA_VENCD", OracleDbType.Varchar2).Value = objSCItems.SCI_OA_VENCD;
                            command.Parameters.Add(":SCI_UPD_ID", OracleDbType.Varchar2).Value = header.SCH_UPD_ID;
                            command.Parameters.Add(":SCI_CHARACTERISTICS", OracleDbType.Varchar2).Value = objSCItems.SCI_CHARACTERISTICS;
                            command.Parameters.Add(":SCI_COMPOSITION", OracleDbType.Varchar2).Value = objSCItems.SCI_COMPOSITION;
                            command.Parameters.Add(":SCI_ENDUSE", OracleDbType.Varchar2).Value = objSCItems.SCI_ENDUSE;
                            command.Parameters.Add(":SCI_FUNCTION", OracleDbType.Varchar2).Value = objSCItems.SCI_FUNCTION;
                            command.Parameters.Add(":SCI_TXT_PROC_CONS", OracleDbType.Varchar2).Value = objSCItems.SCI_TXT_PROC_CONS;
                            command.Parameters.Add(":SCI_IMP_PLANT_MACHINERY", OracleDbType.Varchar2).Value = objSCItems.SCI_IMP_PLANT_MACHINERY;
                            command.Parameters.Add(":SCI_INSTALLED_QTY", OracleDbType.Varchar2).Value = objSCItems.SCI_INSTALLED_QTY;
                            command.Parameters.Add(":SCI_REQUESTER", OracleDbType.Varchar2).Value = objSCItems.SCI_REQUESTER;
                            command.Parameters.Add(":SCI_FRN_PRICE", OracleDbType.Varchar2).Value = objSCItems.SCI_FRN_PRICE;
                            command.Parameters.Add(":SCI_FRN_CURR_CD", OracleDbType.Varchar2).Value = objSCItems.SCI_FRN_CURR_CD;
                            command.Parameters.Add(":SCI_EXCHNG_RATE", OracleDbType.Varchar2).Value = objSCItems.SCI_EXCHNG_RATE;
                            command.Parameters.Add(":SCI_MATL_GRP", OracleDbType.Varchar2).Value = objSCItems.SCI_MATL_GRP;
                            command.Parameters.Add(":SCI_STRG_LOC", OracleDbType.Varchar2).Value = objSCItems.SCI_STRG_LOC;
                            command.Parameters.Add(":SCI_PROC_TYP", OracleDbType.Varchar2).Value = objSCItems.SCI_PROC_TYP;
                            command.Parameters.Add(":SCI_SPARES_CATEGORY", OracleDbType.Varchar2).Value = objSCItems.SCI_SPARES_CATEGORY;
                            command.Parameters.Add(":SCI_DLV_POINT", OracleDbType.Varchar2).Value = objSCItems.SCI_DLV_POINT;
                            command.Parameters.Add(":SCI_CART_NO", OracleDbType.Int64).Value = objSCItems.SCI_CART_NO;
                            command.Parameters.Add(":SCI_MATL_NO", OracleDbType.Varchar2).Value = objSCItems.SCI_MATL_NO;
                            //command.Parameters.Add("err_msg", OracleDbType.Varchar2, 32000).Direction = ParameterDirection.Output;

                            attachInsertCount = command.ExecuteNonQuery();
                            InsertClasificationDocument(objSCItems);


                        }
                    }

                    command.CommandText = "P_INS_SIS_SC_APPROVAL";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    command.Parameters.Add("tot_amnt", OracleDbType.Varchar2).Value = header.SCH_TOT_VAL;
                    command.Parameters.Add("indnt_type", OracleDbType.Varchar2).Value = header.SCH_INDT_TYP;
                    command.Parameters.Add("scartno", OracleDbType.Varchar2).Value = header.SCH_CART_NO;
                    command.Parameters.Add("dept_no", OracleDbType.Varchar2).Value = header.SCH_DEPT;
                    command.Parameters.Add("Committed_Expenditure_Val", OracleDbType.Varchar2).Value = CommittedExpenditure.ToString();
                    command.Parameters.Add("Spare_Budget_Val", OracleDbType.Varchar2).Value = SpareBudget.ToString();
                    int j = command.ExecuteNonQuery();

                    command.CommandText = DBConst.IndentUpdateStatus;
                    command.CommandType = CommandType.Text;
                    command.Parameters.Clear();
                    command.Parameters.Add(":STATUS", "39");
                    command.Parameters.Add(":SCH_CART_NO", header.SCH_CART_NO);
                    int k = command.ExecuteNonQuery();
                    //else { attachInsertCount = BasicId; }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }
        //SelectUMCFPDTYPE
        public async Task<ShoppingCartItem> GetSCItemDetailsFromUMCAndSCNO(string SC_NO, string UMCNo, string FODTYPE, Dictionary<string, List<string>> validation)
        {
            ShoppingCartItem shoppingCartItem = new ShoppingCartItem();
            //  int[] compareCurrentStatus = { 52,45 };  // 40,53,45
            try
            {


                DataTable dataTable = GetSCItemDetailsFromUMC(SC_NO, UMCNo);

                if (dataTable.Rows.Count > 0)
                {
                    shoppingCartItem.Verpr = "0";
                    shoppingCartItem.SCI_CART_NO = dataTable.Rows[0]["SCI_CART_NO"].ToString();
                    shoppingCartItem.SCI_MATL_NO = dataTable.Rows[0]["SCI_MATL_NO"].ToString();
                    shoppingCartItem.SCI_MATL_GRP = dataTable.Rows[0]["SCI_MATL_GRP"].ToString();
                    shoppingCartItem.SCI_PLANT_CD = dataTable.Rows[0]["SCI_PLANT_CD"].ToString();
                    shoppingCartItem.PG_GRP_DESC = dataTable.Rows[0]["pg_desc"].ToString();
                    shoppingCartItem.SCI_SPARES_CATEGORY = dataTable.Rows[0]["SPARE"].ToString();
                    shoppingCartItem.SCI_DLV_POINT = dataTable.Rows[0]["SCI_DLV_POINT"].ToString();
                    shoppingCartItem.SLOC_DESC = dataTable.Rows[0]["SLOC_DESC"].ToString();
                    shoppingCartItem.SCI_STRG_LOC = dataTable.Rows[0]["SCI_STRG_LOC"].ToString();
                    shoppingCartItem.DOC_TYPE_DESC = dataTable.Rows[0]["document_type_DESC"].ToString();
                    shoppingCartItem.SCI_PROC_TYP = dataTable.Rows[0]["PROC_TYPE"].ToString();
                    shoppingCartItem.SCI_PRICE = dataTable.Rows[0]["SCI_PRICE"].ToString();
                    shoppingCartItem.SCI_PUR_GRP = dataTable.Rows[0]["SCI_PUR_GRP"].ToString();
                    shoppingCartItem.SCI_DOC_TYPE = dataTable.Rows[0]["SCI_DOC_TYPE"].ToString();
                    shoppingCartItem.SCI_QTY = dataTable.Rows[0]["SCI_QTY"].ToString();
                    shoppingCartItem.SCI_QTY_UNIT = dataTable.Rows[0]["SCI_QTY_UNIT"].ToString();
                    shoppingCartItem.SCI_PRICE_UNIT = dataTable.Rows[0]["SCI_PRICE_UNIT"].ToString();
                    shoppingCartItem.SCI_REQD_ON_DT = dataTable.Rows[0]["SCI_REQD_ON_DT"].ToString();
                    shoppingCartItem.SCI_FOD_TYPE = dataTable.Rows[0]["SCI_FOD_TYPE"].ToString();
                    shoppingCartItem.SCI_SAC_CODE = dataTable.Rows[0]["SCI_SAC_CODE"].ToString();
                    shoppingCartItem.SCI_CHARACTERISTICS = dataTable.Rows[0]["SCI_CHARACTERISTICS"].ToString();
                    shoppingCartItem.SCI_COMPOSITION = dataTable.Rows[0]["SCI_COMPOSITION"].ToString();
                    shoppingCartItem.SCI_ENDUSE = dataTable.Rows[0]["SCI_ENDUSE"].ToString();
                    shoppingCartItem.SCI_FUNCTION = dataTable.Rows[0]["SCI_FUNCTION"].ToString();
                    shoppingCartItem.UMC_DESC = dataTable.Rows[0]["UMC_DESC"].ToString();
                    shoppingCartItem.SCI_ITEM_NO = dataTable.Rows[0]["SCI_ITEM_NO"].ToString();
                    shoppingCartItem.SCI_OA_VENCD = dataTable.Rows[0]["SCI_OA_VENCD"].ToString();
                    shoppingCartItem.DEPT = dataTable.Rows[0]["INDENTOR_DEPT"].ToString();
                    shoppingCartItem.SCI_TXT_PROC_CONS = dataTable.Rows[0]["SCI_TXT_PROC_CONS"].ToString();
                    shoppingCartItem.SCI_IMP_PLANT_MACHINERY = dataTable.Rows[0]["SCI_IMP_PLANT_MACHINERY"].ToString();
                    shoppingCartItem.SCI_INSTALLED_QTY = dataTable.Rows[0]["SCI_INSTALLED_QTY"].ToString();
                    shoppingCartItem.SCI_REQUESTER = dataTable.Rows[0]["SCI_REQUESTER"].ToString();
                    shoppingCartItem.SCI_FOD_ITEM_NO = dataTable.Rows[0]["SCI_FOD_ITEM_NO"].ToString();
                    shoppingCartItem.SCI_FOD_NO = dataTable.Rows[0]["SCI_FOD_NO"].ToString();
                    shoppingCartItem.SCI_SAP_ERR_MSG = dataTable.Rows[0]["SCI_SAP_ERR_MSG"].ToString();
                    shoppingCartItem.SCI_FOD_CRT_DT = dataTable.Rows[0]["SCI_FOD_CRT_DT"].ToString();
                    shoppingCartItem.SCH_INDT_TYP = dataTable.Rows[0]["SCH_INDT_TYP"].ToString();
                    shoppingCartItem.SCI_FRN_PRICE = dataTable.Rows[0]["SCI_FRN_PRICE"].ToString();
                    shoppingCartItem.SCI_FRN_CURR_CD = dataTable.Rows[0]["SCI_FRN_CURR_CD"].ToString();
                    shoppingCartItem.SCI_EXCHNG_RATE = dataTable.Rows[0]["SCI_EXCHNG_RATE"].ToString();
                    shoppingCartItem.SCI_REF_OA_NO = dataTable.Rows[0]["SCI_REF_OA_NO"].ToString();
                    shoppingCartItem.SCI_OA_ITEM_NO = dataTable.Rows[0]["SCI_OA_ITEM_NO"].ToString();
                    shoppingCartItem.SCI_MFRNR = dataTable.Rows[0]["SCI_MFRNR"].ToString();
                    shoppingCartItem.SCH_CART_NAME = dataTable.Rows[0]["SCH_CART_NAME"].ToString();
                    shoppingCartItem.INDENT_CURRENT_STATUS = Convert.ToInt32(dataTable.Rows[0]["INDENT_CURRENT_STATUS"].ToString());
                    shoppingCartItem.SCI_ClassificationEnable = checkClassificationEnable(dataTable.Rows[0]["SCI_PUR_GRP"].ToString());
                    shoppingCartItem.MaterialConsumptionPlanEnble = await checkMaterialConsumptionPlanEnble(dataTable.Rows[0]["SCI_PUR_GRP"].ToString(), dataTable.Rows[0]["SCI_MATL_NO"].ToString(), dataTable.Rows[0]["SCI_PLANT_CD"].ToString());
                    string jsonstring = JsonConvert.SerializeObject(GetCostAssesmentData(dataTable.Rows[0]["SCI_CART_NO"].ToString(), dataTable.Rows[0]["SCI_ITEM_NO"].ToString()));
                    shoppingCartItem.sccostAssignment = JsonConvert.DeserializeObject<List<SCCostAssignment>>(jsonstring);
                    shoppingCartItem.SCI_CHARACTERISTICS_DOC = "";
                    shoppingCartItem.SCI_COMPOSITION_DOC = "";
                    shoppingCartItem.SCI_ENDUSE_DOC = "";
                    shoppingCartItem.SCI_FUNCTION_DOC = "";
                    shoppingCartItem.SCI_HSN_NO = GetHSN_NO(shoppingCartItem);

                    if (FODTYPE == "RO" && shoppingCartItem.INDENT_CURRENT_STATUS <= 39)
                    {

                        if (String.IsNullOrEmpty(dataTable.Rows[0]["sci_ref_oa_no"].ToString()))
                        {
                            List<SourceListSet> objSourceListSet = await GetROVendorList("", UMCNo, shoppingCartItem.SCI_PLANT_CD);
                            objSourceListSet[0].SCI_CART_NO = SC_NO;
                            objSourceListSet[0].SCI_ITEM_NO = shoppingCartItem.SCI_ITEM_NO;
                            objSourceListSet[0].SCI_REQD_ON_DT = shoppingCartItem.SCI_REQD_ON_DT;
                            shoppingCartItem.SCI_OA_VENCD = objSourceListSet[0].Vendor_code;
                            shoppingCartItem.SCI_REF_OA_NO = objSourceListSet[0].Contract;
                            shoppingCartItem.SCI_OA_ITEM_NO = objSourceListSet[0].Item_no;
                            string netpr = "";
                            DataTable dataTablePriceForArc = GetROPriceFromEKPO(shoppingCartItem.SCI_REF_OA_NO, shoppingCartItem.SCI_OA_ITEM_NO);
                            if (dataTablePriceForArc.Rows.Count > 0)
                            {
                                DataTable datatable_Currency = GetCurrencyRateFromCurrency(dataTablePriceForArc.Rows[0]["WAERS"].ToString());
                                if (dataTablePriceForArc.Rows[0]["WAERS"].ToString() == "INR")
                                {
                                    netpr = dataTablePriceForArc.Rows[0]["netpr"].ToString();
                                }
                                else
                                {

                                    //shoppingCartItem.SCI_FRN_CURR_CD = dataTablePriceForArc.Rows[0]["WAERS"].ToString();
                                    //shoppingCartItem.SCI_FRN_PRICE = dataTablePriceForArc.Rows[0]["netpr"].ToString();
                                    if (datatable_Currency.Rows.Count > 0)
                                    {
                                        netpr = FRNRateCal(String.IsNullOrEmpty(dataTablePriceForArc.Rows[0]["netpr"].ToString()) ? "0" : dataTablePriceForArc.Rows[0]["netpr"].ToString(), String.IsNullOrEmpty(datatable_Currency.Rows[0]["ukurs"].ToString()) ? "0" : datatable_Currency.Rows[0]["ukurs"].ToString());
                                    }
                                    else
                                    {
                                        netpr = "0";
                                    }
                                }

                            }
                            objSourceListSet[0].TotalPrice = (Convert.ToDouble(shoppingCartItem.SCI_QTY) * Convert.ToDouble(netpr)).ToString();

                            UpdateROVendor(objSourceListSet[0], validation);

                        }
                        //if (String.IsNullOrEmpty(shoppingCartItem.SCI_PRICE) || shoppingCartItem.SCI_PRICE == "0")
                        //{
                        DataTable dataTablePrice = GetROPriceFromEKPO(shoppingCartItem.SCI_REF_OA_NO, shoppingCartItem.SCI_OA_ITEM_NO);

                        if (dataTablePrice.Rows.Count > 0)
                        {
                            DataTable datatable_Currency = GetCurrencyRateFromCurrency(dataTablePrice.Rows[0]["WAERS"].ToString());
                            if (dataTablePrice.Rows[0]["WAERS"].ToString() == "INR")
                            {
                                shoppingCartItem.SCI_PRICE = dataTablePrice.Rows[0]["netpr"].ToString();
                            }
                            else
                            {

                                shoppingCartItem.SCI_FRN_CURR_CD = dataTablePrice.Rows[0]["WAERS"].ToString();
                                shoppingCartItem.SCI_FRN_PRICE = dataTablePrice.Rows[0]["netpr"].ToString();
                                if (datatable_Currency.Rows.Count > 0)
                                {
                                    shoppingCartItem.SCI_PRICE = FRNRateCal(String.IsNullOrEmpty(dataTablePrice.Rows[0]["netpr"].ToString()) ? "0" : dataTablePrice.Rows[0]["netpr"].ToString(), String.IsNullOrEmpty(datatable_Currency.Rows[0]["ukurs"].ToString()) ? "0" : datatable_Currency.Rows[0]["ukurs"].ToString());
                                }
                                else
                                {
                                    shoppingCartItem.SCI_PRICE = "0";
                                }
                            }

                        }
                        //}
                        //if (String.IsNullOrEmpty(shoppingCartItem.SCI_PUR_GRP))
                        //{
                        DataTable dtpurgrp = GETROPurchaseGroupList(shoppingCartItem.SCI_REF_OA_NO, shoppingCartItem.SCI_PLANT_CD);
                        if (dtpurgrp.Rows.Count > 0)
                        {
                            shoppingCartItem.SCI_PUR_GRP = dtpurgrp.Rows[0]["pg_cd"].ToString();
                            UpdatePurchaseGroup(shoppingCartItem);
                        }
                        // }

                    }
                    else
                    {
                        string responseContent = await Get_AVGPRICE_ODATA(dataTable.Rows[0]["SCI_MATL_NO"].ToString(), dataTable.Rows[0]["INDENTOR_DEPT"].ToString()).ConfigureAwait(false);
                        if (!String.IsNullOrEmpty(responseContent))
                        {
                            dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseContent);
                            if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                            {
                                if (responseObject.d.results.Count > 0)
                                {
                                    shoppingCartItem.Verpr = responseObject.d.results[0].Verpr;

                                }
                                else
                                {
                                    shoppingCartItem.Verpr = "0";
                                }
                            }
                        }
                        if (String.IsNullOrEmpty(dataTable.Rows[0]["SCI_PRICE"].ToString()) || dataTable.Rows[0]["SCI_PRICE"].ToString() == "0")
                        {
                            shoppingCartItem.SCI_PRICE = shoppingCartItem.Verpr;
                        }
                    }


                    //else if ()
                    //{
                    //    shoppingCartItem.SCI_PRICE = shoppingCartItem.Verpr;
                    //}
                    if (!String.IsNullOrEmpty(dataTable.Rows[0]["SCI_TXT_PROC_CONS"].ToString()) && dataTable.Rows[0]["SCI_TXT_PROC_CONS"].ToString() != "O" && dataTable.Rows[0]["SCI_TXT_PROC_CONS"].ToString() != "0")
                    {
                        shoppingCartItem.SCI_TXT_PROC_CONS = "MTRCL";
                    }

                }



            }
            catch (Exception excp)
            {

            }


            return shoppingCartItem;
        }

        public string FRNRateCal(string inrrate, string convertrate)
        {
            double rate = Convert.ToDouble(inrrate) * Convert.ToDouble(convertrate);
            return rate.ToString();
        }

        public DataTable GetSCItemDetailsFromUMC(string SC_NO, string UMCNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetShoppingCartItem, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            

                objConn.AddParameters(":SCI_MATL_NO", UMCNo);
                objConn.AddParameters(":SCI_CART_NO", SC_NO);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public string CheckValidationForShoppingCart(ShoppingCartHeader header, List<ShoppingCartItem> items)
        {
            //foreach (var objShoppingCartItems in items)
            //{
            //    if(objShoppingCartItems.)
            //}
            //    if (items == "PR" & productType == "02")
            //{
            //    if (totalprice > COSTMODELVALUE)
            //    {
            //        if (ddCostModel.SelectedValue == "0")
            //        {
            //            err_cnt = err_cnt + 1;
            //            err_tr = new HtmlTableRow();
            //            err_tr.Cells.Add(new HtmlTableCell());
            //            tbl_errors.Rows.Add(err_tr);
            //            err_tr.Cells(0).InnerText = " Basic Data             : You must select a cost model as the price has exceeded the amount of Rs. " + COSTMODELVALUE.ToString;
            //            err_tr.Attributes.Add("style", "color:red; height:3px;");
            //        }
            //    }
            //}
            return "";
        }

        public int InsertSCDocumentDetails(SCDocument sCDocument)
        {
            int respose = 0;
            int max_line_no = 0;
            int int_cnt_line = 0;
            int isDelete = 0;

            isDelete = DeleteTextDocumentFromLVL(sCDocument);
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                int Count = 0;

                try
                {
                    if (!(sCDocument.SCD_TXT.Length == 0))
                    {
                        if (sCDocument.SCD_TXT.Length % 70 == 0)
                        {
                            int_cnt_line = (short)Math.Round(sCDocument.SCD_TXT.Length / 70d);
                        }
                        else if (sCDocument.SCD_TXT.Length > 70)
                        {
                            int_cnt_line = (short)Math.Round(sCDocument.SCD_TXT.Length / 70d);
                            int_cnt_line = (short)(int_cnt_line + 1);
                        }
                        else
                        {
                            int_cnt_line = 1;
                        }
                    }

                    for (short int_ctr_line = 0, loopTo = (short)(int_cnt_line - 1); int_ctr_line <= loopTo; int_ctr_line++)
                    {
                        short ln_no = (short)(int_ctr_line + max_line_no + 1);

                        string str_temp_vend_txt = Mid(sCDocument.SCD_TXT, int_ctr_line * 70 + 1, 70);

                        command.Parameters.Clear();
                        command.CommandText = DBConst.oraInsertSCIDocuments;
                        command.CommandType = CommandType.Text;
                        // Input parameters
                        command.Parameters.Add("scd_cart_no", OracleDbType.Int64).Value = sCDocument.SCD_CART_NO;
                        command.Parameters.Add("scd_item_no", OracleDbType.Int64).Value = sCDocument.SCD_ITEM_NO;
                        command.Parameters.Add("scd_txt_type", OracleDbType.Varchar2).Value = sCDocument.SCD_TXT_TYPE;
                        command.Parameters.Add("scd_line_no", OracleDbType.Int32).Value = ln_no;
                        command.Parameters.Add("scd_txt", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(str_temp_vend_txt) ? " " : str_temp_vend_txt;
                        command.Parameters.Add("scd_upd_id", OracleDbType.Varchar2).Value = sCDocument.SCD_UPD_ID;
                        command.Parameters.Add("scd_lvl", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(sCDocument.SCD_LVL) ? "I" : sCDocument.SCD_LVL;

                        respose = command.ExecuteNonQuery();
                    }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return respose;
        }
        public static string Mid(string str, int Start, int Length)
        {
            if (Start <= 0)
            {
                throw new ArgumentException("Argument_GTZero1", "Start");
            }

            if (Length < 0)
            {
                throw new ArgumentException("Argument_GEZero1", "Length");
            }

            if (Length == 0 || str == null)
            {
                return "";
            }

            int length = str.Length;
            if (Start > length)
            {
                return "";
            }

            checked
            {
                if (Start + Length > length)
                {
                    return str.Substring(Start - 1);
                }

                return str.Substring(Start - 1, Length);
            }
        }

        public int UpdateSCDocumentDetails(SCDocument sCDocument)
        {
            int respose = 0;
            int max_line_no = 0;
            int int_cnt_line = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                int Count = 0;

                try
                {
                    if (!(sCDocument.SCD_TXT.Length == 0))
                    {
                        if (sCDocument.SCD_TXT.Length % 70 == 0)
                        {
                            int_cnt_line = (short)Math.Round(sCDocument.SCD_TXT.Length / 70d);
                        }
                        else if (sCDocument.SCD_TXT.Length > 70)
                        {
                            int_cnt_line = (short)Math.Round(sCDocument.SCD_TXT.Length / 70d);
                            int_cnt_line = (short)(int_cnt_line + 1);
                        }
                        else
                        {
                            int_cnt_line = 1;
                        }
                    }

                    for (short int_ctr_line = 0, loopTo = (short)(int_cnt_line - 1); int_ctr_line <= loopTo; int_ctr_line++)
                    {
                        short ln_no = (short)(int_ctr_line + max_line_no + 1);

                        string str_temp_vend_txt = Mid(sCDocument.SCD_TXT, int_ctr_line * 70 + 1, 70);


                        command.Parameters.Clear();
                        command.CommandText = DBConst.oraUpdateSCIDocuments;
                        command.CommandType = CommandType.Text;
                        // Input parameters


                        command.Parameters.Add("scd_txt", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(str_temp_vend_txt) ? " " : str_temp_vend_txt;
                        command.Parameters.Add("scd_line_no", OracleDbType.Int32).Value = ln_no;
                        command.Parameters.Add("scd_lvl", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(sCDocument.SCD_LVL) ? "I" : sCDocument.SCD_LVL;
                        command.Parameters.Add("scd_upd_id", OracleDbType.Varchar2).Value = sCDocument.SCD_UPD_ID;
                        command.Parameters.Add("scd_cart_no", OracleDbType.Int64).Value = sCDocument.SCD_CART_NO;
                        command.Parameters.Add("scd_item_no", OracleDbType.Int64).Value = sCDocument.SCD_ITEM_NO;
                        command.Parameters.Add("scd_txt_type", OracleDbType.Varchar2).Value = sCDocument.SCD_TXT_TYPE;
                        respose = command.ExecuteNonQuery();
                    }


                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return respose;
        }
        // start of validations
        public DataTable getShoppingCartItemList(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetShoppingCartItemList, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getShoppingCartAccountAssinment(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getShoppingCartAccountAssinment, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getRapidCheckList(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetRapidCheckList, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getdtIsAcntMissing(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getdtIsAcntMissing, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getParamMasterList()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetParamMasterList, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public DataTable getSqlDistinctCat(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getSqlDistinctCat, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getDrft_chk_sc(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getDrft_chk_sc, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getShoppingCartDocument(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getShoppingCartDocument, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getOrderIndicator(string auart)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getOrderIndicator, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":auart", auart);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public DataTable getIndicatorCount(string orderNO, string dept)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getIndicatorCount, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":orderNO", orderNO);
                objConn.AddParameters(":dept", dept);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getShoppingCartItemEcm(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getShoppingCartItemEcm, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public DataTable getSusData(string scNo, string itemNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getSusData, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.AddParameters(":scNo", scNo);
                objConn.AddParameters(":itemNo", itemNo);

                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public void validateCheckRO(DataRow row, Dictionary<string, List<string>> validation, DataTable dtShoppingCartAccountAssinment)
        {
            if (row["SCI_REF_OA_NO"].ToString() == "" && row["SCI_OA_ITEM_NO"].ToString() == "" && row["SCI_OA_VENCD"].ToString() == "")
            {
                if (!validation.ContainsKey("4"))
                {
                    validation["4"] = new List<string>();
                }
                validation["4"].Add("Please select source of supply for item no. " + row["SCI_ITEM_NO"].ToString() + " and save it");
            }

            if (row["sci_fod_type"].ToString().Equals("RO") && row["SCI_PROD_TYPE"].ToString().Equals("01"))
            {
                DataRow[] datarows = dtShoppingCartAccountAssinment.Select(" SAA_ITEM_NO='" + row["SCI_ITEM_NO"].ToString() + "' and  SAA_CATEGORY='U'", "");

                if (datarows.Length > 0)
                {
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Account assignment: Material RO can not be created with Unknown for Service as cost assignment item no. " + row["SCI_ITEM_NO"].ToString() + " and save it");

                }
            }
        }

        public void validateBasicFieldCheck(DataRow row, Dictionary<string, List<string>> validation)
        {
            if (row["SCI_PUR_GRP"].ToString() == "")
            {
                err_cnt++;
                if (!validation.ContainsKey("4"))
                {
                    validation["4"] = new List<string>();
                }
                validation["4"].Add("Basic Data : Purchasing group cannot be left blank for Item no. " + row["SCI_ITEM_NO"].ToString());

            }
        }


        public void validateMaterialForSubmit(DataRow row, Dictionary<string, List<string>> validation)
        {
            DataTable plant_lvl_chk_str_dt = get_plant_lvl_chk_str(row["SCI_MATL_NO"].ToString(), row["SCI_PLANT_CD"].ToString());
            DataTable plant_indpndnt_chk_rdr_dt = get_plant_indpndnt_chk_rdr(row["SCI_MATL_NO"].ToString(), row["SCI_PLANT_CD"].ToString());

            string matl_plantlvl_status = "";
            string plant_indpndnt_status = "";
            string mat_status = "";
            string MAT_DEL_FLAG_PLNT = "";

            if (plant_lvl_chk_str_dt.Rows.Count > 0)
            {
                matl_plantlvl_status = plant_lvl_chk_str_dt.Rows[0]["CROS_PLNT_MAT_STAT"].ToString().Trim();
            }

            if (plant_indpndnt_chk_rdr_dt.Rows.Count > 0)
            {
                plant_indpndnt_status = plant_indpndnt_chk_rdr_dt.Rows[0]["PLNT_MAT_STAT"].ToString().Trim();
                mat_status = plant_indpndnt_chk_rdr_dt.Rows[0]["MAT_TYP"].ToString().Trim();
                MAT_DEL_FLAG_PLNT = plant_indpndnt_chk_rdr_dt.Rows[0]["MAT_DEL_FLAG_PLNT"].ToString().Trim();
            }

            if (row["SCI_FOD_TYPE"].ToString() == "PR" || row["SCI_FOD_TYPE"].ToString() == "ZP" || row["SCI_FOD_TYPE"].ToString() == "MF")
            {

                if (plant_indpndnt_status == "01")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is blocked for Blocked for Procurement/Whse for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");
                }
                else if (matl_plantlvl_status == "01")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is blocked for Blocked for Procurement/Whse in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }


                if (plant_indpndnt_status == "03")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is blocked for Blocked for Procurement for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }
                else if (matl_plantlvl_status == "03")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is blocked for Blocked for Procurement in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }

                if (plant_indpndnt_status == "M1")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add(" Material is Blocked for UOM for Item no. " + row["SCI_ITEM_NO"].ToString() + "Please submit again");

                }
                else if (matl_plantlvl_status == "M1")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for UOM in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }

                if (plant_indpndnt_status == "M3")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for Proc/Resn/Pln for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }
                else if (matl_plantlvl_status == "M3")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for Proc/Resn/Pln in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }

                if (plant_indpndnt_status == "Z1")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked For Proc/Whse/Cost " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }
                else if (matl_plantlvl_status == "Z1")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked For Proc/Whse/Cost in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                }

                if (plant_indpndnt_status == "Z2")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for Postings " + row["SCI_ITEM_NO"].ToString() + " Please submit again");
                }
                else if (matl_plantlvl_status == "Z2")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for Postings in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");
                }

                if (plant_indpndnt_status == "Z3")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for ML Monitoring " + row["SCI_ITEM_NO"].ToString() + " Please submit again");
                }
                else if (matl_plantlvl_status == "Z3")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Material is Blocked for ML Monitoring in plant " + row["SCI_PLANT_CD"].ToString() + " for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");
                }

            }


            //if ((objSCItems.SCI_FOD_TYPE == "PR" || objSCItems.SCI_FOD_TYPE == "MR") && PROD_TYPR=="01")

            if ((row["SCI_FOD_TYPE"].ToString() == "PR" || row["SCI_FOD_TYPE"].ToString() == "MR"))
            {
                if ((!string.IsNullOrWhiteSpace(matl_plantlvl_status) || !string.IsNullOrWhiteSpace(plant_indpndnt_status)) && row["SCI_FOD_TYPE"].ToString() == "PR" && (matl_plantlvl_status.ToUpper().Trim() == "Z4" || plant_indpndnt_status.ToUpper().Trim() == "Z4"))
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("PR cannot be created for the material of item no. " + row["SCI_ITEM_NO"].ToString() + " as material is blocked for Purchase Requision" + " Please submit again");
                }
                else if ((!string.IsNullOrWhiteSpace(matl_plantlvl_status) || !string.IsNullOrWhiteSpace(plant_indpndnt_status)) && row["SCI_FOD_TYPE"].ToString() == "MR" && (matl_plantlvl_status.ToUpper().Trim() == "Z5" || plant_indpndnt_status.ToUpper().Trim() == "Z5"))
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("MR cannot be created for the material of item no. " + row["SCI_ITEM_NO"].ToString() + "  as material is blocked for Reservation. " + " Please submit again");

                }
            }

            DataTable dtParamCd = getParamCd();
            bool MDMACTIVE = false;

            if (dtParamCd.Select("pam_type_cd = 'MDM_ACTV'").Length > 0)
            {
                MDMACTIVE = true;
            }
            string matl_plantlvl_status1 = "";
            string plant_indpndnt_status1 = "";
            if (MDMACTIVE == true)
            {
                DataTable dtPlantCheck = getPlantCheck(row["SCI_MATL_NO"].ToString(), row["SCI_PLANT_CD"].ToString());

                if (dtPlantCheck.Rows.Count > 0)
                {
                    matl_plantlvl_status1 = dtPlantCheck.Rows[0]["CROS_PLNT_MAT_STAT"].ToString().Trim();
                    plant_indpndnt_status1 = dtPlantCheck.Rows[0]["PLNT_MAT_STAT"].ToString().Trim();

                    if (matl_plantlvl_status1.ToUpper().Trim() == "ZP" || plant_indpndnt_status1.ToUpper().Trim() == "ZP")
                    {
                        if (row["SCI_FOD_TYPE"].ToString() == "PR" || row["SCI_FOD_TYPE"].ToString() == "ZP")
                        {
                            err_cnt++;
                            if (!validation.ContainsKey("4"))
                            {
                                validation["4"] = new List<string>();
                            }
                            validation["4"].Add("Material blocked for PR & ZPPR creation for item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                        }
                    }

                }
            }

            if (MAT_DEL_FLAG_PLNT == "X")
            {
                err_cnt++;
                if (!validation.ContainsKey("4"))
                {
                    validation["4"] = new List<string>();
                }
                validation["4"].Add("Material is flagged for deletion  for item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

            }
            //if(objSCItems.SCI_FOD_TYPE == "PR" && objSCItems.SCI_PROD_TYPE=="01" && objSCItems.SCI_MATL_NO!="")
            DataTable division_dt = new DataTable();
            DataTable gsber_dt = new DataTable();
            if (row["SCI_FOD_TYPE"].ToString() == "PR" && row["SCI_MATL_NO"].ToString() != "")
            {
                division_dt = getDivisionData(row["SCI_MATL_NO"].ToString(), row["SCI_PLANT_CD"].ToString());
                if (division_dt.Rows.Count > 0)
                {
                    string spart = division_dt.Rows[0]["spart"].ToString();
                    gsber_dt = getGsber(row["SCI_PLANT_CD"].ToString(), spart);

                    if (gsber_dt.Rows.Count > 0)
                    {
                        string gs = gsber_dt.Rows[0]["gsber"].ToString().Trim();
                        if (gsber_dt.Rows[0]["gsber"].ToString().Trim() == "")
                        {
                            err_cnt++;
                            if (!validation.ContainsKey("4"))
                            {
                                validation["4"] = new List<string>();
                            }
                            validation["4"].Add("Material/Plant/Division not mapped to Business Area,Please contact IBM Help Desk for item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                        }
                    }
                    else if (gsber_dt.Rows.Count == 0)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("3"))
                        {
                            validation["3"] = new List<string>();
                        }
                        validation["3"].Add("Material/Plant/Division not mapped to Business Area,Please contact IBM Help Desk for item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");

                    }

                }
            }

            //if(objSCItems.SCI_FOD_TYPE == "PR" && sci_prod_id=="01")
            if (row["SCI_FOD_TYPE"].ToString() == "PR")
            {
                if (row["SCI_DOC_TYPE"].ToString().Trim() == "NC")
                {
                    DataTable Mat_Val_Cls_dt = get_Mat_Val_Cls(row["SCI_MATL_NO"].ToString(), row["SCI_PLANT_CD"].ToString());

                    string valu_class = "";
                    if (Mat_Val_Cls_dt.Rows.Count > 0)
                    {
                        valu_class = Mat_Val_Cls_dt.Rows[0]["qklas"].ToString();
                    }

                    if (!valu_class.StartsWith("5"))
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("4"))
                        {
                            validation["4"] = new List<string>();
                        }
                        validation["4"].Add("project valuation class is not maintained for this material  for Item no. " + row["SCI_ITEM_NO"].ToString() + " Please submit again");
                    }
                }

            }
        }

        public void validateMpnDrawingForSubmit(DataRow row, Dictionary<string, List<string>> validation)
        {
            if (row["SCI_PART_NO"] == DBNull.Value &&
                    row["SCI_MFRNR"] == DBNull.Value &&
                    row["SCI_MPN_NO"] == DBNull.Value)
            {
                if (!validation.ContainsKey("4"))
                {
                    validation["4"] = new List<string>();
                }
                validation["4"].Add("Please select atleast one value in MPN/Drawing for Item no. " + row["SCI_ITEM_NO"].ToString() + " and submit again!");

            }
        }


        public async Task MastervalidationsOfCheck(ShoppingCartHeader header, List<ShoppingCartItem> items, Dictionary<string, List<string>> validation)
        {
            dynamic responseObject = null;
            string responseData = await Get_budgetConsumptionFormDept_ODATA(header.SCH_DEPT);
            if (!String.IsNullOrEmpty(responseData))
            {
                responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
            }

                //validation for shoppingCart RapidCheck
             DataTable dtShoppingCartItem = getShoppingCartItemList(header.SCH_CART_NO);

            DataTable dtRapidPRCheck = getRapidCheckList(header.SCH_CART_NO);

            DataTable dtShoppingCartAccountAssinment = getShoppingCartAccountAssinment(header.SCH_CART_NO);

            validateRapidPR(dtRapidPRCheck, validation);

            //Value check validation

            string fod_type = items[0].SCI_FOD_TYPE;
            dtShoppingCartItem.Columns.Add("ItemPrice", typeof(double));
            foreach (DataRow row in dtShoppingCartItem.Rows)
            {
                double sci_qty = 0;
                double sci_price = 0;

                // Try to parse "sci_qty" and "sci_price" into double variables
                double.TryParse(row["sci_qty"].ToString(), out sci_qty);
                double.TryParse(row["sci_price"].ToString(), out sci_price);

                // Calculate the product and assign it to "ItemPrice"
                row["ItemPrice"] = sci_qty * sci_price;

                string scNo = row["SCI_CART_NO"].ToString();
                string itemNo = row["SCI_ITEM_NO"].ToString();


                DataTable susDt = getSusData(scNo, itemNo);
                if (susDt.Rows.Count > 0 && susDt.Rows[0][0].ToString() == "0")
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Please fill sustanibility detail for item no. " + row["SCI_ITEM_NO"].ToString());


                }

                //DataTable mpnValueCountDt = getMpnValueCount(row["SCI_MATL_NO"].ToString());
                //string countMpnDrawing = mpnValueCountDt.Rows[0]["counter"].ToString();

                //if (Convert.ToInt32(countMpnDrawing) > 0)
                //{
                //    validateMpnDrawingForSubmit(row, validation);
                //}
                validateMaterialForSubmit(row, validation);
                validateBasicFieldCheck(row, validation);

                if (fod_type == "RO")
                {
                    validateCheckRO(row, validation, dtShoppingCartAccountAssinment);
                }
               
            }

            DataTable dtIntellibuyDetails = GetIntelliBuyChecksHeaderAndItem(header.SCH_INDENT_NO);

            foreach (DataRow row in dtIntellibuyDetails.Rows)
            {
                 DataTable budgetDeptCountdt = getbudgetDeptCount(header.SCH_CART_NO);
                if (budgetDeptCountdt.Rows.Count > 0 && budgetDeptCountdt.Rows[0][0].ToString() != "0")
                {
                    int fiscalYearReqOnDate = 0;
                    fiscalYearReqOnDate = GetFiscalYear(DateTime.Parse(row["requirement_date"].ToString()));
                    int countOfFisYr = 0;
                    if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                    {
                        foreach (var result in responseObject.d.results)
                        {

                            String fisYr = result.FisYr;
                            if (fisYr == fiscalYearReqOnDate.ToString())
                            {
                                countOfFisYr++;
                            }
                        }

                    }

                    if (countOfFisYr == 0)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("4"))
                        {
                            validation["4"] = new List<string>();
                        }
                        validation["4"].Add(" Budget not updated for FY, " + fiscalYearReqOnDate.ToString()  + ". Please Contact CMP. and then submit!!");

                    }
                }

            }

            if (fod_type == "RO")
            {
                DataTable dtIsAcntMissing = getdtIsAcntMissing(header.SCH_CART_NO);

                if (dtIsAcntMissing.Rows.Count > 0)
                {
                    foreach (DataRow row in dtIsAcntMissing.Rows)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("4"))
                        {
                            validation["4"] = new List<string>();
                        }
                        validation["4"].Add("Account assignment missing for item no. " + row["SCI_ITEM_NO"].ToString());

                    }
                }
            }

            DataTable dtParameterMaster = getParamMasterList();
            validateParamMaster(dtShoppingCartItem, dtParameterMaster, validation);

            // validation

            validatePRZPValueCheck(dtShoppingCartItem, items, validation);

            // validation

            validationSummationOfServicePRZP(dtShoppingCartItem, validation);

            DataTable sqlDistinctCatDt = getSqlDistinctCat(header.SCH_CART_NO);
            DataTable drft_chk_sc_dt = getDrft_chk_sc(header.SCH_CART_NO);
            String sch_status = drft_chk_sc_dt.Rows[0]["sch_status"].ToString().Trim();


            validateDataCheck(dtShoppingCartItem, sqlDistinctCatDt, sch_status, validation);

            DataTable dtShoppingCartDocument = getShoppingCartDocument(header.SCH_CART_NO);

            validateDocumentCheck(dtShoppingCartItem, dtShoppingCartDocument, validation);

            validateItemSavedOrNot(dtShoppingCartItem, validation);

            DataTable dtShoppingCartItemEcm = getShoppingCartItemEcm(header.SCH_CART_NO);

            validateShoppingCartItemEcm(dtShoppingCartItem, dtShoppingCartItemEcm, validation);

            return;
        }

        public void validateShoppingCartItemEcm(DataTable dtShoppingCartItem, DataTable dtShoppingCartItemEcm, Dictionary<string, List<string>> validation)
        {
            if (dtShoppingCartItemEcm.Rows.Count > 0)
            {
                foreach (DataRow row in dtShoppingCartItem.Rows)
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add("Item No.: " + row["sci_item_no"].ToString() + " , PGrp : " + row["sci_pur_grp"].ToString() + " and Mat Grp : " + row["sci_matl_grp"].ToString() + " Combination is invalid. For further clarification please contact Procurement. ");

                }
            }
        }

        public void validateItemSavedOrNot(DataTable dtShoppingCartItem, Dictionary<string, List<string>> validation)
        {
            int countNotSavedItem = 0;
            string strNotSaved = "";
            foreach (DataRow row in dtShoppingCartItem.Rows)
            {
                if (!row["sci_itm_saved_stat"].ToString().Equals("Y"))
                {
                    strNotSaved += "," + row["sci_item_no"].ToString();
                    countNotSavedItem++;
                }
            }

            if (strNotSaved.Length > 0 && countNotSavedItem > 0)
            {
                strNotSaved = strNotSaved.Substring(1, strNotSaved.Length - 1);
                err_cnt++;
                if (!validation.ContainsKey("4"))
                {
                    validation["4"] = new List<string>();
                }
                validation["4"].Add(" Item numbers " + strNotSaved + " have not been saved yet !!!  Please save them before you proceed !!!");

            }
        }

        public DataTable getDesvencodr(string vendor)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getDesvencodr, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":vendor", vendor);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public void validateDocumentCheck(DataTable dtShoppingCartItem, DataTable dtShoppingCartDocument, Dictionary<string, List<string>> validation)
        {
            foreach (DataRow row in dtShoppingCartItem.Rows)
            {
                //sci_item_no_read = row["SCI_ITEM_NO"].ToString();
                if (!string.IsNullOrEmpty(row["sci_oa_vencd"].ToString()) && row["sci_fod_type"].ToString().Equals("PR"))
                {
                    DataRow[] datarows = dtShoppingCartDocument.Select("scd_item_no='" + row["SCI_ITEM_NO"].ToString() + "' and scd_txt_type='B32'", "");
                    if (datarows.Length == 0)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("4"))
                        {
                            validation["4"] = new List<string>();
                        }
                        validation["4"].Add("Document Data: You must Select the Justification for Desired Vendor for item no " + row["SCI_ITEM_NO"].ToString() + " and save it ");


                    }
                }

                if (row["sci_fod_type"].ToString().Equals("PR") || row["sci_fod_type"].ToString().Equals("MF"))
                {
                    if (!string.IsNullOrEmpty(row["sci_oa_vencd"].ToString()))
                    {
                        DataTable desvencodrdt = getDesvencodr(row["sci_oa_vencd"].ToString());
                        if (desvencodrdt.Rows.Count > 0)
                        {
                            DataRow row1 = desvencodrdt.Rows[0];
                            if (!string.IsNullOrEmpty(row1[0].ToString().Trim()))
                            {
                                err_cnt++;
                                if (!validation.ContainsKey("4"))
                                {
                                    validation["4"] = new List<string>();
                                }
                                validation["4"].Add("Source Supply/Service : Vendor is blocked");

                            }
                        }

                    }
                }
            }

            foreach (DataRow row in dtShoppingCartItem.Rows)
            {
                if (row["sci_doc_type"].ToString().Equals("NP") && row["sci_fod_type"].ToString().Equals("PR") && row["sci_prod_type"].ToString().Equals("01"))
                {
                    DataRow[] datarows = dtShoppingCartDocument.Select("scd_item_no='" + row["SCI_ITEM_NO"].ToString() + "' and scd_txt_type='B33'");

                    if (datarows.Length == 0)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("4"))
                        {
                            validation["4"] = new List<string>();
                        }
                        validation["4"].Add("Document Data: You must Select the Justification for Proprietary for item no. " + row["SCI_ITEM_NO"].ToString() + " and save it ");


                    }
                }
            }

        }



        public void validateDataCheck(DataTable dtShoppingCartItem, DataTable sqlDistinctCatDt, string sch_status, Dictionary<string, List<string>> validation)
        {
            DataTable sqlDistinctprodtbl = new DataTable();
            DataTable sqlDistinctfodtbl = new DataTable();
            DataView ViewDisc = new DataView(dtShoppingCartItem.Copy());

            if (sqlDistinctCatDt.Rows[0]["sci_prod_type"].ToString() == "1")
            {
                DataRow[] rowDistinctprodtbl = dtShoppingCartItem.Copy().Select("sci_itm_saved_stat = 'Y' and sci_prod_type = '01'");
                if (rowDistinctprodtbl.Length > 0)
                {
                    DataView ViewRcvPlant = new DataView(rowDistinctprodtbl.CopyToDataTable());
                    sqlDistinctprodtbl = ViewDisc.ToTable(true, "sci_prod_type");
                }
            }

            if (sqlDistinctCatDt.Rows[0]["sci_fod_type"].ToString() == "1")
            {
                DataRow[] rowDistinctprodtbl = dtShoppingCartItem.Copy().Select("sci_itm_saved_stat = 'Y' and sci_fod_type in ('PR','RO')");
                if (rowDistinctprodtbl.Length > 0)
                {
                    DataView ViewRcvPlant = new DataView(rowDistinctprodtbl.CopyToDataTable());
                    sqlDistinctfodtbl = ViewDisc.ToTable(true, "sci_fod_type");
                }
            }

            if (sqlDistinctfodtbl.Rows.Count > 0 && sqlDistinctprodtbl.Rows.Count > 0 && sch_status.ToString() == "02" &&
                (int.Parse(sqlDistinctCatDt.Rows[0]["cat"].ToString()) > 1 || int.Parse(sqlDistinctCatDt.Rows[0]["stloc"].ToString()) > 1))
            {
                if (int.Parse(sqlDistinctCatDt.Rows[0]["cat"].ToString()) > 1)
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add(" Account Assignmemnt should be same for all items.");

                }
            }
        }


        public void validateParamMaster(DataTable dtShoppingCartItem, DataTable dtParameterMaster, Dictionary<string, List<string>> validation)
        {
            double PR_Limit = 2000;
            DataTable dtFastPuchaseGroupUpperLimit = new DataTable();
            DataTable dtFastPuchaseGroupLowerLimit = new DataTable();

            if (dtParameterMaster.Rows.Count > 0)
            {
                // Select rows where PAM_TYPE_CD is 'FASTPURLMT'
                DataRow[] rowsFastPuchaseGroupUpperLimit = dtParameterMaster.Copy().Select("PAM_TYPE_CD='FASTPURLMT'", "");
                if (rowsFastPuchaseGroupUpperLimit.Length > 0)
                {
                    // Create a new DataTable from the selected rows
                    dtFastPuchaseGroupUpperLimit = rowsFastPuchaseGroupUpperLimit.CopyToDataTable();
                }

                DataRow[] rowsFastPuchaseGroup = dtParameterMaster.Copy().Select("PAM_TYPE_CD='FASTPURGRP'", "");
                if (rowsFastPuchaseGroup.Length > 0)
                {
                    // Create a new DataTable from the selected rows
                    dtFastPuchaseGroupLowerLimit = rowsFastPuchaseGroup.CopyToDataTable();
                }
            }

            if (dtFastPuchaseGroupUpperLimit.Rows.Count > 0)
            {
                string fastPurchaseInClauseUpperLimit = "";
                foreach (DataRow row in dtFastPuchaseGroupUpperLimit.Rows)
                {
                    fastPurchaseInClauseUpperLimit += "'" + row["PAM_PARAM_CD"].ToString() + "',";
                }
                fastPurchaseInClauseUpperLimit = fastPurchaseInClauseUpperLimit.Substring(0, fastPurchaseInClauseUpperLimit.Length - 1);

                DataView view = new DataView(dtShoppingCartItem.Copy());
                DataTable distinctPurAndMatGrp = view.ToTable(true, "SCI_PUR_GRP", "SCI_MATL_GRP");

                foreach (DataRow row in distinctPurAndMatGrp.Rows)
                {
                    object sumObject = dtShoppingCartItem.Compute("Sum(ItemPrice)",
                        "SCI_PUR_GRP='" + row["SCI_PUR_GRP"] + "' and SCI_MATL_GRP='" + row["SCI_MATL_GRP"] +
                        "' AND sci_fod_type in ('PR','RO') AND sci_pur_grp IN (" + fastPurchaseInClauseUpperLimit + ")");

                    if (sumObject != null)
                    {
                        try
                        {
                            if (sumObject != DBNull.Value && double.Parse(sumObject.ToString()) > 100000)
                            {
                                err_cnt++;
                                if (!validation.ContainsKey("4"))
                                {
                                    validation["4"] = new List<string>();
                                }
                                validation["4"].Add(" Maximum value of PR should be Rs 1 Lakh for Purchasing group 104. For further clarification please contact Procurement. ");

                            }
                        }
                        catch (Exception ex)
                        {
                            // Handle exception (optional)
                        }
                    }
                }
            }

            if (dtFastPuchaseGroupLowerLimit.Rows.Count > 0)
            {
                string fastPurchaseInClause = "";
                foreach (DataRow row in dtFastPuchaseGroupLowerLimit.Rows)
                {
                    fastPurchaseInClause += "'" + row["PAM_PARAM_CD"].ToString() + "',";
                }
                fastPurchaseInClause = fastPurchaseInClause.Substring(0, fastPurchaseInClause.Length - 1);

                DataRow[] FastPuchaseGroupRows = dtShoppingCartItem.Copy().Select("sci_fod_type = 'PR' and Sci_Prod_Type='01' and sci_doc_type in('NB','NP','NC') and sci_pur_grp in(" + fastPurchaseInClause + ")", "");
                bool flag_PR_Val = FastPuchaseGroupRows.Length > 0;

                if (flag_PR_Val == true)
                {
                    DataView view = new DataView(dtShoppingCartItem.Copy());
                    DataTable distinctPurAndMatGrp = view.ToTable(true, "SCI_PUR_GRP", "SCI_MATL_GRP");

                    foreach (DataRow row in distinctPurAndMatGrp.Rows)
                    {
                        object sumObject = dtShoppingCartItem.Compute("Sum(ItemPrice)", "SCI_PUR_GRP='" + row["SCI_PUR_GRP"] + "' and SCI_MATL_GRP='" + row["SCI_MATL_GRP"] + "' AND sci_fod_type = 'PR' AND sci_prod_type = '01' AND sci_doc_type IN ('NB','NP','NC') AND sci_pur_grp IN (" + fastPurchaseInClause + ")");

                        if (sumObject != null)
                        {
                            try
                            {
                                if (sumObject != DBNull.Value && double.Parse(sumObject.ToString()) < PR_Limit)
                                {
                                    err_cnt++;
                                    if (!validation.ContainsKey("4"))
                                    {
                                        validation["4"] = new List<string>();
                                    }
                                    validation["4"].Add(" Minimum value of PR should be Rs " + PR_Limit.ToString() + " . For further clarification please contact Procurement. ");

                                }
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                }
            }
        }

        public void validateRapidPR(DataTable dtRapidPRCheck, Dictionary<string, List<string>> validation)
        {
            if (dtRapidPRCheck.Rows.Count > 0)
            {
                // First Validation
                DataRow[] RapidPRCheckRows = dtRapidPRCheck.Copy().Select("sci_pur_grp = '171' and BGG = 'CENBGG' and amount > 100000");
                if (RapidPRCheckRows.Length > 0)
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add(" PR Value Greater than 1 Lakh and Central BGG to be raised under PGrp = 175. For further clarification please contact Procurement.");
                }
                // Second Validation
                RapidPRCheckRows = dtRapidPRCheck.Copy().Select("sci_pur_grp = '175' and BGG = 'CENBGG' and amount < 100000");
                if (RapidPRCheckRows.Length > 0)
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add(" PR Value Less than 1 Lakh and Central BGG to be raised under PGrp = 171. For further clarification please contact Procurement. ");
                }

                // Third Validation
                RapidPRCheckRows = dtRapidPRCheck.Copy().Select("sci_pur_grp = '175' and BGG = 'LOCAL'");
                if (RapidPRCheckRows.Length > 0)
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add(" PR with Local BGG is allowed under PGrp = 171 only. For further clarification please contact Procurement. ");
                }

                // Fourth Validation
                RapidPRCheckRows = dtRapidPRCheck.Copy().Select("LOC = 'JSR' and amount < 100000");
                if (RapidPRCheckRows.Length > 0)
                {
                    err_cnt++;
                    if (!validation.ContainsKey("4"))
                    {
                        validation["4"] = new List<string>();
                    }
                    validation["4"].Add(" PR with Value Less than Rs 1 Lakh is allowed under Purchasing group 104 only. For further clarification please contact Procurement. ");
                }
            }
        }

        public void validationSummationOfServicePRZP(DataTable dtShoppingCartItem, Dictionary<string, List<string>> validation)
        {

            DataView ViewDisc = new DataView(dtShoppingCartItem.Copy());
            DataTable distinctDisc = ViewDisc.ToTable(true, "sci_oa_item_desc");



            foreach (DataRow row in distinctDisc.Rows)
            {
                if (row["sci_oa_item_desc"] == DBNull.Value || string.IsNullOrEmpty(row["sci_oa_item_desc"].ToString()))
                {
                    continue; // Skip this iteration if sci_oa_item_desc is null or empty
                }
                object sumObject = dtShoppingCartItem.Compute(
                    "Sum(ItemPrice)",
                    "sci_oa_item_desc='" + row["sci_oa_item_desc"].ToString() +
                    "' and sci_fod_type = 'PR' and sci_prod_type='02'"
                );

                if (sumObject != null)
                {
                    try
                    {
                        if (sumObject != DBNull.Value && double.Parse(sumObject.ToString()) > 990000000)
                        {
                            err_cnt++;
                            if (!validation.ContainsKey("4"))
                            {
                                validation["4"] = new List<string>();
                            }
                            validation["4"].Add(" Maximum value of Summation of All Service PR can be Rs 99 crore for Item : " + row["sci_oa_item_desc"].ToString());


                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception
                    }
                }

                sumObject = dtShoppingCartItem.Compute("Sum(ItemPrice)", "sci_oa_item_desc='" + row["sci_oa_item_desc"] + "' and sci_fod_type = 'ZP' and sci_prod_type='02'");

                if (sumObject != null)
                {
                    try
                    {
                        if (sumObject != DBNull.Value && Convert.ToDouble(sumObject) > 990000000)
                        {
                            err_cnt++;
                            if (!validation.ContainsKey("4"))
                            {
                                validation["4"] = new List<string>();
                            }
                            validation["4"].Add(" Maximum value of Summation of All Service ZPPR can be Rs 99 crore for Item  : " + row["sci_oa_item_desc"].ToString());

                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception
                    }
                }
            }
        }

        public void validatePRZPValueCheck(DataTable dtShoppingCartItem, List<ShoppingCartItem> items, Dictionary<string, List<string>> validation)
        {
            foreach (DataRow row in dtShoppingCartItem.Rows)
            {

                double sciQty = 0;
                double sciPrice = 0;
                double.TryParse(row["sci_qty"].ToString(), out sciQty);
                // string itemNo = row["sci_item_no"].ToString();
                //var item = items.Find(i => i.SCI_ITEM_NO.Equals(itemNo));
                //if (item != null)
                //{
                //    double.TryParse(item.SCI_PRICE, out sciPrice);
                //}
                //else if (item == null)
                //{
                //    double.TryParse(row["sci_price"].ToString(), out sciPrice);
                //}

                double.TryParse(row["sci_price"].ToString(), out sciPrice);

                if (row["sci_fod_type"].ToString().Equals("PR") || row["sci_fod_type"].ToString().Equals("ZP"))
                {
                    if ((sciQty * sciPrice) > 990000000)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("4"))
                        {
                            validation["4"] = new List<string>();
                        }
                        validation["4"].Add(" Maximum value of PR / ZP can be Rs 99 crore for Item no : " + row["sci_item_no"].ToString());
                    }
                }

            }
        }

        public DataTable getvPurchaseGrp(ShoppingCartItem objSCItems)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getPurchaseGrp, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_MATL_NO", objSCItems.SCI_MATL_NO);
                objConn.AddParameters(":SCI_PLANT_CD", objSCItems.SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getDatafromS_PURGRP_ekgrp(ShoppingCartItem objSCItems)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getDatafromS_PURGRP_ekgrp, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                objConn.AddParameters(":SCI_PLANT_CD", objSCItems.SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getPurchaseDrpTable(ShoppingCartItem objSCItems)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getPurchaseDrpTable, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":scno", objSCItems.SCI_CART_NO);
                objConn.AddParameters(":itemno", objSCItems.SCI_ITEM_NO);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getbudgetDeptCount(string scno)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getbudgetDeptCount, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":scno", scno);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public string assignHdncheck(ShoppingCartItem objSCItems)
        {
            string HDNfldPurchaseDrp = "";
            //DataTable ds = new DataTable();


            ////if (objSCItems.SCI_FOD_TYPE!="MF")
            ////{
            ////   ds = getDataTableForPurgrp(objSCItems);
            ////}

            //DataTable dtvPurchaseGrp = getvPurchaseGrp(objSCItems);
            //string vpurgrp = string.Empty;
            //if (dtvPurchaseGrp.Rows.Count > 0)
            //{
            //    vpurgrp = dtvPurchaseGrp.Rows[0]["PURGRP"].ToString();
            //}
            //DataTable da = new DataTable();
            //if (objSCItems.SCI_FOD_TYPE != "MF")
            //{
            //    da = getDatafromS_PURGRP_ekgrp(objSCItems);
            //}

            //DataTable purchasedrpTable = getPurchaseDrpTable(objSCItems);

            //if (purchasedrpTable.Rows.Count > 0)
            //{
            //    if (objSCItems.SCI_PUR_GRP != "")
            //    {
            //        string refOaValue = purchasedrpTable.Rows[0]["sci_ref_oa_no"].ToString().Trim();
            //        if (!string.IsNullOrEmpty(refOaValue) && objSCItems.SCI_FOD_TYPE != "QC" && objSCItems.SCI_FOD_TYPE != "MR")
            //        {

            //        }
            //    }
            //}


            return HDNfldPurchaseDrp;
        }
        public void checkValidPurchaseGrp(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation)
        {
            string HDNfldPurchaseDrp = assignHdncheck(objSCItems);
        }

        public DataTable get_plant_lvl_chk_str(string SCI_MATL_NO, string SCI_PLANT_CD)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_get_plant_lvl_chk_str, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":matlNo", SCI_MATL_NO);
                objConn.AddParameters(":plantCd", SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public DataTable get_plant_indpndnt_chk_rdr(string SCI_MATL_NO, string SCI_PLANT_CD)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_plant_indpndnt_chk_rdr, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":matlNo", SCI_MATL_NO);
                objConn.AddParameters(":plantCd", SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable get_Mat_Val_Cls(string SCI_MATL_NO, string SCI_PLANT_CD)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_get_Mat_Val_Cls, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":matlNo", SCI_MATL_NO);
                objConn.AddParameters(":plantCd", SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getPlantCheck(string SCI_MATL_NO, string SCI_PLANT_CD)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getPlantCheck, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":matlNo", SCI_MATL_NO);
                objConn.AddParameters(":plantCd", SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getDivisionData(string SCI_MATL_NO, string SCI_PLANT_CD)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getDivisionData, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":matlNo", SCI_MATL_NO);
                objConn.AddParameters(":plantCd", SCI_PLANT_CD);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getGsber(string SCI_PLANT_CD, string spart)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getGsber, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":plantCd", SCI_PLANT_CD);
                objConn.AddParameters(":spart", spart);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }



        public void BasicCheckForScItemValidation(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState, List<ShoppingCartItem> items)
        {
            decimal foriegnRate;
            if (!objSCItems.SCI_SPARES_CATEGORY.Equals("CONSUMABLES", StringComparison.OrdinalIgnoreCase) && objSCItems.SCI_FOD_TYPE != "RO")
            {
                if (objSCItems.SCI_INSTALLED_QTY == "")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Basic Data : Installed Quantity should be entered for Item no. " + objSCItems.SCI_ITEM_NO);

                }
            }

            DateTime ReqdOnDt = DateTime.ParseExact(objSCItems.SCI_REQD_ON_DT, "dd-MMM-yyyy", CultureInfo.InvariantCulture);
            DateTime todayDate = DateTime.Now;

            if (ReqdOnDt.Date < todayDate.Date)
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data : Required on date is less than system date , Please change the date greater than system date for Item no. " + objSCItems.SCI_ITEM_NO);


            }


            if (objSCItems.SCI_PUR_GRP == "")
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data : Purchasing group cannot be left blank for Item no. " + objSCItems.SCI_ITEM_NO);

            }

            if (string.IsNullOrEmpty(objSCItems.SCI_PRICE) && objSCItems.SCI_FOD_TYPE != "UN" && objSCItems.SCI_FOD_TYPE != "RN")
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data : Rate should be filled for Item no. " + objSCItems.SCI_ITEM_NO);

            }
            else if (!string.IsNullOrEmpty(objSCItems.SCI_FRN_PRICE) && objSCItems.SCI_FRN_PRICE.Contains("."))
            {
                string[] strarry = objSCItems.SCI_FRN_PRICE.Split('.');
                if (strarry[0].Length > 11)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Basic Data : Foreign Rate cannot be greater than 11 digits for Item no. " + objSCItems.SCI_ITEM_NO);

                }
                else if (strarry[1].Length > 2)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Basic Data : Foreign Rate cannot have more than 2 digits after decimal for Item no. " + objSCItems.SCI_ITEM_NO);

                }

            }
            else if (!string.IsNullOrEmpty(objSCItems.SCI_FRN_PRICE) && objSCItems.SCI_FRN_PRICE.Length > 11)
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data : Foreign Rate cannot be greater than 11 digits for Item no. " + objSCItems.SCI_ITEM_NO);

            }
            else if (!string.IsNullOrEmpty(objSCItems.SCI_FRN_PRICE) && !decimal.TryParse(objSCItems.SCI_FRN_PRICE, out foriegnRate))
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data : Foreign Rate should be numeric for Item no. " + objSCItems.SCI_ITEM_NO);

            }


            if ((objSCItems.SCI_PRICE == "0" || objSCItems.SCI_PRICE == null) && objSCItems.SCI_FRN_PRICE == "0" || objSCItems.SCI_PRICE == "" && objSCItems.SCI_FRN_PRICE == "")
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data : Either Rate(INR) or Rate (Foreign Curr.) should be filled and should be greater than zero for Item no. " + objSCItems.SCI_ITEM_NO);

            }

            if (objSCItems.SCI_FOD_TYPE == "PR" && objSCItems.SCI_MATL_NO.Trim().Length != 0)
            {
                if (objSCItems.SCI_PRICE != "" && objSCItems.SCI_PRICE != null)
                {
                    if (Convert.ToDouble(objSCItems.SCI_PRICE.Trim()) < Convert.ToDouble(objSCItems.Verpr.Trim()))
                    {
                        ScItemErrCntState.errCntScItem++;
                        err_cnt++;
                        if (!validation.ContainsKey("3"))
                        {
                            validation["3"] = new List<string>();
                        }
                        validation["3"].Add("Basic Data: Rate should not be less than moving average price of material for Item no. " + objSCItems.SCI_ITEM_NO);

                    }
                }
            }

            if (objSCItems.SCI_PUR_GRP == "110" && objSCItems.SCI_FOD_TYPE == "PR")
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("" + objSCItems.SCI_FOD_TYPE + "Cannot Be Created for PurGrp-110,Please Go through Material catalog for PurGrp-110 for Item no. " + objSCItems.SCI_ITEM_NO);

            }

            if (objSCItems.SCI_FOD_TYPE != "ZP")
            {
                //if(objSCItems.SCI_PROD_TYPE=="01")
                if (objSCItems.SCI_STRG_LOC == "")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Basic Data: Storage Location cannot be left blank for materials for item no. " + objSCItems.SCI_ITEM_NO);


                }
            }

            if (validateCurrency1(objSCItems, items) == 0)
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Basic Data: One shopping cart cannot contain differnt currencies for item no. " + objSCItems.SCI_ITEM_NO);

            }
        }

        public int validateCurrency1(ShoppingCartItem objSCItems, List<ShoppingCartItem> items)
        {
            HashSet<string> distinctCurrencies = new HashSet<string>();
            foreach (var objSCItem in items)
            {
                if (!(objSCItems.SCI_ITEM_NO).Equals(objSCItem.SCI_ITEM_NO))
                {
                    if (!objSCItem.SCI_FRN_CURR_CD.Trim().ToUpper().Equals("INR"))
                    {
                        distinctCurrencies.Add(objSCItem.SCI_FRN_CURR_CD);
                    }
                }

            }

            foreach (var currency in distinctCurrencies)
            {
                if (currency.Trim().Length > 0)
                {
                    if (!currency.Trim().ToUpper().Equals(objSCItems.SCI_FRN_CURR_CD.Trim().ToUpper()))
                    {
                        return 0;
                    }
                    else
                    {
                        return 1;
                    }
                }
            }

            return 1;
        }

        public DataTable GetCurrency(string scNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetCurrencyCheck, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":SCI_CART_NO", scNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int validateCurrency(ShoppingCartItem objSCItems)
        {

            DataTable dtValidateCurr = GetCurrency(objSCItems.SCI_CART_NO);
            string tmpCurr = "";

            if (dtValidateCurr.Rows.Count > 0)
            {
                tmpCurr = dtValidateCurr.Rows[0]["curr"].ToString();
            }

            if (tmpCurr.Trim().Length > 0)
            {
                if (!tmpCurr.Trim().ToUpper().Equals(objSCItems.SCI_FRN_CURR_CD.Trim().ToUpper()))
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }

            return 1;
        }

        public DataTable getParamCd()
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getParamCd, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }



        public void validateMaterial(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState)
        {
            DataTable plant_lvl_chk_str_dt = get_plant_lvl_chk_str(objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);
            DataTable plant_indpndnt_chk_rdr_dt = get_plant_indpndnt_chk_rdr(objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);

            string matl_plantlvl_status = "";
            string plant_indpndnt_status = "";
            string mat_status = "";
            string MAT_DEL_FLAG_PLNT = "";

            if (plant_lvl_chk_str_dt.Rows.Count > 0)
            {
                matl_plantlvl_status = plant_lvl_chk_str_dt.Rows[0]["CROS_PLNT_MAT_STAT"].ToString().Trim();
            }

            if (plant_indpndnt_chk_rdr_dt.Rows.Count > 0)
            {
                plant_indpndnt_status = plant_indpndnt_chk_rdr_dt.Rows[0]["PLNT_MAT_STAT"].ToString().Trim();
                mat_status = plant_indpndnt_chk_rdr_dt.Rows[0]["MAT_TYP"].ToString().Trim();
                MAT_DEL_FLAG_PLNT = plant_indpndnt_chk_rdr_dt.Rows[0]["MAT_DEL_FLAG_PLNT"].ToString().Trim();
            }

            if (objSCItems.SCI_FOD_TYPE == "PR" || objSCItems.SCI_FOD_TYPE == "ZP" || objSCItems.SCI_FOD_TYPE == "MF")
            {

                if (plant_indpndnt_status == "01")
                {
                    err_cnt++;
                    ScItemErrCntState.errCntScItem++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is blocked for Blocked for Procurement/Whse for Item no. " + objSCItems.SCI_ITEM_NO);
                }
                else if (matl_plantlvl_status == "01")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is blocked for Blocked for Procurement/Whse in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);

                }


                if (plant_indpndnt_status == "03")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is blocked for Blocked for Procurement for Item no. " + objSCItems.SCI_ITEM_NO);

                }
                else if (matl_plantlvl_status == "03")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is blocked for Blocked for Procurement in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (plant_indpndnt_status == "M1")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Material is Blocked for UOM for Item no. " + objSCItems.SCI_ITEM_NO);

                }
                else if (matl_plantlvl_status == "M1")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for UOM in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (plant_indpndnt_status == "M3")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for Proc/Resn/Pln for Item no. " + objSCItems.SCI_ITEM_NO);

                }
                else if (matl_plantlvl_status == "M3")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for Proc/Resn/Pln in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (plant_indpndnt_status == "Z1")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked For Proc/Whse/Cost " + objSCItems.SCI_ITEM_NO);

                }
                else if (matl_plantlvl_status == "Z1")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked For Proc/Whse/Cost in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (plant_indpndnt_status == "Z2")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for Postings " + objSCItems.SCI_ITEM_NO);
                }
                else if (matl_plantlvl_status == "Z2")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for Postings in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);
                }

                if (plant_indpndnt_status == "Z3")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for ML Monitoring " + objSCItems.SCI_ITEM_NO);
                }
                else if (matl_plantlvl_status == "Z3")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is Blocked for ML Monitoring in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);
                }

                if (plant_indpndnt_status == "ZV")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is block for EBUY shopping cart for Item no. " + objSCItems.SCI_ITEM_NO);
                }
                else if (matl_plantlvl_status == "ZV")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("Material is block for EBUY shopping cart in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);
                }

                if (objSCItems.SCI_FOD_TYPE == "PR")
                {
                    if (plant_indpndnt_status == "Z6")
                    {
                        ScItemErrCntState.errCntScItem++;
                        err_cnt++;
                        if (!validation.ContainsKey("3"))
                        {
                            validation["3"] = new List<string>();
                        }
                        validation["3"].Add("New WIP BOM, Route, cost for Item no. " + objSCItems.SCI_ITEM_NO);
                    }
                    else if (matl_plantlvl_status == "Z6")
                    {
                        ScItemErrCntState.errCntScItem++;
                        err_cnt++;
                        if (!validation.ContainsKey("3"))
                        {
                            validation["3"] = new List<string>();
                        }
                        validation["3"].Add("New WIP BOM, Route, cost in plant " + objSCItems.SCI_PLANT_CD + " for Item no. " + objSCItems.SCI_ITEM_NO);
                    }
                }
            }


            //if ((objSCItems.SCI_FOD_TYPE == "PR" || objSCItems.SCI_FOD_TYPE == "MR") && PROD_TYPR=="01")

            if ((objSCItems.SCI_FOD_TYPE == "PR" || objSCItems.SCI_FOD_TYPE == "MR"))
            {
                if ((!string.IsNullOrWhiteSpace(matl_plantlvl_status) || !string.IsNullOrWhiteSpace(plant_indpndnt_status)) && objSCItems.SCI_FOD_TYPE == "PR" && (matl_plantlvl_status.ToUpper().Trim() == "Z4" || plant_indpndnt_status.ToUpper().Trim() == "Z4"))
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("PR cannot be created for the material of item no. " + objSCItems.SCI_ITEM_NO + " as material is blocked for Purchase Requision");
                }
                else if ((!string.IsNullOrWhiteSpace(matl_plantlvl_status) || !string.IsNullOrWhiteSpace(plant_indpndnt_status)) && objSCItems.SCI_FOD_TYPE == "MR" && (matl_plantlvl_status.ToUpper().Trim() == "Z5" || plant_indpndnt_status.ToUpper().Trim() == "Z5"))
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("MR cannot be created for the material of item no. " + objSCItems.SCI_ITEM_NO + "  as material is blocked for Reservation. ");

                }
            }

            DataTable dtParamCd = getParamCd();
            bool MDMACTIVE = false;

            if (dtParamCd.Select("pam_type_cd = 'MDM_ACTV'").Length > 0)
            {
                MDMACTIVE = true;
            }
            string matl_plantlvl_status1 = "";
            string plant_indpndnt_status1 = "";
            if (MDMACTIVE == true)
            {
                DataTable dtPlantCheck = getPlantCheck(objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);

                if (dtPlantCheck.Rows.Count > 0)
                {
                    matl_plantlvl_status1 = dtPlantCheck.Rows[0]["CROS_PLNT_MAT_STAT"].ToString().Trim();
                    plant_indpndnt_status1 = dtPlantCheck.Rows[0]["PLNT_MAT_STAT"].ToString().Trim();

                    if (matl_plantlvl_status1.ToUpper().Trim() == "ZP" || plant_indpndnt_status1.ToUpper().Trim() == "ZP")
                    {
                        if (objSCItems.SCI_FOD_TYPE == "PR" || objSCItems.SCI_FOD_TYPE == "ZP")
                        {
                            ScItemErrCntState.errCntScItem++;
                            err_cnt++;
                            if (!validation.ContainsKey("3"))
                            {
                                validation["3"] = new List<string>();
                            }
                            validation["3"].Add("Material blocked for PR & ZPPR creation for item no. " + objSCItems.SCI_ITEM_NO);

                        }
                    }

                }
            }

            if (MAT_DEL_FLAG_PLNT == "X")
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Material is flagged for deletion  for item no. " + objSCItems.SCI_ITEM_NO);

            }
            //if(objSCItems.SCI_FOD_TYPE == "PR" && objSCItems.SCI_PROD_TYPE=="01" && objSCItems.SCI_MATL_NO!="")
            DataTable division_dt = new DataTable();
            DataTable gsber_dt = new DataTable();
            if (objSCItems.SCI_FOD_TYPE == "PR" && objSCItems.SCI_MATL_NO != "")
            {
                division_dt = getDivisionData(objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);
                if (division_dt.Rows.Count > 0)
                {
                    string spart = division_dt.Rows[0]["spart"].ToString();
                    gsber_dt = getGsber(objSCItems.SCI_PLANT_CD, spart);

                    if (gsber_dt.Rows.Count > 0)
                    {
                        string gs = gsber_dt.Rows[0]["gsber"].ToString().Trim();
                        if (gsber_dt.Rows[0]["gsber"].ToString().Trim() == "")
                        {
                            ScItemErrCntState.errCntScItem++;
                            err_cnt++;
                            if (!validation.ContainsKey("3"))
                            {
                                validation["3"] = new List<string>();
                            }
                            validation["3"].Add("Material/Plant/Division not mapped to Business Area,Please contact IBM Help Desk for item no. " + objSCItems.SCI_ITEM_NO);

                        }
                    }
                    else if (gsber_dt.Rows.Count == 0)
                    {
                        ScItemErrCntState.errCntScItem++;
                        err_cnt++;
                        if (!validation.ContainsKey("3"))
                        {
                            validation["3"] = new List<string>();
                        }
                        validation["3"].Add("Material/Plant/Division not mapped to Business Area,Please contact IBM Help Desk for item no. " + objSCItems.SCI_ITEM_NO);

                    }

                }
            }

            //if(objSCItems.SCI_FOD_TYPE == "PR" && sci_prod_id=="01")
            if (objSCItems.SCI_FOD_TYPE == "PR")
            {
                if (objSCItems.SCI_DOC_TYPE.ToString().Trim() == "NC")
                {
                    DataTable Mat_Val_Cls_dt = get_Mat_Val_Cls(objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);

                    string valu_class = "";
                    if (Mat_Val_Cls_dt.Rows.Count > 0)
                    {
                        valu_class = Mat_Val_Cls_dt.Rows[0]["qklas"].ToString();
                    }

                    if (!valu_class.StartsWith("5"))
                    {
                        ScItemErrCntState.errCntScItem++;
                        err_cnt++;
                        if (!validation.ContainsKey("3"))
                        {
                            validation["3"] = new List<string>();
                        }
                        validation["3"].Add("project valuation class is not maintained for this material  for Item no. " + objSCItems.SCI_ITEM_NO);
                    }
                }

            }

            if (objSCItems.SCI_PLANT_CD == "9310" && objSCItems.SCI_FOD_TYPE != "MR")
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("In Plant 9310 only MR creation is allowed  for item no. " + objSCItems.SCI_ITEM_NO);

            }
        }

        public DataTable get_s_pr(string cart_no, string itemNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_get_s_pr, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":cartNo", cart_no);
                objConn.AddParameters(":itemNo", itemNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable get_smd_plnt_cd(string user_id, string dept)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_get_smd_plnt_cd, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":userId", user_id);
                objConn.AddParameters(":dept", dept);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable get_purchasing_dept1(string dept)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_get_purchasing_dept1, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                objConn.AddParameters(":dept", dept);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public async Task validateRoSmdCheck(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState, ShoppingCartHeader header)
        {
            //if (objSCItems.SCI_FOD_TYPE == "RO" && prod_typr=="01")
            if (objSCItems.SCI_FOD_TYPE == "RO")
            {
                DataTable dt_s_pr = get_s_pr(header.SCH_CART_NO, objSCItems.SCI_ITEM_NO);
                if (dt_s_pr.Rows.Count > 0 && string.IsNullOrEmpty(dt_s_pr.Rows[0][0].ToString()))
                {
                    DataTable smd_plnt_cd_dt = get_smd_plnt_cd(header.SCH_UPD_ID, objSCItems.DEPT);
                    string smd_plnt_codes = "";
                    if (smd_plnt_cd_dt.Rows.Count > 0)
                    {
                        foreach (DataRow smd_plnt_dr in smd_plnt_cd_dt.Rows)
                        {
                            if (smd_plnt_codes.Trim().Length == 0)
                            {
                                smd_plnt_codes = smd_plnt_dr["smdplant"].ToString().Trim();
                            }
                            else
                            {
                                smd_plnt_codes += ";" + smd_plnt_dr["smdplant"].ToString().Trim();
                            }
                        }
                    }

                    if (smd_plnt_codes.Trim().Contains(objSCItems.SCI_PLANT_CD))
                    {
                        DataTable dt_purchasing_dept1 = get_purchasing_dept1(objSCItems.DEPT);
                        if (dt_purchasing_dept1.Rows.Count == 0)
                        {
                            ScItemErrCntState.errCntScItem++;
                            err_cnt++;
                            if (!validation.ContainsKey("3"))
                            {
                                validation["3"] = new List<string>();
                            }
                            validation["3"].Add("RO cannot be created for the material of item no. " + objSCItems.SCI_ITEM_NO + "under SMD plant");

                        }
                    }

                }

                List<SourceListSet> objSourceListSet = await GetROVendorList("", objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);
                if (objSourceListSet.Count == 0)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add("RO cannot be created for the material of item no. " + objSCItems.SCI_ITEM_NO + "as contract does not exist");

                }
            }
        }
        public async Task validateRoCheck(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState, ShoppingCartHeader header)
        {
            await validateRoSmdCheck(objSCItems, validation, ScItemErrCntState, header);
        }

        public async Task validateScItem(ShoppingCartItem objSCItems, dynamic responseObject, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState, List<ShoppingCartItem> items, ShoppingCartHeader header)
        {
            if (objSCItems.SCI_FOD_TYPE == "RO")
            {
                await validateRoCheck(objSCItems, validation, ScItemErrCntState, header);
            }

            validateMaterial(objSCItems, validation, ScItemErrCntState);

            BasicCheckForScItemValidation(objSCItems, validation, ScItemErrCntState, items);

            DataTable budgetDeptCountdt = getbudgetDeptCount(objSCItems.SCI_CART_NO);
            if (budgetDeptCountdt.Rows.Count > 0 && budgetDeptCountdt.Rows[0][0].ToString() != "0")
            {
                DateTime date;
                int fiscalYearReqOnDate = 0;
                // Parse the date string to DateTime using the specific format
                if (DateTime.TryParseExact(objSCItems.SCI_REQD_ON_DT, "dd-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                {
                    fiscalYearReqOnDate = GetFiscalYear(date);
                }
                int countOfFisYr = 0;
                if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                {
                    foreach (var result in responseObject.d.results)
                    {

                        String fisYr = result.FisYr;
                        if (fisYr == fiscalYearReqOnDate.ToString())
                        {
                            countOfFisYr++;
                        }
                    }

                }

                if (countOfFisYr == 0)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Budget not updated for FY, " + fiscalYearReqOnDate.ToString() + " for Item no. " + objSCItems.SCI_ITEM_NO + " Please Contact CMP.");

                }
            }


            //validation for consumable item
            await consumableAndMachineryCheck(objSCItems, validation, ScItemErrCntState);

            //if (objSCItems.SCI_PROD_TYPE == "01" && checkClassificationEnable(objSCItems.SCI_PUR_GRP) == true)
            if (checkClassificationEnable(objSCItems.SCI_PUR_GRP) == true)
            {
                validateClassificationTabFields(objSCItems, validation, ScItemErrCntState);
            }

            //DataTable mpnValueCountDt=getMpnValueCount(objSCItems.SCI_MATL_NO);
            //string countMpnDrawing = mpnValueCountDt.Rows[0]["counter"].ToString();

            //if(Convert.ToInt32(countMpnDrawing)>0)
            //{
            //    validateMpnDrawing(objSCItems, validation, ScItemErrCntState);
            //}
        }

        public DataTable getMpnValueCount(string SCI_MATL_NO)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getMpnValueCount, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":matlNo", SCI_MATL_NO);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }



        public DataTable getmpnDrawingData(ShoppingCartItem objSCItems)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getmpnDrawingData, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":scno", objSCItems.SCI_CART_NO);
                objConn.AddParameters(":itemno", objSCItems.SCI_ITEM_NO);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        public void validateMpnDrawing(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState)
        {
            DataTable mpnDrawingDatadt = getmpnDrawingData(objSCItems);
            int Count = 0;
            foreach (DataRow row in mpnDrawingDatadt.Rows)
            {
                // Check if any of the columns are not null
                if (row["SCI_PART_NO"] != DBNull.Value ||
                    row["SCI_MFRNR"] != DBNull.Value ||
                    row["SCI_MPN_NO"] != DBNull.Value)
                {
                    Count++;
                }
            }

            if (Count == 0)
            {
                ScItemErrCntState.errCntScItem++;
                err_cnt++;
                if (!validation.ContainsKey("3"))
                {
                    validation["3"] = new List<string>();
                }
                validation["3"].Add("Please select atleast one value in MPN/Drawing for Item no. " + objSCItems.SCI_ITEM_NO);

            }

        }

        public void validateClassificationTabFields(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState)
        {
            if (objSCItems.SCI_FOD_TYPE == "PR")
            {
                if (objSCItems.SCI_CHARACTERISTICS == "")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: Characteristics should be filled  for Item no. " + objSCItems.SCI_ITEM_NO);

                }
                if (objSCItems.SCI_CHARACTERISTICS.Trim().Length > 200)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: Characteristics can not be greater than 200 character  for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (objSCItems.SCI_COMPOSITION == "")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: Composition should be filled for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (objSCItems.SCI_COMPOSITION.Trim().Length > 200)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: Composition can not be greater than 200 character  for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (objSCItems.SCI_ENDUSE == "")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: End Use should be filled for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (objSCItems.SCI_ENDUSE.Trim().Length > 200)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: End Use can not be greater than 200 character  for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (objSCItems.SCI_FUNCTION == "")
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: Function should be filled for Item no. " + objSCItems.SCI_ITEM_NO);

                }

                if (objSCItems.SCI_FUNCTION.Trim().Length > 200)
                {
                    ScItemErrCntState.errCntScItem++;
                    err_cnt++;
                    if (!validation.ContainsKey("3"))
                    {
                        validation["3"] = new List<string>();
                    }
                    validation["3"].Add(" Classification: Function can not be greater than 200 character  for Item no. " + objSCItems.SCI_ITEM_NO);

                }
            }
        }
        public async Task consumableAndMachineryCheck(ShoppingCartItem objSCItems, Dictionary<string, List<string>> validation, ScItemErrorCnt ScItemErrCntState)
        {
            //if (objSCItems.SCI_FOD_TYPE == "PR" && objSCItems.SCI_PROD_TYPE == "01")
            if (objSCItems.SCI_FOD_TYPE == "PR")
            {
                DataTable import_material_check_dt = new DataTable();
                string responseData = await getMaterialConsumptionPlan(objSCItems.SCI_PUR_GRP, objSCItems.SCI_MATL_NO, objSCItems.SCI_PLANT_CD);
                if (!String.IsNullOrEmpty(responseData))
                {
                    dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                    import_material_check_dt.Columns.Add(new DataColumn("LIFNR"));

                    if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                    {
                        foreach (var result in responseObject.d.results)
                        {
                            import_material_check_dt.Rows.Add(result.Lifnr);
                        }
                    }
                }

                if (import_material_check_dt.Rows.Count > 0)
                {
                    foreach (DataRow row in import_material_check_dt.Rows)
                    {
                        string vendor = row["LIFNR"].ToString();
                        //string vendor = import_material_check_dt.Rows[0]["LIFNR"].ToString();

                        if (vendor.EndsWith("F"))
                        {
                            if (objSCItems.SCI_TXT_PROC_CONS == "")
                            {
                                ScItemErrCntState.errCntScItem++;
                                err_cnt++;
                                if (!validation.ContainsKey("3"))
                                {
                                    validation["3"] = new List<string>();

                                }
                                validation["3"].Add("Basic data: Please Enter Material Consumption Plan for Item no. " + objSCItems.SCI_ITEM_NO);


                            }

                            if (objSCItems.SCI_IMP_PLANT_MACHINERY == "")
                            {
                                ScItemErrCntState.errCntScItem++;
                                err_cnt++;
                                if (!validation.ContainsKey("3"))
                                {
                                    validation["3"] = new List<string>();
                                }
                                validation["3"].Add("Basic data: Please Select Imported Plant And Machiner for Item no. " + objSCItems.SCI_ITEM_NO);

                            }
                        }
                        else
                        {
                            if (objSCItems.SCI_PUR_GRP.Trim() == "107" || objSCItems.SCI_PUR_GRP.Trim() == "173")
                            {
                                if (objSCItems.SCI_TXT_PROC_CONS == "")
                                {
                                    ScItemErrCntState.errCntScItem++;
                                    err_cnt++;
                                    if (!validation.ContainsKey("3"))
                                    {
                                        validation["3"] = new List<string>();

                                    }
                                    validation["3"].Add("Basic data: Please Enter Material Consumption Plan for Item no. " + objSCItems.SCI_ITEM_NO);


                                }

                                if (objSCItems.SCI_IMP_PLANT_MACHINERY == "")
                                {
                                    ScItemErrCntState.errCntScItem++;
                                    err_cnt++;
                                    if (!validation.ContainsKey("3"))
                                    {
                                        validation["3"] = new List<string>();
                                    }
                                    validation["3"].Add("Baisc data: Please Select Imported Plant And Machiner for Item no. " + objSCItems.SCI_ITEM_NO);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (objSCItems.SCI_PUR_GRP.Trim() == "107" || objSCItems.SCI_PUR_GRP.Trim() == "173")
                    {
                        if (objSCItems.SCI_TXT_PROC_CONS == "")
                        {
                            ScItemErrCntState.errCntScItem++;
                            err_cnt++;
                            if (!validation.ContainsKey("3"))
                            {
                                validation["3"] = new List<string>();
                            }
                            validation["3"].Add("Basic data: Please Enter Material Consumption Plan for Item no. " + objSCItems.SCI_ITEM_NO);

                        }

                        if (objSCItems.SCI_IMP_PLANT_MACHINERY == "")
                        {
                            ScItemErrCntState.errCntScItem++;
                            err_cnt++;
                            if (!validation.ContainsKey("3"))
                            {
                                validation["3"] = new List<string>();
                            }
                            validation["3"].Add("Baisc data: Please Select Imported Plant And Machiner for Item no. " + objSCItems.SCI_ITEM_NO);

                        }
                    }
                }


            }

        }



        public int GetFiscalYear(DateTime reqDate)
        {
            // If the month is April (4) or later in the year, the fiscal year is the current year+1.
            // Otherwise, the fiscal year is the current year
            if (reqDate.Month >= 4)
            {
                return reqDate.Year + 1;
            }
            else
            {
                return reqDate.Year;
            }
        }

        public async Task costCenterOrderIndicatorCheck(SCCostAssignment ObjCostAssignment, Dictionary<string, List<string>> errors)
        {
            string txtAssign = ObjCostAssignment.SAA_ASGND_TO;
            //F means Internal order checks
            if (ObjCostAssignment.SAA_CATEGORY == "F" || ObjCostAssignment.SAA_CATEGORY == "Z")
            {
                if (ObjCostAssignment.SAA_CATEGORY == "F")
                {
                    if ((ObjCostAssignment.SAA_ASGND_TO.TrimStart('0')).ToUpper().StartsWith("OB") || (ObjCostAssignment.SAA_ASGND_TO.TrimStart('0')).ToUpper().Substring(0, 2).Trim() == "OB")
                    {
                        txtAssign = txtAssign.PadLeft(11, '0');
                    }
                    else
                    {
                        txtAssign = txtAssign.PadLeft(12, '0');
                    }
                }
                else
                {
                    txtAssign = txtAssign.PadLeft(12, '0');
                }


                string InternalOrder = txtAssign.Trim();

                string DocCategory = "N";
                string activityNo = "0000";
                string PersId = "N";
                string UserCheck = "N";
                string ErrMsg = "";
                string ValidFlag = "N";
                string auart = "";

                string responseData = await AccountCheckOData(InternalOrder).ConfigureAwait(false);
                //await Task.Delay(1000);
                if (!String.IsNullOrEmpty(responseData))
                {
                    dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);

                    if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                    {

                        foreach (var result in responseObject.d.results)
                        {
                            DocCategory = result.DocCategory;
                            activityNo = result.ActivityNo;
                            PersId = result.PersId;
                            UserCheck = result.UserCheck;
                            ValidFlag = result.ValidFlag;
                            ErrMsg = result.ErrMsg;
                            auart = result.Auart;
                        }

                    }
                }

                if (ValidFlag.Equals("N"))
                {
                    err_cnt++;
                    if (!errors.ContainsKey("1"))
                    {
                        errors["1"] = new List<string>();
                    }
                    errors["1"].Add("Cost Assignment: " + ErrMsg);

                }

                DataTable dtOrderIndicator = getOrderIndicator(auart);
                if (dtOrderIndicator.Rows.Count == 0)
                {
                    err_cnt++;
                    if (!errors.ContainsKey("1"))
                    {
                        errors["1"] = new List<string>();
                    }
                    errors["1"].Add("Cost Assignment: Pls maintain Order indicator in SAP R/3");

                }
                else
                {
                    string textName = "";
                    if (ObjCostAssignment.SAA_CATEGORY == "F")
                    {
                        textName = "Internal/PM Order";
                    }
                    if (dtOrderIndicator.Rows[0]["ord_ind"].ToString().Trim() == "I")
                    {
                        DataTable dt = getIndicatorCount(ObjCostAssignment.SAA_ASGND_TO, ObjCostAssignment.ObjShoppingCartItemDetails.DEPT.Trim());
                        if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() == "0")
                        {
                            err_cnt++;
                            if (!errors.ContainsKey("1"))
                            {
                                errors["1"] = new List<string>();
                            }
                            errors["1"].Add("Cost Assignment: Fill valid " + textName + " You are not authorised to use " + InternalOrder.ToString() + "" + textName);

                        }
                    }
                }
            }

        }

        public void costCenterNetworkCheck(List<SCCostAssignment> ObjCostAssignmentList, Dictionary<string, List<string>> errors)
        {

            //if (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "PR" and sci_prod_type=='01')
            if (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "PR")
            {
                if (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_DOC_TYPE.Trim() != "NC" && ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_DOC_TYPE.Trim().Trim() != "CR")
                {
                    if (ObjCostAssignmentList[0].SAA_CATEGORY == "N" || ObjCostAssignmentList[0].SAA_CATEGORY == "Q")
                    {
                        err_cnt++;
                        if (!errors.ContainsKey("1"))
                        {
                            errors["1"] = new List<string>();
                        }
                        errors["1"].Add(" Cost Assignment   : Network or WBS element not allowed. ");

                    }
                }
            }


            if (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_MATL_GRP == "320")
            {
                if (ObjCostAssignmentList[0].SAA_CATEGORY != "N")
                {
                    err_cnt++;
                    if (!errors.ContainsKey("1"))
                    {
                        errors["1"] = new List<string>();
                    }
                    errors["1"].Add(" Cost Assignment    : Category should be Network only for the selected material group ");

                }
            }

            // if(ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "PR" and sci_prod_type== '01' and ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_MATL_GRP != "320")

            if (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "PR" && ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_MATL_GRP != "320")
            {
                if (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_DOC_TYPE.ToString().Trim() == "NC")
                {
                    if (ObjCostAssignmentList[0].SAA_CATEGORY != "N" && ObjCostAssignmentList[0].SAA_CATEGORY != "Q")
                    {
                        err_cnt++;
                        if (!errors.ContainsKey("1"))
                        {
                            errors["1"] = new List<string>();
                        }
                        errors["1"].Add("Cost Assignment: Only Network or WBS element allowed. ");

                    }
                }
            }

            //if((ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE=="PR" || ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "RO"&& sci_prod_type == '01' AND MATERIAL !=0))

            //if ((ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "PR" || ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "RO") && (ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_MATL_NO.Length != 0 || ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_MATL_NO != null))
            //{
            //    //if (ObjCostAssignmentList[0].SAA_CATEGORY == "K" && .Trim('0').Contains("100005"))
            //}
        }


        public async Task checkCostAssignmentErrors(List<SCCostAssignment> ObjCostAssignmentList, Dictionary<string, List<string>> errors)
        {
            double totval = 0.0;
            double txtprc = 0.0;
            double txtqty = 0.0;

            foreach (var ObjCostAssignment in ObjCostAssignmentList)
            {
                await costCenterOrderIndicatorCheck(ObjCostAssignment, errors);
            }

            costCenterNetworkCheck(ObjCostAssignmentList, errors);

            foreach (var ObjCostAssignment in ObjCostAssignmentList)
            {
                totval += Convert.ToDouble(ObjCostAssignment.SAA_DISTRIBUTION_VAL);
            }

            foreach (var ObjCostAssignment in ObjCostAssignmentList)
            {
                //totval += Convert.ToDouble(ObjCostAssignment.SAA_DISTRIBUTION_VAL);
                //err_cnt++;
                //if (!errors.ContainsKey("11"))
                //{
                //    errors["11"] = new List<string>();
                //}
                if (ObjCostAssignment.SAA_CATEGORY == "K")
                {
                    if (CheckValidCostCenter(ObjCostAssignment.SAA_ASGND_TO, ObjCostAssignment.SAA_Dept, ObjCostAssignment.SAA_CATEGORY) == false)
                    {
                        err_cnt++;
                        if (!errors.ContainsKey("1"))
                        {
                            errors["1"] = new List<string>();
                        }
                        errors["1"].Add(" Cost Assignment: Fill valid Cost Center " + ObjCostAssignment.SAA_ASGND_TO.Trim());
                    }
                }
                if ((ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "PR" || ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_FOD_TYPE == "RO") && ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_MATL_NO.Length != 0)
                {
                    if (ObjCostAssignment.SAA_CATEGORY == "K" && ObjCostAssignment.SAA_ASGND_TO.Trim('0').Contains("100005"))
                    {
                        err_cnt++;
                        if (!errors.ContainsKey("1"))
                        {
                            errors["1"] = new List<string>();
                        }
                        errors["1"].Add("Dummy Cost Center not allowed for material PR/RO." + ObjCostAssignment.SAA_ASGND_TO.Trim());

                    }
                }
            }
            if (CheckMultipleAccountAssignment(ObjCostAssignmentList[0].SAA_CART_NO, ObjCostAssignmentList[0].SAA_CATEGORY) == false)
            {
                err_cnt++;
                if (!errors.ContainsKey("1"))
                {
                    errors["1"] = new List<string>();
                }
                errors["1"].Add(" Cost Assignment: Account Assignment should be same for all items.");
            }

            if (string.IsNullOrWhiteSpace(ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_PRICE) || ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_PRICE.Trim() == "0")
            {
                txtprc = 0.0;
            }
            else
            {
                txtprc = Convert.ToDouble(ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_PRICE.Trim());
            }

            if (string.IsNullOrWhiteSpace(ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_QTY) || ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_QTY.Trim() == "0")
            {
                txtqty = 0.0;
            }
            else
            {
                txtqty = Convert.ToDouble(ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_QTY.Trim());
            }

            if (totval != txtqty && ObjCostAssignmentList[0].SAA_DISTRIBUTION_TP == "Q")
            {
                err_cnt++;
                if (!errors.ContainsKey("1"))
                {
                    errors["1"] = new List<string>();
                }
                errors["1"].Add(" Cost Assignment: Total Quantity value should be equal to " + ObjCostAssignmentList[0].ObjShoppingCartItemDetails.SCI_QTY.Trim());


            }
            else if (totval != 100 && (ObjCostAssignmentList[0].SAA_DISTRIBUTION_TP == "P"))
            {
                err_cnt++;
                if (!errors.ContainsKey("1"))
                {
                    errors["1"] = new List<string>();
                }
                errors["1"].Add(" Cost Assignment: Total percentage value cannot be greater than 100 or less than 100");

            }
            else if (ObjCostAssignmentList[0].SAA_DISTRIBUTION_TP == "V")
            {
                double totval_to_compare = txtprc * txtqty;
                if (totval != totval_to_compare && totval_to_compare != 0)
                {
                    err_cnt++;
                    if (!errors.ContainsKey("1"))
                    {
                        errors["1"] = new List<string>();
                    }
                    errors["1"].Add(" Cost Assignment: Total Value should be equal to " + totval_to_compare);

                }

            }
        }

        public void SustainibilityvalidationsOfCheck(SustainibilityCSR objSCSustainibilityCSR, Dictionary<string, List<string>> validation)
        {

            if ((objSCSustainibilityCSR.SCC_FOD_TYPE == "PR" || objSCSustainibilityCSR.SCC_FOD_TYPE == "MR" || objSCSustainibilityCSR.SCC_FOD_TYPE == "RO" || objSCSustainibilityCSR.SCC_FOD_TYPE == "MF") && (objSCSustainibilityCSR.CSR_COMP == null || objSCSustainibilityCSR.CSR_COMP == ""))
            {
                err_cnt++;
                if (!validation.ContainsKey("2"))
                {
                    validation["2"] = new List<string>();
                }
                validation["2"].Add(" Sustainability Expense Details:Please select the Sustainability Type (Appicable of Not)  ");

            }
            int sub_code = 0;
            int activity_code = 0;
            if (objSCSustainibilityCSR.CSR_COMP != "")
            {
                if (objSCSustainibilityCSR.CSR_COMP == "01")
                {
                    if (objSCSustainibilityCSR.SCC_SUB_CODE != "None")
                    {
                        sub_code++;
                    }
                    if (objSCSustainibilityCSR.SCC_SUB_ACTIVITY_CODE != "None")
                    {
                        activity_code++;
                    }
                    if (activity_code == 0 || sub_code == 0)
                    {
                        err_cnt++;
                        if (!validation.ContainsKey("2"))
                        {
                            validation["2"] = new List<string>();
                        }
                        validation["2"].Add(" Sustainability Expense Details:Sustainability Component if selected Social its Sub catagory and its Activity can't be left unselected ");

                    }
                }
            }
        }
        //end of validations


        public async Task<int> InsertCostAssesmentList(List<SCCostAssignment> ObjCostAssignmentList, Dictionary<string, List<string>> errors)
        {

            int respose = 0;//Tem Close
            int isDelete = DeleteCostAssesment(ObjCostAssignmentList[0]);
            await checkCostAssignmentErrors(ObjCostAssignmentList, errors);
            if (errors.Count() > 0)
            {
                return respose;
            }


            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                int Count = 0;

                try
                {

                    foreach (var ObjCostAssignment in ObjCostAssignmentList)
                    {
                        command.Parameters.Clear();
                        command.CommandText = "p_sis_ins_t_sis_sc_acct_asgnmt";
                        command.CommandType = CommandType.StoredProcedure;
                        // Input parameters
                        command.Parameters.Add("n_cart", OracleDbType.Int64).Value = ObjCostAssignment.SAA_CART_NO;
                        command.Parameters.Add("n_itemno", OracleDbType.Int64).Value = ObjCostAssignment.SAA_ITEM_NO;
                        command.Parameters.Add("n_lineno", OracleDbType.Int32).Value = ObjCostAssignment.SAA_LINE_NO;
                        command.Parameters.Add("v_dist", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(ObjCostAssignment.SAA_DISTRIBUTION_TP) ? "" : ObjCostAssignment.SAA_DISTRIBUTION_TP;
                        command.Parameters.Add("v_category", OracleDbType.Varchar2).Value = ObjCostAssignment.SAA_CATEGORY;
                        command.Parameters.Add("v_asgnd", OracleDbType.Varchar2).Value = ObjCostAssignment.SAA_ASGND_TO.Trim();
                        command.Parameters.Add("v_id", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(ObjCostAssignment.SAA_UPD_ID) ? "" : ObjCostAssignment.SAA_UPD_ID;
                        command.Parameters.Add("v_actvty", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(ObjCostAssignment.SAA_ACTIVITY_NUM) ? "" : ObjCostAssignment.SAA_ACTIVITY_NUM;
                        command.Parameters.Add("n_val", OracleDbType.Varchar2).Value = ObjCostAssignment.SAA_DISTRIBUTION_VAL.Trim();
                        respose = command.ExecuteNonQuery();
                    }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return respose;
        }

        public int InsertSustainibilityCsr(SustainibilityCSR objSCSustainibilityCSR, Dictionary<string, List<string>> validation)
        {

            //validation
            int respose = 0;
            SustainibilityvalidationsOfCheck(objSCSustainibilityCSR, validation);
            if (validation.Count() > 0)
            {
                return respose;
            }

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                int Count = 0;

                try
                {

                    command.Parameters.Clear();
                    command.CommandText = "p_sis_insert_T_SHOP_CART_CSR";
                    command.CommandType = CommandType.StoredProcedure;
                    // Input parameters
                    command.Parameters.Add("n_cart", OracleDbType.Int64).Value = objSCSustainibilityCSR.SCC_CART_NO;
                    command.Parameters.Add("n_itemno", OracleDbType.Int64).Value = objSCSustainibilityCSR.SCC_ITEM_NO;
                    command.Parameters.Add("n_fodtype", OracleDbType.Varchar2).Value = objSCSustainibilityCSR.SCC_FOD_TYPE;
                    command.Parameters.Add("v_fodno", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(objSCSustainibilityCSR.SCC_FOD_NO) ? String.Empty : objSCSustainibilityCSR.SCC_FOD_NO;
                    command.Parameters.Add("v_foditemno", OracleDbType.Varchar2).Value = objSCSustainibilityCSR.SCC_FOD_ITEM_NO;
                    command.Parameters.Add("v_dept", OracleDbType.Varchar2).Value = objSCSustainibilityCSR.SCC_DEPT;
                    command.Parameters.Add("v_scttag", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(objSCSustainibilityCSR.CSR_ACT_TAG) ? String.Empty : objSCSustainibilityCSR.CSR_ACT_TAG;
                    command.Parameters.Add("v_comp", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(objSCSustainibilityCSR.CSR_COMP) ? "00" : objSCSustainibilityCSR.CSR_COMP;
                    command.Parameters.Add("n_crtid", OracleDbType.Int32).Value = String.IsNullOrEmpty(objSCSustainibilityCSR.SCC_CRT_ID) ? String.Empty : objSCSustainibilityCSR.SCC_CRT_ID;
                    command.Parameters.Add("v_subcode", OracleDbType.Varchar2).Value = objSCSustainibilityCSR.SCC_SUB_CODE.Trim();
                    command.Parameters.Add("v_subactcode", OracleDbType.Varchar2).Value = objSCSustainibilityCSR.SCC_SUB_ACTIVITY_CODE.Trim();
                    command.Parameters.Add("v_loccode", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(objSCSustainibilityCSR.SCC_LOC_CODE) ? String.Empty : objSCSustainibilityCSR.SCC_LOC_CODE;
                    command.Parameters.Add("v_REMARKS", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(objSCSustainibilityCSR.SCC_REMARKS) ? String.Empty : objSCSustainibilityCSR.SCC_REMARKS;
                    respose = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return respose;
        }


        public DataTable GetShoppingCSRDetails(string SC_NO, string ItemNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetSCCSRDetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            

                objConn.AddParameters(":SCC_CART_NO", SC_NO);
                objConn.AddParameters(":SCC_ITEM_NO", ItemNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GetCostAssesmentData(string SC_NO, string ItemNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetCostAssesmentData, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                objConn.AddParameters(":n_cart", SC_NO);
                objConn.AddParameters(":n_itemno", ItemNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        private double Get_budgetConsumptionFormDept_SIS(string dept)
        {
            double str = 0;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGet_budgetConsumptionFormDept_SIS, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            

                objConn.AddParameters(":sch_dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
                if (dtResult != null)
                {
                    str = Convert.ToDouble(dtResult.Rows[0]["TOTVAL"].ToString());
                }
            }
            catch { }

            return str;
        }

        private double Get_budgetConsumptionFormDept_EBuy(string dept)
        {
            double str = 0;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGet_budgetConsumptionFormDept_EBuy, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                //objConn.AddParameters(":sch_cart_no", sCNo);
                objConn.AddParameters(":sch_dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult != null)
                {
                    str = Convert.ToDouble(dtResult.Rows[0]["TOTVAL"].ToString());
                }

            }
            catch (Exception) { }

            return str;
        }

        private bool checkClassificationEnable(string purgrp)
        {
            bool flag1 = false;
            bool flag2 = false;
            bool flag = false;
            List<string> list = new List<string> { "107", "173", "A09" };
            if (list.Contains(purgrp)) { flag = true; }
            if (purgrp != "")
            {
                objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGet_ClassificationTabEnable, CommandType.Text, true);
                try
                {
                    //Open the connection.
                    objConn.OpenConnection();

                    //Bind the parameters.            

                    objConn.AddParameters(":PAM_PARAM_DESC", purgrp);

                    //Execute the query and assign the resultant table.
                    objConn.FillDataTable();
                    dtResult = objConn.ResultantTable;

                    //Close the connection
                    objConn.CloseConnection();

                    if (dtResult.Rows.Count > 0)
                    {
                        flag1 = true;
                    }

                }
                catch (Exception) { }
            }

            if (flag == true || flag1 == true) { flag = true; } else { flag = false; }
            return flag;
        }

        public string GetCurrentSCStatus(string SC_NO)
        {
            string Status = "0";
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetCurrentSCStatus, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                objConn.AddParameters(":SCH_CART_NO", SC_NO);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult.Rows.Count > 0)
                {
                    Status = dtResult.Rows[0]["INDENT_STATUS"].ToString();
                }


            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return Status;
        }

        public bool checkSCFileUploaded(string SCNO)
        {

            bool flag = false;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetSCAttachmentDetails, CommandType.Text, true);
            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            

                objConn.AddParameters(":SCA_CART_NO", SCNO);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult.Rows.Count > 0)
                {
                    flag = true;
                }

            }
            catch (Exception) { }

            return flag;
        }

        public string GetGLAccountNo(string UMCNO, string Plant, string ACMode)
        {
            string GLAccountNo = "";
            string query = @"SELECT GL_ACC_NO1 konts FROM sapsur.T_S_ACC_TYP WHERE CHRT_ACC = '1000' AND VAL_GRP_CODE in (SELECT VALGRPCD bwmod FROM sapsur.T_S_VALN_AREA 
                           WHERE PLANT = :plant_cd AND COMPCD = '1000')
                AND VAL_CLASS in (Select distinct VAL_CLASS bklas from sapsur.t_umc_prod where PLANT_CD = :plant AND UMC_CD =:UMC_CD ) AND ACC_MOD = :ACC_MOD";
            objConn = new ConnectionOracleDB(strConnSISDB, query, CommandType.Text, true);
            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.         
                objConn.AddParameters(":plant_cd", Plant);
                objConn.AddParameters(":plant", Plant);
                objConn.AddParameters(":UMC_CD", UMCNO);
                objConn.AddParameters(":ACC_MOD", ACMode);




                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult.Rows.Count > 0)
                {
                    GLAccountNo = dtResult.Rows[0]["konts"].ToString();
                }

            }
            catch (Exception ex)
            {

            }

            return GLAccountNo;
        }

        public int InsertSCAttachment(SC_ATTACHMENT objSC_ATTACHMENT)
        {
            int respose = 0;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                int Count = 0;

                try
                {
                    command.Parameters.Clear();
                    if (checkSCFileUploaded(objSC_ATTACHMENT.SCA_CART_NO) == false)
                    {

                        command.CommandText = DBConst.oraInsertSCAttachment;
                        command.CommandType = CommandType.Text;
                        // Input parameters
                        command.Parameters.Add(":SCA_CART_NO", OracleDbType.Int64).Value = objSC_ATTACHMENT.SCA_CART_NO;
                        command.Parameters.Add(":SCA_FILE_NAME", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_FILE_NAME;
                        command.Parameters.Add(":SCA_FILE_TYPE", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_FILE_TYPE;
                        command.Parameters.Add(":SCA_FILE_SIZE", OracleDbType.Int32).Value = objSC_ATTACHMENT.SCA_FILE_SIZE;
                        command.Parameters.Add(":SCA_UPD_ID", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_UPD_ID;
                        command.Parameters.Add(":SCA_FILE", OracleDbType.Blob).Value = objSC_ATTACHMENT.SCA_FILE;

                    }
                    else
                    {
                        command.CommandText = DBConst.oraUpdateSCAttachment;
                        command.CommandType = CommandType.Text;
                        // Input parameters

                        command.Parameters.Add("SCA_UPD_ID", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_UPD_ID;
                        command.Parameters.Add("SCA_FILE_NAME", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_FILE_NAME;
                        command.Parameters.Add("SCA_FILE_TYPE", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_FILE_TYPE;
                        command.Parameters.Add("SCA_FILE_SIZE", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_FILE_SIZE;
                        command.Parameters.Add("SCA_FILE", OracleDbType.Blob).Value = objSC_ATTACHMENT.SCA_FILE;
                        command.Parameters.Add("SCA_CART_NO", OracleDbType.Int64).Value = objSC_ATTACHMENT.SCA_CART_NO;
                        //command.Parameters.Add("SCA_DATAID", OracleDbType.Varchar2).Value = objSC_ATTACHMENT.SCA_DATAID;
                    }
                    respose = command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return respose;
        }

        private async Task<string> getMaterialConsumptionPlan(string purgrp, string UMCNO, string Dept)
        {
            string responseData = "";
            try
            {
                string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
                string apiUrl = BaseURL + "opu/odata/sap/YMPIG_GET_SRC_DTL_SRV/Get_Source_ListSet?$filter=(Material eq  '" + UMCNO + "' and Plant eq '" + Dept + "' )&$format=json";



                using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
                {
                    // Setting the username and password for basic authentication
                    string username = ConfigurationManager.AppSettings["ODataUserName"];
                    string password = ConfigurationManager.AppSettings["ODataPassword"];
                    string authInfo = username + ":" + password;
                    string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                        if (response.IsSuccessStatusCode)
                        {
                            responseData = await response.Content.ReadAsStringAsync();
                        }
                        else
                        {
                            responseData = "";// or BadRequest() or NotFound() based on your needs
                        }

                    }
                    catch (HttpRequestException ex)
                    {
                        responseData = ""; // Return the exception details
                    }
                }

                return responseData;
            }
            catch (Exception)
            {
                return responseData;
            }
        }


        private async Task<bool> checkMaterialConsumptionPlanEnble(string purgrp, string UMCNO, string Dept)
        {
            DataTable import_material_check_dt = new DataTable();
            bool flag = false;
            List<string> list = new List<string> { "107", "173", "A09" };
            if (list.Contains(purgrp)) { flag = true; } else { flag = false; return flag; }
            try
            {
                string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
                string apiUrl = BaseURL + "opu/odata/sap/opu/odata/sap/YMPIG_GET_SOURCE_LIST_SRV/GetSourceListSet?$filter=(Material eq  '" + UMCNO + "' and Plant eq '" + Dept + "' )&$format=json";
                string responseData = "";

                using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
                {
                    // Setting the username and password for basic authentication
                    string username = ConfigurationManager.AppSettings["ODataUserName"];
                    string password = ConfigurationManager.AppSettings["ODataPassword"];
                    string authInfo = username + ":" + password;
                    string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                        if (response.IsSuccessStatusCode)
                        {
                            responseData = await response.Content.ReadAsStringAsync();
                            if (!String.IsNullOrEmpty(responseData))
                            {
                                dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);


                                if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                                {
                                    foreach (var result in responseObject.d.results)
                                    {
                                        //if(result.Lifnr) 
                                    }
                                }
                            }
                        }
                        else
                        {
                            responseData = "";// or BadRequest() or NotFound() based on your needs
                        }
                    }
                    catch (HttpRequestException ex)
                    {
                        responseData = ""; // Return the exception details
                    }
                }


            }
            catch (Exception) { }

            return flag;
        }

        public DataTable GetCostCenterSearch(string CostCenter)
        {
            if (!String.IsNullOrEmpty(CostCenter))
            {
                int a = 0;
                if (int.TryParse(CostCenter, out a))
                {
                    objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetCostCenterSearch, CommandType.Text, true);
                }
                else
                {
                    string oraGetCostCenterSearch = "select distinct COSTCNTR,(COSTCNTR || ' > ' || DESCRIPTION) as DESCRIPTION  from sapsur.T_S_CC_TEXTS where COSTCNTR like '%" + CostCenter.ToUpper() + "%'   and VALTODT >=sysdate";

                    objConn = new ConnectionOracleDB(strConnSISDB, oraGetCostCenterSearch, CommandType.Text, true);
                }


                try
                {
                    //Open the connection.
                    objConn.OpenConnection();

                    //Bind the parameters.           

                    objConn.AddParameters(":costcenter", CostCenter);


                    //Execute the query and assign the resultant table.
                    objConn.FillDataTable();
                    dtResult = objConn.ResultantTable;

                    //Close the connection
                    objConn.CloseConnection();
                }
                catch (Exception excp)
                {
                    throw excp;
                }
            }
            //return the final Data Table.
            return dtResult;
        }
        public bool CheckValidCostCenter(string CostCenter, string Dept, string Indicator)
        {

            bool flag = false;

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraCheckValidCostCenter, CommandType.Text, true);
            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.         


                objConn.AddParameters("dept", Dept);
                objConn.AddParameters("indicator", Indicator);
                objConn.AddParameters("costcenter", CostCenter.Trim());

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult.Rows[0]["COUNT"].ToString() != "0")
                {
                    flag = true;
                }

            }
            catch (Exception) { }

            return flag;
        }

        public bool CheckMultipleAccountAssignment(string SCNO, string Category)
        {

            bool flag = true;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraCheckMultipleAccountAssignment, CommandType.Text, true);
            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.         


                objConn.AddParameters(":SAA_CART_NO", SCNO);


                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
                if (dtResult.Rows.Count > 0)
                {
                    foreach (DataRow row in dtResult.Rows)
                    {
                        if (row["SAA_CATEGORY"].ToString() != Category)
                        {
                            flag = false;
                        }
                    }


                }

            }
            catch (Exception) { }

            return flag;
        }

        public DataTable GetVendorMasterDetails(string VendorCode)
        {
            string query = "select VENDOR,(Vendor ||' > '|| Name1) as VendorName,Name1  from sapsur.T_S_VEN_MAST  where VEN_ACNT_GRP in ('INWB','0002','IMPS','INDS','1500','INJH','INOM') and client='600' and VENDOR like '%" + VendorCode.ToUpper() + "'";
            objConn = new ConnectionOracleDB(strConnSISDB, query, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                //objConn.AddParameters("vendorcode", VendorCode);


                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public DataTable Getmpndrawingsdetails(string UMCNO, string matl_grp, string scno, string itemno, string UserID)
        {
            string oraGetmpndrawingsdetails = "SELECT SHT_DESC PNO,MFRNR ,NAME1 FROM sapsur.t_umc_prod LEFT JOIN CMDRDB.t_s_ven_mast@CTDR_EPROC_DBL  VEN ON  MFRNR=VENDOR AND VEN.CLIENT='600' WHERE bmatn ='" + UMCNO + "' AND mat_typ       ='HERS' AND plnt_mat_Stat =' '";
            objConn = new ConnectionOracleDB(strConnSISDB, oraGetmpndrawingsdetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                //objConn.AddParameters(":UMC_CD", UMCNO);


                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
                var SCDocument = new SCDocument
                {
                    SCD_CART_NO = scno,
                    SCD_ITEM_NO = itemno,
                    SCD_TXT_TYPE = "B51",
                    SCD_UPD_ID = UserID,
                    SCD_LVL = "I",
                };

                if (dtResult.Rows.Count > 0 && matl_grp != "318")
                {
                    int isDelete = DeleteTextDocument(SCDocument);
                    int count = 0;
                    foreach (DataRow row in dtResult.Rows)
                    {
                        count++;
                        SCDocument.SCD_TXT = "Part no : " + row["PNO"] + Environment.NewLine + "Manufacturer : " + row["NAME1"];
                        SCDocument.SCD_LINE_NO = count.ToString();
                        Insert_MNP_TEXT(SCDocument);



                    }
                }

            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int UpdateMPNDrawing(ShoppingCartItem objMPNDrawing)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraUpdateMNPDrawing;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add("SCI_PART_NO", OracleDbType.Varchar2).Value = objMPNDrawing.SCI_PART_NO;
                    command.Parameters.Add("SCI_MFRNR", OracleDbType.Varchar2).Value = objMPNDrawing.SCI_MFRNR;
                    command.Parameters.Add("SCI_MPN_NO", OracleDbType.Varchar2).Value = objMPNDrawing.SCI_MPN_NO;
                    command.Parameters.Add("SCI_CART_NO", OracleDbType.Varchar2).Value = objMPNDrawing.SCI_CART_NO;
                    command.Parameters.Add("SCI_ITEM_NO", OracleDbType.Varchar2).Value = objMPNDrawing.SCI_ITEM_NO;

                    Count = command.ExecuteNonQuery();


                    var SCDocument = new SCDocument
                    {
                        SCD_CART_NO = objMPNDrawing.SCI_CART_NO,
                        SCD_ITEM_NO = objMPNDrawing.SCI_ITEM_NO,
                        SCD_TXT = objMPNDrawing.SCI_PART_NO,
                        SCD_TXT_TYPE = "B51",
                        SCD_UPD_ID = objMPNDrawing.SCI_UPD_ID,
                        SCD_LVL = "I",
                    };
                    int isDelete = DeleteTextDocument(SCDocument);
                    string[] parts = objMPNDrawing.SCI_PART_NO.Split('/');

                    // Check if there are exactly three parts
                    if (parts.Length == 3)
                    {
                        SCDocument.SCD_TXT = "Drawing no : " + parts[0];
                        SCDocument.SCD_LINE_NO = "1";
                        Insert_MNP_TEXT(SCDocument);
                        SCDocument.SCD_TXT = "Drawing version no : " + parts[1];
                        SCDocument.SCD_LINE_NO = "2";
                        Insert_MNP_TEXT(SCDocument);
                        SCDocument.SCD_TXT = "Drawing part no : " + parts[2];
                        SCDocument.SCD_LINE_NO = "3";
                        Insert_MNP_TEXT(SCDocument);
                    }
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public int DeleteCostAssesment(SCCostAssignment sCCostAssignment)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;


                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraDeleteCostAssesment;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add("saa_cart_no", OracleDbType.Varchar2).Value = sCCostAssignment.SAA_CART_NO;
                    command.Parameters.Add("saa_item_no", OracleDbType.Varchar2).Value = sCCostAssignment.SAA_ITEM_NO;


                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public DataTable GetVendorDetails(string VendorCode)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectVendorDetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                objConn.AddParameters("vendorcode", VendorCode);


                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int Insert_MNP_TEXT(SCDocument sCDocument)
        {
            int respose = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                int Count = 0;

                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraInsertSCIDocuments;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add("scd_cart_no", OracleDbType.Int64).Value = sCDocument.SCD_CART_NO;
                    command.Parameters.Add("scd_item_no", OracleDbType.Int64).Value = sCDocument.SCD_ITEM_NO;
                    command.Parameters.Add("scd_txt_type", OracleDbType.Varchar2).Value = sCDocument.SCD_TXT_TYPE;
                    command.Parameters.Add("scd_line_no", OracleDbType.Int32).Value = sCDocument.SCD_LINE_NO;
                    command.Parameters.Add("scd_txt", OracleDbType.Varchar2).Value = sCDocument.SCD_TXT + Environment.NewLine;
                    command.Parameters.Add("scd_upd_id", OracleDbType.Varchar2).Value = sCDocument.SCD_UPD_ID;
                    command.Parameters.Add("scd_lvl", OracleDbType.Varchar2).Value = String.IsNullOrEmpty(sCDocument.SCD_LVL) ? "I" : sCDocument.SCD_LVL;



                    respose = command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return respose;
        }

        public int DeleteTextDocument(SCDocument sCDocument)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraDeleteDocumentText;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add("SCD_CART_NO", OracleDbType.Varchar2).Value = sCDocument.SCD_CART_NO;
                    command.Parameters.Add("SCD_ITEM_NO", OracleDbType.Varchar2).Value = sCDocument.SCD_ITEM_NO;
                    command.Parameters.Add("SCD_TXT_TYPE", OracleDbType.Varchar2).Value = sCDocument.SCD_TXT_TYPE;
                    //command.Parameters.Add("SCD_LINE_NO", OracleDbType.Varchar2).Value = sCDocument.SCD_LINE_NO;
                    //command.Parameters.Add("SCD_LVL", OracleDbType.Varchar2).Value = sCDocument.SCD_LVL;
                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public int DeleteTextDocumentFromLVL(SCDocument sCDocument)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();
                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraDeleteDocumentLVLText;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add("SCD_CART_NO", OracleDbType.Varchar2).Value = sCDocument.SCD_CART_NO;
                    command.Parameters.Add("SCD_ITEM_NO", OracleDbType.Varchar2).Value = sCDocument.SCD_ITEM_NO;
                    command.Parameters.Add("SCD_TXT_TYPE", OracleDbType.Varchar2).Value = sCDocument.SCD_TXT_TYPE;
                    //command.Parameters.Add("SCD_LINE_NO", OracleDbType.Varchar2).Value = sCDocument.SCD_LINE_NO;
                    command.Parameters.Add("SCD_LVL", OracleDbType.Varchar2).Value = sCDocument.SCD_LVL;
                    Count = command.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public string GETCurrentFYPercentage(int fy, List<BBPRList> bBPRLists)
        {
            string Percentege = "";
            try
            {
                if (bBPRLists != null)
                {
                    var bBPRListsItem = bBPRLists.FirstOrDefault(p => p.FY == fy);
                    if (bBPRListsItem != null)
                    {
                        Percentege = bBPRListsItem.PERCENTAGE;
                    }
                    else
                    {
                        Percentege = bBPRLists[0].PERCENTAGE;
                    }
                }


            }
            catch (Exception ex)
            {

                Percentege = "";
            }
            return Percentege;
        }


        public async Task<BudgetDetails> GetBudgetDetails(string dept, string SCH_CART_NO)
        {
            List<BBPRList> bBPRList = new List<BBPRList>();
            BudgetDetails objBudget = new BudgetDetails();
            try
            {
                DataTable dtShoppingCartItem = GetIntelliBuyChecksHeaderAndItem(SCH_CART_NO);

                int Currentfy = GetFinancialYear(DateTime.Now);

                double Budget_EBUY = Get_budgetConsumptionFormDept_EBuy(dept);
                double Budget_SIS = Get_budgetConsumptionFormDept_SIS(dept);
                string responseData = await Get_budgetConsumptionFormDept_ODATA(dept);
                var bbprlist = new BBPRList();
                foreach (DataRow row in dtShoppingCartItem.Rows)
                {

                    int ReqDatefy = GetFinancialYear(Convert.ToDateTime(row["requirement_date"].ToString()));
                    int FinYear = 0;
                    double CommittedExpenditure = 0;
                    if (ReqDatefy > Currentfy) { FinYear = ReqDatefy; }
                    else { FinYear = Currentfy; }

                    if (!String.IsNullOrEmpty(responseData))
                    {
                        dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                        if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                        {
                            string StrPOValue = "0";
                            string StrPRValue = "0";
                            string StrSpareValue = "0";
                            string StrTotBudget = "0";

                            foreach (var result in responseObject.d.results)
                            {

                                // Check the DocType and assign the values accordingly
                                if (result.DocType == "PO" && result.FisYr == FinYear)
                                {
                                    StrPOValue = result.Value;
                                }
                                else if (result.DocType == "PR" && result.FisYr == FinYear)
                                {
                                    StrPRValue = result.Value;
                                }
                                else if (result.DocType == "TOTAL" && result.FisYr == FinYear)
                                {
                                    StrSpareValue = result.Value;
                                    StrTotBudget = result.TotBudget;
                                }


                                if (result.FisYr == FinYear && result.DocType == "TOTAL")
                                {
                                    double spareValue = double.Parse(StrTotBudget) * 105 / 100;
                                    double PRValue = double.Parse(StrPRValue);
                                    double POValue = double.Parse(StrPOValue);
                                    if (FinYear == Currentfy)
                                    {
                                        CommittedExpenditure = Math.Round(Budget_EBUY + POValue + PRValue + Budget_SIS);
                                    }
                                    else
                                    {
                                        CommittedExpenditure = Math.Round(POValue + PRValue);
                                    }

                                    bbprlist.FY = FinYear;
                                    bbprlist.COMMITTEDEXPENDITURE = Convert.ToInt32(Math.Round(CommittedExpenditure));
                                    bbprlist.SPAREBUDGET = Convert.ToInt32(Math.Round(spareValue));
                                    if (!bBPRList.Any(e => e.FY == bbprlist.FY))
                                    {
                                        bbprlist.PERCENTAGE = Math.Round((100 * CommittedExpenditure) / spareValue).ToString();
                                        bBPRList.Add(new BBPRList { FY = bbprlist.FY, COMMITTEDEXPENDITURE = bbprlist.COMMITTEDEXPENDITURE, SPAREBUDGET = bbprlist.SPAREBUDGET, PERCENTAGE = bbprlist.PERCENTAGE });
                                    }

                                }
                            }

                        }
                    }

                }


                objBudget.CurrFY = Currentfy;
                objBudget.BBPRList = bBPRList;
                objBudget.BudgetPercentage = GETCurrentFYPercentage(Currentfy, bBPRList);

            }
            catch (Exception ex)
            {

            }


            return objBudget;
        }

        public DataTable GetSCAttachmentDetails(string SC_NO)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_GetSCAttachmentDetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            


                objConn.AddParameters(":SCA_CART_NO", SC_NO);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int ChangeShoppingCart_DraftStage(string SC_NO)
        {

            string CurrentStatus = GetCurrentSCStatus(SC_NO);

            int respose = 0;
            if (CurrentStatus == "52")
            {
                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleCommand command = connection.CreateCommand();
                    OracleTransaction transaction = connection.BeginTransaction();

                    command.Transaction = transaction;
                    int Count = 0;

                    try
                    {
                        //command.Parameters.Clear();
                        //command.CommandText = DBConst.IndentUpdateStatus;
                        //command.Parameters.Clear();
                        //command.Parameters.Add(":STATUS", "38");
                        //command.Parameters.Add(":SCH_CART_NO", SC_NO);
                        //respose= command.ExecuteNonQuery();
                        command.Parameters.Clear();
                        command.CommandText = DBConst.ora_Updateto_Draft;
                        command.Parameters.Add(":SCH_CART_NO", SC_NO);
                        respose += command.ExecuteNonQuery();

                        transaction.Commit();
                    }
                    catch (OracleException excp)
                    {
                        //string result1 = command.Parameters["err_msg"].Value.ToString();
                        transaction.Rollback();
                        throw excp;
                    }
                    catch (Exception excp)
                    {
                        transaction.Rollback();
                        throw excp;
                    }

                }
            }
            else if (CurrentStatus == "39")
            {
                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleCommand command = connection.CreateCommand();
                    OracleTransaction transaction = connection.BeginTransaction();

                    command.Transaction = transaction;
                    int Count = 0;

                    try
                    {
                        //command.Parameters.Clear();
                        //command.CommandText = DBConst.IndentUpdateStatus;
                        //command.Parameters.Clear();
                        //command.Parameters.Add(":STATUS", "38");
                        //command.Parameters.Add(":SCH_CART_NO", SC_NO);
                        //respose = command.ExecuteNonQuery();
                        command.Parameters.Clear();
                        command.CommandText = DBConst.ora_Updateto_Draft;
                        command.Parameters.Add(":SCH_CART_NO", SC_NO);
                        respose += command.ExecuteNonQuery();

                        transaction.Commit();
                    }
                    catch (OracleException excp)
                    {
                        //string result1 = command.Parameters["err_msg"].Value.ToString();
                        transaction.Rollback();
                        throw excp;
                    }
                    catch (Exception excp)
                    {
                        transaction.Rollback();
                        throw excp;
                    }

                }
            }
            return respose;
        }

        public DataTable GetPurchaseGroupList(string WERKS)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getPursaseGroup, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            


                objConn.AddParameters(":WERKS", WERKS);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int InsertClasificationDocument(ShoppingCartItem shoppingCartItem)
        {
            int i = 0;
            if (!String.IsNullOrEmpty(shoppingCartItem.SCI_CHARACTERISTICS) || !String.IsNullOrEmpty(shoppingCartItem.SCI_COMPOSITION) || !String.IsNullOrEmpty(shoppingCartItem.SCI_ENDUSE) || !String.IsNullOrEmpty(shoppingCartItem.SCI_FUNCTION))
            {
                var SCDocument = new SCDocument
                {
                    SCD_CART_NO = shoppingCartItem.SCI_CART_NO,
                    SCD_ITEM_NO = shoppingCartItem.SCI_ITEM_NO,
                    SCD_TXT_TYPE = "B44",
                    SCD_UPD_ID = shoppingCartItem.SCI_UPD_ID,
                    SCD_LVL = "I",
                };
                int isDelete = DeleteTextDocument(SCDocument);
                SCDocument.SCD_TXT = "Material Consumption Plan :-" + (String.IsNullOrEmpty(shoppingCartItem.SCI_TXT_PROC_CONS) ? String.Empty : shoppingCartItem.SCI_TXT_PROC_CONS);
                SCDocument.SCD_LINE_NO = "1";
                i = Insert_MNP_TEXT(SCDocument);
                SCDocument.SCD_TXT = "Imported Plant And Machinery :-" + (String.IsNullOrEmpty(shoppingCartItem.SCI_IMP_PLANT_MACHINERY) ? String.Empty : shoppingCartItem.SCI_IMP_PLANT_MACHINERY);
                SCDocument.SCD_LINE_NO = "2";
                i = Insert_MNP_TEXT(SCDocument);
                if (shoppingCartItem.SCI_CHARACTERISTICS_DOC == "OTHERS")
                {
                    SCDocument.SCD_TXT = "Characteristics[OTHERS] :-" + shoppingCartItem.SCI_CHARACTERISTICS;
                }
                else { SCDocument.SCD_TXT = "Characteristics :-" + shoppingCartItem.SCI_CHARACTERISTICS; }
                SCDocument.SCD_LINE_NO = "3";
                i = Insert_MNP_TEXT(SCDocument);
                if (shoppingCartItem.SCI_COMPOSITION_DOC == "OTHERS")
                {
                    SCDocument.SCD_TXT = "Composition[OTHERS] :- " + shoppingCartItem.SCI_COMPOSITION;
                }
                else
                {
                    SCDocument.SCD_TXT = "Composition :- " + shoppingCartItem.SCI_COMPOSITION;
                }
                SCDocument.SCD_LINE_NO = "4";
                i = Insert_MNP_TEXT(SCDocument);
                if (shoppingCartItem.SCI_ENDUSE_DOC == "OTHERS")
                {
                    SCDocument.SCD_TXT = "End Use[OTHERS] :- " + shoppingCartItem.SCI_ENDUSE;
                }
                else
                {
                    SCDocument.SCD_TXT = "End Use :- " + shoppingCartItem.SCI_ENDUSE;
                }
                SCDocument.SCD_LINE_NO = "5";
                i = Insert_MNP_TEXT(SCDocument);
                if (shoppingCartItem.SCI_FUNCTION_DOC == "OTHERS")
                {
                    SCDocument.SCD_TXT = "Function[OTHERS] :- " + shoppingCartItem.SCI_FUNCTION;
                }
                else
                {
                    SCDocument.SCD_TXT = "Function :- " + shoppingCartItem.SCI_FUNCTION;
                }

                SCDocument.SCD_LINE_NO = "6";
                i = Insert_MNP_TEXT(SCDocument);
                SCDocument.SCD_TXT = "HSN NO. :-" + (String.IsNullOrEmpty(shoppingCartItem.SCI_HSN_NO) ? String.Empty : shoppingCartItem.SCI_HSN_NO);
                SCDocument.SCD_LINE_NO = "7";
                i = Insert_MNP_TEXT(SCDocument);
            }
            return i;

        }

        public async Task<List<SourceListSet>> GetROVendorList(string purgrp, string UMCNO, string Dept)
        {
            DataTable dataTable = new DataTable();
            List<SourceListSet> sourceListSet = new List<SourceListSet>();
            string responseData = await getMaterialConsumptionPlan(purgrp, UMCNO, Dept);
            dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
            if (!String.IsNullOrEmpty(responseData))
            {
                string jsonstring = JsonConvert.SerializeObject(responseObject.d.results);
                sourceListSet = JsonConvert.DeserializeObject<List<SourceListSet>>(jsonstring);

            }


            return sourceListSet;
        }

        public DataTable getFrgKeFromEkko(string contract)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getFrgKeFromEkko, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":ebeln", contract);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getloekzCountFromEkpo(string contract, string item)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getloekzCountFromEkpo, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":ebeln", contract);
                objConn.AddParameters(":ebelp", item);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getCurrencyAndValue(string contract)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getCurrencyAndValue, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":ebeln", contract);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable getCurrencyValueFromT_S_CURR_CODES(string WAERS)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_getCurrencyValueFromT_S_CURR_CODES, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                objConn.AddParameters(":WAERS", WAERS);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }
        public void contractRoCheck(SourceListSet objSourceListSet, Dictionary<string, List<string>> validation, string key)
        {
            string frgke = "";
            DataTable getFrgKeFromEkkoDt = getFrgKeFromEkko(objSourceListSet.Contract);
            if (getFrgKeFromEkkoDt.Rows.Count > 0)
            {
                frgke = getFrgKeFromEkkoDt.Rows[0]["frgke"].ToString();
            }

            if (frgke != "C" && frgke != "")
            {
                if (!validation.ContainsKey(key))
                {
                    validation[key] = new List<string>();
                }
                validation[key].Add("Contract is not in release state for contract no. " + objSourceListSet.Contract + " of Item no. " + objSourceListSet.SCI_ITEM_NO);

            }

            string loekz = "";
            DataTable getloekzCountFromEkpoDt = getloekzCountFromEkpo(objSourceListSet.Contract, objSourceListSet.Item_no);
            if (getloekzCountFromEkpoDt.Rows.Count > 0)
            {
                loekz = getloekzCountFromEkpoDt.Rows[0]["counter"].ToString();
            }
            if (loekz == "1")
            {
                if (!validation.ContainsKey(key))
                {
                    validation[key] = new List<string>();
                }
                validation[key].Add("Contract Item deleted for contract no. " + objSourceListSet.Contract + " of Item no. " + objSourceListSet.SCI_ITEM_NO);

            }

            DateTime sourceToDate = DateTime.ParseExact(objSourceListSet.Souce_valid_to, "yyyy-MM-dd", CultureInfo.InvariantCulture);

            DateTime reqOnDateParsed = DateTime.ParseExact(objSourceListSet.SCI_REQD_ON_DT, "dd-MMM-yyyy", CultureInfo.InvariantCulture);

            DateTime contractToDate = DateTime.ParseExact(objSourceListSet.Contract_valid_to, "yyyy-MM-dd", CultureInfo.InvariantCulture);


            // Compare the dates
            if (reqOnDateParsed.Date > sourceToDate.Date)
            {
                if (!validation.ContainsKey(key))
                {
                    validation[key] = new List<string>();
                }
                validation[key].Add("Requirement date is not within validity period for Source Valid To for contract no. " + objSourceListSet.Contract + " of Item no. " + objSourceListSet.SCI_ITEM_NO);

            }

            if (reqOnDateParsed.Date > contractToDate.Date)
            {
                if (!validation.ContainsKey(key))
                {
                    validation[key] = new List<string>();
                }
                validation[key].Add("Requirement date is not within validity period for contract Valid To for contract no. " + objSourceListSet.Contract + " of Item no. " + objSourceListSet.SCI_ITEM_NO);

            }
            DataTable getCurrencydt = getCurrencyAndValue(objSourceListSet.Contract);
            string WAERS = getCurrencydt.Rows[0]["WAERS"].ToString();
            string WKURS = getCurrencydt.Rows[0]["WKURS"].ToString();
            double balance = 0.0;

            if (WAERS == "INR")
            {
                balance = Convert.ToDouble(objSourceListSet.Balance);
            }
            else
            {

                if (string.IsNullOrEmpty(WKURS))
                {
                    DataTable CurrencyFromT_S_CURR_CODESdt = getCurrencyValueFromT_S_CURR_CODES(WAERS);
                    double updateCurrencyValue = Convert.ToDouble(CurrencyFromT_S_CURR_CODESdt.Rows[0]["UKURS"].ToString());
                    balance = Convert.ToDouble(objSourceListSet.Balance) * updateCurrencyValue;

                }
                else
                {
                    balance = Convert.ToDouble(objSourceListSet.Balance) * Convert.ToDouble(WKURS);
                }
            }

            if (balance < Convert.ToDouble(objSourceListSet.TotalPrice))
            {
                if (!validation.ContainsKey(key))
                {
                    validation[key] = new List<string>();
                }
                validation[key].Add("Target Value of the ARC No. " + objSourceListSet.Contract + " , Exceeded by Rs. " + (Convert.ToDouble(objSourceListSet.TotalPrice) - balance).ToString("0.00"));

            }

        }


        public int UpdateROVendor(SourceListSet objSourceListSet, Dictionary<string, List<string>> validation)
        {
            int Count = 0;
            contractRoCheck(objSourceListSet, validation, "5");
            if (validation.Count() > 0)
            {
                return Count;
            }


            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraUpdateROVendor;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add(":sci_ref_oa_no", OracleDbType.Varchar2).Value = objSourceListSet.Contract;
                    command.Parameters.Add(":sci_oa_item_no", OracleDbType.Varchar2).Value = objSourceListSet.Item_no;
                    command.Parameters.Add(":sci_oa_vencd", OracleDbType.Varchar2).Value = objSourceListSet.Vendor_code;
                    command.Parameters.Add(":sci_cart_no", OracleDbType.Varchar2).Value = objSourceListSet.SCI_CART_NO;
                    command.Parameters.Add(":sci_item_no", OracleDbType.Varchar2).Value = objSourceListSet.SCI_ITEM_NO;

                    Count = command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public async Task<int> UpdateROVendorByDefault(SourceListSet objSourceListSet, string SCNo, string ItemNo)
        {
            int Count = 0;

            if (objSourceListSet.Contract != null)
            {

                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleCommand command = connection.CreateCommand();
                    OracleTransaction transaction = connection.BeginTransaction();

                    command.Transaction = transaction;
                    try
                    {

                        command.Parameters.Clear();
                        command.CommandText = DBConst.oraUpdateROVendor;
                        command.CommandType = CommandType.Text;
                        // Input parameters
                        command.Parameters.Add(":sci_ref_oa_no", OracleDbType.Varchar2).Value = objSourceListSet.Contract;
                        command.Parameters.Add(":sci_oa_item_no", OracleDbType.Varchar2).Value = objSourceListSet.Item_no;
                        command.Parameters.Add(":sci_oa_vencd", OracleDbType.Varchar2).Value = objSourceListSet.Vendor_code;
                        command.Parameters.Add(":sci_cart_no", OracleDbType.Varchar2).Value = SCNo;
                        command.Parameters.Add(":sci_item_no", OracleDbType.Varchar2).Value = ItemNo;

                        Count = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    catch (OracleException excp)
                    {
                        //string result1 = command.Parameters["err_msg"].Value.ToString();
                        transaction.Rollback();
                        throw excp;
                    }
                    catch (Exception excp)
                    {
                        transaction.Rollback();
                        throw excp;
                    }

                }
                return Count;
            }
            return Count;

        }

        public DataTable GetROPriceFromEKPO(string Contract, string ItemNo)
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGetROPriceFromEKPO, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                //Bind the parameters.            
                objConn.AddParameters(":contract", Contract);
                objConn.AddParameters(":ItemNo", ItemNo);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public DataTable GETROPurchaseGroupList(string Contract, string plant)
        {
            DataTable dataTable_PurGrp = new DataTable();
            string ekgrp = "";
            try
            {
                string query = "Select ekgrp from sapsur.ekko where ebeln='" + Contract + "'";
                DataTable dataTable_ekko = GetDataTableFromQuery(query);
                if (dataTable_ekko.Rows.Count > 0)
                {
                    ekgrp = dataTable_ekko.Rows[0]["ekgrp"].ToString();
                }
                dataTable_PurGrp = GetPurchaseGroupList(plant);
                if (dataTable_PurGrp.Rows.Count > 0)
                {
                    DataRow[] dataRows = dataTable_PurGrp.Select("pg_cd = '" + ekgrp + "'");
                    bool idExists = dataTable_PurGrp.AsEnumerable().Any(row => row.Field<string>("pg_cd") == ekgrp);
                    if (idExists == false)
                    {
                        dataTable_PurGrp.Rows.Clear();
                        string strquery = "select PURGRP pg_cd,DESCRIPTION || '<' || PURGRP pgl, central_local_tag centag from sapsur.T_S_PURGRP where PURGRP = '" + ekgrp + "' and CLIENT = '600'";
                        dataTable_PurGrp = GetDataTableFromQuery(strquery);
                    }
                    else
                    {
                        dataTable_PurGrp.Rows.Clear();
                        string strquery = "select PURGRP pg_cd,DESCRIPTION || '<' || PURGRP pgl, central_local_tag centag from sapsur.T_S_PURGRP where PURGRP = '" + ekgrp + "' and CLIENT = '600'";
                        dataTable_PurGrp = GetDataTableFromQuery(strquery);
                        //MoveRowToTop(dataTable_PurGrp, ekgrp);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return dataTable_PurGrp;


        }

        static void MoveRowToTop(DataTable dataTable, string selectedId)
        {
            // Find the row with the selected ID
            DataRow selectedRow = dataTable.AsEnumerable()
                                            .FirstOrDefault(row => row.Field<string>("pg_cd") == selectedId);

            if (selectedRow != null)
            {
                // Create a new DataTable to hold the reordered rows
                DataTable newTable = dataTable.Clone(); // Clone the structure

                // Add the selected row to the new table first
                newTable.ImportRow(selectedRow);

                // Add the remaining rows except the selected one
                foreach (DataRow row in dataTable.AsEnumerable().Where(r => r != selectedRow))
                {
                    newTable.ImportRow(row);
                }

                // Clear the original DataTable and import the new rows
                dataTable.Clear();
                foreach (DataRow row in newTable.Rows)
                {
                    dataTable.ImportRow(row);
                }
            }
        }
        public DataTable GetDataTableFromQuery(string query)
        {
            objConn = new ConnectionOracleDB(strConnSISDB, query, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public int UpdatePurchaseGroup(ShoppingCartItem objShoppingCartItem)
        {
            int Count = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction = connection.BeginTransaction();

                command.Transaction = transaction;
                try
                {

                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraUpdatePurchaseGroup;
                    command.CommandType = CommandType.Text;
                    // Input parameters
                    command.Parameters.Add(":SCI_PUR_GRP", OracleDbType.Varchar2).Value = objShoppingCartItem.SCI_PUR_GRP;
                    command.Parameters.Add(":SCI_PRICE", OracleDbType.Varchar2).Value = objShoppingCartItem.SCI_PRICE;
                    command.Parameters.Add(":SCI_CART_NO", OracleDbType.Varchar2).Value = objShoppingCartItem.SCI_CART_NO;
                    command.Parameters.Add(":SCI_ITEM_NO", OracleDbType.Varchar2).Value = objShoppingCartItem.SCI_ITEM_NO;
                    command.Parameters.Add(":SCI_MATL_NO", OracleDbType.Varchar2).Value = objShoppingCartItem.SCI_MATL_NO;


                    Count = command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (OracleException excp)
                {
                    //string result1 = command.Parameters["err_msg"].Value.ToString();
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }

            }
            return Count;
        }

        public DataTable Get_DocumentsFromSC(string SCNo, string SCI_MATL_NO)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.ora_get_DocumentsFromSC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":scp_cart_no", SCNo);
                objConn.AddParameters(":SCI_MATL_NO", SCI_MATL_NO);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        // Fetch Classification 
        public DataTable GetClassificationItemDetails(string umcNo, string Type)
        {
            string Query = "";
            if (Type.ToLower() == "characteristics")
            {
                Query = "select MTC_MATNR,MTC_CHAR CL_CODE ,MTC_CHAR CL_VALUE from sapsur.T_MATERIAL_CLASSIFICATION where MTC_MATNR='" + umcNo + "'  union select 'X' MTC_MATNR,'OTHERS' CL_CODE ,'OTHERS' CL_VALUE from dual";
            }
            else if (Type.ToLower() == "composition")
            {
                Query = "select MTC_MATNR,MTC_COMP CL_CODE ,MTC_COMP CL_VALUE from sapsur.T_MATERIAL_CLASSIFICATION where MTC_MATNR='" + umcNo + "'  union select 'X' MTC_MATNR,'OTHERS' CL_CODE ,'OTHERS' CL_VALUE from dual";
            }
            else if (Type.ToLower() == "end use")
            {
                Query = "select MTC_MATNR,MTC_ENDU CL_CODE ,MTC_ENDU CL_VALUE from sapsur.T_MATERIAL_CLASSIFICATION where MTC_MATNR='" + umcNo + "'  union select 'X' MTC_MATNR,'OTHERS' CL_CODE ,'OTHERS' CL_VALUE from dual";
            }
            else if (Type.ToLower() == "function")
            {
                Query = " select MTC_MATNR, MTC_FUNC CL_CODE ,MTC_FUNC CL_VALUE from sapsur.T_MATERIAL_CLASSIFICATION where MTC_MATNR='" + umcNo + "'  union select 'X' MTC_MATNR,'OTHERS' CL_CODE ,'OTHERS' CL_VALUE from dual ";
            }
            else
            {
                Query = "select MTC_MATNR,MTC_CHAR CL_CODE ,MTC_CHAR CL_VALUE from sapsur.T_MATERIAL_CLASSIFICATION where MTC_MATNR='" + umcNo + "'  union select 'X' MTC_MATNR,'OTHERS' CL_CODE ,'OTHERS' CL_VALUE from dual";
            }
            objConn = new ConnectionOracleDB(strConnSISDB, Query, CommandType.Text, true);
            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                //objConn.AddParameters(":MTC_MATNR", MTC_MATNR);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public string GetHSN_NO(ShoppingCartItem objShoppingCartItem)
        {
            string hsn = "";
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraGet_HSN_NO, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.           

                objConn.AddParameters(":MTC_MATNR", objShoppingCartItem.SCI_MATL_NO);
                objConn.AddParameters(":MTC_CHAR", objShoppingCartItem.SCI_CHARACTERISTICS);
                objConn.AddParameters(":MTC_COMP", objShoppingCartItem.SCI_COMPOSITION);
                objConn.AddParameters(":MTC_ENDU", objShoppingCartItem.SCI_ENDUSE);
                objConn.AddParameters(":MTC_FUNC", objShoppingCartItem.SCI_FUNCTION);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult.Rows.Count > 0)
                {
                    hsn = dtResult.Rows[0]["MTC_HSN"].ToString();
                }


            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return hsn;
        }

        #region ODATA 

        public async Task<string> AccountCheckOData(string OrderNo)
        {
            string DocCategory = "N";
            string activityNo = "0000";
            string PersId = "N";
            string UserCheck = "N";
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            string apiUrl = BaseURL + "opu/odata/sap/YMPIG_ACCT_CHECK_SRV/ACCT_CHECKSet?$filter=( DocCategory eq '" + DocCategory + "' and OrderNo eq '" + OrderNo + "' and ActivityNo eq '" + activityNo + "' and PersId eq '" + PersId + "' and UserCheck eq '" + UserCheck + "'  )&$format=json";
            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }
        public async Task<string> Get_AVGPRICE_ODATA(string UMCNO, string Dept)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            string apiUrl = BaseURL + "opu/odata/sap/YMPI_AVG_PRICE_SRV/It_detailsSet?$filter=(InputMaterial eq '" + UMCNO + "' and Department eq '" + Dept + "')&$format=json";
            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }
        public async Task<string> Get_budgetConsumptionFormDept_ODATA(string Dept)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            string apiUrl = BaseURL + "opu/odata/sap/YMPI_BUDGET_DETAILS_SRV/BUDGET_detailSet?$filter=( Department eq '" + Dept + "' )&$format=json";
            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();

                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }


        #endregion




    }
    public class DBConst
    {
        #region ShoppingCart
        //added by Animesh

        public const string ora_Get_CSR_Category = @"Select CSR_CODE value ,CSR_DESC label from sapsur.CSR_CODES_MASTER ORDER BY CSR_CODE";
        public const string ora_Get_Cost_CategoryDeptType = @"SELECT acct_asgnmt_cat,acct_asgnmt_desc FROM sapsur.t_acct_asgnmt where  acct_asgnmt_cat not in ('U','Q')  and acct_applicable in ('S','B')";
        public const string ora_Get_Cost_Category = @"SELECT acct_asgnmt_cat,acct_asgnmt_desc FROM sapsur.t_acct_asgnmt where  acct_asgnmt_cat in (' ','N')   and acct_applicable in ('S','B')";
        public const string ora_GetDocumentsText = @"select t.text_id,t.txt_fod_type ||' - '|| t.txt_desc txt_desc,t.txt_fod_type,t.TXT_LVL,'' className  from sapsur.t_text_type t where t.txt_fod_type = :FODTYPE and TXT_LVL <>'S'";
        public const string ora_GetCurrencyCode = @"SELECT Distinct T.FROM_CURR FCURR  FROM SAPSUR.T_S_CURR_CODES T where TO_CURR = 'INR'";
        public const string ora_GetCurrencyRateFromCurrency = @"SELECT T.FROM_CURR FCURR,T.EX_DATE GDATU,EX_RATE_TYP KURST,T.LNG_TXT LTEXT,T.TO_CURR TCURR,
T.EX_RATE UKURS  FROM SAPSUR.T_S_CURR_CODES T where FROM_CURR = :FROM_CURR AND TO_CURR = 'INR' order by EX_DATE DESC";
        public const string ora_GetShoppingCartItemList = @"select * from t_sis_shopping_cart_item where nvl(sci_del_ind,'Y') <> 'X' and  SCI_CART_NO=:SCI_CART_NO";
        public const string ora_Get_CSR_CODE_SUB_MASTER = @"Select CSR_SUB_CODE value,CSR_SUB_CODE_DESC label from sapsur.CSR_CODE_SUB_MASTER ORDER BY CSR_SUB_CODE";
        public const string ora_Get_CSR_SUB_CODE_ACTIVITY = @"Select CSR_ACITIVITY_CODE value,CSR_ACITIVITY_DESC label from sapsur.CSR_SUB_CODE_ACTIVITY where CSR_SUB_CODE =:CSR_SUB_CODE ORDER BY CSR_ACITIVITY_CODE";
        public const string oraGetIntelliBuyChecksHeaderAndItem = @"SELECT ROW_NUMBER() OVER (ORDER BY INTBUY_I.EXISTING_UMC) AS srno ,IND.INDENT_ID,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,UMC.REQ_UMC_BGG,to_char(INTBUY_I.SCI_REQD_ON_DT, 'DD-MON-YYYY') as requirement_date,nvl(SC_I.SCI_PRICE,0) SCI_PRICE,umc.document_type,
umc.fod_type,umc.req_umc_desc ,UMC.UOM,scv.code_val_desc INDENT_CURRENT_STATUS,ind.INDENT_CURRENT_STATUS INDENT_CURRENT_STATUS_CODE , umc.EXISTING_UMC || '-' || umc.EXIS_UMC_DESC as TaggedUMC,
nvl(UMC.TOTAL_SAP_DOC_QTY,0) TOTAL_SAP_DOC_QTY,(nvl(QTY,0)-nvl(UMC.TOTAL_SAP_DOC_QTY,0)) as AllowedQty,UMC.UMC_INDENT_ID,IND.INDENTOR_DEPT,IND.INDENT_DESC,IND.INDENT_REMARKS,IND.INDENT_CRT_BY,UMC.ISACTIVE,UMC.IS_REFURBISHABLE
,INTBUY_I.item_id,INTBUY_I.SCI_QTY QTY,SC_I.SCI_QTY_UNIT,SC_I.SCI_ITEM_NO,SC_I.SCI_PRICE_UNIT,INTBUY_I.SYS_REQ_DATE,SCVCode.code_value ||' - '|| SCVCode.CODE_VAL_DESC document_type_DESC,DEPTDESC||'('||ind.indentor_dept||')' DEPT,UMC.CONSUMP_DT,UMC.DEST_SLOC,UMC.CURRENCY,UMC.PUR_GRP,UMC.PROC_TYPE,
UMC.DEST_SLOC,INTBUY_H.SCH_CART_NO,umc.PUR_GRP ||' - '|| pur.DESCRIPTION pg_desc, UMCPCODE.CODE_VAL_DESC SPARE,UMC.DEST_SLOC ||' - '|| LOC.DESCRIPTION SLOC_DESC,DEPTMST.DEPTTYPE, bgg.MATLGRP||'-'|| bgg.DESCRIPTION as SCI_MATL_GRP,
nvl( SC_I.SCI_FRN_PRICE,0) SCI_FRN_PRICE
,SC_I.SCI_FRN_CURR_CD,INTBUY_H.SCH_CART_NAME

--,umcp.ins_spare
            FROM
T_SIS_INDENT_DETAILS IND  INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID           
             inner join 
            T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS 
left join T_SIS_CODE_VALUE SCVCode on SCVCode.CODE_VALUE= umc.DOCUMENT_TYPE and SCVCode.CODETYPE_ID=5
            left join
     T_SIS_INTELLIBUY_CHECK_ITEM INTBUY_I on INTBUY_I.INDENT_ID= IND.INDENT_ID and INTBUY_I.EXISTING_UMC=umc.REQ_UMC_NO
left join
     T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H on INTBUY_H.INDENT_ID= IND.INDENT_ID
left join T_SIS_SHOPPING_CART_HDR SC_H on SC_H.SCH_CART_NO = INTBUY_H.SCH_CART_NO
left join T_SIS_SHOPPING_CART_ITEM SC_I on SC_I.SCI_CART_NO=INTBUY_H.SCH_CART_NO and SC_I.SCI_MATL_NO=INTBUY_I.EXISTING_UMC
 INNER JOIN sapsur.t_s_dept_mst DEPTMST ON DEPTMST.DEPTNO= ind.indentor_dept
 INNER JOIN sapsur.T_UMC_PROD UMCP ON UMCP.UMC_CD= UMC.REQ_UMC_NO and UMCP.PLANT_CD=IND.INDENTOR_PLANT
 Inner Join sapsur.T_S_PURGRP PUR ON pur.purgrp = umc.pur_grp
 left Join T_SIS_CODE_VALUE UMCPCODE on UMCPCODE.CODE_VALUE=umcp.ins_spare and UMCPCODE.CODETYPE_ID=9
 left Join sapsur.T_S_SLOC LOC on LOC.sloc=UMC.DEST_SLOC and loc.plant=IND.INDENTOR_PLANT
  left join  sapsur.T_S_MATL_GRP bgg on bgg.MATLGRP =UMC.REQ_UMC_BGG

            where INTBUY_I.ISACTIVE= 'Y' and INDENT_CURRENT_STATUS >= 37 and IND.INDENT_ID= :INDENT_ID  and SCVCode.ACTIVE_FLG='Y'   order by IND.INDENT_ID ASC";


        public const string oraUpdateShoppingCartItem = @"
update t_SIS_shopping_cart_item set 
				
       
SCI_PLANT_CD            =:SCI_PLANT_CD     
,SCI_PUR_GRP             =:SCI_PUR_GRP             
,SCI_DOC_TYPE            =:SCI_DOC_TYPE         
,SCI_QTY                 =:SCI_QTY                 
,SCI_QTY_UNIT            =:SCI_QTY_UNIT            
,SCI_PRICE               =:SCI_PRICE          
,SCI_REQD_ON_DT          =:SCI_REQD_ON_DT     
,SCI_FOD_TYPE            =:SCI_FOD_TYPE 
,SCI_OA_VENCD            =:SCI_OA_VENCD
,SCI_UPD_ID              =:SCI_UPD_ID              
,SCI_UPD_DT              =sysdate  
,SCI_CHARACTERISTICS=:SCI_CHARACTERISTICS
,SCI_COMPOSITION     =:SCI_COMPOSITION
,SCI_ENDUSE          =:SCI_ENDUSE
,SCI_FUNCTION        =:SCI_FUNCTION
,SCI_TXT_PROC_CONS =: SCI_TXT_PROC_CONS
,SCI_IMP_PLANT_MACHINERY =: SCI_IMP_PLANT_MACHINERY
,SCI_INSTALLED_QTY =:SCI_INSTALLED_QTY
,SCI_REQUESTER=:SCI_REQUESTER
,SCI_FRN_PRICE=:SCI_FRN_PRICE
,SCI_FRN_CURR_CD=:SCI_FRN_CURR_CD
,SCI_EXCHNG_RATE=:SCI_EXCHNG_RATE

,SCI_MATL_GRP=:SCI_MATL_GRP
,SCI_STRG_LOC=:SCI_STRG_LOC
,SCI_PROC_TYP=:SCI_PROC_TYP
,SCI_SPARES_CATEGORY=:SCI_SPARES_CATEGORY
,SCI_DLV_POINT=:SCI_DLV_POINT
,SCI_ITM_SAVED_STAT='Y'

where SCI_CART_NO=:SCI_CART_NO and SCI_MATL_NO=:SCI_MATL_NO";
        public const string oraSubmitShoppingCartItem = @"
update t_SIS_shopping_cart_item set 
				
       
SCI_PLANT_CD            =:SCI_PLANT_CD     
,SCI_PUR_GRP             =:SCI_PUR_GRP             
,SCI_DOC_TYPE            =:SCI_DOC_TYPE         
,SCI_QTY                 =:SCI_QTY                 
,SCI_QTY_UNIT            =:SCI_QTY_UNIT            
,SCI_PRICE               =:SCI_PRICE          
,SCI_REQD_ON_DT          =:SCI_REQD_ON_DT     
,SCI_FOD_TYPE            =:SCI_FOD_TYPE 
,SCI_OA_VENCD            =:SCI_OA_VENCD
,SCI_UPD_ID              =:SCI_UPD_ID              
,SCI_UPD_DT              =sysdate  
,SCI_CHARACTERISTICS=:SCI_CHARACTERISTICS
,SCI_COMPOSITION     =:SCI_COMPOSITION
,SCI_ENDUSE          =:SCI_ENDUSE
,SCI_FUNCTION        =:SCI_FUNCTION
,SCI_TXT_PROC_CONS =: SCI_TXT_PROC_CONS
,SCI_IMP_PLANT_MACHINERY =: SCI_IMP_PLANT_MACHINERY
,SCI_INSTALLED_QTY =:SCI_INSTALLED_QTY
,SCI_REQUESTER=:SCI_REQUESTER
,SCI_FRN_PRICE=:SCI_FRN_PRICE
,SCI_FRN_CURR_CD=:SCI_FRN_CURR_CD
,SCI_EXCHNG_RATE=:SCI_EXCHNG_RATE
,SCI_MATL_GRP=:SCI_MATL_GRP
,SCI_STRG_LOC=:SCI_STRG_LOC
,SCI_PROC_TYP=:SCI_PROC_TYP
,SCI_SPARES_CATEGORY=:SCI_SPARES_CATEGORY
,SCI_DLV_POINT=:SCI_DLV_POINT
,SCI_ITM_SAVED_STAT='Y' 
,SCI_REQUIRED_DT_TYP='O'

where SCI_CART_NO=:SCI_CART_NO and SCI_MATL_NO=:SCI_MATL_NO";
        public const string oraUpdateShoppingCartHDR = @"
update T_SIS_SHOPPING_CART_HDR set 
SCH_UPD_ID=:SCH_UPD_ID
,SCH_DEPT=:SCH_DEPT
,SCH_CRT_FY=:SCH_CRT_FY
,SCH_STATUS=:SCH_STATUS
,SCH_TOT_VAL=:SCH_TOT_VAL
,SCH_INDT_TYP=:SCH_INDT_TYP
,SCH_BUDGET_EXCEEDED_AMT=:SCH_BUDGET_EXCEEDED_AMT
,SCH_GEP_CART_TYPE='SIS'
,SCH_PI_STATUS='N'
,SCH_UPD_DT=sysdate
,SCH_CURR_APPR_LVL='1'
where SCH_CART_NO=:SCH_CART_NO";
        public const string oraGetShoppingCartItem = @"SELECT ROW_NUMBER() OVER (ORDER BY UMC.UMC_INDENT_ID) AS srno , 
IND.INDENT_ID,
IND.INDENTOR_PLANT,
SC_H.SCH_CART_NO,
SCI_MATL_NO
,IND.INDENTOR_DEPT
,REQ_UMC_BGG SCI_MATL_GRP
,IND.INDENTOR_PLANT SCI_PLANT_CD
,umc.PUR_GRP ||' - '|| pur.DESCRIPTION pg_desc
,UMCPCODE.CODE_VAL_DESC SPARE
,UMC.DEST_SLOC ||' - '|| LOC.DESCRIPTION SLOC_DESC
,UMC.DEST_SLOC SCI_STRG_LOC
,SCVCode.code_value ||' - '|| SCVCode.CODE_VAL_DESC document_type_DESC
,UMC.PROC_TYPE
,nvl( SC_I.SCI_PRICE,0) SCI_PRICE
,UMC.DEL_POINT SCI_DLV_POINT
,nvl(SC_I.SCI_PUR_GRP,umc.PUR_GRP)  SCI_PUR_GRP
,UMC.DOCUMENT_TYPE SCI_DOC_TYPE
--,SCI_STK_TYPE
,INT_I.SCI_QTY
,SC_I.SCI_QTY_UNIT
, SC_I.SCI_PRICE_UNIT
,to_char(INT_I.SCI_REQD_ON_DT, 'DD-MON-YYYY') SCI_REQD_ON_DT
--,SCI_REQUESTER
--,SCI_STATUS
,UMC.FOD_TYPE SCI_FOD_TYPE
,CHAP_ID SCI_SAC_CODE
 ,INT_I.EXISTING_UMC || '-' || INT_I.EXISTING_UMC_DESC as UMC_DESC
--,nvl(UMC.MAP_VALUE,0) MAP_VALUE
,SC_I.SCI_CART_NO
,SC_I.SCI_CHARACTERISTICS
,SC_I.SCI_COMPOSITION
,SC_I.SCI_ENDUSE
,SC_I.SCI_FUNCTION
,SC_I.SCI_ITEM_NO
,SCI_OA_VENCD
,SCI_TXT_PROC_CONS
,SCI_IMP_PLANT_MACHINERY
,SC_I.SCI_INSTALLED_QTY
, um.UM_USR_NAME as SCI_REQUESTER
,nvl(SC_I.SCI_FOD_ITEM_NO,'FOD Not Created') SCI_FOD_ITEM_NO
,nvl(SC_I.SCI_FOD_NO,'FOD Not Created') SCI_FOD_NO
,to_char(SC_I.SCI_FOD_CRT_DT, 'DD-MON-YYYY HH:MI AM') SCI_FOD_CRT_DT
,SC_I.SCI_SAP_ERR_MSG
,deptmst.DEPTTYPE SCH_INDT_TYP
,nvl( SC_I.SCI_FRN_PRICE,0) SCI_FRN_PRICE
,SC_I.SCI_FRN_CURR_CD
,nvl (SC_I.SCI_EXCHNG_RATE,0) SCI_EXCHNG_RATE
,SC_I.SCI_REF_OA_NO
,SC_I.SCI_OA_ITEM_NO
,IND.INDENT_CURRENT_STATUS
,SC_I.SCI_MFRNR
,INTBUY_H.SCH_CART_NAME
   FROM
T_SIS_INDENT_DETAILS IND  
INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.INDENT_ID= IND.INDENT_ID 
inner join T_SIS_INTELLIBUY_CHECK_HEADER INTBUY_H on INTBUY_H.INDENT_ID= IND.INDENT_ID 
inner join T_SIS_INTELLIBUY_CHECK_ITEM INT_I on INT_I.INDENT_ID=INTBUY_H.INDENT_ID and INT_I.EXISTING_UMC=UMC.REQ_UMC_NO
inner join T_SIS_SHOPPING_CART_HDR SC_H on SC_H.SCH_CART_NO = INTBUY_H.SCH_CART_NO
inner join T_SIS_SHOPPING_CART_ITEM SC_I on SC_I.SCI_CART_NO=INTBUY_H.SCH_CART_NO and SC_I.SCI_MATL_NO=INT_I.EXISTING_UMC
--inner join T_SIS_CODE_VALUE SCV on scv.id= ind.INDENT_CURRENT_STATUS 
left join T_SIS_CODE_VALUE SCVCode on SCVCode.CODE_VALUE= umc.DOCUMENT_TYPE and SCVCode.CODETYPE_ID=5
inner JOIN sapsur.t_s_dept_mst deptmst ON deptmst.DEPTNO= ind.indentor_dept 
 Inner Join sapsur.T_S_PURGRP PUR ON pur.purgrp = umc.pur_grp
left join sapsur.T_UMC_PROD UMCP on UMCP.UMC_CD=UMC.REQ_UMC_NO and UMCP.PLANT_CD=IND.INDENTOR_PLANT 
 left Join sapsur.T_S_SLOC LOC on LOC.sloc=UMC.DEST_SLOC and loc.plant=IND.INDENTOR_PLANT
  left Join T_SIS_CODE_VALUE UMCPCODE on UMCPCODE.CODE_VALUE=umcp.ins_spare and UMCPCODE.CODETYPE_ID=9
 left join sapsur.t_user_master um on um.UM_USR_ID = INTBUY_H.SCH_USR_NAME
where SC_I.SCI_MATL_NO =:SCI_MATL_NO and SC_I.SCI_CART_NO=:SCI_CART_NO";
        internal static string ora_GetPRTextDocuments = "select LNG_DESC From sapsur.T_UMC_PROD UMCP where UMCP.UMC_CD= :UMC_CD and UMCP.PLANT_CD=:PLANT_CD";
        internal static string ora_GetSCDocuments = "select scd_txt FROM t_sis_sc_document where scd_cart_no=:scd_cart_no and scd_item_no=:scd_item_no and scd_txt_type =:scd_txt_type and scd_lvl=:scd_lvl";
        internal static string ora_GetCSRLocation = "SELECT CSR_LOC_CODE, CSR_LOC_DESC FROM SAPSUR.CSR_LOCATION_MASTER";
        public const string oraInsertSCIDocuments = "INSERT INTO t_sis_sc_document (scd_cart_no, scd_item_no, scd_txt_type, scd_line_no, scd_txt,scd_upd_id, scd_upd_dt, scd_lvl) VALUES (:scd_cart_no, :scd_item_no, :scd_txt_type, :scd_line_no, :scd_txt,:scd_upd_id, sysdate, :scd_lvl)";
        public const string oraUpdateSCIDocuments = @"UPDATE t_sis_sc_document
        SET scd_txt = :scd_txt,scd_line_no=:scd_line_no,scd_lvl=:scd_lvl,scd_upd_id=:scd_upd_id,scd_upd_dt=sysdate
        WHERE scd_cart_no=:scd_cart_no and scd_item_no=:scd_item_no and scd_txt_type=:scd_txt_type";
        public const string oraGetSCCSRDetails = @"select SCC_CART_NO
,SCC_ITEM_NO
,SCC_FOD_TYPE
,SCC_FOD_NO
,SCC_FOD_ITEM_NO
,SCC_DEPT
,CSR_ACT_TAG
,CSR_COMP
,SCC_CRT_ID
,SCC_CRT_DT
,SCC_SUB_CODE
,SCC_SUB_ACTIVITY_CODE
,SCC_LOC_CODE
,SCC_REMARKS from T_SIS_SHOP_CART_CSR where SCC_CART_NO=:SCC_CART_NO and SCC_ITEM_NO=:SCC_ITEM_NO";
        public const string oraGetCostAssesmentData = @"select  saa_cart_no,saa_item_no,saa_line_no,saa_distribution_tp,saa_category, (T_S_CC_TEXTS.COSTCNTR ||' > '|| T_S_CC_TEXTS.DESCRIPTION) as  saa_asgnd_to,saa_upd_id,saa_upd_dt,to_char( saa_distribution_val) saa_distribution_val,saa_activity_num     
     from t_sis_sc_acct_asgnmt , sapsur.T_S_CC_TEXTS where  T_SIS_SC_ACCT_ASGNMT.SAA_ASGND_TO = T_S_CC_TEXTS.COSTCNTR and CNTLAREA='1000' and T_S_CC_TEXTS.CLIENT='600' and T_S_CC_TEXTS.VALTODT >= sysdate and saa_cart_no = :n_cart AND saa_item_no = :n_itemno";
        public const string IndentUpdateStatus = @"update T_SIS_INDENT_DETAILS set INDENT_CURRENT_STATUS = :STATUS  where INDENT_ID=(select INDENT_ID from T_SIS_INTELLIBUY_CHECK_HEADER where SCH_CART_NO=:SCH_CART_NO)";
        public const string UpdateSCSubmitStatus = @"update T_SIS_INDENT_DETAILS set INDENT_CURRENT_STATUS = '39'  where INDENT_ID=(select INDENT_ID from T_SIS_INTELLIBUY_CHECK_HEADER where SCH_CART_NO=:SCH_CART_NO)";
        public const string oraGet_budgetConsumptionFormDept_EBuy = @"select fy, sum( totalvalue) Totval from  
(select case when (to_number(to_char(add_months(trunc(sysdate), 9), 'YYYY')) 
- to_number(to_char(add_months(nvl(sci_reqd_on_dt,trunc(sysdate)),9),'YYYY'))) >= 0  then to_char(add_months(trunc(sysdate), 9), 'YYYY')
else to_char(add_months(nvl(sci_reqd_on_dt, trunc(sysdate)), 9), 'YYYY') end as FY,sci_qty * sci_price totalvalue 
From sapsur.t_shopping_cart_hdr, sapsur.t_shopping_cart_item , sapsur.t_umc_prod where sch_dept = :sch_dept  and sch_status = '04' 
and sch_cart_no = sci_cart_no  and sci_prod_type ='01' and nvl(sci_del_ind, 'Y') <> 'X'  and sci_fod_type in ('RO', 'PR') 
and sci_matl_grp <> '320' and ( nvl(sci_aa_cat,' ') = ' ' or  nvl(sci_aa_cat,'L')  ='L') and nvl(sci_status,'X') <> '06'   
and SCI_MATL_NO = UMC_CD   and SCI_PLANT_CD=PLANT_CD and  MAT_TYP in  ('ERSA','HIBE')  )  group by fy
";
        public const string oraGet_budgetConsumptionFormDept_SIS = @"select fy, sum( totalvalue) Totval from  
(select case when (to_number(to_char(add_months(trunc(sysdate), 9), 'YYYY')) 
- to_number(to_char(add_months(nvl(sci_reqd_on_dt,trunc(sysdate)),9),'YYYY'))) >= 0  then to_char(add_months(trunc(sysdate), 9), 'YYYY')
else to_char(add_months(nvl(sci_reqd_on_dt, trunc(sysdate)), 9), 'YYYY') end as FY,sci_qty * sci_price totalvalue 
From t_sis_shopping_cart_hdr, t_sis_shopping_cart_item , sapsur.t_umc_prod where sch_dept = :sch_dept  and sch_status = '04' 
and sch_cart_no = sci_cart_no  and sci_prod_type ='01' and nvl(sci_del_ind, 'Y') <> 'X'  and sci_fod_type in ('RO', 'PR') 
and sci_matl_grp <> '320' and ( nvl(sci_aa_cat,' ') = ' ' or  nvl(sci_aa_cat,'L')  ='L') and nvl(sci_status,'X') <> '06'   
and SCI_MATL_NO = UMC_CD   and SCI_PLANT_CD=PLANT_CD and  MAT_TYP in  ('ERSA','HIBE')  )  group by fy ";
        public const string oraGet_ClassificationTabEnable = "select 1 from sapsur.t_parameter_master WHERE PAM_TYPE_CD = 'CLASSPURGRP' AND PAM_PARAM_DESC=:PAM_PARAM_DESC AND PAM_ACTIVE_TAG='A' AND PAM_EN_CODE='00001'";
        public const string ora_GetRapidCheckList = @"SELECT sci_matl_grp,
  sci_pur_grp,
  sci_doc_type,
  NVL(loc, 'OTHER') Loc,
  NVL(bgg, 'LOCAL') BGG,
  SUM(amount) Amount
FROM
  (SELECT sci_matl_grp,
    sci_pur_grp,
    sci_doc_type,
    (SELECT pam_param_desc
    FROM(SAPSUR.t_parameter_master)
    WHERE pam_en_code  = '00001'
    AND pam_type_cd    = 'PGRPCHK'
    AND pam_active_tag = 'A'
    AND sci_pur_grp    = pam_param_cd
    ) Loc,
    (SELECT pam_param_desc
    FROM(SAPSUR.t_parameter_master)
    WHERE pam_en_code  = '00001'
    AND pam_type_cd    = 'CENBGG'
    AND pam_active_tag = 'A'
    AND sci_matl_grp   = pam_param_cd
    ) BGG,
    (NVL(sci_qty, 0) * NVL(sci_price, 0)) Amount
  FROM(t_sis_shopping_cart_item)
  WHERE sci_fod_type        ='PR'
  AND sci_prod_type         ='01'
  AND NVL(sci_del_ind,'Y') <> 'X'
  AND SCI_CART_NO           =:SCI_CART_NO
  )
GROUP BY sci_matl_grp,
  sci_pur_grp,
  sci_doc_type,
  Loc,
  BGG";
        public const string oraGetCurrentSCStatus = @"  select IND.INDENT_CURRENT_STATUS INDENT_STATUS from T_SIS_INTELLIBUY_CHECK_HEADER INT_H inner join T_SIS_INDENT_DETAILS IND on IND.INDENT_ID=INT_H.INDENT_ID  
             where INT_H.SCH_CART_NO=:SCH_CART_NO";
        public const string ora_GetParamMasterList = @"SELECT PAM_PARAM_CD,
  PAM_TYPE_CD
FROM SAPSUR.t_parameter_master
WHERE PAM_TYPE_CD IN('FASTPURGRP','FASTPURLMT')
AND PAM_ACTIVE_TAG = 'A'";
        public const string ora_GetSCAttachmentDetails = @"select * from T_SIS_SC_ATTACHMENT where SCA_CART_NO =:SCA_CART_NO";
        public const string oraInsertSCAttachment = @"insert into t_sis_sc_attachment(SCA_CART_NO, SCA_ITEM_NO, SCA_ATTCH_NO, SCA_FILE_NAME, SCA_FILE_TYPE, SCA_FILE_SIZE,  SCA_UPD_ID,SCA_FILE )
                        values(:SCA_CART_NO, '1','1',:SCA_FILE_NAME ,:SCA_FILE_TYPE, :SCA_FILE_SIZE,:SCA_UPD_ID ,:SCA_FILE )";
        public const string oraUpdateSCAttachment = @"update t_sis_sc_attachment set 
           SCA_UPD_ID=:SCA_UPD_ID 
          ,SCA_UPD_DT=sysdate           
          ,SCA_FILE_NAME=:SCA_FILE_NAME 
          ,SCA_FILE_TYPE=:SCA_FILE_TYPE
          ,SCA_FILE_SIZE=:SCA_FILE_SIZE
          ,SCA_FILE=:SCA_FILE
           where SCA_CART_NO=:SCA_CART_NO";
        public const string oraGetGLAccountNo = @"SELECT GL_ACC_NO1 konts FROM sapsur.T_S_ACC_TYP WHERE CHRT_ACC = '1000' AND VAL_GRP_CODE in (SELECT VALGRPCD bwmod FROM sapsur.T_S_VALN_AREA 
                            WHERE PLANT = 077 AND COMPCD = '1000')
            AND VAL_CLASS in (Select distinct VAL_CLASS bklas from sapsur.t_umc_prod where UMC_CD ='5006A0001' and PLANT_CD =077) AND ACC_MOD = 'VBR'";

        public const string oraGetCostCenterSearch = @"select distinct COSTCNTR,(COSTCNTR ||' > '|| DESCRIPTION) as DESCRIPTION  from sapsur.T_S_CC_TEXTS where COSTCNTR = lpad(:costcenter,10,0)  and VALTODT >=sysdate";

        public const string ora_getSqlDistinctCat = @"SELECT NVL(COUNT(DISTINCT(sci_aa_cat)),'0') AS cat,
  NVL(COUNT(DISTINCT(coll_centre)),'0')     AS stloc ,
  NVL(COUNT(DISTINCT(sci_prod_type)),'0')   AS sci_prod_type ,
  NVL(COUNT(DISTINCT(sci_fod_type)),'0')    AS sci_fod_type
FROM t_sis_shopping_cart_item,
  SAPSUR.ympit_collcenter
WHERE sci_cart_no         =:SCI_CART_NO
AND sci_strg_loc          =storage_loc
AND sci_plant_cd          =plant
AND sci_itm_saved_stat    ='Y'
AND NVL(sci_del_ind,'Y') <> 'X' ";

        public const string ora_getDrft_chk_sc = @"SELECT sch_status,
  NVL(SCH_GEP_CART_TYPE,'') SCH_GEP_CART_TYPE
FROM t_sis_shopping_cart_hdr
WHERE sch_cart_no=:SCI_CART_NO";


        public const string ora_getShoppingCartDocument = @"SELECT * FROM t_sis_sc_document WHERE scd_cart_no=:SCI_CART_NO";

        public const string ora_getOrderIndicator = @"SELECT ordind ord_ind FROM SAPSUR.t_s_ord_indicator WHERE DOCTYP = :auart";

        public const string ora_getIndicatorCount = @"SELECT COUNT(1)
FROM SAPSUR.t_s_ccvalidate
WHERE tsc_orderno LIKE '%'
  || :orderNO
AND tsc_indicator='F'
AND tsc_deptno   =:dept";

        public const string oraCheckValidCostCenter = @"SELECT COUNT(*) COUNT FROM (sapsur.T_S_CC_TEXTS) WHERE COSTCNTR  IN (SELECT DISTINCT substr(tsc_orderno, -10, 10) FROM (sapsur.t_s_ccvalidate) WHERE tsc_deptno = :dept AND tsc_indicator =:indicator) AND trunc(SYSDATE) BETWEEN VALFRMDT AND  VALTODT AND COSTCNTR =:costcenter";
        public const string oraCheckMultipleAccountAssignment = @"select SAA_CATEGORY from T_SIS_SC_ACCT_ASGNMT where SAA_CART_NO=:SAA_CART_NO";
        public const string oraGetVendorMasterDetails = @"select VENDOR,(Vendor ||' > '|| Name1) as VendorName from sapsur.T_S_VEN_MAST  where VENDOR like '%vendorcode'";
        public const string oraUpdateMNPDrawing = @"UPDATE T_SIS_SHOPPING_CART_ITEM set SCI_PART_NO=:SCI_PART_NO , SCI_MFRNR=:SCI_MFRNR ,SCI_MPN_NO=:SCI_MPN_NO  where SCI_CART_NO=:SCI_CART_NO and SCI_ITEM_NO=:SCI_ITEM_NO";
        public const string oraDeleteCostAssesment = @"Delete from t_sis_sc_acct_asgnmt a where a.saa_cart_no=:saa_cart_no and a.saa_item_no= :saa_item_no";
        public const string oraDeleteDocumentText = @"Delete from T_SIS_SC_DOCUMENT a where a.SCD_CART_NO=:SCD_CART_NO and a.SCD_ITEM_NO= :SCD_ITEM_NO and a.SCD_TXT_TYPE=:SCD_TXT_TYPE";
        public const string oraDeleteDocumentLVLText = @"Delete from T_SIS_SC_DOCUMENT a where a.SCD_CART_NO=:SCD_CART_NO and a.SCD_ITEM_NO= :SCD_ITEM_NO and a.SCD_TXT_TYPE=:SCD_TXT_TYPE and a.SCD_LVL=:SCD_LVL";
        public const string oraSelectVendorDetails = @"SELECT T.VENDOR, T.NAME1 FROM SAPSUR.T_S_VEN_MAST T where T.VENDOR = :VENDOR and T.client='600'";
        public const string ora_getPurchaseGrp = @"SELECT t.PURGRP PURGRP,
  t.DESCRIPTION pg_desc
FROM SAPSUR.T_UMC_PROD m,
  sapsur.T_S_PURGRP t
WHERE m.UMC_CD = :SCI_MATL_NO
AND m.PLANT_CD = :SCI_PLANT_CD
AND m.PUR_GRP  = t.PURGRP";

        public const string ora_getDatafromS_PURGRP_ekgrp = @"SELECT NULL AS pg_cd, NULL AS pgl FROM dual
UNION
SELECT P.EKGRP AS pg_cd, t.description || '<' || P.EKGRP AS pgl
FROM SAPSUR.t_plant_purgrp P
JOIN SAPSUR.T_S_PURGRP t ON P.EKGRP = t.PURGRP
WHERE P.WERKS = :plant AND P.ekgrp = '110' AND CLIENT = '600'";

        public const string ora_getPurchaseDrpTable = @"SELECT sci_ref_oa_no
FROM t_sis_shopping_cart_item
WHERE sci_cart_no = :scno
AND sci_item_no   = :itemNo";

        public const string ora_getmpnDrawingData = @"SELECT SCI_PART_NO,
  SCI_MFRNR,
  SCI_MPN_NO
FROM T_SIS_SHOPPING_CART_ITEM
WHERE SCI_CART_NO=:SCI_CART_NO
AND SCI_ITEM_NO  =:SCI_ITEM_NO";

        public const string ora_getDesvencodr = @"SELECT BLOCK_CD sperq
FROM SAPSUR.T_S_VEN_MAST
WHERE VENDOR=:vendor
AND client  ='600'";

        public const string ora_getShoppingCartItemEcm = @"SELECT sci_item_no ,
  sci_pur_grp ,
  sci_matl_grp
FROM t_sis_shopping_cart_item itm
WHERE sci_prod_type        = '01'
AND sci_fod_type          IN ('PR')
AND NVL(sci_del_ind, 'Y') <> 'X'
AND sci_cart_no            = :scNo
AND sci_pur_grp           IN
  (SELECT DISTINCT PAM_TYPE_CD
  FROM SAPSUR.t_parameter_master
  WHERE PAM_EN_CODE  = '00001'
  AND pam_param_desc = 'ECMMATPGRP'
  )
AND (sci_pur_grp
  || sci_matl_grp) NOT IN
  (SELECT DISTINCT PAM_TYPE_CD
    || pam_param_cd
  FROM SAPSUR.t_parameter_master
  WHERE PAM_EN_CODE  = '00001'
  AND pam_param_desc = 'ECMMATPGRP'
  )";

        public const string ora_get_plant_lvl_chk_str = @"SELECT CROS_PLNT_MAT_STAT
FROM SAPSUR.T_UMC_PROD
WHERE UMC_CD=:matlNo
AND PLANT_CD=:plantCd";

        public const string ora_plant_indpndnt_chk_rdr = @"SELECT PLNT_MAT_STAT,
  MAT_TYP, MAT_DEL_FLAG_PLNT
FROM SAPSUR.t_umc_prod
WHERE UMC_CD=:matlNo
AND PLANT_CD=:plantCd";


        public const string ora_get_Mat_Val_Cls = @"SELECT NVL(VAL_CLASS_PROJ,'0') qklas
FROM SAPSUR.T_UMC_PROD
WHERE UMC_CD=:matlNo
AND PLANT_CD=:plantCd";

        public const string ora_GetCurrencyCheck = @"SELECT DISTINCT sci_frn_curr_cd curr
FROM t_sis_shopping_cart_item
WHERE sci_cart_no   =:scNo
AND sci_frn_curr_cd<>'INR'";

        public const string ora_getParamCd = @"SELECT pam_type_cd
FROM SAPSUR.t_parameter_master
WHERE pam_type_cd IN('MDM_ACTV','MDMUMC_BLK')
AND PAM_PARAM_CD   ='Y'
AND PAM_ACTIVE_TAG ='A'";

        public const string ora_getPlantCheck = @"SELECT CROS_PLNT_MAT_STAT ,
  PLNT_MAT_STAT
FROM SAPSUR.t_umc_prod
WHERE umc_cd =:matlNo
AND plant_cd =:plantCd
AND EXISTS
  (SELECT 1
  FROM SAPSUR.t_parameter_master
  WHERE pam_type_cd  = 'MDM_MATBLK'
  AND PAM_PARAM_CD   = 'Y'
  AND PAM_ACTIVE_TAG = 'A')";


        public const string ora_getDivisionData = @"SELECT DIVISION spart
FROM SAPSUR.T_UMC_PROD
WHERE UMC_CD =:matlNo
AND PLANT_CD =:plantCd";

        public const string ora_getbudgetDeptCount = @"SELECT COUNT(1)
FROM SAPSUR.t_s_dept_mst
WHERE NVL(BUDGTCHK,'N') <>'N'
AND client               = '600'
AND deptno               =
  (SELECT sch_dept FROM t_sis_shopping_cart_hdr WHERE sch_cart_no=:scno)";


        public const string ora_getGsber = @"SELECT gsber FROM SAPSUR.T134G WHERE werks = :plantCd AND spart=:spart";


        public const string ora_Updateto_Draft = "update T_SIS_SHOPPING_CART_HDR set SCH_STATUS='03', SCH_CURR_APPR_LVL='' where SCH_CART_NO=:SCH_CART_NO";

        public const string ora_getPursaseGroup = @" select distinct P.EKGRP pg_cd,t.description|| ' < '||P.EKGRP pgl from sapsur.t_plant_purgrp p,sapsur.T_S_PURGRP t   where(P.EKGRP = t.PURGRP)   and P.WERKS=:WERKS 
        and CLIENT='600' and t.PURGRP not in    (Select pam_param_desc From sapsur.t_parameter_master Where pam_type_cd='PURGRP_EXCL' and pam_param_cd='01')";


        public const string ora_getSusData = @"select count(1) from t_sis_shop_cart_csr where scc_cart_no=:scNo and scc_item_no=:itemNo";

        public const string oraUpdateROVendor = "update t_sis_shopping_cart_item set sci_ref_oa_no =:sci_ref_oa_no, sci_oa_item_no =:sci_oa_item_no,sci_oa_vencd=:sci_oa_vencd where sci_cart_no = :sci_cart_no  and sci_item_no =:sci_item_no";

        // public const string oraUpdateROVendorByDefault = "update t_sis_shopping_cart_item set sci_ref_oa_no =:sci_ref_oa_no, sci_oa_item_no =:sci_oa_item_no,sci_oa_vencd=:sci_oa_vencd where sci_cart_no = :sci_cart_no  and sci_item_no =:sci_item_no and sci_ref_oa_no is null";

        public const string oraGetROPriceFromEKPO = "SELECT a.ebeln, ebelp,netpr, PEINH ,waers FROM sapsur.ekpo a,sapsur.ekko b WHERE a.ebeln = b.ebeln and a.ebeln = :contract AND ebelp = Lpad(:ItemNo,'5','0')";

        public const string oraUpdatePurchaseGroup = "update t_sis_shopping_cart_item set SCI_PUR_GRP =:SCI_PUR_GRP,SCI_PRICE=:SCI_PRICE,SCI_UPD_DT=sysdate where SCI_CART_NO = :SCI_CART_NO  and SCI_ITEM_NO =:SCI_ITEM_NO and SCI_MATL_NO=:SCI_MATL_NO ";


        public const string ora_getFrgKeFromEkko = @"select frgke from sapsur.ekko where ebeln = :ebeln";

        public const string ora_getloekzCountFromEkpo = @"select count(1) as counter from sapsur.ekPo where ebeln=:ebeln and ebelp = :ebelp and loekz = 'L'";

        public const string ora_getdtIsAcntMissing = @"SELECT SCI_ITEM_NO
FROM t_sis_shopping_cart_item
WHERE NVL(SCI_AA_CAT,'U') NOT IN (' ','U')
AND NVL(SCI_DEL_IND,'Z')       ='Z'
AND sci_cart_no                =:SCI_CART_NO
AND sci_item_no NOT           IN
  (SELECT SAA_ITEM_NO FROM t_sis_sc_acct_asgnmt WHERE SAA_CART_NO=:SCI_CART_NO
  )";


        public const string ora_getShoppingCartAccountAssinment = @"select * from t_sis_sc_acct_asgnmt where SAA_CART_NO =:SCI_CART_NO";

        public const string ora_get_s_pr = @"SELECT sci_ref_oa_no  FROM t_sis_shopping_cart_item WHERE sci_cart_no =:cartNo AND sci_item_no =:itemNo";

        public const string ora_get_smd_plnt_cd = @"SELECT DISTINCT smdplant
FROM SAPSUR.t_plant_smdplant
WHERE iplant IN
  (SELECT rov_val
  FROM(SAPSUR.t_role_obj_val)
  WHERE rov_object = 'OBJ_PLANT'
  AND rov_role_id IN
    (SELECT rov_role_id
    FROM(SAPSUR.t_role_obj_val)
    WHERE rov_role_id IN
      (SELECT DISTINCT tru_role_id
      FROM(SAPSUR.t_role_user)
      WHERE tru_udr_id   = :userId
      AND (tru_from_dat <= sysdate
      AND tru_to_dat    >= sysdate)
      )
    AND rov_object   = 'OBJ_DEPT'
    AND rov_val      = :dept
    AND rov_role_typ = 'IND'
    )
  ) ";

        public const string ora_get_purchasing_dept1 = @"SELECT 1 FROM SAPSUR.T_S_DEPT_MST  WHERE DEPTTAG='PURCHASING_DEPT' AND DEPTNO=:dept";
        public const string ora_getCurrencyAndValue = @"select WAERS, WKURS from sapsur.ekko where ebeln=:ebeln";
        public const string ora_getCurrencyValueFromT_S_CURR_CODES = @"SELECT T.FROM_CURR FCURR,
  T.EX_DATE GDATU,
  EX_RATE_TYP KURST,
  T.LNG_TXT LTEXT,
  T.TO_CURR TCURR,
  T.EX_RATE UKURS
FROM SAPSUR.T_S_CURR_CODES T
WHERE FROM_CURR = :WAERS
AND TO_CURR     = 'INR'
ORDER BY GDATU DESC";
        public const string ora_get_DocumentsFromSC = @"SELECT
TXT_TYP.TEXT_ID,
TXT_TYP.TXT_DESC,
LISTAGG(SC_D.SCD_TXT, ', ') WITHIN GROUP(ORDER BY SC_D.SCD_LINE_NO,SC_D.SCD_LVL) AS SCD_TXT,txt_typ.txt_lvl
FROM
    t_SIS_sc_document SC_D
INNER JOIN
    sapsur.t_text_type TXT_TYP ON SC_D.SCD_TXT_TYPE = TXT_TYP.text_id and SC_D.SCD_LVL=txt_typ.txt_lvl
INNER JOIN
    T_SIS_SHOPPING_CART_ITEM SC_I ON SC_I.SCI_CART_NO = SC_D.SCD_CART_NO
                                   AND SC_I.sci_item_no = SC_D.SCD_ITEM_NO
WHERE
    SC_D.SCD_CART_NO = :scp_cart_no
   AND SC_I.SCI_MATL_NO = :SCI_MATL_NO
GROUP BY
    TXT_TYP.TEXT_ID, TXT_TYP.TXT_DESC, txt_typ.txt_lvl";


        public const string ora_getMpnValueCount = @"SELECT count(1) as counter
FROM SAPSUR.t_umc_prod
LEFT JOIN CMDRDB.t_s_ven_mast@CTDR_EPROC_DBL VEN
ON MFRNR          =VENDOR
AND VEN.CLIENT    ='600'
WHERE bmatn       = :matlNo
AND mat_typ       ='HERS'
AND plnt_mat_Stat =' '";

        public const string oraGet_HSN_NO = "select MTC_HSN from sapsur.T_MATERIAL_CLASSIFICATION where  MTC_MATNR =:MTC_MATNR and trim(MTC_CHAR)=:MTC_CHAR and trim(MTC_COMP)=:MTC_COMP AND trim(MTC_ENDU)=:MTC_ENDU AND trim(MTC_FUNC)=:MTC_FUNC";

        //        public const string oraUpdateShoppingCartItem = @"
        //update t_shopping_cart_item set 

        //--,SCI_ITEM_NO             =:SCI_ITEM_NO             
        //,SCI_ITEM_DESC           =:SCI_ITEM_DESC           
        //,SCI_PROD_TYPE           =:SCI_PROD_TYPE           
        //,SCI_MATL_NO             =:SCI_MATL_NO             
        //--,SCI_REF_OA_NO           =:SCI_REF_OA_NO           
        //--,SCI_OA_ITEM_NO          =:SCI_OA_ITEM_NO          
        //,SCI_OA_SERV_LINE_NO     =:SCI_OA_SERV_LINE_NO     
        //,SCI_OA_ITEM_DESC        =:SCI_OA_ITEM_DESC        
        //--,SCI_OA_VENCD            =:SCI_OA_VENCD            
        //,SCI_MATL_GRP            =:SCI_MATL_GRP            
        //--,SCI_PLANT_CD            =:SCI_PLANT_CD            
        //--,SCI_STRG_LOC            =:SCI_STRG_LOC            
        //,SCI_DLV_POINT           =:SCI_DLV_POINT           
        //--,SCI_PUR_GRP             =:SCI_PUR_GRP             
        //--,SCI_DOC_TYPE            =:SCI_DOC_TYPE            
        //,SCI_STK_TYPE            =:SCI_STK_TYPE            
        //--,SCI_QTY                 =:SCI_QTY                 
        //--,SCI_QTY_UNIT            =:SCI_QTY_UNIT            
        //--,SCI_PRICE               =:SCI_PRICE               
        //,SCI_PRICE_UNIT          =:SCI_PRICE_UNIT          
        //--,SCI_REQD_ON_DT          =:SCI_REQD_ON_DT          
        //,SCI_GOOD_RCPNT          =:SCI_GOOD_RCPNT          
        //,SCI_REQUESTER           =:SCI_REQUESTER           
        //,SCI_STATUS              =:SCI_STATUS              
        //--,SCI_FOD_TYPE            =:SCI_FOD_TYPE            
        //,SCI_FOD_ITEM_NO         =:SCI_FOD_ITEM_NO         
        //,SCI_FOD_NO              =:SCI_FOD_NO              
        //,SCI_FOD_CRT_DT          =:SCI_FOD_CRT_DT          
        //--,SCI_UPD_ID              =:SCI_UPD_ID              
        //--,SCI_UPD_DT              =:SCI_UPD_DT              
        //--,SCI_AA_CAT              =:SCI_AA_CAT              
        //,SCI_REQUIRED_DT_TYP     =:SCI_REQUIRED_DT_TYP     
        //,SCI_REQUIRED_FROM_DT    =:SCI_REQUIRED_FROM_DT    
        //,SCI_REQUIRED_TO_DT      =:SCI_REQUIRED_TO_DT      
        //,SCI_FOD_SERVICE_LINE_NO =:SCI_FOD_SERVICE_LINE_NO 
        //,SCI_INT_FOD_TYPE        =:SCI_INT_FOD_TYPE        
        //,SCI_INT_FOD_NO          =:SCI_INT_FOD_NO          
        //,SCI_INT_FOD_ITEM_NO     =:SCI_INT_FOD_ITEM_NO     
        //,SCI_INT_FOD_SERV_LINE_NO=:SCI_INT_FOD_SERV_LINE_NO
        //,SCI_OA_SERV_LINE_DESC   =:SCI_OA_SERV_LINE_DESC   
        //,SCI_SAP_ERR_MSG         =:SCI_SAP_ERR_MSG         
        //--,SCI_DEL_IND             =:SCI_DEL_IND             
        //,--SCI_ITM_SAVED_STAT    =:--SCI_ITM_SAVED_STAT    
        //,SCI_FOD_ERR_MAIL        =:SCI_FOD_ERR_MAIL        
        //,SCI_RCV_PLANT           =:SCI_RCV_PLANT           
        //,SCI_RCV_STRG_LOC        =:SCI_RCV_STRG_LOC        
        //,SCI_FRN_PRICE           =:SCI_FRN_PRICE           
        //,SCI_FRN_CURR_CD         =:SCI_FRN_CURR_CD         
        //,SCI_EXCHNG_RATE         =:SCI_EXCHNG_RATE         
        //,SCI_COST_MODEL_NO       =:SCI_COST_MODEL_NO       
        //,SCI_MR_TEXT             =:SCI_MR_TEXT             
        //,SCI_TXT_PROC_CONS       =:SCI_TXT_PROC_CONS       
        //,SCI_IMP_PLANT_MACHINERY =:SCI_IMP_PLANT_MACHINERY 
        //,SCI_OSJ_ID              =:SCI_OSJ_ID              
        //,SCI_USC_SOP             =:SCI_USC_SOP             
        //,SCI_GDCS_UID            =:SCI_GDCS_UID            
        //,--SCI_PROP_TAG          =:--SCI_PROP_TAG          
        //,SCI_USR_REQ_ID          =:SCI_USR_REQ_ID          
        //,SCI_SUST_ID             =:SCI_SUST_ID             
        //,SCI_SUB_PACK_NO         =:SCI_SUB_PACK_NO         
        //,SCI_CREATOR_MOB         =:SCI_CREATOR_MOB         
        //,SCI_RECEIVER_NAME       =:SCI_RECEIVER_NAME       
        //,SCI_RECEIVER_PNO        =:SCI_RECEIVER_PNO        
        //,SCI_RECIVER_MOB         =:SCI_RECIVER_MOB         
        //,SCI_CRE_SUP_NAME        =:SCI_CRE_SUP_NAME        
        //,SCI_CRE_SUP_PNO         =:SCI_CRE_SUP_PNO         
        //,SCI_CRE_SUP_MOB         =:SCI_CRE_SUP_MOB         
        //,SCI_BUYER_ID            =:SCI_BUYER_ID            
        //,SCI_PI_STATUS           =:SCI_PI_STATUS           
        //,SCI_PI_PICK_TIMESTAMP   =:SCI_PI_PICK_TIMESTAMP   
        //,SCI_PI_ACK_TIMESTAMP    =:SCI_PI_ACK_TIMESTAMP    
        //,SCI_PI_FINAL_TIMESTAMP  =:SCI_PI_FINAL_TIMESTAMP  
        //,SCI_PI_IB_MESSAGE_ID    =:SCI_PI_IB_MESSAGE_ID    
        //,SCI_PI_OB_MESSAGE_ID    =:SCI_PI_OB_MESSAGE_ID    
        //,SCI_PI_SOURCE_PGM       =:SCI_PI_SOURCE_PGM       
        //,--SCI_REBURBISH_QTY     =:--SCI_REBURBISH_QTY     
        //,--SCI_INSTALLED_QTY     =:--SCI_INSTALLED_QTY     
        //,--SCI_PROC_TYP          =:--SCI_PROC_TYP          
        //,--SCI_SPARES_CATEGORY   =:--SCI_SPARES_CATEGORY   
        //---,SCI_HAZARD_LVL          =:SCI_HAZARD_LVL          
        //--,SCI_PART_NO             =:SCI_PART_NO             
        //--,SCI_MFRNR               =:SCI_MFRNR               
        //,SCI_SAC_CODE            =:SCI_SAC_CODE            
        //,SCI_RISK_CAT            =:SCI_RISK_CAT            
        //,--SCI_RMC_CONTRACT      =:--SCI_RMC_CONTRACT      
        //,--SCI_RMC_ITEM          =:--SCI_RMC_ITEM          
        //,SCI_REGION              =:SCI_REGION              
        //,SCI_RMC_GRADE           =:SCI_RMC_GRADE           
        //,SCI_SUBCON_STATUS       =:SCI_SUBCON_STATUS       
        //,SCI_SUBCON_ERR          =:SCI_SUBCON_ERR          
        //,SCI_SUBCON_NO           =:SCI_SUBCON_NO           
        //,SCI_SUBCON_ITEM         =:SCI_SUBCON_ITEM         
        //,PI_OB_MESSAGE_ID        =:PI_OB_MESSAGE_ID        
        //,PI_POST_TIMESTAMP       =:PI_POST_TIMESTAMP       
        //,PI_SOURCE_PGM           =:PI_SOURCE_PGM           
        //--,SCI_MPN_NO              =:SCI_MPN_NO              
        //,SCI_DATAID              =:SCI_DATAID              
        //,SCI_SANC_REQ_NO         =:SCI_SANC_REQ_NO         
        //,--SCI_DECISION          =:--SCI_DECISION          
        //,SCI_CHARACTERISTICS     =:SCI_CHARACTERISTICS     
        //,SCI_COMPOSITION         =:SCI_COMPOSITION         
        //,SCI_ENDUSE              =:SCI_ENDUSE              
        //,SCI_FUNCTION            =:SCI_FUNCTION            
        //,SCI_CLASS_CODE          =:SCI_CLASS_CODE          where SCI_CART_NO=:SCI_CART_NO";
        #endregion


    }
}
﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Results;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;


namespace SIS_BACKEND_API.App_Code.DAL.ShoppingCart
{
    public class SC_ApprovalDAL
    {

        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        // This Method used for assign the Approver 
        public void InsertApprovals(List<ApprovalRequest> approvals)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                foreach (var approval in approvals)
                {
                    using (var command = new OracleCommand("p_ins_sis_sc_approval", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("tot_amnt", OracleDbType.Int32).Value = approval.tot_amnt;
                        command.Parameters.Add("indnt_type", OracleDbType.Varchar2).Value = approval.indnt_type;
                        command.Parameters.Add("scartno", OracleDbType.Int32).Value = approval.scartno;
                        command.Parameters.Add("dept_no", OracleDbType.Int32).Value = approval.dept_no;
                        command.Parameters.Add("Committed_Expenditure_Val", OracleDbType.Int32).Value = approval.Committed_Expenditure_Val;
                        command.Parameters.Add("Spare_Budget_Val", OracleDbType.Int32).Value = approval.Spare_Budget_Val;


                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        // This Method used for update the Action like "APPROVE, REJECT, RETURN"
        public void InsertApprovalSection(ApprovalSection approvalSec)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                using (var command = new OracleCommand("p_sis_appr_section", connection))               
                {
                    command.Parameters.Clear();
                    command.CommandText = "p_sis_appr_section";                   
                    command.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    command.Parameters.Add("nscnum", OracleDbType.Varchar2).Value = approvalSec.nscnum;
                    command.Parameters.Add("status", OracleDbType.Varchar2).Value = approvalSec._status;   // "1";    
                    command.Parameters.Add("appr_id", OracleDbType.Varchar2).Value = approvalSec.appr_id;  // "163402";  
                    command.Parameters.Add("appr_rem", OracleDbType.Varchar2).Value = approvalSec.appr_rem; // "Approval Remarks" 
                  //  command.Parameters.Add("mail_to", OracleDbType.Varchar2).Value = approvalSec.mail_to;   // "ALL";  
                  //  command.Parameters.Add("IMEI_no", OracleDbType.Varchar2).Value = approvalSec.IMEI_no;  // "WEB";

                    // Output parameter
                    OracleParameter outputParam = new OracleParameter("err_msg", OracleDbType.Varchar2);
                    outputParam.Direction = ParameterDirection.Output;
                    outputParam.Size = 500; // Adjust size as per your requirement
                    command.Parameters.Add(outputParam);
                    int i = command.ExecuteNonQuery();

                }

            }
        }

        // This Method used for upload Attchement  
        public int UploadApprovalFile_Dal(FileUploadModel fileUploadModel)
        {
            int i=0;
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = @"
                    UPDATE t_sis_sc_approval SET 
                        scp_filename = :FileName,
                        scp_atchmnt = :BlobParameter 
                    WHERE
                        scp_cart_no = :Sno 
                        AND scp_apprvr = :UserId 
                       AND (scp_mailsend_status = '01')
                        AND scp_app_status = '00' 
                        AND scp_ver_no = (
                            SELECT MAX(scp_ver_no) 
                            FROM t_sis_sc_approval 
                            WHERE scp_cart_no = :Sno
                        )";

                    command.Parameters.Add(new OracleParameter("FileName", OracleDbType.Varchar2) { Value = fileUploadModel.FileName });
                    command.Parameters.Add(new OracleParameter("BlobParameter", OracleDbType.Blob) { Value = fileUploadModel.FileContent });
                    command.Parameters.Add(new OracleParameter("Sno", OracleDbType.Varchar2) { Value = fileUploadModel.Sno });
                    command.Parameters.Add(new OracleParameter("UserId", OracleDbType.Varchar2) { Value = fileUploadModel.UserId });

                     i = command.ExecuteNonQuery(); 
                }
            }
            return i;
        }

        // This Method used for fetch the Shopping Cart Details
        public DataTable GetShoppingCartDetails_DAL(string SCId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryShoppingCartDetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":sci_cart_no", SCId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the data for SC_APPROVAL page for Header & Material Level Details
        public DataTable GetSCHeaderAndMaterialDetails_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.oraGetSCHeaderAndMaterialDetails, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the data from assign approver level 
        public DataTable GetSCApprovalHierarchy_DAL(string SCNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetSCApprovalHierarchy, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":scp_cart_no", SCNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the approval remarks
        public DataTable GetSCAppRemarks_DAL(string SCNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetSCAppRemarks, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":scp_cart_no", SCNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the data for pending approval
        public DataTable GetSCApprovalPendingList_DAL(string UserId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QrySCApprovalPendingList, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.  
                objConn.AddParameters(":userid", UserId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the for display report for view details
        public DataTable GetIntelliBuyChecksHeaderAndItem(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.oraGetIntelliBuyChecksHeaderAndItem, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the data for view Details
        public DataTable GetSCDetailsForApproval_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.oraGetSCDetailsForApproval, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetch the Justification and display in SC_Approval Page
        public DataTable GetJustification_DAL(string SCNo,string SCI_MATL_NO)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetJustification, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":scp_cart_no", SCNo);
                objConn.AddParameters(":SCI_MATL_NO", SCI_MATL_NO);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the Answare status for Communication purpuse
        public DataTable GetAnswerStatus_DAL(string SCNo, string UserId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetAnswerStatus, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":scp_cart_no", SCNo);
                objConn.AddParameters(":UserId", UserId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }



        // This Method used for fetching records for communication purpuse
        public async Task<DataTable> GetRecordAsync(string cartNo)
        {
            DataTable dtResult = new DataTable();
            var query = @"SELECT SCC_SEQ_NO, SCC_FROM_ID, SCC_TO_ID, SCC_IS_CONFIDENTIAL 
                      FROM T_SIS_SC_COMMUNICATION 
                      WHERE SCC_CART_NO = :SCC_CART_NO 
                      AND SCC_SEQ_NO = (SELECT MAX(SCC_SEQ_NO) 
                                        FROM T_SIS_SC_COMMUNICATION 
                                        WHERE SCC_CART_NO = :SCC_CART_NO)";

            using (var connection = new OracleConnection(strConnSISDB))
            {
                await connection.OpenAsync();
                using (var command = new OracleCommand(query, connection))
                {
                    command.Parameters.Add(new OracleParameter("SCC_CART_NO", cartNo));

                    using (var adapter = new OracleDataAdapter(command))
                    {
                        await Task.Run(() => adapter.Fill(dtResult));
                    }
                }
            }

            return dtResult;
        }

        // This Method used for insert the record in communication table 
        public async Task InsertCommunication_OnlyInsertAsync(CommunicationRequest request)
        {
            var query = @"INSERT INTO T_SIS_SC_COMMUNICATION 
                  (SCC_CART_NO, SCC_SEQ_NO, SCC_TYPE, SCC_TEXT, SCC_FROM_ID, SCC_TO_ID, SCC_ACTIVE_FLAG, SCC_STATUS, SCC_CRT_DT, SCC_CRT_BY, SCC_IS_CONFIDENTIAL) 
                  VALUES 
                  (:SCC_CART_NO, :SCC_SEQ_NO, :SCC_TYPE, :SCC_TEXT, :SCC_FROM_ID, :SCC_TO_ID, :SCC_ACTIVE_FLAG, :SCC_STATUS, SYSDATE, :SCC_CRT_BY, :SCC_IS_CONFIDENTIAL)";

            using (var connection = new OracleConnection(strConnSISDB))
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Check for existing communication with SCC_IS_ANSWER = 'N'
                        var duplicateCheckQuery = @"SELECT COUNT(*) 
                                            FROM T_SIS_SC_COMMUNICATION 
                                            WHERE SCC_CART_NO = :SCC_CART_NO 
                                            AND SCC_FROM_ID = :SCC_FROM_ID 
                                            AND SCC_IS_ANSWER = 'N'";

                        using (var duplicateCommand = new OracleCommand(duplicateCheckQuery, connection))
                        {
                            duplicateCommand.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));
                            duplicateCommand.Parameters.Add(new OracleParameter("SCC_FROM_ID", request.SCC_FROM_ID));

                            var duplicateCount = Convert.ToInt32(await duplicateCommand.ExecuteScalarAsync());

                            if (duplicateCount > 0)
                            {
                                throw new Exception("A pending communication already exists. Please answer the existing one before creating a new one.");
                            }
                        }

                        var seqNo = 1;

                        // Get the current record's sequence number
                        var selectQuery = @"SELECT SCC_SEQ_NO 
                                    FROM T_SIS_SC_COMMUNICATION 
                                    WHERE SCC_CART_NO = :SCC_CART_NO 
                                    AND SCC_SEQ_NO = (SELECT MAX(SCC_SEQ_NO) 
                                                      FROM T_SIS_SC_COMMUNICATION 
                                                      WHERE SCC_CART_NO = :SCC_CART_NO)";

                        using (var selectCommand = new OracleCommand(selectQuery, connection))
                        {
                            selectCommand.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));

                            using (var reader = await selectCommand.ExecuteReaderAsync())
                            {
                                if (await reader.ReadAsync())
                                {
                                    seqNo = reader.GetInt32(0) + 1;
                                }
                            }
                        }

                        // Insert new communication if no pending communication found
                        using (var insertCommand = new OracleCommand(query, connection))
                        {
                            insertCommand.Transaction = transaction;
                            insertCommand.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_SEQ_NO", seqNo));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_TYPE", request.SCC_TYPE));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_TEXT", request.SCC_TEXT));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_FROM_ID", request.SCC_FROM_ID));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_TO_ID", request.SCC_TO_ID));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_ACTIVE_FLAG", request.SCC_ACTIVE_FLAG));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_STATUS", request.SCC_STATUS));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_CRT_BY", request.SCC_CRT_BY));
                            insertCommand.Parameters.Add(new OracleParameter("SCC_IS_CONFIDENTIAL", request.SCC_IS_CONFIDENTIAL));

                            await insertCommand.ExecuteNonQueryAsync();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        // Log the exception
                        throw;
                    }
                }
            }
        }


        //public async Task InsertCommunication_OnlyInsertAsync(CommunicationRequest request)
        //{
        //    var query = @"INSERT INTO T_SIS_SC_COMMUNICATION 
        //              (SCC_CART_NO, SCC_SEQ_NO, SCC_TYPE, SCC_TEXT, SCC_FROM_ID, SCC_TO_ID, SCC_ACTIVE_FLAG, SCC_STATUS, SCC_CRT_DT, SCC_CRT_BY, SCC_IS_CONFIDENTIAL) 
        //              VALUES 
        //              (:SCC_CART_NO, :SCC_SEQ_NO, :SCC_TYPE, :SCC_TEXT, :SCC_FROM_ID, :SCC_TO_ID, :SCC_ACTIVE_FLAG, :SCC_STATUS, SYSDATE, :SCC_CRT_BY, :SCC_IS_CONFIDENTIAL)";

        //    using (var connection = new OracleConnection(strConnSISDB))
        //    {
        //        await connection.OpenAsync();
        //        using (var transaction = connection.BeginTransaction())
        //        {
        //            try
        //            {
        //                var seqNo = 1;
        //                var replyTo = string.Empty;
        //                var isConfidential = string.Empty;

        //                // Get the current record
        //                var selectQuery = @"SELECT SCC_SEQ_NO, SCC_FROM_ID, SCC_TO_ID, SCC_IS_CONFIDENTIAL 
        //                                FROM T_SIS_SC_COMMUNICATION 
        //                                WHERE SCC_CART_NO = :SCC_CART_NO 
        //                                AND SCC_SEQ_NO = (SELECT MAX(SCC_SEQ_NO) 
        //                                                  FROM T_SIS_SC_COMMUNICATION 
        //                                                  WHERE SCC_CART_NO = :SCC_CART_NO)";
        //                using (var selectCommand = new OracleCommand(selectQuery, connection))
        //                {
        //                    selectCommand.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));

        //                    using (var reader = await selectCommand.ExecuteReaderAsync())
        //                    {
        //                        if (await reader.ReadAsync())
        //                        {
        //                            seqNo = reader.GetInt32(0) + 1;
        //                            //  replyTo = reader.GetString(1);
        //                            //  isConfidential = reader.GetString(3);
        //                        }
        //                    }
        //                }

        //                // Insert new communication
        //                using (var insertCommand = new OracleCommand(query, connection))
        //                {
        //                    insertCommand.Transaction = transaction;
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_SEQ_NO", seqNo));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_TYPE", request.SCC_TYPE));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_TEXT", request.SCC_TEXT));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_FROM_ID", request.SCC_FROM_ID));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_TO_ID", request.SCC_TO_ID));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_ACTIVE_FLAG", request.SCC_ACTIVE_FLAG));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_STATUS", request.SCC_STATUS));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_CRT_BY", request.SCC_CRT_BY));
        //                    insertCommand.Parameters.Add(new OracleParameter("SCC_IS_CONFIDENTIAL", request.SCC_IS_CONFIDENTIAL));

        //                    await insertCommand.ExecuteNonQueryAsync();
        //                }

        //                transaction.Commit();
        //            }
        //            catch (Exception ex)
        //            {
        //                transaction.Rollback();
        //                // Log the exception
        //                throw;
        //            }
        //        }
        //    }
        //}


        // This Method used for upadte the answare in communication table
        public async Task InsertCommunicationAsync(CommunicationRequest request)
        {
            //var query = @"INSERT INTO T_SIS_SC_COMMUNICATION 
            //          (SCC_CART_NO, SCC_SEQ_NO, SCC_TYPE, SCC_TEXT, SCC_FROM_ID, SCC_TO_ID, SCC_ACTIVE_FLAG, SCC_STATUS, SCC_CRT_DT, SCC_CRT_BY, SCC_IS_CONFIDENTIAL) 
            //          VALUES 
            //          (:SCC_CART_NO, :SCC_SEQ_NO, :SCC_TYPE, :SCC_TEXT, :SCC_FROM_ID, :SCC_TO_ID, :SCC_ACTIVE_FLAG, :SCC_STATUS, SYSDATE, :SCC_CRT_BY, :SCC_IS_CONFIDENTIAL)";


         

            using (var connection = new OracleConnection(strConnSISDB))
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var seqNo = 0;
                        var replyTo = string.Empty;
                        var isConfidential = string.Empty;

                        // Get the current record
                        var selectQuery = @"SELECT SCC_SEQ_NO, SCC_FROM_ID, SCC_TO_ID, SCC_IS_CONFIDENTIAL 
                                        FROM T_SIS_SC_COMMUNICATION 
                                        WHERE SCC_CART_NO = :SCC_CART_NO 
                                        AND SCC_SEQ_NO = (SELECT MAX(SCC_SEQ_NO) 
                                                          FROM T_SIS_SC_COMMUNICATION 
                                                          WHERE SCC_CART_NO = :SCC_CART_NO)";



                        using (var selectCommand = new OracleCommand(selectQuery, connection))
                        {
                            selectCommand.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));

                            using (var reader = await selectCommand.ExecuteReaderAsync())
                            {
                                if (await reader.ReadAsync())
                                {
                                    seqNo = reader.GetInt32(0);                                    
                                }
                            }
                        }

                           var QryUpdateAnswer = @"UPDATE T_SIS_SC_COMMUNICATION  SET SCC_IS_ANSWER='Y',SCC_ANSWER=:SCC_ANSWER, SCC_UPD_DT=SYSDATE   WHERE SCC_CART_NO=:SCC_CART_NO AND SCC_SEQ_NO=:SCC_SEQ_NO AND SCC_IS_ANSWER='N'  ";
                        // update Answer new communication
                        using (var command = new OracleCommand(QryUpdateAnswer, connection))
                        {
                            
                            command.Parameters.Add(new OracleParameter("SCC_ANSWER", request.SCC_TEXT));
                            command.Parameters.Add(new OracleParameter("SCC_CART_NO", request.SCC_CART_NO));
                            command.Parameters.Add(new OracleParameter("SCC_SEQ_NO", seqNo));
                           // command.Parameters.Add(new OracleParameter("SCC_UPD_BY", request.SCC_FROM_ID));
                            
                            await command.ExecuteNonQueryAsync();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        // Log the exception
                        throw;
                    }
                }
            }
        }



        // This Method used for update the status in Shopping card header table 
        public async Task UpdateShoppingCartAsync(ShoppingCartUpdateRequest request)
        {

            if (request.RETRUN_LVL == "99")   //  --------Level-99 is Indenter-----
            {
                var query = @"UPDATE T_SIS_SHOPPING_CART_HDR SET SCH_STATUS = :SCH_STATUS, SCH_UPD_DT = SYSDATE, SCH_UPD_ID = :SCH_UPD_ID , SCH_CURR_APPR_LVL='1' WHERE SCH_CART_NO = :SCH_CART_NO";

                var UpdateIndentStatus = @"  UPDATE T_SIS_INDENT_DETAILS SET INDENT_CURRENT_STATUS = '52'  WHERE INDENT_ID = :INDENT_ID ";

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    await connection.OpenAsync();
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("SCH_STATUS", request.RETRUN_LVL));
                        command.Parameters.Add(new OracleParameter("SCH_UPD_ID", request.SCH_UPD_ID));
                        command.Parameters.Add(new OracleParameter("SCH_CART_NO", request.SCH_CART_NO));

                        await command.ExecuteNonQueryAsync();
                    }

                    using (var command = new OracleCommand(UpdateIndentStatus, connection))
                    {
                        command.Parameters.Add(new OracleParameter("INDENT_ID", request.INDENT_NO));
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            else if (request.RETRUN_LVL == "1" || request.RETRUN_LVL == "2" || request.RETRUN_LVL == "3" || request.RETRUN_LVL == "4" || request.RETRUN_LVL == "5")
            {
                var query = @"UPDATE T_SIS_SHOPPING_CART_HDR 
                      SET SCH_STATUS = :SCH_STATUS, SCH_UPD_DT = SYSDATE, SCH_UPD_ID = :SCH_UPD_ID 
                      WHERE SCH_CART_NO = :SCH_CART_NO";

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    await connection.OpenAsync();
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("SCH_STATUS", request.SCH_STATUS));
                        command.Parameters.Add(new OracleParameter("SCH_UPD_ID", request.SCH_UPD_ID));
                        command.Parameters.Add(new OracleParameter("SCH_CART_NO", request.SCH_CART_NO));

                        await command.ExecuteNonQueryAsync();
                    }
                }




                // Step 1: Query to get the maximum approval level for the given cart number
                var MaxLevelQuery = @"SELECT MAX(scp_app_lvl) FROM t_sis_sc_approval WHERE scp_cart_no = :SCH_CART_NO";

                // Step 2: Query to update the approval levels (level-2 and level-3 in this case)

                var ReturnUpdateQry = @"
             UPDATE t_sis_sc_approval 
             SET scp_app_status = '00', 
             scp_remarks = '', 
             scp_app_dt = '',
             scp_mailsend_status = '00'
             WHERE scp_cart_no = :SCH_CART_NO
             AND scp_app_lvl BETWEEN :START_LVL AND :END_LVL
              AND scp_ver_no = (
                            SELECT MAX(scp_ver_no) 
                            FROM t_sis_sc_approval 
                            WHERE scp_cart_no = :SCH_CART_NO
                        )";

             


                var LevelUpdateQuery = @"UPDATE T_SIS_SHOPPING_CART_HDR   SET SCH_CURR_APPR_LVL = " + request.RETRUN_LVL + "  WHERE SCH_CART_NO = '" + request.SCH_CART_NO + "'";

                //   var LevelUpdateQuery = "update T_SIS_SHOPPING_CART_HDR set sch_curr_appr_lvl = 1 where sch_cart_no = '4100000160'";

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    await connection.OpenAsync();


                    using (var command = new OracleCommand(LevelUpdateQuery, connection))
                    {
                        // Add parameters for the query
                        // command.Parameters.Add(new OracleParameter("SCH_CART_NO", request.SCH_CART_NO));


                        //command.Parameters.Add(new OracleParameter("RETRUN_LVL",  Convert.ToInt32(request.RETRUN_LVL)));  // Level-2


                        // Execute the update query

                        await command.ExecuteNonQueryAsync();

                    }



                    // Step 1: Retrieve the maximum approval level
                    int maxLevel;
                    using (var command = new OracleCommand(MaxLevelQuery, connection))
                    {
                        command.Parameters.Add(new OracleParameter("SCH_CART_NO", request.SCH_CART_NO));
                        var result = await command.ExecuteScalarAsync();
                        maxLevel = result != null ? Convert.ToInt32(result) : 0;
                    }

                    // Ensure max level was retrieved correctly
                    if (maxLevel == 0)
                    {
                        throw new InvalidOperationException("No approval levels found for the given cart number.");
                    }

                    // Step 2: Update the approval levels
                    using (var command = new OracleCommand(ReturnUpdateQry, connection))
                    {
                        // Add parameters for the query
                        command.Parameters.Add(new OracleParameter("SCH_CART_NO", request.SCH_CART_NO));

                        // Calculate the range of levels to update, assuming you want to update levels between 2 and the max level
                        command.Parameters.Add(new OracleParameter("START_LVL", request.RETRUN_LVL));  // Level-2
                        command.Parameters.Add(new OracleParameter("END_LVL", maxLevel));  // Max level minus 1 (update up to level-3)

                        // Execute the update query
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }//-------end if
        }


        // This Method used for fetching SCH_STATUS of  Shopping card header table 
        public async Task<string> GetStatusAsync(string cartNo)
        {
            var query = "SELECT SCH_STATUS FROM T_SIS_SHOPPING_CART_HDR WHERE SCH_CART_NO = :SCH_CART_NO";

            using (var connection = new OracleConnection(strConnSISDB))
            {
                await connection.OpenAsync();
                using (var command = new OracleCommand(query, connection))
                {
                    command.Parameters.Add(new OracleParameter("SCH_CART_NO", cartNo));

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return reader.GetString(0);
                        }
                        else
                        {
                            return null;
                        }
                    }
                }
            }
        }

        // This Method used for fetching the Assign level 
        public DataTable SC_Recipient_Dal(string SC_No, string DeptId, string UserId)
        {
            DataTable dataTable = new DataTable();

            using (var connection = new OracleConnection(strConnSISDB))
            {

                string query = @" 
                    SELECT
                    h.sch_crt_id AS scp_apprvr,
                    h.sch_crt_id || '--' || tum.um_usr_name  || '(Indenter)' AS um_usr_name,
                    99 as scp_app_lvl
                    FROM
                   t_sis_shopping_cart_hdr h
                    JOIN sapsur.t_user_master tum ON h.sch_crt_id = tum.um_usr_id
                    WHERE  sch_crt_id =tum.um_usr_id  and SCH_STATUS !='99'
                    AND sch_cart_no = '" + SC_No + @"'                 
                    UNION
                    SELECT DISTINCT
                    ap.scp_apprvr AS scp_apprvr,
                    ap.scp_apprvr || '--' || usr.um_usr_name || '(Lvl-' ||  ap.scp_app_lvl || ')' AS um_usr_name,
                    ap.scp_app_lvl
                    FROM
                    t_sis_sc_approval ap
                    JOIN sapsur.t_user_master usr ON ap.scp_apprvr = usr.um_usr_id
                    WHERE               
                    ap.scp_app_status !='00'
                    AND ap.scp_remarks IS NOT NULL
                    and ap.scp_cart_no= '" + SC_No + "' ";

                //string query = @"SELECT h.sch_crt_id AS scp_apprvr, h.sch_crt_id || '--' || tum.um_usr_name AS um_usr_name FROM
                //t_sis_shopping_cart_hdr h JOIN sapsur.t_user_master tum ON h.sch_crt_id = tum.um_usr_id  WHERE
                //    sch_crt_id <>  '" + UserId + "'     AND  sch_crt_id =tum.um_usr_id AND sch_cart_no = '" + SC_No + @"'    
                //    UNION    SELECT DISTINCT  ap.apr_id AS scp_apprvr,  ap.apr_id || '--' || usr.um_usr_name AS um_usr_name FROM    sapsur.t_approver ap  JOIN sapsur.t_user_master usr ON ap.apr_id = usr.um_usr_id  WHERE apr_dept ='" + DeptId + "'  AND ap.apr_id <> '" + UserId + "'";




                //     string query = @"
                // SELECT
                //     h.sch_crt_id AS scp_apprvr,
                //     h.sch_crt_id || '--' || tum.um_usr_name AS um_usr_name
                // FROM
                //     t_sis_shopping_cart_hdr h
                //     JOIN sapsur.t_user_master tum ON h.sch_crt_id = tum.um_usr_id
                //     WHERE
                //         sch_crt_id <>  :UserId
                //         AND
                //        sch_crt_id =tum.um_usr_id
                //        AND sch_cart_no = :SC_No

                //UNION
                // SELECT DISTINCT
                //     ap.apr_id AS scp_apprvr,
                //     ap.apr_id || '--' || usr.um_usr_name AS um_usr_name
                // FROM
                //     sapsur.t_approver ap
                //     JOIN sapsur.t_user_master usr ON ap.apr_id = usr.um_usr_id
                // WHERE
                //     ap.apr_dept = :DeptId
                //     AND ap.apr_id <> :UserId";

                using (OracleCommand cmd = new OracleCommand(query, connection))
                {
                    // Log DeptId to ensure it is correct                
                 
                    // Trim and convert DeptId to uppercase
                   // cmd.Parameters.Add(new OracleParameter("DeptId", DeptId.Trim().ToUpper()));
                   // cmd.Parameters.Add(new OracleParameter("UserId", UserId));
                   //  cmd.Parameters.Add(new OracleParameter("SC_No", SC_No));

                    using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                    {
                        connection.Open();
                        adapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }



        // This Method used for fetching the Communication details only display purpus
        public DataTable SC_GetReplayCommunications_DAL(string sno, string userId)
        {
            DataTable dataTable = new DataTable();

            using (var connection = new OracleConnection(strConnSISDB))
            {
                string query = @"SELECT 
SCC_FROM_ID || '--' || u.um_usr_name SCC_FROM_ID, 
SCC_TO_ID || '--' || u1.um_usr_name SCC_TO_ID,
SCC_TEXT,
SCC_CRT_DT, 
SCC_IS_CONFIDENTIAL,
SCC_TYPE,
SCC_IS_ANSWER,
SCC_ANSWER,
SCC_UPD_DT

FROM T_SIS_SC_COMMUNICATION 
INNER JOIN sapsur.t_user_master u ON SCC_FROM_ID = u.um_usr_id 
INNER JOIN sapsur.t_user_master u1 ON SCC_TO_ID = u1.um_usr_id 
WHERE SCC_CART_NO = :sno AND 
(SCC_FROM_ID = :userId OR SCC_TO_ID = :userId)
ORDER BY SCC_SEQ_NO";

                using (OracleCommand cmd = new OracleCommand(query, connection))
                {
                    cmd.Parameters.Add(new OracleParameter("sno", sno));
                    cmd.Parameters.Add(new OracleParameter("userId", userId));

                    //cmd.Parameters.Add(":userId", OracleType.VarChar).Value = userId;

                    using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                    {
                        connection.Open();
                        adapter.Fill(dataTable);
                    }
                }
            }

            return (dataTable);
        }


        // This Method used for fetching the MaxQty Data
        public DataTable GetMaxQtyData_SC_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetMaxQtyData_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching the Requirement Consumption Data
        public DataTable GetRequiConsumData_SC_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetRequiConsumData_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching VMI_ARC Data
        public DataTable GetVMI_ARCData_SC_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetVMI_ARCData_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for fetching Refurshibility Data
        public DataTable GetRefurshibilityData_SC_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetRefurshibilityData_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        // This Method used for fetching Deprop Data
        public DataTable GetDepropmData_SC_DAL(string IndentId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetDepropmData_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":INDENT_ID", IndentId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        // This Method used for fetching Email id of Approver
        public DataTable GetUserEmailId_SC_DAL(string UserId)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetUserEmailId_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":UserId", UserId);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }



        // This Method used for related to ODATA 
        public async Task<List<IntelliBuyIndentDetails_ODA_SC>> GetIntelliBuyChecksDetails_ODA_SC_DAL(string IndentId ,string INDENTOR_DEPT)
        {
            int flag = 0;
            var ObjIndentDetails = new List<IntelliBuyIndentDetails_ODA_SC>();
            double SpareBudget = 0;
            double CommittedExpenditure = 0;
            string percentBudgetConsumption = "0";
            double percent = 0;
            string FY = "";
            try
            {
               
                double Budget_EBUY = Get_budgetConsumptionFormDept_EBuy(INDENTOR_DEPT);
                double Budget_SIS = Get_budgetConsumptionFormDept_SIS(INDENTOR_DEPT);

                string responseData = await Get_budgetConsumptionFormDept_ODATA(INDENTOR_DEPT, Budget_EBUY, 0);
                if (!String.IsNullOrEmpty(responseData))
                {
                    dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                    if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                    {
                        string StrPOValue = "0";
                        string StrPRValue = "0";
                        string StrSpareValue = "0";
                        string StrTotBudget = "0";

                        foreach (var result in responseObject.d.results)
                        {
                            // Check the DocType and assign the values accordingly
                            if (result.DocType == "PO")
                            {
                                StrPOValue = result.Value;
                            }
                            else if (result.DocType == "PR")
                            {
                                StrPRValue = result.Value;
                            }
                            else if (result.DocType == "TOTAL")
                            {
                                StrSpareValue = result.Value;
                                StrTotBudget = result.TotBudget;
                            }
                            FY = result.FisYr;
                        }

                        double poValue = double.Parse(StrPOValue);
                        double totalValue = double.Parse(StrSpareValue);
                        double spareValue = Math.Round(double.Parse(StrTotBudget)*105/100);
                        double oraTotalComp = Budget_EBUY;
                        //double percent = (totalValue * 100) / spareValue;
                        CommittedExpenditure = Budget_EBUY + totalValue + Budget_SIS;
                        if (spareValue != 0)
                        {
                            percent = (100 * CommittedExpenditure) / spareValue;
                        }
                        else { percent = 0; }
                        percentBudgetConsumption = percent.ToString("0.000");
                        SpareBudget = Math.Round(spareValue);

                        if (spareValue != 0)
                        {
                            percent = (100 * CommittedExpenditure) / spareValue;
                        }
                        else
                        {
                            percent = 0;
                        }

                        percentBudgetConsumption = percent.ToString("0.000");
                        CommittedExpenditure = Convert.ToDouble(percent.ToString("0"));
                        


                    }
                }


                //ODATA CALLING

               
             //   foreach (DataRow item in IntelliBuyIndentDetails_ODA_SC)
             //   {
                   
                   
                    var newItem = new IntelliBuyIndentDetails_ODA_SC
                    {                     
                        DeptBudgetConsumption = percentBudgetConsumption,                      
                        COMMITTEDEXPENDITURE = CommittedExpenditure,
                       
                        SPAREBUDGET = SpareBudget,
                        FY_YEAR = FY
                        
                    };



                    ObjIndentDetails.Add(newItem);

               // }
            }
            catch (Exception ex)
            {


            }

            return ObjIndentDetails;

        }

        // This Method used for related to ODATA 
        public async Task<string> Get_budgetConsumptionFormDept_ODATA(string Dept, double Budget_SIS, double Budget_Ebuy)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            string apiUrl = BaseURL + "opu/odata/sap/YMPI_BUDGET_DETAILS_SRV/BUDGET_detailSet?$filter=( Department eq '" + Dept + "' )&$format=json";
            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();

                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }

        // This Method used for related to ODATA 
        private double Get_budgetConsumptionFormDept_SIS(string dept)
        {
            double str = 0;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.oraGet_budgetConsumptionFormDept_SIS, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            

                objConn.AddParameters(":sch_dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
                if (dtResult != null)
                {
                    str = Convert.ToDouble(dtResult.Rows[0]["TOTVAL"].ToString());
                }
            }
            catch { }

            return str;
        }

        // This Method used for related to ODATA 
        private double Get_budgetConsumptionFormDept_EBuy(string dept)
        {
            double str = 0;
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.oraGet_budgetConsumptionFormDept_EBuy, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                //objConn.AddParameters(":sch_cart_no", sCNo);
                objConn.AddParameters(":sch_dept", dept);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();

                if (dtResult != null)
                {
                    str = Convert.ToDouble(dtResult.Rows[0]["TOTVAL"].ToString());
                }

            }
            catch (Exception) { }

            return str;
        }

        // This Method used for Fetching the Creater id 
        public DataTable GetCreaterAndFinalApproverID_SC_DAL(string SCNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetCreaterAndFinalApproverID_SC, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":scno", SCNo);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }


        //==================================Regenerate Approval======================
        // This Method used for Reset the Approver 
        public DataTable GetShoppingCart_ForRegenApprover_DAL(string cartNo, string creatorName, string fromDate, string toDate, string department )
        {

            string lstrMain = string.Empty;
            if (!string.IsNullOrEmpty(fromDate) && !string.IsNullOrEmpty(toDate))
            {
             lstrMain = "AND trim(a.sch_crt_dt)BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND  TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
            }

            string lstrSCNo = string.IsNullOrEmpty(cartNo) ? "%" : "%" + cartNo + "%";
            string lstrDept = string.IsNullOrEmpty(department) ? "%" : "%" + department + "%";
            string lstrCrtDt = string.IsNullOrEmpty(creatorName) ? "%" : "%" + creatorName + "%";

            string query;
           
                query = "SELECT a.sch_cart_no, b.sch_cart_name,  d.deptdesc ||'('|| d.deptno || ')' DeptDesc , a.sch_crt_id, a.sch_crt_dt, a.sch_tot_val FROM t_sis_shopping_cart_hdr a  inner join T_SIS_INTELLIBUY_CHECK_HEADER b on a.sch_cart_no=b.sch_cart_no  INNER JOIN SAPSUR.t_s_dept_mst d on d.deptno= a.sch_dept WHERE " +
                        "a.sch_dept LIKE :Dept  " + lstrMain + " AND (a.SCH_STATUS = '04') " +
                        "AND (a.SCH_CART_NO LIKE :CartNo) AND (a.SCH_CRT_ID LIKE :CreatorName)";
            

            objConn = new ConnectionOracleDB(strConnSISDB, query, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":Dept", lstrDept);
                objConn.AddParameters(":CartNo", lstrSCNo);
                objConn.AddParameters(":CreatorName", lstrCrtDt);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for Fetch the Approver & Level
        public DataTable GetApprovedBySc(string cartNo)
        {
           
            using (var conn = new OracleConnection(strConnSISDB))
            {
                using (var cmd = new OracleCommand(DBConst_Approval.QryGetApprovedBySc, conn))
                {
                    cmd.Parameters.Add(new OracleParameter("cartNo", cartNo));
                    var adapter = new OracleDataAdapter(cmd);
                    var dt = new DataTable();
                    conn.Open();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        // This Method used for Fetch the Department
        public DataTable GetDeptSc(string cartNo)
        {
          
            using (var conn = new OracleConnection(strConnSISDB))
            {
                using (var cmd = new OracleCommand(DBConst_Approval.QryGetDeptSc, conn))
                {
                    cmd.Parameters.Add(new OracleParameter("cartNo", cartNo));
                    var adapter = new OracleDataAdapter(cmd);
                    var dt = new DataTable();
                    conn.Open();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        // This Method used for Fetch the DeptType
        public DataTable GetDeptType(string deptNo)
        {
           
            using (var conn = new OracleConnection(strConnSISDB))
            {
                using (var cmd = new OracleCommand(DBConst_Approval.QryGetDeptType, conn))
                {
                    cmd.Parameters.Add(new OracleParameter("DeptNo", deptNo));
                    var adapter = new OracleDataAdapter(cmd);
                    var dt = new DataTable();
                    conn.Open();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        // This Method used for Insert the Approver as a new version 
        public void InsertApprovalRecord(string cartNo, string totVal, string indntType, string deptNo)
        {
            using (var conn = new OracleConnection(strConnSISDB))
            {
                using (var cmd = new OracleCommand("P_INS_SIS_SC_APPROVAL_RESET", conn))
                {
                   

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("tot_amnt", OracleDbType.Varchar2).Value = totVal;
                    cmd.Parameters.Add("indnt_type", OracleDbType.Varchar2).Value = indntType;
                    cmd.Parameters.Add("scartno", OracleDbType.Varchar2).Value = cartNo;                 
                    cmd.Parameters.Add("dept_no", OracleDbType.Varchar2).Value = deptNo;
                    cmd.Parameters.Add("Committed_Expenditure_Val", OracleDbType.Int32).Value =0;
                    cmd.Parameters.Add("Spare_Budget_Val", OracleDbType.Int32).Value = 0;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    
                }
            }
        }

        // This Method used for Update the Approver status
        public void UpdateApprovalStatus(string cartNo, string apprvr, string appLvl)
        {           
            try
            {
                using (var conn = new OracleConnection(strConnSISDB))
                {
                    conn.Open();
                    using (var transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // Check approval query
                            string checkApprvrQuery = "select count(scp_apprvr) from t_sis_sc_approval where scp_cart_no='" + cartNo + "' and (scp_mailsend_status='00' or scp_mailsend_status='01') and scp_app_status='00' and scp_ver_no=(select max(scp_ver_no) from t_sis_sc_approval where scp_cart_no='" + cartNo + "') and scp_apprvr='" + apprvr + "' and scp_app_lvl='" + appLvl + "'";

                            DataTable checkApprvrDt = new DataTable();
                            using (var cmd = new OracleCommand(checkApprvrQuery, conn))
                            {
                                cmd.Transaction = transaction; // Assign the transaction
                                var adapter = new OracleDataAdapter(cmd);
                                adapter.Fill(checkApprvrDt);
                            }

                            if (Convert.ToInt32(checkApprvrDt.Rows[0][0]) > 0)
                            {
                                // Update approval query
                                string updateApprovalQuery = "update t_sis_sc_approval set scp_app_status='01', scp_app_dt=sysdate where scp_cart_no='" + cartNo + "' and (scp_mailsend_status='00' or scp_mailsend_status='01') and  scp_ver_no=(select max(scp_ver_no) from t_sis_sc_approval where scp_cart_no='" + cartNo + "') and scp_apprvr='" + apprvr + "' and scp_app_lvl='" + appLvl + "'";

                                using (var cmd = new OracleCommand(updateApprovalQuery, conn))
                                {
                                    cmd.Transaction = transaction; // Assign the transaction
                                    cmd.ExecuteNonQuery();
                                }

                                // Update action taken query
                                string updateActionTakenQuery = "update t_sis_sc_approval set scp_app_status='05' where scp_cart_no='" + cartNo + "' and scp_ver_no=(select max(scp_ver_no) from t_sis_sc_approval where scp_cart_no='" + cartNo + "') and scp_app_lvl='" + appLvl + "' and scp_app_dt is null";

                                using (var cmd = new OracleCommand(updateActionTakenQuery, conn))
                                {
                                    cmd.Transaction = transaction; // Assign the transaction
                                    cmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                // If no approval record, rollback transaction
                                transaction.Rollback();
                                return;
                            }

                            // Get next level approver query
                            string nextLvlApprvrQuery = "select min(scp_app_lvl) from t_sis_sc_approval where scp_cart_no='" + cartNo + "' and scp_app_status='00' and scp_ver_no=(select max(scp_ver_no) from t_sis_sc_approval where scp_cart_no='" + cartNo + "')";

                            DataTable nextLvlApprvrDt = new DataTable();
                            using (var cmd = new OracleCommand(nextLvlApprvrQuery, conn))
                            {
                                cmd.Transaction = transaction; // Assign the transaction
                                var adapter = new OracleDataAdapter(cmd);
                                adapter.Fill(nextLvlApprvrDt);
                            }

                            if (nextLvlApprvrDt.Rows.Count > 0)
                            {
                                // Update header approval status query
                                string updateHdrAppStatusQuery = "update t_sis_shopping_cart_hdr set sch_curr_appr_lvl='" + nextLvlApprvrDt.Rows[0][0].ToString() + "' where sch_cart_no='" + cartNo + "'";

                                using (var cmd = new OracleCommand(updateHdrAppStatusQuery, conn))
                                {
                                    cmd.Transaction = transaction; // Assign the transaction
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            // Commit transaction if all operations succeed
                            transaction.Commit();
                        }
                        catch (Exception)
                        {
                            // Rollback transaction in case of any exception
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                // return BadRequest($"Error occurred: {ex.Message}");
            }




        }


        // This Method used for send the Email
        public void SendApprovalEmail(string cartNo, string stage, string mailTo)
        {
            using (var conn = new OracleConnection(strConnSISDB))
            {
                using (var cmd = new OracleCommand("p_sis_send_mail", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("vscnum", OracleDbType.Int32).Value = cartNo;
                    cmd.Parameters.Add("stage", OracleDbType.Int32).Value = stage;
                    cmd.Parameters.Add("cstatus", OracleDbType.Varchar2).Value = "1";
                    cmd.Parameters.Add("mail_to", OracleDbType.Varchar2).Value = mailTo;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }


        // This Method used for Fetch the PGList
        public DataTable GetPGList_SC_DAL()
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetPGList_SC, CommandType.Text, true);
            try
            {
                objConn.OpenConnection();
                //objConn.AddParameters(":UserId", UserId);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }
            return dtResult;
        }

        // This Method used for Fetch the BGGList
        public DataTable GetBGGList_SC_DAL()
        {
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetBGGList_SC, CommandType.Text, true);
            try
            {
                objConn.OpenConnection();
                //objConn.AddParameters(":UserId", UserId);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }
            return dtResult;
        }

        // This Method used for Fetch CMBGGMapping Data for Reports purpus
        public DataTable GetCMBGGMapping_SC_DAL(string pg, string bgg)
        {
            string[] pgArray = pg.Split(',');
            string formattedPG = string.Join(",", pgArray.Select(_pg => "'" + _pg + "'"));

            string strwhere = string.Empty;
            if (!string.IsNullOrEmpty(bgg))
            {
                strwhere = " AND MATKL ='"+ bgg + "' ";
            }
            string QryGetCMBGGMapping = "select ROW_NUMBER() OVER (ORDER BY EKGRP) AS srno, MANDT, APPTYP, MATKL,EKGRP,CMGRCD,CMGRNM,CMGRPN,CASOCD,CASONM,CASOPN,DELMN,DMMAP,DEMPN,GRPCD,HEADPN,CHFPN,CRDAT,CRNAM,CHDAT,CHNAM,CMAMOB,DMMOB,CMMOB from CMDRDB.T_YMPIT_MRO_CMBGG@CTDR_EPROC_DBL WHERE EKGRP IN (" + formattedPG + ") " + strwhere + " order by EKGRP ";

        objConn = new ConnectionOracleDB(strConnSISDB, QryGetCMBGGMapping, CommandType.Text, true);

         
            try
            {
                objConn.OpenConnection();
               // objConn.AddParameters(":PG", formattedPG);
                //objConn.AddParameters(":BGG", bgg);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }
            return dtResult;
        }

        //==================================Add Approval======================
        // This Method used for Fetch SC Details
        public DataTable GetShoppingCart_ForAddApprover_DAL(string cartNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.GetSCDetailsForAddApprover, CommandType.Text, true);

            try
            {                
                objConn.OpenConnection();
                objConn.AddParameters(":CartNo", cartNo);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for Fetch the Approver level of particular sc
        public DataTable GetApproverLevel_DAL(string cartNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryGetApproverLevel, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.AddParameters(":CartNo", cartNo);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        // This Method used for Add  the New Approver in Approver Table
        public async Task SC_AddApprover_DAL(AddApprover_SC request, FileUploadModel fileUploadModel)
        {
           

            using (var connection = new OracleConnection(strConnSISDB))
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {


                        string Ver = string.Empty;
                        using (var cmd = new OracleCommand(DBConst_Approval.QryGetMAxVerOfApproval, connection))
                        {
                            cmd.Parameters.Add(new OracleParameter("SCP_CART_NO", request.scp_cart_no));
                            var adapter = new OracleDataAdapter(cmd);
                            var dt = new DataTable();                           
                            adapter.Fill(dt);
                            if (dt.Rows.Count>0)
                            {
                                Ver = dt.Rows[0]["SCP_VER_NO"].ToString();
                            }
                           
                        }

                        // Insert new communication if no pending communication found
                        using (var insertCommand = new OracleCommand(DBConst_Approval.QryAddApprover, connection))
                        {
                            insertCommand.Transaction = transaction;
                            insertCommand.Parameters.Add(new OracleParameter("scp_cart_no", request.scp_cart_no));
                            insertCommand.Parameters.Add(new OracleParameter("SCP_APP_LVL", request.SCP_APP_LVL));
                            insertCommand.Parameters.Add(new OracleParameter("SCP_APPRVR", request.SCP_APPRVR));
                            insertCommand.Parameters.Add(new OracleParameter("SCP_APP_STATUS", "00"));
                            insertCommand.Parameters.Add(new OracleParameter("SCP_MAILSEND_STATUS", "01"));
                            insertCommand.Parameters.Add(new OracleParameter("SCP_VER_NO", Ver));
                            insertCommand.Parameters.Add(new OracleParameter("SCP_SELECTED", 'Y'));
                           

                            await insertCommand.ExecuteNonQueryAsync();
                        }

                        using (var insertCommand = new OracleCommand(DBConst_Approval.QryInsertAddApprovalDelegate, connection))
                        {
                            insertCommand.Transaction = transaction;                          
                            insertCommand.Parameters.Add(new OracleParameter("SCD_CART_NO", request.scp_cart_no));
                            insertCommand.Parameters.Add(new OracleParameter("SCD_LVL", request.SCP_APP_LVL));
                            insertCommand.Parameters.Add(new OracleParameter("SCD_PIN_NO", request.SCP_APPRVR));
                            insertCommand.Parameters.Add(new OracleParameter("SCD_ATCH_FILE", fileUploadModel.FileContent));
                            insertCommand.Parameters.Add(new OracleParameter("SCD_CRT_BY", request.SCD_CRT_BY));
                            insertCommand.Parameters.Add(new OracleParameter("SCD_ATCH_FILENAME", fileUploadModel.FileName));                          
                          
                            

                            await insertCommand.ExecuteNonQueryAsync();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        // Log the exception
                        throw;
                    }
                }
            }
        }

        // This Method used for check the valid PNo.
        public DataTable GetValidatePIN_DAL(string PinNo)
        {

            objConn = new ConnectionOracleDB(strConnSISDB, DBConst_Approval.QryValidatePIN, CommandType.Text, true);

            try
            {
                objConn.OpenConnection();
                objConn.AddParameters(":APR_ID", PinNo);
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

    }

    public class DBConst_Approval
    {
        #region ApprovalShoppingCart
        //added by Niraj

        public const string QryShoppingCartDetails = @"SELECT    SCH_CART_NO, SCH_CART_NAME, SCH_TOT_VAL, sch_val_unit   FROM T_SIS_SHOPPING_CART_HDR  WHERE SCH_CART_NO = :SCH_CART_NO ORDER BY 1";

        public const string oraGetSCHeaderAndMaterialDetails = @"SELECT
    ROW_NUMBER() OVER (ORDER BY sc_i.sci_matl_no) AS srno, UMC.UMC_INDENT_ID,
    ind.indent_id,
    ic_h.sch_cart_no,
    sc_h.sch_crt_id,
    ur_m.um_usr_name,
    sc_i.sci_fod_type ||'-'||cd.code_val_desc   as sci_fod_type ,
    ind.indent_desc,
    --sc_h.sch_note_app,
    ic_h.SCH_CART_NAME as sch_note_app,
    sc_h.sch_dept  DeptId ,
    deptdesc
    || '('
    || ind.indentor_dept
    || ')' sch_dept,
    sc_h.sch_tot_val,
    sc_atch.sca_file,
    sc_atch.sca_file_name,
----MATERIAL COLOUMN-----
    sc_i.sci_matl_no,
--SC_I.SCI_ITEM_DESC,
    umc.req_umc_desc,
    --sc_i.sci_matl_grp,
   -- (select MATLGRP,DESCRIPTION, MATLGRP||'-'||DESCRIPTION matkl_wgbez  from sapsur.T_S_MATL_GRP where MATLGRP= ) as sci_matl_grp,
    bgg.MATLGRP||'-'|| bgg.DESCRIPTION as sci_matl_grp,
    '--' AS added,
     umc.QTY ,
    ic_i.sci_qty,
    sc_i.SCI_PRICE,
    (UMC.QTY * UMC.MAP_VALUE) AS INITIAL_INDENT_VALUE,
    -- SC_H.SCH_TOT_VAL AS FINAL_INDENT_VALUE,
    (ic_i.sci_qty * sc_i.SCI_PRICE) as  FINAL_INDENT_VALUE,
    to_char( ic_i.consump_dt, 'DD-MON-YYYY') as consump_dt,
    to_char(ic_i.sci_reqd_on_dt, 'DD-MON-YYYY') as sci_reqd_on_dt
FROM
    t_sis_indent_details ind
    INNER JOIN t_sis_umc_indent_details umc ON umc.indent_id = ind.indent_id
    INNER JOIN SAPSUR.t_umc_prod umcp ON umcp.umc_cd = umc.req_umc_no
                                  AND umcp.plant_cd = ind.indentor_plant
    INNER JOIN t_sis_intellibuy_check_header ic_h ON ic_h.indent_id = ind.indent_id
      INNER JOIN sapsur.t_s_dept_mst ON deptno = ind.indentor_dept
    INNER JOIN t_sis_shopping_cart_hdr sc_h ON sc_h.sch_cart_no = ic_h.sch_cart_no
    INNER JOIN SAPSUR.t_user_master ur_m ON ur_m.um_usr_id = sc_h.sch_crt_id
    INNER JOIN t_sis_shopping_cart_item sc_i ON sc_i.sci_cart_no = ic_h.sch_cart_no
                                                AND sc_i.sci_matl_no = umc.req_umc_no
    LEFT JOIN t_sis_intellibuy_check_item ic_i ON ic_i.indent_id = ind.indent_id
                                                  AND ic_i.existing_umc = umc.req_umc_no
    LEFT JOIN t_sis_sc_attachment SC_ATCH ON sc_atch.sca_cart_no=sc_h.sch_cart_no   
    left join  sapsur.T_S_MATL_GRP bgg on bgg.MATLGRP =sc_i.sci_matl_grp
    left join t_sis_code_value cd on cd.code_value= sc_i.sci_fod_type  AND cd.codetype_id = 6
WHERE
    ind.indent_id = :INDENT_ID
    --AND ind.indent_current_status = '37'
    AND ic_i.isactive = 'Y'
ORDER BY 
    ind.indent_id ASC";


        public const string QryGetSCApprovalHierarchy = @"SELECT x.scp_ver_no version,
x.scp_app_lvl lvl, 
u.um_usr_name||'('||x.scp_apprvr||')' approver, 
 v.status_desc status,
 to_char(x.scp_app_dt, 'MM/DD/YYYY hh:mi:ss AM') action_dt,
x.scp_app_status app_state,
  x.scp_remarks remarks,
                    x.scp_mailsend_status mailsend,  x.scp_atchmnt,x.scp_filename
                    FROM t_sis_sc_approval x ,sapsur.t_user_master u ,sapsur.t_status_master v
                    WHERE x.scp_cart_no =:scp_cart_no
                    AND u.um_usr_id = x.scp_apprvr 
                    and x.scp_app_status=v.status_cd
                    and v.status_of='SC_APP' 
                    order by version,lvl,status";


        public const string QryGetSCAppRemarks = @"SELECT x.scp_ver_no version,
x.scp_app_lvl lvl, 
u.um_usr_name||'('||x.scp_apprvr||')' approver, 
v.status_desc status,
to_char(x.scp_app_dt, 'MM/DD/YYYY hh:mi:ss AM') action_dt,
x.scp_app_status app_state,
x.scp_remarks remarks,
x.scp_mailsend_status mailsend
FROM t_sis_sc_approval x ,sapsur.t_user_master u ,sapsur.t_status_master v
WHERE x.scp_cart_no = :scp_cart_no
AND u.um_usr_id = x.scp_apprvr 
and x.scp_app_status=v.status_cd
and v.status_of='SC_APP'     
and x.scp_app_dt is not null
order by version,lvl,status
";


        public const string QrySCApprovalPendingList = @"WITH rankeddata AS (
            SELECT
                sc_h.sch_cart_no,
                ic_h.indent_id,
                deptdesc
                || '('
                || sc_h.sch_dept
                || ')' AS dept,
                sc_h.sch_dept,
                sc_i.sci_fod_type,
                sc_h.sch_tot_val,
                CASE
                    WHEN sc_a.scp_app_status = '00' THEN 'Awaiting'
                    WHEN sc_a.scp_app_status = '01' THEN 'Approved'
                    WHEN sc_a.scp_app_status = '02' THEN 'Reject'
                    WHEN sc_a.scp_app_status = '03' THEN 'Return'
                END AS status,
                sc_a.scp_app_status,
                sc_a.scp_apprvr,
                sc_a.scp_upd_dt   AS pendingsince,
                ROW_NUMBER() OVER(
                    PARTITION BY sc_h.sch_cart_no
                    ORDER BY
                        sc_a.scp_upd_dt DESC
                ) AS rn
            FROM
                t_sis_shopping_cart_hdr sc_h
                INNER JOIN t_sis_intellibuy_check_header ic_h ON sc_h.sch_cart_no = ic_h.sch_cart_no
                INNER JOIN t_sis_shopping_cart_item sc_i ON sc_i.sci_cart_no = ic_h.sch_cart_no
                INNER JOIN sapsur.t_s_dept_mst d ON d.deptno = sc_h.sch_dept
                INNER JOIN t_sis_sc_approval sc_a ON sc_a.scp_cart_no = sc_h.sch_cart_no
            WHERE
                sc_h.sch_status != '99'
        ), nextapproval AS (
            SELECT
                t1.scp_cart_no,
                t1.scp_app_lvl,
                t1.scp_apprvr,
                t1.scp_app_status,
                t2.next_approval_level
            FROM
                t_sis_sc_approval t1
                JOIN (
                    SELECT
                        scp_cart_no,
                        MIN(scp_app_lvl) AS next_approval_level
                    FROM
                        t_sis_sc_approval
                    WHERE
                        scp_app_status = '00'

                    GROUP BY
                        scp_cart_no
                ) t2 ON t1.scp_cart_no = t2.scp_cart_no
                        AND t1.scp_app_lvl = t2.next_approval_level
            WHERE
                t1.scp_apprvr = :userid
            ORDER BY
                t1.scp_cart_no,
                t1.scp_app_lvl
        )
        SELECT DISTINCT
            rd.sch_cart_no,
            rd.indent_id,
            rd.dept,
            rd.sch_dept,
            rd.sci_fod_type,
            rd.sch_tot_val,
            rd.status,
            rd.scp_app_status,
            rd.scp_apprvr,
            rd.pendingsince,
            CASE
                WHEN EXISTS (
                    SELECT
                        1
                    FROM
                        t_sis_sc_approval sub_sc_a
                    WHERE
                        sub_sc_a.scp_cart_no = rd.sch_cart_no
                        AND sub_sc_a.scp_app_status = '02'
                ) THEN NULL
                ELSE na.scp_app_lvl
            END AS next_approval_level,
            CASE
                WHEN EXISTS (
                    SELECT
                        1
                    FROM
                        t_sis_sc_approval sub_sc_a
                    WHERE
                        sub_sc_a.scp_cart_no = rd.sch_cart_no
                        AND sub_sc_a.scp_app_status = '02'
                ) THEN NULL
                ELSE na.scp_apprvr
            END AS next_approver,
            CASE
                WHEN EXISTS (
                    SELECT
                        1
                    FROM
                        t_sis_sc_approval sub_sc_a
                    WHERE
                        sub_sc_a.scp_cart_no = rd.sch_cart_no
                        AND sub_sc_a.scp_app_status = '02'
                ) THEN NULL
                ELSE na.scp_app_status
            END AS next_scp_app_status,
            CASE
                WHEN EXISTS (
                    SELECT
                        1
                    FROM
                        t_sis_sc_approval sub_sc_a
                    WHERE
                        sub_sc_a.scp_cart_no = rd.sch_cart_no
                        AND sub_sc_a.scp_app_status = '02'
                ) THEN 'Complete'
                WHEN na.scp_app_status = '00' THEN 'Awaiting'
                WHEN na.scp_app_status = '01' THEN 'Approved'
                WHEN na.scp_app_status = '02' THEN 'Reject'
                WHEN na.scp_app_status = '03' THEN 'Return'
                WHEN na.scp_app_status IS NULL THEN 'Complete'
                ELSE na.scp_app_status
            END AS next_status

          -- na.scp_app_lvl, -- Include na.scp_app_lvl
         -- na.scp_apprvr as  scp_apprvr2  -- Include na.scp_apprvr
        FROM
            rankeddata rd
            LEFT JOIN nextapproval na ON rd.sch_cart_no = na.scp_cart_no
        WHERE
            rd.rn = 1


        ORDER BY
            rd.sch_cart_no
           -- na.scp_app_lvl,
            --na.scp_apprvr";



        public const string oraGetIntelliBuyChecksHeaderAndItem = @"SELECT
    ROW_NUMBER() OVER(
        ORDER BY
            intbuy_i.existing_umc
    ) AS srno,
    ind.indent_id,
    ind.indentor_plant,
    umc.req_umc_no,
    umc.req_umc_bgg,
    TO_CHAR(umc.requirement_date, 'DD-MON-YYYY') AS requirement_date,
    umc.price_per_item,
    umc.document_type,
    --umc.fod_type,
     sc_i.sci_fod_type ||'-'||cd.code_val_desc   as fod_type ,
    umc.req_umc_desc,
    umc.uom,
    scv.code_val_desc           indent_current_status,
    ind.indent_current_status   indent_current_status_code,
    umc.existing_umc
    || '-'
    || umc.exis_umc_desc AS taggedumc,
    umc.total_sap_doc_qty,
    ( qty - total_sap_doc_qty ) AS allowedqty,
    umc.umc_indent_id,
    ind.indentor_dept,
    ind.indent_desc,
    ind.indent_remarks,
    umc.isactive,
    umc.is_refurbishable,
    intbuy_i.item_id,
    intbuy_i.max_qty            qty,
    intbuy_i.sys_req_date,
    scvcode.code_value
    || ' - '
    || scvcode.code_val_desc document_type_desc,
    deptdesc
    || '('
    || ind.indentor_dept
    || ')' dept,
    umc.consump_dt,
    umc.dest_sloc,
    umc.currency,
    umc.pur_grp,
    umc.proc_type,
    umc.dest_sloc,
    intbuy_h.sch_cart_no,
    umc.pur_grp
    || ' - '
    || pur.description pg_desc,
    umcpcode.code_val_desc      spare,
    umc.dest_sloc
    || ' - '
    || loc.description sloc_desc,
--,umcp.ins_spare
    umc.qty,
    sc_i.sci_price,
    ( umc.qty * sc_i.sci_price ) AS total_value_of_indent,
    ( umc.qty - umc.total_sap_doc_qty ) AS differential_qty_after_sharing,
    ( ( umc.qty - umc.total_sap_doc_qty ) * sc_i.sci_price ) AS t_value_of_diff_qty,
 intbuy_i.MAXQTY_STATUS, intbuy_i.RCM_STATUS, intbuy_i.VMIARC_STATUS, intbuy_i.REFURSHIBILITY_STATUS, intbuy_i.DEPROP_STATUS
FROM
    t_sis_indent_details ind
    INNER JOIN t_sis_umc_indent_details umc ON umc.indent_id = ind.indent_id
    INNER JOIN t_sis_code_value scv ON scv.id = ind.indent_current_status
    LEFT JOIN t_sis_code_value scvcode ON scvcode.code_value = umc.document_type and SCVCode.CODETYPE_ID=5
    LEFT JOIN t_sis_intellibuy_check_item intbuy_i ON intbuy_i.indent_id = ind.indent_id
                                                      AND intbuy_i.existing_umc = umc.req_umc_no
    LEFT JOIN t_sis_intellibuy_check_header intbuy_h ON intbuy_h.indent_id = ind.indent_id
    INNER JOIN sapsur.t_s_dept_mst ON deptno = ind.indentor_dept
    INNER JOIN sapsur.t_umc_prod umcp ON umcp.umc_cd = umc.req_umc_no
                                         AND umcp.plant_cd = ind.indentor_plant
    INNER JOIN sapsur.t_s_purgrp pur ON pur.purgrp = umc.pur_grp
    LEFT JOIN t_sis_code_value umcpcode ON umcpcode.code_value = umcp.ins_spare
                                           AND umcpcode.codetype_id = 9
    LEFT JOIN sapsur.t_s_sloc loc ON loc.sloc = umc.dest_sloc
                                     AND loc.plant = ind.indentor_plant
    INNER JOIN t_sis_shopping_cart_item sc_i ON sc_i.sci_cart_no = intbuy_h.sch_cart_no
                                                AND sc_i.sci_matl_no = umc.req_umc_no
                                                 left join t_sis_code_value cd on cd.code_value= sc_i.sci_fod_type AND cd.codetype_id = 6
            where INTBUY_I.ISACTIVE= 'Y'   AND ind.indent_current_status >= '37'  AND cd.active_flg = 'Y' and IND.INDENT_ID= :INDENT_ID  order by IND.INDENT_ID ASC";

        public const string oraGetSCDetailsForApproval = @"WITH ShoppingCartDetails AS (
    SELECT 
        DISTINCT SC_H.SCH_CART_NO,
        IC_H.SCH_CART_NAME,
        SC_H.SCH_DEPT || ' - ' || DPT.DEPTDESC AS DEPT,
        SC_I.SCI_PUR_GRP || ' - ' || PUR.DESCRIPTION AS PURDESC,
        SC_I.SCI_FOD_TYPE,
        umc.document_type,
           umc.document_type ||'-'||cd.code_val_desc   as SCI_FOD_TYPE_DESC ,
        UMC.REQ_UMC_NO,
        UMC.QTY,
         UMC.MAP_VALUE AS MAP, --MAP TAKE FROM T_SIS_UMC_INDENT_DETAILS WHEN COLUMN ADDED
        (UMC.QTY * SC_I.SCI_PRICE) AS INITIAL_INDENT_VALUE,
         SC_H.SCH_TOT_VAL AS FINAL_INDENT_VALUE,
         SC_H.SCH_TOT_VAL AS SAVING_VALUE
    FROM 
        t_sis_shopping_cart_hdr SC_H
        INNER JOIN T_SIS_SHOPPING_CART_ITEM SC_I ON SC_I.SCI_CART_NO = SC_H.SCH_CART_NO
        LEFT JOIN sapsur.T_S_PURGRP PUR ON SC_I.SCI_PUR_GRP = PUR.PURGRP                                                                                
        INNER JOIN sapsur.t_s_dept_mst DPT ON DPT.DEPTNO = SC_H.SCH_DEPT
        INNER JOIN T_SIS_INTELLIBUY_CHECK_HEADER IC_H ON IC_H.SCH_CART_NO = SC_H.SCH_CART_NO
        INNER JOIN T_SIS_INTELLIBUY_CHECK_ITEM IC_I ON IC_I.INDENT_ID = IC_H.INDENT_ID
        INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC ON UMC.INDENT_ID = IC_I.INDENT_ID AND UMC.REQ_UMC_NO=SC_I.sci_matl_no
         left join t_sis_code_value cd on cd.code_value= sc_i.sci_fod_type
         WHERE IC_H.INDENT_ID= :INDENT_ID
)
SELECT 
    SCH_CART_NO,
    SCH_CART_NAME,
    DEPT,
    PURDESC,
    SCI_FOD_TYPE,
    document_type,
    SCI_FOD_TYPE_DESC,
    REQ_UMC_NO,
    QTY,
    MAP,
    INITIAL_INDENT_VALUE,  
    (SELECT SUM(INITIAL_INDENT_VALUE) FROM ShoppingCartDetails) AS TOTAL_INITIAL_INDENT_VALUE,
      FINAL_INDENT_VALUE,
     -- ((SELECT SUM(INITIAL_INDENT_VALUE) FROM ShoppingCartDetails) - FINAL_INDENT_VALUE) AS SAVING_VALUE
 CASE 
        WHEN (SELECT SUM(INITIAL_INDENT_VALUE) FROM ShoppingCartDetails) - FINAL_INDENT_VALUE < 0 
        THEN 0 
        ELSE (SELECT SUM(INITIAL_INDENT_VALUE) FROM ShoppingCartDetails) - FINAL_INDENT_VALUE
  END AS SAVING_VALUE
    
FROM 
    ShoppingCartDetails";

        //public const string QryGetJustification = @" SELECT TXT_TYP.TEXT_ID,TXT_TYP.TXT_DESC,SC_D.SCD_TXT from t_SIS_sc_document SC_D 
        //    INNER JOIN  sapsur.t_text_type TXT_TYP ON SC_D.SCD_TXT_TYPE= TXT_TYP.text_id
        //    INNER JOIN T_SIS_SHOPPING_CART_ITEM SC_I ON SC_I.SCI_CART_NO=SC_D.SCD_CART_NO AND SC_I.sci_item_no=SC_D.SCD_ITEM_NO
        //    WHERE SC_D.SCD_CART_NO=:scp_cart_no AND SC_I.SCI_MATL_NO=:SCI_MATL_NO" ;



        public const string QryGetJustification = @"   SELECT
TXT_TYP.TEXT_ID,
TXT_TYP.TXT_DESC,
LISTAGG(SC_D.SCD_TXT, ', ') WITHIN GROUP(ORDER BY SC_D.SCD_LINE_NO,SC_D.SCD_LVL) AS SCD_TXT
FROM
    t_SIS_sc_document SC_D
INNER JOIN
    sapsur.t_text_type TXT_TYP ON SC_D.SCD_TXT_TYPE = TXT_TYP.text_id and SC_D.SCD_LVL=txt_typ.txt_lvl
INNER JOIN
    T_SIS_SHOPPING_CART_ITEM SC_I ON SC_I.SCI_CART_NO = SC_D.SCD_CART_NO
                                   AND SC_I.sci_item_no = SC_D.SCD_ITEM_NO
WHERE
    SC_D.SCD_CART_NO = :scp_cart_no
   AND SC_I.SCI_MATL_NO = :SCI_MATL_NO
GROUP BY
    TXT_TYP.TEXT_ID, TXT_TYP.TXT_DESC";





        public const string QryGetAnswerStatus = @" select SCC_CART_NO,SCC_SEQ_NO,SCC_TYPE,SCC_TEXT,SCC_FROM_ID,SCC_TO_ID,SCC_CRT_DT,SCC_UPD_DT,SCC_IS_ANSWER,SCC_ANSWER 
from T_SIS_SC_COMMUNICATION where scc_is_answer='N' and scc_cart_no=:scc_cart_no and scc_to_id=:UserId";


        public const string QryGetMaxQtyData_SC = @"select
            ROW_NUMBER() OVER (ORDER BY EXISTING_UMC) AS SRNO,
            EXISTING_UMC,
            EXISTING_UMC_DESC,
            PIPELINE_QTY	,
            REFURBISHED_QTY	,
            CHARGEDOUT_QTY	,
            SCI_PLANT_CD,
            MAX_QTY,
            ALLOWED_QTY	,
            MAXQTY_STATUS	,
            SCI_QTY,
            USER_REMARKS_MAXQTY
            from T_SIS_INTELLIBUY_CHECK_ITEM where Indent_id=:INDENT_ID";


        public const string QryGetRequiConsumData_SC = @"select
            ROW_NUMBER() OVER (ORDER BY EXISTING_UMC) AS SRNO,
            EXISTING_UMC,
            EXISTING_UMC_DESC,
            SYS_REQ_DATE,
            SYS_CONSUMP_DT,
            SCI_REQD_ON_DT ,    
            CONSUMP_DT, 
            RCM_STATUS,
            USER_REMARKS_RCM
            from T_SIS_INTELLIBUY_CHECK_ITEM where Indent_id=:INDENT_ID";

        public const string QryGetVMI_ARCData_SC = @"select
            ROW_NUMBER() OVER (ORDER BY EXISTING_UMC) AS SRNO,
            EXISTING_UMC,
            EXISTING_UMC_DESC,          
            VMIARC_STATUS
            from T_SIS_INTELLIBUY_CHECK_ITEM 
            where Indent_id=:INDENT_ID";

        public const string QryGetRefurshibilityData_SC = @"

            select
            ROW_NUMBER() OVER (ORDER BY intbuy_i.EXISTING_UMC) AS SRNO,
            intbuy_i.EXISTING_UMC,
            intbuy_i.EXISTING_UMC_DESC,   
            (case when umcp.refurbishable='N' then 'Non Refurbishable' when  umcp.refurbishable='R' then 'Refurbishable' else 'NA'  end )  as     IS_REFURBISHABLE,
            intbuy_i.REFURSHIBILITY_STATUS
            FROM
            t_sis_indent_details ind
            INNER JOIN t_sis_umc_indent_details umc ON umc.indent_id = ind.indent_id
            LEFT JOIN t_sis_intellibuy_check_item intbuy_i ON intbuy_i.indent_id = ind.indent_id
                        AND intbuy_i.existing_umc = umc.req_umc_no
            INNER JOIN sapsur.t_umc_prod umcp ON umcp.umc_cd = umc.req_umc_no
            AND umcp.plant_cd = ind.indentor_plant
            where intbuy_i.Indent_id=:INDENT_ID";

        public const string QryGetDepropmData_SC = @"select
            ROW_NUMBER() OVER (ORDER BY intbuy_i.EXISTING_UMC) AS SRNO,
            intbuy_i.EXISTING_UMC,
            intbuy_i.EXISTING_UMC_DESC,   
                scvcode.code_value || ' - ' || scvcode.code_val_desc DOCUMENT_TYPE_DESC,
            intbuy_i.DEPROP_STATUS
            FROM
            t_sis_indent_details ind
            INNER JOIN t_sis_umc_indent_details umc ON umc.indent_id = ind.indent_id
            INNER JOIN t_sis_code_value scv ON scv.id = ind.indent_current_status
            LEFT JOIN t_sis_code_value scvcode ON scvcode.code_value = umc.document_type
            AND scvcode.codetype_id = 5
            LEFT JOIN t_sis_intellibuy_check_item intbuy_i ON intbuy_i.indent_id = ind.indent_id
            AND intbuy_i.existing_umc = umc.req_umc_no
            where intbuy_i.Indent_id=:INDENT_ID";


        public const string QryGetUserEmailId_SC = @"select UM_USR_NAME, UM_EMAIL_ID, UM_USR_ID from SAPSUR.t_user_master u where u.um_usr_id=:UserId";

        //public const string QryGetCreaterAndFinalApproverID_SC = @"select h.SCH_CRT_ID,a.SCP_APPRVR from T_SIS_SHOPPING_CART_HDR h inner join t_sis_sc_approval a  on h.SCH_CART_NO=a.scp_cart_no where  a.scp_cart_no=:scno and  a.SCP_APP_LVL=(select max(SCP_APP_LVL) from t_sis_sc_approval)";



        public const string QryGetCreaterAndFinalApproverID_SC = @" SELECT h.SCH_CRT_ID, a.SCP_APPRVR, a.SCP_APP_LVL,
    (SELECT MAX(sc.SCP_APP_LVL)
     FROM t_sis_sc_approval sc
     WHERE sc.scp_cart_no = :scno) AS MaxLevel  -- Add MaxLevel as a column
FROM T_SIS_SHOPPING_CART_HDR h
INNER JOIN t_sis_sc_approval a ON h.SCH_CART_NO = a.scp_cart_no
WHERE a.scp_cart_no = :scno
  AND a.SCP_APP_STATUS = '00'  -- Fetch only pending records
  AND a.SCP_APP_LVL = (
    SELECT MAX(sc.SCP_APP_LVL)
    FROM t_sis_sc_approval sc
    WHERE sc.scp_cart_no = :scno
      AND sc.SCP_APP_STATUS = '00'  -- Only consider pending levels
      AND NOT EXISTS(
        -- Ensure all previous levels are completed (SCP_APP_STATUS != '00')
        SELECT 1
        FROM t_sis_sc_approval sc_sub
        WHERE sc_sub.scp_cart_no = :scno
          AND sc_sub.SCP_APP_LVL<sc.SCP_APP_LVL
          AND sc_sub.SCP_APP_STATUS = '00'  -- Any previous level still pending
      )
  )";




        

        #endregion


        //------ODATA----
        public const string oraGet_budgetConsumptionFormDept_EBuy = @"select fy, sum( totalvalue) Totval from  
(select case when (to_number(to_char(add_months(trunc(sysdate), 9), 'YYYY')) 
- to_number(to_char(add_months(nvl(sci_reqd_on_dt,trunc(sysdate)),9),'YYYY'))) >= 0  then to_char(add_months(trunc(sysdate), 9), 'YYYY')
else to_char(add_months(nvl(sci_reqd_on_dt, trunc(sysdate)), 9), 'YYYY') end as FY,sci_qty * sci_price totalvalue 
From sapsur.t_shopping_cart_hdr, sapsur.t_shopping_cart_item , sapsur.t_umc_prod where sch_dept = :sch_dept  and sch_status = '04' 
and sch_cart_no = sci_cart_no  and sci_prod_type ='01' and nvl(sci_del_ind, 'Y') <> 'X'  and sci_fod_type in ('RO', 'PR') 
and sci_matl_grp <> '320' and ( nvl(sci_aa_cat,' ') = ' ' or  nvl(sci_aa_cat,'L')  ='L') and nvl(sci_status,'X') <> '06'   
and SCI_MATL_NO = UMC_CD   and SCI_PLANT_CD=PLANT_CD and  MAT_TYP in  ('ERSA','HIBE')  )  group by fy
";
        public const string oraGet_budgetConsumptionFormDept_SIS = @"select fy, sum( totalvalue) Totval from  
(select case when (to_number(to_char(add_months(trunc(sysdate), 9), 'YYYY')) 
- to_number(to_char(add_months(nvl(sci_reqd_on_dt,trunc(sysdate)),9),'YYYY'))) >= 0  then to_char(add_months(trunc(sysdate), 9), 'YYYY')
else to_char(add_months(nvl(sci_reqd_on_dt, trunc(sysdate)), 9), 'YYYY') end as FY,sci_qty * sci_price totalvalue 
From t_sis_shopping_cart_hdr, t_sis_shopping_cart_item , sapsur.t_umc_prod where sch_dept = :sch_dept  and sch_status = '04' 
and sch_cart_no = sci_cart_no  and sci_prod_type ='01' and nvl(sci_del_ind, 'Y') <> 'X'  and sci_fod_type in ('RO', 'PR') 
and sci_matl_grp <> '320' and ( nvl(sci_aa_cat,' ') = ' ' or  nvl(sci_aa_cat,'L')  ='L') and nvl(sci_status,'X') <> '06'   
and SCI_MATL_NO = UMC_CD   and SCI_PLANT_CD=PLANT_CD and  MAT_TYP in  ('ERSA','HIBE')  )  group by fy ";


        public const string  QryGetApprovedBySc = "SELECT scp_apprvr, scp_app_lvl FROM t_sis_sc_approval WHERE scp_cart_no = :cartNo " +
                           "AND scp_app_status = '01' AND scp_app_dt IS NOT NULL GROUP BY scp_apprvr, scp_app_lvl order by scp_app_lvl";

        public const string QryGetDeptSc = " select sch_dept from t_sis_shopping_cart_hdr where Sch_Cart_No=:cartNo";

        public const string QryGetDeptType = "SELECT DEPTTYPE FROM SAPSUR.T_S_DEPT_MST WHERE DEPTNO = :DeptNo AND CLIENT = '600'";

        public const string QryGetPGList_SC = "select DISTINCT cd.EKGRP, p.DESCRIPTION || '(' || cd.EKGRP  || ')' AS DESCRIPTION  from  CMDRDB.T_YMPIT_MRO_CMBGG@CTDR_EPROC_DBL  cd inner join sapsur.T_S_PURGRP p on cd.EKGRP= p.purgrp order by DESCRIPTION ";

        public const string QryGetBGGList_SC = "select DISTINCT cd.MATKL, b.DESCRIPTION || '(' || cd.MATKL  || ')' AS DESCRIPTION  from  CMDRDB.T_YMPIT_MRO_CMBGG@CTDR_EPROC_DBL  cd inner join sapsur.T_S_MATL_GRP b on cd.MATKL= b.MATLGRP order by DESCRIPTION ";

        public const string GetSCDetailsForAddApprover = "SELECT a.sch_cart_no, b.sch_cart_name,  d.deptdesc ||'('|| d.deptno || ')' DeptDesc , a.sch_crt_id, a.sch_crt_dt, a.sch_tot_val FROM t_sis_shopping_cart_hdr a  inner join T_SIS_INTELLIBUY_CHECK_HEADER b on a.sch_cart_no=b.sch_cart_no  INNER JOIN SAPSUR.t_s_dept_mst d on d.deptno= a.sch_dept WHERE a.SCH_CART_NO=:CartNo";

        public const string QryGetApproverLevel = "select distinct scp_app_lvl , 'LEVEL - ' || scp_app_lvl  LVLDESC from t_sis_sc_approval where scp_cart_no=:CartNo and scp_ver_no = (select max(scp_ver_no) from t_sis_sc_approval where scp_cart_no =:CartNo) order by scp_app_lvl";

        public const string QryAddApprover = @"insert into t_sis_sc_approval (scp_cart_no,SCP_APP_LVL,SCP_APPRVR,SCP_APP_STATUS,SCP_MAILSEND_STATUS,SCP_UPD_DT,SCP_VER_NO,SCP_SELECTED)
values (:scp_cart_no,:SCP_APP_LVL,:SCP_APPRVR,:SCP_APP_STATUS,:SCP_MAILSEND_STATUS,sysdate,:SCP_VER_NO,:SCP_SELECTED)";

        public const string QryGetMAxVerOfApproval = @"SELECT MAX(SCP_VER_NO) SCP_VER_NO FROM t_sis_sc_approval WHERE SCP_CART_NO = :SCP_CART_NO";

        public const string QryInsertAddApprovalDelegate = @"insert into T_SIS_SHOPPING_CART_DELEGATE(SCD_CART_NO, SCD_LVL, SCD_PIN_NO, SCD_ATCH_FILE, SCD_CRT_DT, SCD_CRT_BY,SCD_ATCH_FILENAME) values(:SCD_CART_NO,:SCD_LVL,:SCD_PIN_NO,:SCD_ATCH_FILE, SYSDATE,:SCD_CRT_BY,:SCD_ATCH_FILENAME)";

        public const string QryValidatePIN = @"select APR_ID from sapsur.t_approver where APR_ID =: APR_ID";
  
    }
}




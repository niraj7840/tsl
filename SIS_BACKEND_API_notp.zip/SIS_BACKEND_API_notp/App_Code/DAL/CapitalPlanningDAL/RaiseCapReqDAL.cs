﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
    public class RaiseCapReqDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;


        //start of funtion
        public int AddRequestFinal(CapexApprovalRequest newApprovals, Dictionary<string, List<string>> existingUmcDict)
        {
            int result = 0;
            Boolean isCapex = true;
            Boolean isClosed = true;
            try
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            //string deptCode = GetDepartmentCode(newApprovals.CUR_CREATED_BY, connection, transaction);

                            //if (string.IsNullOrEmpty(deptCode))
                            //{
                            //    deptCode = "164";
                            //}

                            //if (CheckExistingUmcs(newApprovals, existingUmcDict, connection, transaction))
                            //{
                            //    transaction.Rollback();
                            //    return -1; // Indicate that the operation was not performed
                            //}

                            foreach (FormModel newApproval in newApprovals.Forms)
                            {
                                //int newId = GetNewRequestId(connection, transaction);

                                //result+=InsertCapRequest(newApproval, newId, deptCode, newApprovals, connection, transaction);

                                //result+= InsertQuestionResponses(newApproval, newId, newApprovals.CUR_CREATED_BY, connection, transaction);

                                result += ExecuteInsertOperationRevenue(connection, transaction, newApproval, newApprovals);
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            return result;
                        }
                        if (connection.State == ConnectionState.Closed)
                        {
                            connection.Open();
                        }
                        try
                        {
                            if (newApprovals.CUA_INTENT_NO != null)
                            {
                                isCapex = isPendingForCapexOrIntellibuy((newApprovals.CUA_INTENT_NO).ToString(), connection);
                                isClosed = isWorkflowClosed((newApprovals.CUA_INTENT_NO).ToString(), connection);
                            }

                            if (isCapex == false && isClosed==false)
                            {
                                UpdateIndentStatus(connection, Convert.ToInt32(newApprovals.CUA_INTENT_NO), DalQueryApproval.ChangeIndentStatusToIntellibuy);
                            }
                            else if(isCapex == false && isClosed==true)
                            {
                                UpdateIndentStatus(connection, Convert.ToInt32(newApprovals.CUA_INTENT_NO), DalQuery.ChangeIndentStatusToClosed);
                            }
                        }
                        catch (Exception ex)
                        {
                            //Console.WriteLine(ex.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log or handle the error here
                return result;
            }

            return result;
        }


        public void UpdateIndentStatus(OracleConnection connection, int indentId, string query)
        {
            using (var command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(new OracleParameter("Indent_Id", indentId));
                command.ExecuteNonQuery();
            }
        }

        //start of function

        public Boolean isWorkflowClosed(string indent, OracleConnection connection)
        {
            DataTable dt = new DataTable();
            using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntent, connection))
            {
                command.Parameters.Add(new OracleParameter(":intent", indent));

                using (var reader = command.ExecuteReader())
                {

                    dt.Load(reader);
                }
            }
            if (dt.Rows.Count > 0)
            {
                var isAllCap = 0;
                foreach (DataRow row in dt.Rows)
                {
                    string columnValue = row["TAG"].ToString();
                    string columnUmc = row["REQ_UMC_NO"].ToString();
                    // Perform your check on the column value
                    if (columnValue.Equals("C"))
                    {
                        isAllCap++;
                    }
                }

                if (isAllCap == dt.Rows.Count)
                {
                    return true;
                }
            }
            return false;
        }

        //end of function

        //start of function

        public Boolean isPendingForCapexOrIntellibuy(string indent, OracleConnection connection)
        {
            DataTable dt = new DataTable();
            using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntent, connection))
            {
                command.Parameters.Add(new OracleParameter(":intent", indent));

                using (var reader = command.ExecuteReader())
                {

                    dt.Load(reader);
                }
            }

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    string columnValue = row["TAG"].ToString();
                    string columnUmc = row["REQ_UMC_NO"].ToString();
                    // Perform your check on the column value
                    if (columnValue.Equals("N"))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //end of function

        private int ExecuteInsertOperationRevenue(OracleConnection connection, OracleTransaction transaction, FormModel newApproval,  CapexApprovalRequest model)
        {
            int rowsAffected = 0;
            string updateQuery1 = DalQuery.insertIntoUmcRevTable;
            using (var command = new OracleCommand(updateQuery1, connection))
            {
                command.Transaction = transaction;
                command.Parameters.Add(new OracleParameter("CRU_UMC", OracleDbType.Varchar2) { Value = newApproval.UmcNumber });
                command.Parameters.Add(new OracleParameter("CRU_TAG", OracleDbType.Varchar2) { Value = newApproval.tag });
                command.Parameters.Add(new OracleParameter("CRU_REQUEST_ID", OracleDbType.Varchar2) { Value = model.CUA_INTENT_NO });
                command.Parameters.Add(new OracleParameter("CRU_STATUS", OracleDbType.Char) { Value = 'T' });
                command.Parameters.Add(new OracleParameter("CRU_CREATED_BY", OracleDbType.Varchar2) { Value = model.CUR_CREATED_BY });

                rowsAffected = command.ExecuteNonQuery();
            }

            return rowsAffected;
        }

        private string GetDepartmentCode(string userId, OracleConnection connection, OracleTransaction transaction)
        {
            string deptCode = "";
            string query = "select um_dept_cd from SAPSUR.t_user_master where UM_USR_ID = :CUR_CREATED_BY";
            using (var command = new OracleCommand(query, connection))
            {
                command.Transaction = transaction;
                command.Parameters.Add(new OracleParameter("CUR_CREATED_BY", userId));
                var deptCodeObj = command.ExecuteScalar();
                if (deptCodeObj != null)
                {
                    deptCode = deptCodeObj.ToString();
                }
                return deptCode;
            }
        }

        private bool CheckExistingUmcs(CapexApprovalRequest newApprovals, Dictionary<string, List<string>> existingUmcDict, OracleConnection connection, OracleTransaction transaction)
        {
            foreach (FormModel newApproval in newApprovals.Forms)
            {
                string checkUmcQuery = "select CRU_UMC, CRU_TAG from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC AND (CRU_TAG='R' OR CRU_TAG='C')";
                using (var checkUmcCommand = new OracleCommand(checkUmcQuery, connection))
                {
                    checkUmcCommand.Transaction = transaction;
                    checkUmcCommand.Parameters.Add(new OracleParameter(":CRU_UMC", newApproval.UmcNumber));

                    using (var reader = checkUmcCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string umc = reader.GetString(0);
                            string tag = reader.GetString(1);
                            if (!existingUmcDict.ContainsKey(tag))
                            {
                                existingUmcDict[tag] = new List<string>();
                            }
                            existingUmcDict[tag].Add(umc);
                        }
                    }
                }
            }

            return existingUmcDict.Any(kv => kv.Value.Count > 0);
        }

        private int GetNewRequestId(OracleConnection connection, OracleTransaction transaction)
        {
            int newId;
            using (var command = new OracleCommand(DalQuery.getLastIdQuery, connection))
            {
                command.Transaction = transaction;

                var lastId = command.ExecuteScalar().ToString();

                if (string.IsNullOrEmpty(lastId))
                {
                    newId = 10000001;
                }
                else
                {
                    newId = Convert.ToInt32(lastId) + 1;
                }
            }
            return newId;
        }

        private int InsertCapRequest(FormModel newApproval, int newId, string deptCode, CapexApprovalRequest newApprovals, OracleConnection connection, OracleTransaction transaction)
        {
            using (var command = new OracleCommand(DalQuery.insertCapRequestQuery1, connection))
            {
                command.Transaction = transaction;

                command.Parameters.Add(new OracleParameter("CUA_REQUEST_ID", OracleDbType.Varchar2) { Value = newId });
                command.Parameters.Add(new OracleParameter("CUA_UMC", OracleDbType.Varchar2) { Value = newApproval.UmcNumber });
                command.Parameters.Add(new OracleParameter("CUA_USER_REMARKS", OracleDbType.Varchar2) { Value = newApproval.Remarks });
                command.Parameters.Add(new OracleParameter("CUA_STATUS", OracleDbType.Varchar2) { Value = "1" });
                command.Parameters.Add(new OracleParameter("CUA_LEVEL1_APPRD_BY", OracleDbType.Varchar2) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_LEVEL1_APPRD_ON", OracleDbType.Date) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_LEVEL1_APPRD_REMARKS", OracleDbType.Varchar2) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_LEVEL2_APPRD_BY", OracleDbType.Varchar2) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_LEVEL2_APPRD_ON", OracleDbType.Date) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_LEVEL2_APPRD_REMARKS", OracleDbType.Varchar2) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_CAPACCNTS_APPRD_BY", OracleDbType.Varchar2) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_CAPACCNTS_APPRD_ON", OracleDbType.Date) { Value = DBNull.Value });
                command.Parameters.Add(new OracleParameter("CUA_CAPACCNTS_APPRD_REMARKS", OracleDbType.Varchar2) { Value = DBNull.Value });

                if (newApprovals.CUA_INTENT_NO.HasValue)
                {
                    command.Parameters.Add(new OracleParameter("CUA_INTENT_NO", OracleDbType.Int32) { Value = newApprovals.CUA_INTENT_NO });
                }
                else
                {
                    command.Parameters.Add(new OracleParameter("CUA_INTENT_NO", OracleDbType.Int32) { Value = DBNull.Value });
                }

                command.Parameters.Add(new OracleParameter("CUA_DEPTNO", OracleDbType.Varchar2) { Value = deptCode });
                command.Parameters.Add(new OracleParameter("CUA_UMC_TAG", OracleDbType.Varchar2) { Value = newApproval.tag});
                command.Parameters.Add(new OracleParameter("CUA_UMC_DESC", OracleDbType.Varchar2) { Value = newApproval.description });
                command.Parameters.Add(new OracleParameter("CUA_BGG", OracleDbType.Varchar2) { Value = newApproval.BGG });


                return command.ExecuteNonQuery();
            }
        }

        private int InsertQuestionResponses(FormModel newApproval, int newId, string createdBy, OracleConnection connection, OracleTransaction transaction)
        {
            int result = 0;
            var questionIds = GetQuestionIds(connection, transaction);

            int i = 0;
            foreach (var response in newApproval.QuestionResponses)
            {
                using (var command = new OracleCommand(DalQuery.insertCapRequestQuery2, connection))
                {
                    command.Transaction = transaction;

                    command.Parameters.Add(new OracleParameter("CUR_REQUEST_ID", OracleDbType.Varchar2) { Value = newId });
                    command.Parameters.Add(new OracleParameter("CUR_QUESTION_ID", OracleDbType.Int32) { Value = questionIds[i] });
                    command.Parameters.Add(new OracleParameter("CUR_RESPONSE", OracleDbType.Varchar2) { Value = response });
                    command.Parameters.Add(new OracleParameter("CUR_CREATED_BY", OracleDbType.Varchar2) { Value = createdBy });
                    command.Parameters.Add(new OracleParameter("CUR_CREATED_DATE", OracleDbType.Date) { Value = DateTime.Now });

                    result+=command.ExecuteNonQuery();
                }
                i++;
            }
            return result;
        }

        private List<int> GetQuestionIds(OracleConnection connection, OracleTransaction transaction)
        {
            var questionIds = new List<int>();
            string query = "SELECT CQM_QUES_ID FROM T_SIS_CAP_QUES_MASTER ORDER BY CQM_QUES_ID ASC";
            using (var command = new OracleCommand(query, connection))
            {
                command.Transaction = transaction;
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        questionIds.Add(reader.GetInt32(0));
                    }
                }
            }
            return questionIds;
        }

        //end of funtion

        //start of function
        public string GetPlant(string dept)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                string query = @"select plant from SAPSUR.T_S_DEPT_MST where deptno=:dept";

                using (var command = new OracleCommand(query, connection))
                {
                    command.Parameters.Add(new OracleParameter(":dept", dept));

                    using (var reader = command.ExecuteReader(CommandBehavior.SingleRow))
                    {
                        if (reader.Read())
                        {
                            return reader["PLANT"].ToString();
                        }
                    }
                }
            }
            return null;
        }


        //end of function
    }

    public class DalQuery
    {
        public const string getLastIdQuery = "SELECT MAX((CUA_REQUEST_ID)) FROM T_SIS_CAP_UMC_APRVL";

        public const string insertCapRequestQuery1 = @"INSERT INTO T_SIS_CAP_UMC_APRVL (CUA_REQUEST_ID,
                                                    CUA_UMC, CUA_USER_REMARKS, CUA_STATUS, CUA_LEVEL1_APPRD_BY, 
                                                    CUA_LEVEL1_APPRD_ON, CUA_LEVEL1_APPRD_REMARKS, CUA_LEVEL2_APPRD_BY, CUA_LEVEL2_APPRD_ON, 
                                                    CUA_LEVEL2_APPRD_REMARKS, CUA_CAPACCNTS_APPRD_BY, CUA_CAPACCNTS_APPRD_ON, CUA_CAPACCNTS_APPRD_REMARKS,
                                                    CUA_INDENT_NO, CUA_DEPTNO, CUA_UMC_TAG, CUA_UMC_DESC, CUA_BGG
                                                ) VALUES (:CUA_REQUEST_ID,
                                                    :CUA_UMC, :CUA_USER_REMARKS, :CUA_STATUS, :CUA_LEVEL1_APPRD_BY, 
                                                    :CUA_LEVEL1_APPRD_ON, :CUA_LEVEL1_APPRD_REMARKS, :CUA_LEVEL2_APPRD_BY, :CUA_LEVEL2_APPRD_ON, 
                                                    :CUA_LEVEL2_APPRD_REMARKS, :CUA_CAPACCNTS_APPRD_BY, :CUA_CAPACCNTS_APPRD_ON, :CUA_CAPACCNTS_APPRD_REMARKS,
                                                    :CUA_INDENT_NO, :CUA_DEPTNO, :CUA_UMC_TAG, :CUA_UMC_DESC, :CUA_BGG
                                                )";

        public const string insertCapRequestQuery2 = @"
                    INSERT INTO T_SIS_CAP_UMC_REQ (CUR_REQUEST_ID, CUR_QUESTION_ID, CUR_RESPONSE, CUR_CREATED_BY, CUR_CREATED_ON)
                    VALUES (:CUR_REQUEST_ID, :CUR_QUESTION_ID, :CUR_RESPONSE, :CUR_CREATED_BY, :CUR_CREATED_ON)";


        public const string insertIntoUmcRevTable = @"INSERT
INTO T_SIS_CAP_REV_UMC
  (
    CRU_UMC,
    CRU_TAG,
    CRU_REQUEST_ID,
    CRU_STATUS,
    CRU_CREATED_BY,
    CRU_CREATED_ON
  )
  VALUES
  (
    :CRU_UMC,
    :CRU_TAG,
    :CRU_REQUEST_ID,
    :CRU_STATUS,
    :CRU_CREATED_BY,
    SYSDATE
  )";
        public const string ChangeIndentStatusToClosed = @"UPDATE t_sis_indent_details SET Indent_Current_Status = '5' WHERE Indent_Id = :Indent_ID";

    }
}
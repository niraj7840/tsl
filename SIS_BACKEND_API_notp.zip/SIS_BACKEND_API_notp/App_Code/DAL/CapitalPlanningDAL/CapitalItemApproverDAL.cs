﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Security;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
    public class CapitalItemApproverDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        //start of function

        //this api will give role by using adid

        public void GetRole(string adid, Dictionary<string, object> result)
        {

            string getDept=getDeptFromAdid(adid);

            // Check for level 1 role
            string level1Dept = GetDeptByLevel(adid, "1", getDept);
            if (!string.IsNullOrEmpty(level1Dept))
            {
                result.Add("level_1", level1Dept);
                return;
            }

            // Check for level 2 role
            string level2Dept = GetDeptByLevel(adid, "2", getDept);
            if (!string.IsNullOrEmpty(level2Dept))
            {
                result.Add("level_2", level2Dept);
                return;
                
            }

            // Check for capital accounts role
            string BAGDept = GetBagCount(adid, getDept);
            if (!string.IsNullOrEmpty(BAGDept))
            {
                result.Add("BAG", BAGDept);
                return;

            }

        }

        private string getDeptFromAdid(string adid)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                string query = @"select um_dept_cd from SAPSUR.t_user_master where UM_USR_ID= :adid";

                using (var command = new OracleCommand(query, connection))
                {
                    //command.Parameters.Add(new OracleParameter("position", level));
                    command.Parameters.Add(new OracleParameter("adid", adid));

                    using (var reader = command.ExecuteReader(CommandBehavior.SingleRow))
                    {
                        if (reader.Read())
                        {
                            return reader["um_dept_cd"].ToString();
                        }
                    }
                }
            }
            return null;
        }

        //this function will return whether the adid is in level 1 or level 2
        private string GetDeptByLevel(string adid, string level, string getDept)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                string query = @"SELECT APR_DEPT FROM SAPSUR.T_APPROVER a, SAPSUR.t_user_master b where UM_USR_ID=a.apr_id and APR_DEPT=um_dept_cd
                                    AND APR_LEVEL=:position
                                    and apr_id=:adid
                                    and um_dept_cd=:department";

                using (var command = new OracleCommand(query, connection))
                {                  
                    command.Parameters.Add(new OracleParameter("position", level));
                    command.Parameters.Add(new OracleParameter("adid", adid));
                    command.Parameters.Add(new OracleParameter("department", getDept));

                    using (var reader = command.ExecuteReader(CommandBehavior.SingleRow))
                    {
                        if (reader.Read())
                        {
                            return reader["APR_DEPT"].ToString();
                        }
                    }
                }
            }
            return null;
        }

        //this function will return whether the adid role is capital acountant or not
        //if count>0 if capex
        private string GetBagCount(string adid, string dept)
        {
            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                string query = @"select  rov_for_dept_cd from SAPSUR.T_ROLE_OBJ_VAL  a ,SAPSUR.T_ROLE_USER b where
                                    ROV_ROLE_ID like 'BAG_%'
                                    and ROV_ROLE_ID=TRU_ROLE_ID
                                    and rov_for_dept_cd=:department
                                    and tru_udr_id=:adid";

                using (var command = new OracleCommand(query, connection))
                {
                    //command.Parameters.Add(new OracleParameter("position", level));
                    command.Parameters.Add(new OracleParameter("department", dept));
                    command.Parameters.Add(new OracleParameter("adid", adid));

                    using (var reader = command.ExecuteReader(CommandBehavior.SingleRow))
                    {
                        if (reader.Read())
                        {
                            return reader["rov_for_dept_cd"].ToString();
                        }
                    }
                }
            }
            return null;
        }
        //end of function

        //start of funtion
        //this funtion gives data on frontend based on this level

        public DataTable GetApproverScreen1(string role)
        {
            DataTable dt = new DataTable();
            string query = string.Empty;

            if (string.IsNullOrEmpty(role))
            {
                return dt; // Early return if role is null or empty
            }

            switch (role.ToLower())
            {
                case "level_1":
                    query = DalQueryApproval.GetApproverScreenForLevel_1;
                    break;
                case "level_2":
                    query = DalQueryApproval.GetApproverScreenForLevel_2;
                    break;
                case "capex":
                    query = DalQueryApproval.GetApproverScreenForCapex;
                    break;
                default:
                    return dt; // Return empty DataTable for unrecognized roles
            }

            try
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();

                    using (var command = new OracleCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            dt.Load(reader);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return dt;
            }

            return dt;
        }

        //end of funtion


        //start of funtion
        public int UpdateApproverScreenRequestID(string role, UmcCapexApprovalUpdateModel model)
        {
            int rowsAffected = 0;

            string query = string.Empty;
            string remarks = string.Empty;
            string approvedBy = string.Empty;

            switch (role.ToLower())
            {
                case "level_1":
                    query = DalQueryApproval.queryUpdateLevel1Approve;
                    remarks = model.CUA_LEVEL1_APPRD_REMARKS;
                    approvedBy = model.CUA_LEVEL1_APPRD_BY;
                    break;
                case "level_2":
                    query = DalQueryApproval.queryUpdateLevel2Approve;
                    remarks = model.CUA_LEVEL2_APPRD_REMARKS;
                    approvedBy = model.CUA_LEVEL2_APPRD_BY;
                    break;
                default:
                    return rowsAffected; // Invalid role
            }

            try
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {
                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("approvedBy", OracleDbType.Varchar2) { Value = approvedBy });
                        command.Parameters.Add(new OracleParameter("remarks", OracleDbType.Varchar2) { Value = remarks });
                        command.Parameters.Add(new OracleParameter("requestId", OracleDbType.Varchar2) { Value = model.CUA_REQUEST_ID });


                        connection.Open();
                        rowsAffected = command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception here, e.g., using a logging framework
                // For example: Logger.LogError(ex, "Error updating approver screen request ID");
            }

            return rowsAffected;
        }


        //end of funtion


        //start of funtion
        public int UpdateApproverScreenRejectRequestID(string role, UmcCapexApprovalUpdateModel model)
        {
            int rowsAffected = 0;
            if (role.ToLower() == "capex")
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {

                    using (var command = new OracleCommand(DalQueryApproval.queryUpdateCapexReject, connection))
                    {

                        OracleParameter paramCapRemark = new OracleParameter("remarks", OracleDbType.Varchar2);
                        //paramCapRemark.Value = model.CUA_CAPEX_REMARKS;
                        command.Parameters.Add(paramCapRemark);


                        OracleParameter paramRequestId = new OracleParameter("requestId", OracleDbType.Varchar2);
                        paramRequestId.Value = model.CUA_REQUEST_ID;
                        command.Parameters.Add(paramRequestId);
                        try
                        {
                            connection.Open();
                            rowsAffected = command.ExecuteNonQuery();

                            /** if (rowsAffected == 0)
                             {
                                 return NotFound();
                             }
                             return Ok(new { RowsAffected = rowsAffected });*/


                        }
                        catch (Exception ex)
                        {
                            return rowsAffected;
                        }
                    }
                }

            }
            else if (role.ToLower() == "vp")
            {
                using (var connection = new OracleConnection(strConnSISDB))
                {



                    using (var command = new OracleCommand(DalQueryApproval.queryUpdateVpReject, connection))
                    {

                        OracleParameter paramVpRemark = new OracleParameter("remarks", OracleDbType.Varchar2);
                        //paramVpRemark.Value = model.CUA_VP_REMARKS;
                        command.Parameters.Add(paramVpRemark);


                        OracleParameter paramRequestId = new OracleParameter("requestId", OracleDbType.Varchar2);
                        paramRequestId.Value = model.CUA_REQUEST_ID;
                        command.Parameters.Add(paramRequestId);
                        try
                        {
                            connection.Open();
                            rowsAffected = command.ExecuteNonQuery();

                            /** if (rowsAffected == 0)
                             {
                                 return NotFound();
                             }
                             return Ok(new { RowsAffected = rowsAffected });*/


                        }
                        catch (Exception ex)
                        {
                            return rowsAffected;
                        }

                    }

                }

            }
            return rowsAffected;

        }


        //end of funtion


        // start of function

        public int UPSERTAPPROVEPAGE(T_CAP_REV_UMC model)
        {
            int result = 0;
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                OracleTransaction transaction = connection.BeginTransaction();
                try
                {


                    using (OracleCommand command = new OracleCommand(DalQueryApproval.queryUpsertCapitalTagApprovalByVp, connection))
                    {

                        command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                        command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                        command.Parameters.Add(":CRU_REQUEST_ID", model.CRU_REQUEST_ID);
                        command.Parameters.Add(":CRU_STATUS", 'N');
                        command.Parameters.Add(":CRU_CREATED_BY", "capex");




                        result = command.ExecuteNonQuery();
                    }

                    transaction.Commit();

                }
                catch (Exception ex)
                {
                    transaction.Rollback();


                }
                return result;
            }
        }


        //end of funtion

        //start of funtion

        public int CAPEXMARKEDREVENUE(string role, T_CAP_REV_UMC model)
        {
            int result = 0;
            if (role.ToLower() == "capex")
            {
                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleTransaction transaction = connection.BeginTransaction();
                    try
                    {


                        using (OracleCommand command = new OracleCommand(DalQueryApproval.queryUpsertRevenueTagByCapex, connection))
                        {

                            command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                            command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                            command.Parameters.Add(":CRU_REQUEST_ID", model.CRU_REQUEST_ID);
                            command.Parameters.Add(":CRU_STATUS", 'N');
                            command.Parameters.Add(":CRU_CREATED_BY", "Capex Team");




                            result = command.ExecuteNonQuery();
                        }


                        transaction.Commit();

                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();


                    }
                }
            }
            else if (role.ToLower() == "vp")
            {
                using (OracleConnection connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();
                    OracleTransaction transaction = connection.BeginTransaction();
                    try
                    {


                        using (OracleCommand command = new OracleCommand(DalQueryApproval.queryUpsertRevenueTagByCapex, connection))
                        {

                            command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                            command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                            command.Parameters.Add(":CRU_REQUEST_ID", model.CRU_REQUEST_ID);
                            command.Parameters.Add(":CRU_STATUS", 'N');
                            command.Parameters.Add(":CRU_CREATED_BY", "vp");




                            result = command.ExecuteNonQuery();
                        }

                        transaction.Commit();

                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();


                    }
                }
            }
            return result;
        }
        //end of funtion

        //start of function

        public int CAPEXMARKEDCAPITAL(string role, T_CAP_REV_UMC_USER model)
        {
            int rowsAffected = 0;
            Boolean isCapex=true;
            string updateQuery = GetUpdateQueryCapital(role);
            string updateRemarks = GetUpdateRemarksCapital(role, model);
            string updateApprovedBy = GetUpdateApprovedByCapital(role, model);

            if(model.taggingWhenRaised=="R")
            {
                model.CRU_TAG = "R";
            }

            if (string.IsNullOrEmpty(updateQuery) || string.IsNullOrEmpty(updateRemarks) || string.IsNullOrEmpty(updateApprovedBy))
            {
                return rowsAffected; // Invalid role
            }

            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        rowsAffected = ExecuteUpdateOperationCapital(connection, transaction, updateQuery, updateApprovedBy, updateRemarks, model.CUA_REQUEST_ID);

                        if (rowsAffected != 0)
                        {
                            rowsAffected = ExecuteInsertOperationCapital(connection, transaction, model);
                            if (rowsAffected != 0)
                            {
                                transaction.Commit();
                                
                            }
                            else
                            {
                                transaction.Rollback();
                                rowsAffected = 0;
                            }
                        }
                        else
                        {
                            transaction.Rollback();
                            rowsAffected = 0;
                        }

                        //transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                         rowsAffected = 0;
                    }

                    if(connection.State==ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    try
                    {
                        if (model.CUA_INDENT_NO != null)
                        {
                            isCapex = isPendingForCapexOrIntellibuy(model.CUA_INDENT_NO, connection);
                        }

                        if (isCapex == false)
                        {
                            UpdateIndentStatus(connection, Convert.ToInt32(model.CUA_INDENT_NO), DalQueryApproval.ChangeIndentStatusToIntellibuy);
                        }
                    }
                    catch(Exception ex) { 
                        //Console.WriteLine(ex.ToString());
                    }
                }
            }

            return rowsAffected;
        }

        public void UpdateIndentStatus(OracleConnection connection, int indentId, string query)
        {
            using (var command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(new OracleParameter("Indent_Id", indentId));
                command.ExecuteNonQuery();
            }
        }

        //start of function

        public Boolean isPendingForCapexOrIntellibuy(string indent, OracleConnection connection)
        {
            DataTable dt = new DataTable();
            using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntent, connection))
            {
                command.Parameters.Add(new OracleParameter(":intent", indent));

                using (var reader = command.ExecuteReader())
                {

                    dt.Load(reader);
                }
            }

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    // Assuming you want to check the value of a column named "ColumnName"
                    string columnValue = row["TAG"].ToString();
                    string columnUmc = row["REQ_UMC_NO"].ToString();
                    // Perform your check on the column value
                    if (columnValue.Equals("N"))
                    {
                        // Check the status in another table
                        return true;
                    }
                }
            }
            return false;
        }

        //end of function

        private string GetUpdateQueryCapital(string role)
        {
            switch (role.ToLower())
            {
                case "capex":
                    return DalQueryApproval.queryUpdateCapexApprove;
                default:
                    return string.Empty;
            }
        }

        private string GetUpdateRemarksCapital(string role, T_CAP_REV_UMC_USER model)
        {
            switch (role.ToLower())
            {
                case "capex":
                    return model.CUA_CAPACCNTS_APPRD_REMARKS;
                default:
                    return string.Empty;
            }
        }

        private string GetUpdateApprovedByCapital(string role, T_CAP_REV_UMC_USER model)
        {
            switch (role.ToLower())
            {
                case "capex":
                    return model.CUA_CAPACCNTS_APPRD_BY;
                default:
                    return string.Empty;
            }
        }

        private int ExecuteUpdateOperationCapital(OracleConnection connection, OracleTransaction transaction, string query, string approvedBy, string remarks, int requestId)
        {
            int rowsAffected = 0;

            using (var command = new OracleCommand(DalQueryApproval.queryUpdateCapexApprove, connection))
            {
                command.Transaction = transaction;
                command.Parameters.Add(new OracleParameter("approvedBy", OracleDbType.Varchar2) { Value = approvedBy });
                command.Parameters.Add(new OracleParameter("remarks", OracleDbType.Varchar2) { Value = remarks });
                command.Parameters.Add(new OracleParameter("requestId", OracleDbType.Varchar2) { Value = requestId });

                rowsAffected = command.ExecuteNonQuery();
            }

            return rowsAffected;
        }

        private int ExecuteInsertOperationCapital(OracleConnection connection, OracleTransaction transaction, T_CAP_REV_UMC_USER model)
        {
            int rowsAffected = 0;

            using (var command = new OracleCommand(DalQueryApproval.queryUpsertCapitalTagApprovalByCapex, connection))
            {
                command.Transaction = transaction;
                command.Parameters.Add(":CRU_UMC", model.CRU_UMC);
                command.Parameters.Add(":CRU_TAG", model.CRU_TAG);
                command.Parameters.Add(":CRU_REQUEST_ID", model.CUA_REQUEST_ID);
                command.Parameters.Add(":CRU_STATUS", 'N');
                command.Parameters.Add(":CRU_CREATED_BY", model.CUA_CAPACCNTS_APPRD_BY);

                rowsAffected = command.ExecuteNonQuery();
            }

            return rowsAffected;
        }


        // end of function
        //start of function 

        // if approver of any level rejects, then only terminates the worflow means mark as status as 4
        //dont insert anything in table means dont tagg.
        public int REJECTNMARKEDREVENUE(string role, T_CAP_REV_UMC_USER model)
        {
            int rowsAffected = 0;

            string updateQuery = GetUpdateRejectQuery(role);
            string updateRemarks = GetUpdateRejectRemarks(role, model);
           // string updateApprovedBy = GetUpdateRejectApprovedBy(role, model);

            if (string.IsNullOrEmpty(updateQuery) || string.IsNullOrEmpty(updateRemarks))
            {
                return rowsAffected; // Invalid role
            }

            using (var connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Update Operation
                        rowsAffected = ExecuteUpdateOperationRevenue(connection, transaction, updateQuery, updateRemarks, model.CUA_REQUEST_ID);

                        if (rowsAffected > 0)
                        {
                            // Insert Operation
                           // rowsAffected = ExecuteInsertOperationRevenue(role, connection, transaction, model);

                            if (rowsAffected != 0)
                            {
                                transaction.Commit();
                            }
                            else
                            {
                                transaction.Rollback();
                                rowsAffected = 0;
                            }
                        }
                        else
                        {
                            transaction.Rollback();
                            rowsAffected = 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        rowsAffected = 0;
                        // Log the exception here
                    }
                }
            }

            return rowsAffected;
        }

        private int ExecuteUpdateOperationRevenue(OracleConnection connection, OracleTransaction transaction, string query, string remarks, int requestId)
        {
            int rowsAffected = 0;

            using (var command = new OracleCommand(query, connection))
            {
                command.Transaction = transaction;
               // command.Parameters.Add(new OracleParameter("approvedBy", OracleDbType.Varchar2) { Value = approvedBy });
                command.Parameters.Add(new OracleParameter("remarks", OracleDbType.Varchar2) { Value = remarks });
                command.Parameters.Add(new OracleParameter("requestId", OracleDbType.Varchar2) { Value = requestId });

                rowsAffected = command.ExecuteNonQuery();
            }

            return rowsAffected;
        }

        private int ExecuteInsertOperationRevenue(string role, OracleConnection connection, OracleTransaction transaction, T_CAP_REV_UMC_USER model)
        {
            int rowsAffected = 0;
            string updateQuery1 = GetInsertRejectQuery(role);
            using (var command = new OracleCommand(updateQuery1, connection))
            {
                command.Transaction = transaction;
                command.Parameters.Add(new OracleParameter("CRU_UMC", OracleDbType.Varchar2) { Value = model.CRU_UMC });
                command.Parameters.Add(new OracleParameter("CRU_TAG", OracleDbType.Varchar2) { Value = model.CRU_TAG });
                command.Parameters.Add(new OracleParameter("CRU_REQUEST_ID", OracleDbType.Varchar2) { Value = model.CUA_REQUEST_ID });
                command.Parameters.Add(new OracleParameter("CRU_STATUS", OracleDbType.Char) { Value = model.CRU_STATUS });
                command.Parameters.Add(new OracleParameter("CRU_CREATED_BY", OracleDbType.Varchar2) { Value = model.CRU_CREATED_BY });

                rowsAffected = command.ExecuteNonQuery();
            }

            return rowsAffected;
        }

        private string GetUpdateRejectQuery(string role)
        {
            switch (role.ToLower())
            {
                case "level_1":
                    return DalQueryApproval.queryUpdateLevel1Reject;
                case "level_2":
                    return DalQueryApproval.queryUpdateLevel2Reject;
                case "capex":
                    return DalQueryApproval.queryUpdateCapitalReject;
                default:
                    return string.Empty;
            }
        }

        private string GetUpdateRejectRemarks(string role, T_CAP_REV_UMC_USER model)
        {
            switch (role.ToLower())
            {
                case "level_1":
                    return model.CUA_LEVEL1_APPRD_REMARKS;
                case "level_2":
                    return model.CUA_LEVEL2_APPRD_REMARKS;
                case "capex":
                    return model.CUA_CAPACCNTS_APPRD_REMARKS;
                default:
                    return string.Empty;
            }
        }

        private string GetUpdateRejectApprovedBy(string role, T_CAP_REV_UMC_USER model)
        {
            switch (role.ToLower())
            {
                case "capex":
                    return "Capex Team";
                case "vp":
                    return "VP";
                default:
                    return string.Empty;
            }
        }

        private string GetInsertRejectQuery(string role)
        {
            switch (role.ToLower())
            {
                case "level_1":
                    return DalQueryApproval.queryUpsertRevenueTagByCapex;
                case "level_2":
                    return DalQueryApproval.queryUpsertRevenueTagByCapex;
                case "capex":
                    return DalQueryApproval.queryUpsertRevenueTagByCapex;
                default:
                    return string.Empty;
            }
        }



        //end of function



    }

    public class DalQueryApproval
    {
        public const string GetApproverScreenForLevel_1 = @"SELECT a.CUA_REQUEST_ID,
  a.CUA_UMC,
  a.CUA_USER_REMARKS,
  a.CUA_UMC_DESC,
  a.CUA_BGG,
  a.CUA_DEPTNO,
  a.CUA_UMC_TAG,
  a.CUA_LEVEL1_APPRD_BY,
  a.CUA_LEVEL1_APPRD_ON,
  a.CUA_LEVEL1_APPRD_REMARKS,
  a.CUA_LEVEL2_APPRD_BY,
  a.CUA_LEVEL2_APPRD_ON,
  a.CUA_LEVEL2_APPRD_REMARKS,
  a.CUA_CAPACCNTS_APPRD_BY,
  a.CUA_CAPACCNTS_APPRD_ON,
  a.CUA_CAPACCNTS_APPRD_REMARKS,
  a.CUA_INDENT_NO,
  r.CUR_QUESTION_ID,
  r.CUR_RESPONSE,
  r.CUR_CREATED_ON,
  r.CUR_CREATED_BY,
  q.CQM_QUES_DESC
FROM T_SIS_CAP_UMC_APRVL a
JOIN T_SIS_CAP_UMC_REQ r
ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
JOIN T_SIS_CAP_QUES_MASTER q
ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
WHERE a.CUA_STATUS   = '1'
ORDER BY a.CUA_REQUEST_ID";

        public const string GetApproverScreenForLevel_2 = @"SELECT a.CUA_REQUEST_ID,
  a.CUA_UMC,
  a.CUA_USER_REMARKS,
  a.CUA_UMC_DESC,
  a.CUA_BGG,
  a.CUA_DEPTNO,
  a.CUA_UMC_TAG,
  a.CUA_LEVEL1_APPRD_BY,
  a.CUA_LEVEL1_APPRD_ON,
  a.CUA_LEVEL1_APPRD_REMARKS,
  a.CUA_LEVEL2_APPRD_BY,
  a.CUA_LEVEL2_APPRD_ON,
  a.CUA_LEVEL2_APPRD_REMARKS,
  a.CUA_CAPACCNTS_APPRD_BY,
  a.CUA_CAPACCNTS_APPRD_ON,
  a.CUA_CAPACCNTS_APPRD_REMARKS,
  a.CUA_INDENT_NO,
  r.CUR_QUESTION_ID,
  r.CUR_RESPONSE,
  r.CUR_CREATED_ON,
  r.CUR_CREATED_BY,
  q.CQM_QUES_DESC
FROM T_SIS_CAP_UMC_APRVL a
JOIN T_SIS_CAP_UMC_REQ r
ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
JOIN T_SIS_CAP_QUES_MASTER q
ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
WHERE a.CUA_STATUS   = '2'
ORDER BY a.CUA_REQUEST_ID";

        public const string GetApproverScreenForCapex = @"SELECT a.CUA_REQUEST_ID,
  a.CUA_UMC,
  a.CUA_USER_REMARKS,
  a.CUA_UMC_DESC,
  a.CUA_BGG,
  a.CUA_DEPTNO,
  a.CUA_UMC_TAG,
  a.CUA_LEVEL1_APPRD_BY,
  a.CUA_LEVEL1_APPRD_ON,
  a.CUA_LEVEL1_APPRD_REMARKS,
  a.CUA_LEVEL2_APPRD_BY,
  a.CUA_LEVEL2_APPRD_ON,
  a.CUA_LEVEL2_APPRD_REMARKS,
  a.CUA_CAPACCNTS_APPRD_BY,
  a.CUA_CAPACCNTS_APPRD_ON,
  a.CUA_CAPACCNTS_APPRD_REMARKS,
  a.CUA_INDENT_NO,
  r.CUR_QUESTION_ID,
  r.CUR_RESPONSE,
  r.CUR_CREATED_ON,
  r.CUR_CREATED_BY,
  q.CQM_QUES_DESC
FROM T_SIS_CAP_UMC_APRVL a
JOIN T_SIS_CAP_UMC_REQ r
ON a.CUA_REQUEST_ID = r.CUR_REQUEST_ID
JOIN T_SIS_CAP_QUES_MASTER q
ON r.CUR_QUESTION_ID = q.CQM_QUES_ID
WHERE a.CUA_STATUS   = '3'
ORDER BY a.CUA_REQUEST_ID";

        public const string queryUpdateLevel1Approve = @"UPDATE T_SIS_CAP_UMC_APRVL
                                                        SET
                                                          CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1),
                                                          CUA_LEVEL1_APPRD_BY = :approvedBy,
                                                          CUA_LEVEL1_APPRD_ON = SYSDATE,
                                                          CUA_LEVEL1_APPRD_REMARKS = :remarks
                                                        WHERE CUA_REQUEST_ID = :requestId
                                                        AND CUA_STATUS ='1'";

        public const string queryUpdateLevel2Approve = @"UPDATE T_SIS_CAP_UMC_APRVL
                                                        SET
                                                          CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1),
                                                          CUA_LEVEL2_APPRD_BY = :approvedBy,
                                                          CUA_LEVEL2_APPRD_ON = SYSDATE,
                                                          CUA_LEVEL2_APPRD_REMARKS = :remarks
                                                        WHERE CUA_REQUEST_ID = :requestId
                                                        AND CUA_STATUS ='2'";

        public const string queryUpdateCapexApprove = @"UPDATE T_SIS_CAP_UMC_APRVL
                                                        SET
                                                          CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1),
                                                          CUA_CAPACCNTS_APPRD_BY = :approvedBy,
                                                          CUA_CAPACCNTS_APPRD_ON = SYSDATE,
                                                          CUA_CAPACCNTS_APPRD_REMARKS = :remarks
                                                        WHERE CUA_REQUEST_ID = :requestId
                                                        AND CUA_STATUS ='3'";

        public const string queryUpdateVpApprove = @"UPDATE T_SIS_CAP_UMC_APRVL
                                        SET CUA_VP_REMARKS = :remarks,
                                            CUA_VP_APPROVED_BY=:approvedBy,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1),
                                            CUA_VP_APPROVED_ON = SYSDATE
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='2'";

        public const string queryUpdateCapexReject = @"UPDATE T_SIS_CAP_UMC_APRVL
                                        SET CUA_CAPEX_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 3)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='1'";

        public const string queryUpdateVpReject = @"UPDATE T_SIS_CAP_UMC_APRVL
                                        SET CUA_VP_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 3)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='2'";


        public const string queryUpdateLevel1Reject = @"UPDATE T_SIS_CAP_UMC_APRVL
                                        SET CUA_LEVEL1_APPRD_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 3)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='1'";

        public const string queryUpdateLevel2Reject = @"UPDATE T_SIS_CAP_UMC_APRVL
                                        SET CUA_LEVEL2_APPRD_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 2)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='2'";

        public const string queryUpdateCapitalReject = @"UPDATE T_SIS_CAP_UMC_APRVL
                                        SET CUA_CAPACCNTS_APPRD_REMARKS = :remarks,
                                            CUA_STATUS = TO_CHAR(TO_NUMBER(CUA_STATUS) + 1)
                                            WHERE CUA_REQUEST_ID = :requestId
                                             AND CUA_STATUS='3'";


        public const string queryUpsertCapitalTagApprovalByVp = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";

        public const string queryUpsertCapitalTagApprovalByCapex = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";

        public const string queryUpsertRevenueTagByCapex = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";

        public const string queryUpsertRevenueTagByvp = @"DECLARE
                                      UMCexists number :=0;
                                      BEGIN
                                      Select COUNT(*) into UMCexists from T_SIS_CAP_REV_UMC where CRU_UMC=:CRU_UMC;
                                    if(UMCexists <= 0)
                                    THEN
                                      INSERT INTO T_SIS_CAP_REV_UMC
                                      (CRU_UMC, CRU_TAG, CRU_REQUEST_ID, CRU_STATUS, CRU_CREATED_BY, CRU_CREATED_ON)
                                      VALUES
                                      (:CRU_UMC, :CRU_TAG, :CRU_REQUEST_ID, :CRU_STATUS, :CRU_CREATED_BY, SYSDATE);
                                    ELSE
                                      UPDATE T_SIS_CAP_REV_UMC
                                      SET
                                      CRU_TAG=:CRU_TAG,
                                      CRU_CREATED_BY=:CRU_CREATED_BY,
                                      CRU_CREATED_ON=SYSDATE
                                      WHERE CRU_UMC=:CRU_UMC;
                                    END IF;
                                    END;";

        public const string ChangeIndentStatusToIntellibuy = @"UPDATE t_sis_indent_details SET Indent_Current_Status = '16' WHERE Indent_Id = :Indent_ID";
    }
}
﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.UI.WebControls;

namespace SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL
{
    public class IndentUmcStatusDAL
    {
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        //start of function

        public DataTable GetUmcsTaggedUnderIntent(string intent)
        {
            var approvalDataList = new List<CapexApprovalRequestData>();
            DataTable dt = new DataTable();
            try
            {

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();


                    using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntent, connection))
                    {

                        command.Parameters.Add(new OracleParameter(":intent", intent));

                        using (var reader = command.ExecuteReader())
                        {

                            dt.Load(reader);
                        }
                    }
                    connection.Close();
                }
                

            }
            catch (Exception ex)
            {
                return dt;
            }

            return dt;
        }


        //end of function


        //start of function
        public string GetStatusOfUMCIndent(string umc, int indent)
        {
            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {

                using (OracleCommand command = new OracleCommand(DalQueryindentUmc.queryGetStatusOfUmc, connection))
                {
                    // Set parameter values
                    command.Parameters.Add(":umc", OracleDbType.Varchar2).Value = umc;
                    command.Parameters.Add(":indent", OracleDbType.Varchar2).Value = indent;

                    try
                    {
                        connection.Open();
                        var status = command.ExecuteScalar(); // Assuming status is a single value

                        // Check if status is null
                        if (status != null)
                        {
                            return status.ToString();
                        }
                        else
                        {
                            // UMC with the given intent not found
                            return "NotFound";
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception
                        Console.WriteLine("Error fetching status: " + ex.Message);
                        return null;
                    }
                }
            }
        }

        //end od function

        //start of function

        public DataTable GetUmcsUnderIntent(string indent)
        {
            var approvalDataList = new List<CapexApprovalRequestData>();
            DataTable dt = new DataTable();
            try
            {

                using (var connection = new OracleConnection(strConnSISDB))
                {
                    connection.Open();


                    using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntentInAprvl, connection))
                    {

                        command.Parameters.Add(new OracleParameter(":indent", indent));

                        using (var reader = command.ExecuteReader())
                        {

                            dt.Load(reader);
                        }
                    }
                    connection.Close();


                }

            }
            catch (Exception ex)
            {
                return dt;
            }

            return dt;
        }


        //end of function
        // return true if it is still capex else false means tagging is either all tagged as "R" or "C"
        // means pending for intelliby
        //true mean capex, false means intellibuy(all tagged)
        //start of function

        public Boolean isPendingForCapexOrIntellibuy(string indent, OracleConnection connection)
        {
            DataTable dt = new DataTable();
            using (var command = new OracleCommand(DalQueryindentUmc.queryGetUmcsUnderIntent, connection))
            {

                command.Parameters.Add(new OracleParameter(":intent", indent));

                using (var reader = command.ExecuteReader())
                {

                    dt.Load(reader);
                }
            }

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    // Assuming you want to check the value of a column named "ColumnName"
                    string columnValue = row["TAG"].ToString();
                    string columnUmc = row["REQ_UMC_NO"].ToString();
                    // Perform your check on the column value
                    if (columnValue.Equals("N"))
                    {
                        // Check the status in another table
                        if (CheckStatusInAnotherTable(columnUmc, indent, connection))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        //end of function

        //start of function

        private Boolean CheckStatusInAnotherTable(string umc, string indent, OracleConnection connection)
        {
            string query = "select CUA_STATUS FROM T_SIS_CAP_UMC_APRVL WHERE CUA_UMC=:umc AND CUA_INDENT_NO=:indent";
            using (var command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(new OracleParameter(":umc", umc));
                command.Parameters.Add(new OracleParameter(":indent", indent));

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string status = reader["CUA_STATUS"].ToString();
                        if (status != "4")
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }


        //end of function

    }

    public class DalQueryindentUmc
    {

        public const string queryGetUmcsUnderIntent1 = @"select a.req_umc_no,  nvl(b.cru_tag,'N') tag, a.REQ_UMC_DESC description, a.REQ_UMC_BGG BGG
                                                        from t_sis_umc_indent_details a, T_SIS_CAP_REV_UMC b 
                                                        where indent_id=:intent
                                                        and req_umc_no = cru_umc(+)
                                                        and REQ_UMC_NO is not null AND REQ_UMC_NO <> ' '";
        public const string queryGetUmcsUnderIntent = @"SELECT a.req_umc_no,
  NVL(b.cru_tag,'N') tag,
  a.REQ_UMC_DESC description,
  a.REQ_UMC_BGG BGG
FROM t_sis_umc_indent_details a,
  T_SIS_CAP_REV_UMC b
WHERE indent_id =:intent
AND indent_id=CRU_REQUEST_ID(+)
AND req_umc_no  = cru_umc(+)
AND REQ_UMC_NO IS NOT NULL
AND a.ISACTIVE='Y'
AND REQ_UMC_NO <> ' '";

        public const string queryGetStatusOfUmc = @"select cua_status from t_sis_cap_umc_aprvl where cua_umc=:umc and cua_indent_no=:indent and rownum<2";

        public const string queryGetUmcsUnderIntentInAprvl = @"select cua_umc, count(*) as counter from T_SIS_CAP_UMC_APRVL where cua_indent_no=:indent
                                                               group by cua_umc";

    }
}
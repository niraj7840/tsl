﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using SIS_BACKEND_API.Models;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class Indent_DAL
    {

        Indent_qry qry = new Indent_qry();
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        indentApproval_DAL objIndentApproval = new indentApproval_DAL();

        public int GetMaxIndentId()
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                connection.Open();
                int RntVal = 0;
                try
                {


                    string query = qry.GetMaxId;

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {

                        int maxId = Convert.ToInt32(command.ExecuteScalar());


                        RntVal = maxId;

                    }


                    return RntVal;
                }
                catch (Exception ex)
                {
                    return RntVal;
                }
            }

            // Check the number of rows affected

        }

        public string GetDOPValue(decimal Indentvalue)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.GetDOPLevel;
                    using (var command = new OracleCommand(query, connection))
                    {
                        

                        //command.Parameters.Add(new OracleParameter("USERNAME", obj.USERNAME));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            if (Indentvalue > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (Indentvalue <= decimal.Parse(dt.Rows[i]["AMT"].ToString()))
                    {
                        return dt.Rows[i][0].ToString();
                    }
                }
                return "5";
            }
            return "";

        }

        public async Task<object> CreateIndentForApproval(SaveIndent obj)
        {
            OracleConnection connection = new OracleConnection(connectionString);

            connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();
            int RntVal = 0;
            
            try
            {
                if (obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                {
                    RntVal = int.Parse(obj.T_SII_INDENT_DETAILS.IndentId);
                    if (obj.IsDraft == "N")
                    {
                        UpdateIndent(obj.T_SII_INDENT_DETAILS,"L1", ref transaction, ref connection);
                    }
                    RntVal = UpdateUMC_ChildDetails(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection);
                }
                else
                {
                    RntVal = SaveIndentforApproval(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection, obj.IsDraft);

                }
                decimal totalMAP = 0;
                decimal totalStoreValue = 0;
                foreach (var model in obj.T_SIS_UMC_INDENT_DETAILS)
                {
                    try
                    { 
                       
                           
                        string responseData = await Get_MAP_VALUE_ODATA(model.REQ_UMC_NO, obj.T_SII_INDENT_DETAILS.IndentorDept);
                        if (!String.IsNullOrEmpty(responseData))
                        {
                            dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                            if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                            {
                                foreach (var rsult in responseObject.d.results)
                                {
                                    var resultObject = (Newtonsoft.Json.Linq.JObject)rsult;
                                    if (resultObject.ContainsKey("Verpr"))
                                    {
                                        model.MAP = resultObject["Verpr"].ToString();
                                    }
                                    else
                                    {
                                        model.MAP = "0";
                                    }

                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    if (model.MAP.Length == 0)
                    {
                        model.MAP = "0";
                    }

                    decimal requestQty =decimal.Parse( model.QTY);
                    decimal storeQty = 0;
                    if (obj.T_SII_INDENT_DETAILS.STATUS == CommonConstants.INTERPENDING && model.ISCONSUMABLE == "Y")
                    {
                        storeQty = 0;
                    }
                    else
                    {

                        storeQty = decimal.Parse(model.aiulpInventory) + decimal.Parse(model.intraInventory) + decimal.Parse(model.interInventory);
                    }
                    totalStoreValue = totalStoreValue + storeQty;
                    decimal LastQty = requestQty < storeQty ? requestQty : storeQty;
                    decimal CalMAPValue = decimal.Parse(model.MAP) *LastQty;
                    totalMAP = totalMAP + CalMAPValue;
                    string Umc_Indent_Id = "0";
                    if (model.UMC_INDENT_ID.Length > 0)
                    {
                        List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.UMC_INDENT_ID == model.UMC_INDENT_ID && x.INDENT_ID == model.INDENT_ID && x.DEST_SLOC == model.DEST_SLOC).ToList<T_SII_WORK_FLOW>();

                        Umc_Indent_Id = UpdateIndentChildDetails(model, ref transaction, ref connection, RntVal);
                        

                    }
                    else
                    {
                        Umc_Indent_Id = SaveIndentChildDetails(model, ref transaction, ref connection, RntVal.ToString());
                        

                    }

                }
                string LVL = GetDOPValue(totalMAP);
                string typ = "";
                if (totalStoreValue > 0)
                {
                    typ = "OK";
                    var result = UpdateLevelStatusForIndId(RntVal.ToString(), LVL, totalMAP.ToString(), ref transaction, ref connection);
                }
                else
                {
                    typ = "CAPX";
                    var result = UpdateLevelStatusForCapX(RntVal.ToString(), LVL, totalMAP.ToString(), ref transaction, ref connection);
                }
                transaction.Commit();

              if (typ == "OK")  objIndentApproval.TriggerEmailToApprover(connection, RntVal.ToString(), 1, null);
               
                //RntVal = GetMaxIndentId();
                return new { StatusCode = typ, data = RntVal.ToString(), Typ = typ };
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return new { StatusCode = "error", data = "0", Typ = "" };
            }
            finally { connection.Close(); }


            // Check the number of rows affected

        }
        public async Task<int> CreateIndent(SaveIndent obj)
        {
            OracleConnection connection = new OracleConnection(connectionString);

            connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();
            int RntVal = 0;
            try
            {
                if (obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                {
                    if (obj.IsDraft == "N")
                    {
                        UpdateIndent(obj.T_SII_INDENT_DETAILS,"CMPLT", ref transaction, ref connection);
                    }
                    RntVal = UpdateUMC_ChildDetails(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection);
                }
                else
                {
                    RntVal = SaveIndent(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection, obj.IsDraft);

                }

                foreach (var model in obj.T_SIS_UMC_INDENT_DETAILS)
                {
                    try
                    {
                        string responseData = await Get_MAP_VALUE_ODATA(model.REQ_UMC_NO, obj.T_SII_INDENT_DETAILS.IndentorDept);
                        if (!String.IsNullOrEmpty(responseData))
                        {
                            dynamic responseObject = JsonConvert.DeserializeObject<dynamic>(responseData);
                            if (responseObject != null && responseObject.d != null && responseObject.d.results != null)
                            {
                                foreach (var result in responseObject.d.results)
                                {
                                    model.MAP = ((Newtonsoft.Json.Linq.JProperty)((Newtonsoft.Json.Linq.JContainer)result).Last).Value.ToString();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    if (model.MAP.Length == 0)
                    {
                        model.MAP = "0";
                    }
                    string Umc_Indent_Id = "0";
                    if (model.UMC_INDENT_ID.Length > 0)
                    {
                        List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.UMC_INDENT_ID == model.UMC_INDENT_ID && x.INDENT_ID == model.INDENT_ID && x.DEST_SLOC == model.DEST_SLOC).ToList<T_SII_WORK_FLOW>();

                        Umc_Indent_Id = UpdateIndentChildDetails(model, ref transaction, ref connection, RntVal);
                        if (obj.IsDraft == "N")
                        {
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.UMC_INDENT_ID = model.UMC_INDENT_ID;
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                string Wf_ID = SaveWorkFlowDetails(wfmodel, ref transaction, ref connection, Umc_Indent_Id);
                                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);

                            }
                        }

                    }
                    else
                    {
                        Umc_Indent_Id = SaveIndentChildDetails(model, ref transaction, ref connection, RntVal.ToString());
                        if (obj.IsDraft == "N" && obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                        {
                            List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.INDENT_ID == model.INDENT_ID && x.REQ_UMC_NO == model.REQ_UMC_NO).ToList<T_SII_WORK_FLOW>();
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                string Wf_ID = SaveWorkFlowDetails(wfmodel, ref transaction, ref connection, Umc_Indent_Id);

                                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);
                            }
                        }
                        else if (obj.IsDraft == "N" && obj.T_SII_INDENT_DETAILS.IndentId.Length == 0)
                        {
                            List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.REQ_UMC_NO == model.REQ_UMC_NO).ToList<T_SII_WORK_FLOW>();
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                string Wf_ID = SaveWorkFlowDetailsDirect(wfmodel, ref transaction, ref connection, Umc_Indent_Id);

                                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);
                            }
                        }

                    }

                }

                transaction.Commit();
                //RntVal = GetMaxIndentId();
                return RntVal;
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return 0;
            }
            finally { connection.Close(); }


            // Check the number of rows affected

        }
        public int CreateIndentForDOP(SaveIndent obj , ref OracleConnection connection, ref OracleTransaction transaction)
        {
            
            
            int RntVal = 0;
            try
            {
                if (obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                {
                    RntVal = int.Parse(obj.T_SII_INDENT_DETAILS.IndentId);
                    if (obj.IsDraft == "N")
                    {
                        obj.T_SII_INDENT_DETAILS.LEVEL = "CMPLT";
                        updateIndentForApproval(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection);
                    }
                    RntVal = UpdateUMC_ChildDetails(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection);
                }
                else
                {
                    RntVal = SaveIndent(obj.T_SII_INDENT_DETAILS, ref transaction, ref connection, obj.IsDraft);

                }

                foreach (var model in obj.T_SIS_UMC_INDENT_DETAILS)
                {
                    

                    string Umc_Indent_Id = "0";
                    if (model.UMC_INDENT_ID.Length > 0)
                    {
                        List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.UMC_INDENT_ID == model.UMC_INDENT_ID && x.INDENT_ID == model.INDENT_ID && x.DEST_SLOC == model.DEST_SLOC).ToList<T_SII_WORK_FLOW>();

                        Umc_Indent_Id = UpdateIndentChildDetailsForDOP(model, ref transaction, ref connection, RntVal);
                        if (obj.IsDraft == "N")
                        {
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.UMC_INDENT_ID = model.UMC_INDENT_ID;
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                string Wf_ID = SaveWorkFlowDetails(wfmodel, ref transaction, ref connection, Umc_Indent_Id);
                                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);

                            }
                        }

                    }
                    else
                    {
                        Umc_Indent_Id = SaveIndentChildDetails(model, ref transaction, ref connection, RntVal.ToString());
                        if (obj.IsDraft == "N" && obj.T_SII_INDENT_DETAILS.IndentId.Length > 0)
                        {
                            List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.INDENT_ID == model.INDENT_ID && x.REQ_UMC_NO == model.REQ_UMC_NO).ToList<T_SII_WORK_FLOW>();
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                string Wf_ID = SaveWorkFlowDetails(wfmodel, ref transaction, ref connection, Umc_Indent_Id);

                                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);
                            }
                        }
                        else if (obj.IsDraft == "N" && obj.T_SII_INDENT_DETAILS.IndentId.Length == 0)
                        {
                            List<T_SII_WORK_FLOW> lst = obj.T_SII_WORK_FLOW.Where(x => x.REQ_UMC_NO == model.REQ_UMC_NO).ToList<T_SII_WORK_FLOW>();
                            foreach (var wfmodel in lst)
                            {
                                wfmodel.INDENT_ID = model.INDENT_ID;
                                string Wf_ID = SaveWorkFlowDetailsDirect(wfmodel, ref transaction, ref connection, Umc_Indent_Id);

                                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);
                            }
                        }

                    }

                }

                //transaction.Commit();
                //RntVal = GetMaxIndentId();
                return RntVal;
            }
            catch (Exception ex)
            {
                //transaction.Rollback();
                return 0;
            }
            finally {  }


            // Check the number of rows affected

        }

        public int SaveBatchWorkflow(T_SII_WORK_FLOW wfmodel)
        {
            OracleConnection connection = new OracleConnection(connectionString);

            connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();

            try
            {

                string Wf_ID = SaveWorkFlowDetails(wfmodel, ref transaction, ref connection, wfmodel.UMC_INDENT_ID);
                insertWorlflowAudit(wfmodel, ref transaction, ref connection, Wf_ID);



                transaction.Commit();

                return 1;
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return 0;
            }
            finally { connection.Close(); }


            // Check the number of rows affected

        }
        public int SaveIndentforApproval(T_SII_INDENT_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection, string typ)
        {

            int primaryKeyValue = 0;
            string query = qry.InsertIndent;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":IndentorLoc", obj.IndentorLoc);
                command.Parameters.Add(":IndentorPlant", obj.IndentorPlant);
                command.Parameters.Add(":IndentorDept", obj.IndentorDept);
                command.Parameters.Add(":IndentDesc", obj.IndentDesc);

                command.Parameters.Add(":IndentRemarks", obj.IndentRemarks);
                command.Parameters.Add(":IndentStatus", "L1");
                command.Parameters.Add(":UserName", obj.UserName);
                command.Parameters.Add(":STATUS", obj.STATUS);

                OracleParameter outputParameter = new OracleParameter(":PrimaryKey", OracleDbType.Int32);
                outputParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(outputParameter);

                command.ExecuteNonQuery();

                // Retrieve the primary key value
                primaryKeyValue = Convert.ToInt32(((OracleDecimal)outputParameter.Value).Value);

            }


            return primaryKeyValue;


            // Check the number of rows affected

        }
        public int SaveIndent(T_SII_INDENT_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection, string typ)
        {

            int primaryKeyValue = 0;
            string query = qry.InsertIndent;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":IndentorLoc", obj.IndentorLoc);
                command.Parameters.Add(":IndentorPlant", obj.IndentorPlant);
                command.Parameters.Add(":IndentorDept", obj.IndentorDept);
                command.Parameters.Add(":IndentDesc", obj.IndentDesc);

                command.Parameters.Add(":IndentRemarks", obj.IndentRemarks);
                command.Parameters.Add(":IndentStatus", typ == "Y" ? "DRAFT" : "CMPLT");
                command.Parameters.Add(":UserName", obj.UserName);
                command.Parameters.Add(":STATUS", obj.STATUS);

                OracleParameter outputParameter = new OracleParameter(":PrimaryKey", OracleDbType.Int32);
                outputParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(outputParameter);

                command.ExecuteNonQuery();

                // Retrieve the primary key value
                primaryKeyValue = Convert.ToInt32(((OracleDecimal)outputParameter.Value).Value);

            }


            return primaryKeyValue;


            // Check the number of rows affected

        }
        public void UpdateIndent(T_SII_INDENT_DETAILS obj,string CSTATE, ref OracleTransaction transaction, ref OracleConnection connection)
        {


            string query = qry.updateIndent;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":IndentDesc", obj.IndentDesc);
                command.Parameters.Add(":IndentRemarks", obj.IndentRemarks);
                command.Parameters.Add(":INDENT_STATUS", CSTATE);
                
                command.Parameters.Add(":UserName", obj.UserName);
                command.Parameters.Add(":STATUS", obj.STATUS);
                command.Parameters.Add(":IndentId", obj.IndentId);



                command.ExecuteNonQuery();
            }




            // Check the number of rows affected

        }

        public void updateIndentForApproval(T_SII_INDENT_DETAILS obj, ref OracleTransaction transaction, ref OracleConnection connection)
        {


            string query = qry.updateIndentForApproval;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                
                command.Parameters.Add(":INDENT_STATUS", obj.LEVEL);
                command.Parameters.Add(":UserName", obj.UserName);
                command.Parameters.Add(":STATUS", obj.STATUS);
                command.Parameters.Add(":IndentId", obj.IndentId);



                command.ExecuteNonQuery();
            }




            // Check the number of rows affected

        }
        public string SaveIndentChildDetails(T_SIS_UMC_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection, string RntVal)
        {

            string Umc_Indent_Id = "0";

            string query = qry.InsertIndentChild;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":REQ_UMC_NO", OracleDbType.Varchar2).Value = model.REQ_UMC_NO;
                command.Parameters.Add(":INDENT_ID", OracleDbType.Varchar2).Value = RntVal;
                command.Parameters.Add(":REQ_UMC_DESC", OracleDbType.Varchar2).Value = model.REQ_UMC_DESC;
                command.Parameters.Add(":EXISTING_UMC", OracleDbType.Varchar2).Value = model.EXISTING_UMC;
                command.Parameters.Add(":EXIS_UMC_DESC", OracleDbType.Varchar2).Value = model.EXIS_UMC_DESC;
                command.Parameters.Add(":DEST_SLOC", OracleDbType.Varchar2).Value = model.DEST_SLOC;
                command.Parameters.Add(":UOM", OracleDbType.Varchar2).Value = model.UOM;
                command.Parameters.Add(":QTY", OracleDbType.Varchar2).Value = model.QTY;
                command.Parameters.Add(":IS_REFURBISHABLE", OracleDbType.Varchar2).Value = model.IS_REFURBISHABLE;
                command.Parameters.Add(":IS_CRITICAL", OracleDbType.Varchar2).Value = model.IS_CRITICAL;
                command.Parameters.Add(":IS_PERISHABLE", OracleDbType.Varchar2).Value = model.IS_PERISHABLE;
                command.Parameters.Add(":REQ_DT", OracleDbType.Varchar2).Value = model.REQ_DT;
                command.Parameters.Add(":CONSUMP_DT", OracleDbType.Varchar2).Value = model.consumptionDate;
                command.Parameters.Add(":PROC_TYPE", OracleDbType.Varchar2).Value = model.PROC_TYPE;
                command.Parameters.Add(":USERNAME", OracleDbType.Varchar2).Value = model.USERNAME;
                command.Parameters.Add(":AIULP_INVENTORY", OracleDbType.Varchar2).Value = model.aiulpInventory;
                command.Parameters.Add(":INTRA_INVENTORY", OracleDbType.Varchar2).Value = model.intraInventory;
                command.Parameters.Add(":INTER_INVENTORY", OracleDbType.Varchar2).Value = model.interInventory;
                command.Parameters.Add(":UMC_STATUS", OracleDbType.Varchar2).Value = model.UMC_STATUS;
                command.Parameters.Add(":PRICE_PER_ITEM", OracleDbType.Varchar2).Value = model.rate;
                command.Parameters.Add(":REQUIREMENT_DATE", OracleDbType.Varchar2).Value = model.requestedOn;
                command.Parameters.Add(":REQ_UMC_BGG", OracleDbType.Varchar2).Value = model.materialBGG;
                command.Parameters.Add(":FOD_TYPE", OracleDbType.Varchar2).Value = model.fodType;
                command.Parameters.Add(":DOCUMENT_TYP", OracleDbType.Varchar2).Value = model.docType;
                command.Parameters.Add(":CURRENCY", OracleDbType.Varchar2).Value = model.currency;
                command.Parameters.Add(":PUR_GRP", OracleDbType.Varchar2).Value = model.purchaseGroup;
                command.Parameters.Add(":DEL_POINT", OracleDbType.Varchar2).Value = model.delPoint;
                command.Parameters.Add(":MAP", OracleDbType.Varchar2).Value = model.MAP;
                command.Parameters.Add(":ISCONSUMABLE", OracleDbType.Varchar2).Value = model.ISCONSUMABLE;

                OracleParameter outputParameter = new OracleParameter(":PrimaryKey", OracleDbType.Int32);
                outputParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(outputParameter);

                command.ExecuteNonQuery();

                // Retrieve the primary key value
                Umc_Indent_Id = (((OracleDecimal)outputParameter.Value).Value).ToString();


            }
            return Umc_Indent_Id;

        }

        public string UpdateIndentChildDetails(T_SIS_UMC_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection, int Indent_Id)
        {



            string query = qry.updateIndentChild;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":REQ_UMC_NO", OracleDbType.Varchar2).Value = model.REQ_UMC_NO;

                command.Parameters.Add(":REQ_UMC_DESC", OracleDbType.Varchar2).Value = model.REQ_UMC_DESC;
                command.Parameters.Add(":EXISTING_UMC", OracleDbType.Varchar2).Value = model.EXISTING_UMC;
                command.Parameters.Add(":EXIS_UMC_DESC", OracleDbType.Varchar2).Value = model.EXIS_UMC_DESC;
                command.Parameters.Add(":DEST_SLOC", OracleDbType.Varchar2).Value = model.DEST_SLOC;
                command.Parameters.Add(":UOM", OracleDbType.Varchar2).Value = model.UOM;
                command.Parameters.Add(":QTY", OracleDbType.Varchar2).Value = model.QTY;
                command.Parameters.Add(":IS_REFURBISHABLE", OracleDbType.Varchar2).Value = model.IS_REFURBISHABLE;
                command.Parameters.Add(":IS_CRITICAL", OracleDbType.Varchar2).Value = model.IS_CRITICAL;
                command.Parameters.Add(":IS_PERISHABLE", OracleDbType.Varchar2).Value = model.IS_PERISHABLE;
                command.Parameters.Add(":REQ_DT", OracleDbType.Varchar2).Value = model.REQ_DT;
                command.Parameters.Add(":CONSUMP_DT", OracleDbType.Varchar2).Value = model.consumptionDate;
                command.Parameters.Add(":PROC_TYPE", OracleDbType.Varchar2).Value = model.PROC_TYPE;
                command.Parameters.Add(":USERNAME", OracleDbType.Varchar2).Value = model.USERNAME;
                command.Parameters.Add(":AIULP_INVENTORY", OracleDbType.Varchar2).Value = model.aiulpInventory;
                command.Parameters.Add(":INTRA_INVENTORY", OracleDbType.Varchar2).Value = model.intraInventory;
                command.Parameters.Add(":INTER_INVENTORY", OracleDbType.Varchar2).Value = model.interInventory;
                command.Parameters.Add(":UMC_STATUS", OracleDbType.Varchar2).Value = model.UMC_STATUS;
                command.Parameters.Add(":PRICE_PER_ITEM", OracleDbType.Varchar2).Value = model.rate;
                command.Parameters.Add(":REQUIREMENT_DATE", OracleDbType.Varchar2).Value = model.requestedOn;
                command.Parameters.Add(":REQ_UMC_BGG", OracleDbType.Varchar2).Value = model.materialBGG;
                command.Parameters.Add(":FOD_TYPE", OracleDbType.Varchar2).Value = model.fodType;
                command.Parameters.Add(":DOCUMENT_TYP", OracleDbType.Varchar2).Value = model.docType;
                command.Parameters.Add(":CURRENCY", OracleDbType.Varchar2).Value = model.currency;
                command.Parameters.Add(":PUR_GRP", OracleDbType.Varchar2).Value = model.purchaseGroup;
                command.Parameters.Add(":DEL_POINT", OracleDbType.Varchar2).Value = model.delPoint;
                command.Parameters.Add(":MAP", OracleDbType.Varchar2).Value = model.MAP;
                command.Parameters.Add(":ISCONSUMABLE", OracleDbType.Varchar2).Value = model.ISCONSUMABLE;

                command.Parameters.Add(":UMC_INDENT_ID", OracleDbType.Varchar2).Value = model.UMC_INDENT_ID;
                command.Parameters.Add(":INDENT_ID", OracleDbType.Varchar2).Value = Indent_Id.ToString();

                command.ExecuteNonQuery();


            }

            return model.UMC_INDENT_ID.ToString();
        }
        public string UpdateIndentChildDetailsForDOP(T_SIS_UMC_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection, int Indent_Id)
        {



            string query = qry.updateIndentChildDOP;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":REQ_UMC_NO", OracleDbType.Varchar2).Value = model.REQ_UMC_NO;

                command.Parameters.Add(":REQ_UMC_DESC", OracleDbType.Varchar2).Value = model.REQ_UMC_DESC;
                command.Parameters.Add(":EXISTING_UMC", OracleDbType.Varchar2).Value = model.EXISTING_UMC;
                command.Parameters.Add(":EXIS_UMC_DESC", OracleDbType.Varchar2).Value = model.EXIS_UMC_DESC;
                command.Parameters.Add(":DEST_SLOC", OracleDbType.Varchar2).Value = model.DEST_SLOC;
                command.Parameters.Add(":UOM", OracleDbType.Varchar2).Value = model.UOM;
                command.Parameters.Add(":QTY", OracleDbType.Varchar2).Value = model.QTY;
                command.Parameters.Add(":IS_REFURBISHABLE", OracleDbType.Varchar2).Value = model.IS_REFURBISHABLE;
                command.Parameters.Add(":IS_CRITICAL", OracleDbType.Varchar2).Value = model.IS_CRITICAL;
                command.Parameters.Add(":IS_PERISHABLE", OracleDbType.Varchar2).Value = model.IS_PERISHABLE;
                command.Parameters.Add(":REQ_DT", OracleDbType.Varchar2).Value = model.REQ_DT;
                command.Parameters.Add(":CONSUMP_DT", OracleDbType.Varchar2).Value = model.consumptionDate;
                command.Parameters.Add(":PROC_TYPE", OracleDbType.Varchar2).Value = model.PROC_TYPE;
                command.Parameters.Add(":USERNAME", OracleDbType.Varchar2).Value = model.USERNAME;
                command.Parameters.Add(":AIULP_INVENTORY", OracleDbType.Varchar2).Value = model.aiulpInventory;
                command.Parameters.Add(":INTRA_INVENTORY", OracleDbType.Varchar2).Value = model.intraInventory;
                command.Parameters.Add(":INTER_INVENTORY", OracleDbType.Varchar2).Value = model.interInventory;
                command.Parameters.Add(":UMC_STATUS", OracleDbType.Varchar2).Value = model.UMC_STATUS;
                command.Parameters.Add(":PRICE_PER_ITEM", OracleDbType.Varchar2).Value = model.rate;
                command.Parameters.Add(":REQUIREMENT_DATE", OracleDbType.Varchar2).Value = model.requestedOn;
                command.Parameters.Add(":REQ_UMC_BGG", OracleDbType.Varchar2).Value = model.materialBGG;
                command.Parameters.Add(":FOD_TYPE", OracleDbType.Varchar2).Value = model.fodType;
                command.Parameters.Add(":DOCUMENT_TYP", OracleDbType.Varchar2).Value = model.docType;
                command.Parameters.Add(":CURRENCY", OracleDbType.Varchar2).Value = model.currency;
                command.Parameters.Add(":PUR_GRP", OracleDbType.Varchar2).Value = model.purchaseGroup;
                command.Parameters.Add(":DEL_POINT", OracleDbType.Varchar2).Value = model.delPoint;
                command.Parameters.Add(":ISCONSUMABLE", OracleDbType.Varchar2).Value = model.ISCONSUMABLE;

                command.Parameters.Add(":UMC_INDENT_ID", OracleDbType.Varchar2).Value = model.UMC_INDENT_ID;
                command.Parameters.Add(":INDENT_ID", OracleDbType.Varchar2).Value = Indent_Id.ToString();

                command.ExecuteNonQuery();


            }

            return model.UMC_INDENT_ID.ToString();
        }

        public string SaveWorkFlowDetails(T_SII_WORK_FLOW model, ref OracleTransaction transaction, ref OracleConnection connection, string Umc_Indent_Id)
        {
            string Wf_ID = "0";
            string APPON = "null";
            if (model.WF_TYPE == "AIULP")
            {
                model.WF_EXPIRY_DT = "0";
                APPON = "sysdate";

            }
            else
            {
                model.WF_EXPIRY_DT = GetExpiryDays().ToString();

            }
            string Dt = DateTime.Now.AddDays(int.Parse(model.WF_EXPIRY_DT)).ToString("dd-MMM-yyyy 23:59:59");
            string query = qry.InsertWorkFlow;

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":UMC_INDENT_ID", Umc_Indent_Id);

                //command.Parameters.Add(":INDENT_ID", model.INDENT_ID);
                command.Parameters.Add(":REQ_UMC_NO", model.REQ_UMC_NO);
                // command.Parameters.Add(":DEST_SLOC", model.SRC_LOC_DESC==""?model.DEST_SLOC: model.SRC_LOC_DESC);

                command.Parameters.Add(":SRC_LOC_ID", model.SRC_LOC_DESC);
                command.Parameters.Add(":SRC_LOC_DESC", model.SRC_LOC_ID);
                command.Parameters.Add(":SRC_PLANT_ID", model.SRC_PLANT_ID);
                command.Parameters.Add(":SRC_PLANT_DESC", model.SRC_PLANT_DESC);
                command.Parameters.Add(":SRC_DEPT_ID", model.SRC_DEPT_ID);
                command.Parameters.Add(":SRC_DEPT_DESC", "");
                command.Parameters.Add(":REQ_QUANTITY", model.REQ_QUANTITY);
                if (model.WF_TYPE == "AIULP")
                {
                    command.Parameters.Add(":APPROVED_QTY", model.REQ_QUANTITY);
                }
                else
                {
                    command.Parameters.Add(":APPROVED_QTY", "0");
                }
                command.Parameters.Add(":WF_TYPE", model.WF_TYPE == "" ? "INTRA" : model.WF_TYPE);
                command.Parameters.Add(":WF_STATUS", model.WF_STATUS);
                command.Parameters.Add(":DT", Dt);
                command.Parameters.Add(":WF_REMARKS", model.WF_REMARKS);
                command.Parameters.Add(":USERNAME", model.USERNAME);
                command.Parameters.Add(":SRC_SLOC", model.SLOC);
                command.Parameters.Add(":STOCK_AGE", int.Parse(model.InvAge).ToString());
                command.Parameters.Add(":TAGED_UMC", model.MappedMaterial);
                command.Parameters.Add(":AIULP_QTY", model.AIULP_QTY);
                command.Parameters.Add(":INTRA_QTY", model.INTRA_QTY);
                command.Parameters.Add(":INTER_QTY", model.INTER_QTY);

                if (model.WF_TYPE == "AIULP")
                {
                    command.Parameters.Add(":APP_ON", DateTime.Now.Date);
                }
                else
                {
                    command.Parameters.Add(":APP_ON", null);
                }
                OracleParameter outputParameter = new OracleParameter(":PrimaryKey", OracleDbType.Int32);
                outputParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(outputParameter);

                command.ExecuteNonQuery();

                // Retrieve the primary key value
                Wf_ID = (((OracleDecimal)outputParameter.Value).Value).ToString();
            }


            return Wf_ID;
        }
        public string SaveWorkFlowDetailsDirect(T_SII_WORK_FLOW model, ref OracleTransaction transaction, ref OracleConnection connection, string UMC_Indent_ID)
        {
            string WF_Id = "0";
            string APPON = "null";
            if (model.WF_TYPE == "AIULP")
            {
                model.WF_EXPIRY_DT = "0";
                APPON = "null";
            }
            else
            {

                model.WF_EXPIRY_DT = GetExpiryDays().ToString();

            }
            if(connection.State==ConnectionState.Closed)
            {
                connection.Open();
            }
            string Dt = DateTime.Now.AddDays(int.Parse(model.WF_EXPIRY_DT)).ToString("dd-MMM-yyyy 23:59:59");
            string query = qry.InsertWorkFlow;

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":UMC_INDENT_ID", UMC_Indent_ID);

                //command.Parameters.Add(":INDENT_ID", model.INDENT_ID);
                command.Parameters.Add(":REQ_UMC_DESC", model.REQ_UMC_NO);
                //  command.Parameters.Add(":DEST_SLOC", model.SRC_LOC_DESC);

                command.Parameters.Add(":SRC_LOC_ID", model.SRC_LOC_DESC);
                command.Parameters.Add(":SRC_LOC_DESC", "");
                command.Parameters.Add(":SRC_PLANT_ID", model.SRC_PLANT_ID);
                command.Parameters.Add(":SRC_PLANT_DESC", model.SRC_PLANT_DESC);
                command.Parameters.Add(":SRC_DEPT_ID", model.SRC_DEPT_ID);
                command.Parameters.Add(":SRC_DEPT_DESC", model.SRC_DEPT_DESC);
                command.Parameters.Add(":REQ_QUANTITY", model.REQ_QUANTITY);
                if (model.WF_TYPE == "AIULP")
                {
                    command.Parameters.Add(":APPROVED_QTY", model.REQ_QUANTITY);
                }
                else
                {
                    command.Parameters.Add(":APPROVED_QTY", "0");
                }

                command.Parameters.Add(":WF_TYPE", model.WF_TYPE == "" ? "INTRA" : model.WF_TYPE);
                command.Parameters.Add(":WF_STATUS", model.WF_STATUS);
                command.Parameters.Add(":DT", Dt);
                command.Parameters.Add(":WF_REMARKS", model.WF_REMARKS);
                command.Parameters.Add(":USERNAME", model.USERNAME);
                command.Parameters.Add(":SRC_SLOC", model.SLOC);
                command.Parameters.Add(":STOCK_AGE", int.Parse(model.InvAge).ToString());
                command.Parameters.Add(":TAGED_UMC", model.MappedMaterial);
                command.Parameters.Add(":AIULP_QTY", model.AIULP_QTY);
                command.Parameters.Add(":INTRA_QTY", model.INTRA_QTY);
                command.Parameters.Add(":INTER_QTY", model.INTER_QTY);

               // command.Parameters.Add(":WF_TYPE", model.WF_TYPE == "" ? "INTRA" : model.WF_TYPE);
               if(model.WF_TYPE== "AIULP")
                {
                    command.Parameters.Add(":APP_ON", DateTime.Now.Date);
                }
                else
                {
                    command.Parameters.Add(":APP_ON", null);
                }
              // ,decode(:WF_TYPE, 'AIULP', sysdate, null)
                OracleParameter outputParameter = new OracleParameter(":PrimaryKey", OracleDbType.Int32);
                outputParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(outputParameter);

                command.ExecuteNonQuery();

                // Retrieve the primary key value
                WF_Id = (((OracleDecimal)outputParameter.Value).Value).ToString();
            }


            return WF_Id;
        }

        public int UpdateUMC_ChildDetails(T_SII_INDENT_DETAILS model, ref OracleTransaction transaction, ref OracleConnection connection)
        {


            string query = qry.UpdateIndentChildStatus;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":UserName", model.UserName);
                command.Parameters.Add(":INDENT_ID", model.IndentId);




                command.ExecuteNonQuery();
            }
            return Convert.ToInt32(model.IndentId);


        }

        public void insertWorlflowAudit(T_SII_WORK_FLOW model, ref OracleTransaction transaction, ref OracleConnection connection, string Wf_Id)
        {


            string query = qry.oraInsertWorkFlowAudit;

            using (OracleCommand command = new OracleCommand(query, connection))
            {


                command.Parameters.Add(":Wf_ID", Wf_Id);
                command.Parameters.Add(":WF_TYPE", model.WF_TYPE);

                command.Parameters.Add(":CRT_BY", model.USERNAME);



                command.ExecuteNonQuery();
            }



        }

        public void UpdateStatusForIndId(string indId, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            string query = qry.UpdateStatus;

            using (OracleCommand command = new OracleCommand(query, connection))
            {

                command.Parameters.Add(":INDENT_ID", indId);



                command.ExecuteNonQuery();
            }




        }

        public int UpdateLevelStatusForIndId(string indId, string LVL, string MAP, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            string query = qry.UpdateaindentLvl;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":LVL", LVL);
                command.Parameters.Add(":MAP", MAP);
                command.Parameters.Add(":INDENT_ID", indId);



               return command.ExecuteNonQuery();
            }




        }
        public int UpdateLevelStatusForCapX(string indId, string LVL, string MAP, ref OracleTransaction transaction, ref OracleConnection connection)
        {

            string query = qry.UpdateindentForCapx;

            using (OracleCommand command = new OracleCommand(query, connection))
            {
                command.Parameters.Add(":LVL", "0");
                command.Parameters.Add(":MAP", "0");
                command.Parameters.Add(":INDENT_ID", indId);



                return command.ExecuteNonQuery();
            }




        }

        int GetExpiryDays()
        {
            DateTime currentDate = DateTime.Today;


            int dys = 0;
            for (int i = 1; i <= 5; i++)
            {
                DateTime futureDate = currentDate.AddDays(dys);
                if (futureDate.DayOfWeek == DayOfWeek.Saturday || futureDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    i = i - 1;
                }
                dys = dys + 1;
            }
            return dys;
        }

        public async Task<string> Get_MAP_VALUE_ODATA(string UMC, string DEPT)
        {
            string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
            //string apiUrl = BaseURL + "opu/odata/sap/YMPI_BUDGET_DETAILS_SRV/BUDGET_detailSet?$filter=( Department eq '" + Dept + "' )&$format=json";
            string apiUrl = BaseURL + "opu/odata/sap/YMPI_AVG_PRICE_SRV/It_detailsSet?$filter=( InputMaterial eq '" + UMC + "' and Department eq '" + DEPT + "' )&$format=json";

            string responseData = "";

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                // Setting the username and password for basic authentication
                string username = ConfigurationManager.AppSettings["ODataUserName"];
                string password = ConfigurationManager.AppSettings["ODataPassword"];
                string authInfo = username + ":" + password;
                string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl).ConfigureAwait(false);

                    if (response.IsSuccessStatusCode)
                    {
                        responseData = await response.Content.ReadAsStringAsync();

                    }
                    else
                    {
                        responseData = "";// or BadRequest() or NotFound() based on your needs
                    }
                }
                catch (HttpRequestException ex)
                {
                    responseData = ""; // Return the exception details
                }
            }
            return responseData;
        }


    }




    public class Indent_qry
    {
        public string GetMaxId = @"select nvl(max(INDENT_ID),0) as IndentId from T_SIS_INDENT_DETAILS";
        public string InsertIndent = @"INSERT INTO T_SIS_INDENT_DETAILS 
                    (INDENT_ID,INDENTOR_LOC, INDENTOR_PLANT, INDENTOR_DEPT, INDENT_DESC, 
                    INDENT_REMARKS,INDENT_STATUS, INDENT_CRT_BY, INDENT_CRT_DT,INDENT_CURRENT_STATUS) 
                    VALUES 
                    (
(select nvl(max(INDENT_ID),0)+1 from T_SIS_INDENT_DETAILS), :IndentorLoc, :IndentorPlant, :IndentorDept, :IndentDesc, 
                    :IndentRemarks, :IndentStatus, :UserName, sysdate,:STATUS) RETURNING INDENT_ID INTO :PrimaryKey";
        public string updateIndent = @"UPDATE T_SIS_INDENT_DETAILS 
                    SET INDENT_DESC =:IndentDesc,
INDENT_REMARKS=:IndentRemarks ,INDENT_STATUS=:INDENT_STATUS, INDENT_MOD_BY=:UserName, INDENT_MOD_DT=SYSDATE,INDENT_CURRENT_STATUS=:STATUS
where INDENT_ID=:IndentId";

        public string updateIndentForApproval = @"UPDATE T_SIS_INDENT_DETAILS 
                    SET INDENT_STATUS=:INDENT_STATUS, INDENT_MOD_BY=:UserName, INDENT_MOD_DT=SYSDATE,INDENT_CURRENT_STATUS=:STATUS
where INDENT_ID=:IndentId";

        public string UpdateIndentChildStatus = @"UPDATE T_SIS_UMC_INDENT_DETAILS SET ISACTIVE='N',MOD_BY=:UserName,MOD_DT=SYSDATE WHERE to_char(INDENT_ID)=:IndentId";
        public string InsertIndentChild = @"INSERT INTO T_SIS_UMC_INDENT_DETAILS
(UMC_INDENT_ID, REQ_UMC_NO, INDENT_ID, REQ_UMC_DESC,
EXISTING_UMC, EXIS_UMC_DESC, DEST_SLOC, UOM, QTY,
IS_REFURBISHABLE, IS_CRITICAL, IS_PERISHABLE, REQ_DT,
CONSUMP_DT, PROC_TYPE, CRT_BY, CRT_DT,ISACTIVE,AIULP_INVENTORY,INTRA_INVENTORY,INTER_INVENTORY,UMC_STATUS,PRICE_PER_ITEM,
REQUIREMENT_DATE,
REQ_UMC_BGG,
FOD_TYPE,
DOCUMENT_TYPE,
CURRENCY,TOTAL_SAP_DOC_QTY,PUR_GRP,DEL_POINT,MAP_VALUE,IS_CONSUMABLE)
VALUES
((select nvl(max(UMC_INDENT_ID),0)+1 from T_SIS_UMC_INDENT_DETAILS), :REQ_UMC_NO, nvl(:INDENT_ID,(select nvl(max(INDENT_ID),0) from T_SIS_INDENT_DETAILS)), :REQ_UMC_DESC,
:EXISTING_UMC, :EXIS_UMC_DESC, :DEST_SLOC, :UOM, :QTY,
:IS_REFURBISHABLE, :IS_CRITICAL, :IS_PERISHABLE, :REQ_DT,
to_date(:CONSUMP_DT,'YYYY-MM-DD'), :PROC_TYPE, :USERNAME, SYSDATE,'Y',:AIULP_INVENTORY,:INTRA_INVENTORY,:INTER_INVENTORY,:UMC_STATUS,
:PRICE_PER_ITEM,
to_date(:REQUIREMENT_DATE,'YYYY-MM-DD'),
:REQ_UMC_BGG,
:FOD_TYPE,
:DOCUMENT_TYPE,
:CURRENCY,'0',:PUR_GRP,:DEL_POINT,:MAP,:ISCONSUMABLE) RETURNING UMC_INDENT_ID INTO :PrimaryKey";

        public string updateIndentChild = @"UPDATE T_SIS_UMC_INDENT_DETAILS
SET REQ_UMC_NO=:REQ_UMC_NO, REQ_UMC_DESC=:REQ_UMC_DESC,
EXISTING_UMC=:EXISTING_UMC, EXIS_UMC_DESC=:EXIS_UMC_DESC, DEST_SLOC=:DEST_SLOC, UOM=:UOM, QTY=:QTY,
IS_REFURBISHABLE=:IS_REFURBISHABLE, IS_CRITICAL=:IS_CRITICAL, IS_PERISHABLE=:IS_PERISHABLE, REQ_DT=:REQ_DT,
CONSUMP_DT=to_date(:CONSUMP_DT,'YYYY-MM-DD'), PROC_TYPE=:PROC_TYPE, MOD_BY=:USERNAME, MOD_DT=SYSDATE,ISACTIVE='Y',AIULP_INVENTORY=:AIULP_INVENTORY,
INTRA_INVENTORY=:INTRA_INVENTORY,INTER_INVENTORY=:INTER_INVENTORY,UMC_STATUS=:UMC_STATUS,

PRICE_PER_ITEM=:PRICE_PER_ITEM,
REQUIREMENT_DATE=to_date(:REQUIREMENT_DATE,'YYYY-MM-DD'),
REQ_UMC_BGG=:REQ_UMC_BGG,
FOD_TYPE=:FOD_TYPE,
DOCUMENT_TYPE=:DOCUMENT_TYPE,
CURRENCY=:CURRENCY,
TOTAL_SAP_DOC_QTY='0',
PUR_GRP=:PUR_GRP,DEL_POINT=:DEL_POINT,MAP_VALUE=:MAP,IS_CONSUMABLE=:ISCONSUMABLE
where UMC_INDENT_ID=:UMC_INDENT_ID AND INDENT_ID=:INDENT_ID";

        public string updateIndentChildDOP = @"UPDATE T_SIS_UMC_INDENT_DETAILS
SET REQ_UMC_NO=:REQ_UMC_NO, REQ_UMC_DESC=:REQ_UMC_DESC,
EXISTING_UMC=:EXISTING_UMC, EXIS_UMC_DESC=:EXIS_UMC_DESC, DEST_SLOC=:DEST_SLOC, UOM=:UOM, QTY=:QTY,
IS_REFURBISHABLE=:IS_REFURBISHABLE, IS_CRITICAL=:IS_CRITICAL, IS_PERISHABLE=:IS_PERISHABLE, REQ_DT=:REQ_DT,
CONSUMP_DT=to_date(:CONSUMP_DT,'YYYY-MM-DD'), PROC_TYPE=:PROC_TYPE, MOD_BY=:USERNAME, MOD_DT=SYSDATE,ISACTIVE='Y',AIULP_INVENTORY=:AIULP_INVENTORY,
INTRA_INVENTORY=:INTRA_INVENTORY,INTER_INVENTORY=:INTER_INVENTORY,UMC_STATUS=:UMC_STATUS,

PRICE_PER_ITEM=:PRICE_PER_ITEM,
REQUIREMENT_DATE=to_date(:REQUIREMENT_DATE,'YYYY-MM-DD'),
REQ_UMC_BGG=:REQ_UMC_BGG,
FOD_TYPE=:FOD_TYPE,
DOCUMENT_TYPE=:DOCUMENT_TYPE,
CURRENCY=:CURRENCY,
TOTAL_SAP_DOC_QTY='0',
PUR_GRP=:PUR_GRP,DEL_POINT=:DEL_POINT,IS_CONSUMABLE=:ISCONSUMABLE
where UMC_INDENT_ID=:UMC_INDENT_ID AND INDENT_ID=:INDENT_ID";



        public string InsertWorkFlow = @"INSERT INTO T_SIS_WORK_FLOW
(WF_ID, UMC_INDENT_ID, SRC_LOC_ID, SRC_LOC_DESC,
SRC_PLANT_ID, SRC_PLANT_DESC, SRC_DEPT_ID, SRC_DEPT_DESC,
REQ_QUANTITY, APPROVED_QTY, WF_TYPE, WF_STATUS, WF_EXPIRY_DT,
WF_REMARKS, CRT_BY, CRT_ON,MOD_ON,SRC_SLOC,STOCK_AGE,TAGED_UMC,
AIULP_QTY,
INTRA_QTY,
INTER_QTY,APP_ON)
VALUES 
((select nvl(max(WF_ID),0)+1 from T_SIS_WORK_FLOW), nvl(:UMC_INDENT_ID,(select nvl(max(UMC_INDENT_ID),0) from T_SIS_UMC_INDENT_DETAILS WHERE REQ_UMC_NO=:REQ_UMC_NO AND ISACTIVE='Y' )), :SRC_LOC_ID, :SRC_LOC_DESC,
:SRC_PLANT_ID, :SRC_PLANT_DESC, :SRC_DEPT_ID, :SRC_DEPT_DESC,
:REQ_QUANTITY, :APPROVED_QTY, :WF_TYPE, :WF_STATUS, to_date(:DT,'dd-MON-yyyy HH24:MI:SS'),
:WF_REMARKS, :USERNAME, SYSDATE,SYSDATE,:SRC_SLOC,:STOCK_AGE,:TAGED_UMC,
:AIULP_QTY,
:INTRA_QTY,
:INTER_QTY, :APP_ON) RETURNING WF_ID INTO :PrimaryKey";
        public string InsertWorkFlowDirect = @"INSERT INTO T_SIS_WORK_FLOW
(WF_ID, UMC_INDENT_ID, SRC_LOC_ID, SRC_LOC_DESC,
SRC_PLANT_ID, SRC_PLANT_DESC, SRC_DEPT_ID, SRC_DEPT_DESC,
REQ_QUANTITY, APPROVED_QTY, WF_TYPE, WF_STATUS, WF_EXPIRY_DT,
WF_REMARKS, CRT_BY, CRT_ON,MOD_ON,SRC_SLOC,STOCK_AGE,TAGED_UMC,
AIULP_QTY,
INTRA_QTY,
INTER_QTY,APP_ON)
VALUES 
((select nvl(max(WF_ID),0)+1 from T_SIS_WORK_FLOW), nvl(:UMC_INDENT_ID,(select nvl(max(UMC_INDENT_ID),0) from T_SIS_UMC_INDENT_DETAILS WHERE REQ_UMC_NO=:REQ_UMC_NO AND ISACTIVE='Y' )), :SRC_LOC_ID, :SRC_LOC_DESC,
:SRC_PLANT_ID, :SRC_PLANT_DESC, :SRC_DEPT_ID, :SRC_DEPT_DESC,
:REQ_QUANTITY, :APPROVED_QTY, :WF_TYPE, :WF_STATUS, SYSDATE+@DYS,
:WF_REMARKS, :USERNAME, SYSDATE,SYSDATE,:SRC_SLOC,:STOCK_AGE,:TAGED_UMC,
:AIULP_QTY,
:INTRA_QTY,
:INTER_QTY,decode(:WF_TYPE,'AIULP',sysdate,null))";
        public string UpdateStatus = @"update T_SIS_INDENT_DETAILS set INDENT_STATUS='CMPLT'  where INDENT_ID=:INDENT_ID";
        public string oraInsertWorkFlowAudit = @"insert into T_SIS_WORKFLOW_AUDIT (ID,WF_ID,WF_TYPE,WF_STATUS,WF_REMARKS,CRT_BY,CRT_DT) values ((SELECT coalesce(MAX(ID),0) + 1 FROM T_SIS_WORKFLOW_AUDIT),nvl(:Wf_ID,(select nvl(max(WF_ID),0) from T_SIS_WORK_FLOW)),:WF_TYPE,'2','',:CRT_BY,SYSDATE)";

        public string UpdateaindentLvl = @"update T_SIS_INDENT_DETAILS set INDENT_LEVEL=:LVL,INDENT_TOTAL_MAP=:MAP  where INDENT_ID=:INDENT_ID";
        public string UpdateindentForCapx = @"update T_SIS_INDENT_DETAILS set INDENT_STATUS='CMPLT',INDENT_CURRENT_STATUS='15', INDENT_LEVEL=:LVL,INDENT_TOTAL_MAP=:MAP  where INDENT_ID=:INDENT_ID";

        public string GetDOPLevel= @"SELECT ""LEVEL"",MAX_AMOUNT AMT FROM T_SIS_INDENT_DOP_APRVL WHERE ACTIVE_FLG='Y' ORDER BY 1";
    }

}
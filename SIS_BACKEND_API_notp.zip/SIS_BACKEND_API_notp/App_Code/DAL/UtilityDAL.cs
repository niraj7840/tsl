﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.Reflection;
using Microsoft.IdentityModel.Tokens;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class UtilityDAL
    {
        string SISLink = "https://dlmstest.corp.tatasteel.com/SIS/";

        HRServices.Service objHRService = new HRServices.Service();

        HRServices.EmpDetails[] objEmpDetails;

        

        public void UpdateBodyRequirement(BodyContent bodyRequiredDetails, OracleConnection connection)
        {
            int umcIndentId = bodyRequiredDetails.UMCIndentId;

            int indentId = 0;
            string indenterADID = null;
            string materialName = null;
            string indenterDept = null;


            using (var command = new OracleCommand(MailQuery.GetIndenterDetails, connection))
            {
                command.Parameters.Add(new OracleParameter("UMC_INDENT_ID", umcIndentId));
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        indentId = Convert.ToInt32(reader["INDENT_ID"]);
                        materialName = reader["REQ_UMC_DESC"].ToString();
                        indenterADID = reader["INDENT_CRT_BY"].ToString();
                        indenterDept = reader["Indentor_Dept"].ToString();
                    }
                }
            }

            string indenterName = null;
            string indenterEmail = null;

            objEmpDetails = objHRService.getDetails(new string[] { indenterADID });
            if (objEmpDetails.Length > 0)
            {
                string UserName = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                indenterName = String.IsNullOrEmpty(UserName) ? indenterADID : UserName;
                indenterEmail = objEmpDetails[0].getsetEmailId;
            }


            bodyRequiredDetails.IndenterDept = indenterDept;
            bodyRequiredDetails.IndenterName = indenterName;
            bodyRequiredDetails.IndenterEmail = indenterEmail;
            bodyRequiredDetails.IndeterADID = indenterADID;
            bodyRequiredDetails.MaterialName = materialName;
            bodyRequiredDetails.IndentId = indentId;
            

        }

        public void GetIndenterDetails(IndenterDetails intendterDetails, OracleConnection connection,int indentId)
        {
            using (var command = new OracleCommand(MailQuery.GetIndentDetails, connection))
            {
                command.Parameters.Add(new OracleParameter("INDENT_ID", indentId));
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        intendterDetails.IndeterADID = reader["INDENT_CRT_BY"].ToString();
                        intendterDetails.IndenterDept = reader["INDENTOR_DEPT"].ToString();
                        intendterDetails.IndenterPlant = reader["INDENTOR_PLANT"].ToString();
                        intendterDetails.IndentCrtDate = reader["INDENT_CRT_DT"].ToString();
                    }
                }
            }

            objEmpDetails = objHRService.getDetails(new string[] { intendterDetails.IndeterADID });
            if (objEmpDetails.Length > 0)
            {
                string UserName = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                intendterDetails.IndenterName = String.IsNullOrEmpty(UserName) ? intendterDetails.IndeterADID : UserName;
                intendterDetails.IndenterEmail = objEmpDetails[0].getsetEmailId;
            }

        }

        //public WorkFlowModel GetWorkflowDetails(string wfid)
        //{
        //    WorkFlowModel workFlow = new WorkFlowModel();
        //    using (OracleConnection connectionWork = new OracleConnection(strConnSISDB))
        //    {

        //        using (var command = new OracleCommand(MailQuery.GetWorkflowDetails, connectionWork))
        //        {
        //            command.Parameters.Add(new OracleParameter("wfid", wfid));

        //            try
        //            {
        //                if (connectionWork.State == ConnectionState.Closed)
        //                {
        //                    connectionWork.Open();
        //                }
        //                using (var reader = command.ExecuteReader())
        //                {
        //                    if (reader.Read())
        //                    {
        //                        workFlow.WF_ID = reader["WF_ID"].ToString();
        //                        workFlow.UMC_INDENT_ID = reader["UMC_INDENT_ID"].ToString();
        //                        workFlow.REQ_QUANTITY = reader["REQ_QUANTITY"].ToString();
        //                        workFlow.SRC_PLANT_ID = reader["SRC_PLANT_ID"].ToString();
        //                        workFlow.SRC_DEPT_ID = reader["SRC_DEPT_ID"].ToString();
        //                        workFlow.APPROVED_QTY = reader["APPROVED_QTY"] != DBNull.Value ? reader["APPROVED_QTY"].ToString() : "0";
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine("Error fetching UMC workflows during AIULP Workflow updation: " + ex.Message);
        //            }
        //        }
        //    }
        //    return workFlow;
        //}

        public List<ApproverDetails> GetChiefDetails(string dept, string plant, OracleConnection connection)
        {
            List<ApproverDetails> ApproverDetails = new List<ApproverDetails>();

            using (var command = new OracleCommand(MailQuery.GetChiefDetails, connection))
            {
                command.Parameters.Add(new OracleParameter("DEPT", dept));
                command.Parameters.Add(new OracleParameter("PLANT", plant));

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ApproverDetails.Add(new ApproverDetails
                        {
                            ADID = reader["APR_ID"].ToString(),
                        });
                    }
                }
            }
            return ApproverDetails;
        }

        public List<string> GetDetails(string dept, string plant, OracleConnection connection,int ApproverLevel)
        {
            List<ApproverDetails> ApproverDetails = new List<ApproverDetails>();

            List<string> approverEmail = new List<string>();

            using (var command = new OracleCommand(MailQuery.GetApproverDetails, connection))
            {
                command.Parameters.Add(new OracleParameter("DEPT", dept));
                command.Parameters.Add(new OracleParameter("PLANT", plant));
                command.Parameters.Add(new OracleParameter("Approver",ApproverLevel));

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ApproverDetails.Add(new ApproverDetails
                        {
                            ADID = reader["APR_ID"].ToString(),
                        });
                    }
                }
            }
            foreach (var item in ApproverDetails)
            {
                objEmpDetails = objHRService.getDetails(new string[] { item.ADID });
                if (objEmpDetails.Length > 0)
                {
                    string UserName = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                    item.Name = String.IsNullOrEmpty(UserName) ? item.ADID : UserName;
                    item.Email = objEmpDetails[0].getsetEmailId;
                    if(item.Email != null)approverEmail.Add(item.Email);
                }
            }
            return approverEmail;
        }

        public List<ApproverDetails> GetHeadDetails(string dept, string plant, OracleConnection connection)
        {
            List<ApproverDetails> ApproverDetails = new List<ApproverDetails>();

            using (var command = new OracleCommand(MailQuery.GetHeadDetails, connection))
            {
                command.Parameters.Add(new OracleParameter("DEPT", dept));
                command.Parameters.Add(new OracleParameter("PLANT", plant));

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ApproverDetails.Add(new ApproverDetails
                        {
                            ADID = reader["APR_ID"].ToString(),
                        });
                    }
                }
            }
            return ApproverDetails;
        }

        public void UpdateMailTable(MailDetails mailDetails, OracleConnection connection)
        {
            if (connection.State == ConnectionState.Closed) connection.Open();
            OracleTransaction transaction = connection.BeginTransaction();
            using (var command = new OracleCommand(MailQuery.InsertMail, connection))
            {
                try
                {
                    command.Parameters.Add(new OracleParameter("MAIL_TO", OracleDbType.Varchar2) { Value = mailDetails.Mail_To });
                    command.Parameters.Add(new OracleParameter("MAIL_CC", OracleDbType.Varchar2) { Value = mailDetails.MAIL_CC ?? string.Empty });
                    command.Parameters.Add(new OracleParameter("MAIL_BCC", OracleDbType.Varchar2) { Value = mailDetails.MAIL_BCC ?? string.Empty });
                    command.Parameters.Add(new OracleParameter("INDENT_ID", OracleDbType.Int32) { Value = mailDetails.INDENT_ID });
                    command.Parameters.Add(new OracleParameter("UMC_INDENT_ID", OracleDbType.Int32) { Value = mailDetails.UMCIndentId });
                    command.Parameters.Add(new OracleParameter("WF_ID", OracleDbType.Int32) { Value = mailDetails.WF_ID });
                    command.Parameters.Add(new OracleParameter("MAIL_SUB", OracleDbType.Varchar2) { Value = mailDetails.Mail_Subject });
                    command.Parameters.Add(new OracleParameter("MAIL_BODY", OracleDbType.Varchar2) { Value = mailDetails.Mail_Body });
                    command.Parameters.Add(new OracleParameter("MODIFIED_BY", OracleDbType.Varchar2) { Value = "SISADMIN" });
                    command.Parameters.Add(new OracleParameter("MODIFIED_DATE", OracleDbType.Date) { Value = DateTime.Now });

                    command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine("Error inserting mail in database: " + ex.Message);
                    transaction.Rollback();
                }
            }
        }

        public void SendMail(MailFormat obj, OracleConnection connection)
        {
            string strSmtpServerHost = "144.0.11.253";
            SmtpClient objSmtpClient = new SmtpClient(strSmtpServerHost);
            MailMessage mail = new MailMessage();

            string mailFrom = "SISAdmin@tatasteel.com";
            mail.From = new MailAddress(mailFrom);

            if (obj.Mail_To != null && obj.Mail_To.Count > 0)
            {
                mail.To.Add("suryanshu.jha@tatasteel.com");
                mail.To.Add("prashant.thakur@tatasteel.com");
                foreach (string toEmail in obj.Mail_To)
                {
                   // mail.To.Add(toEmail);
                }
            }

            //if (obj.Mail_CC != null && obj.Mail_CC.Count > 0)
            //{
            //    foreach (string ccEmail in obj.Mail_CC)
            //    {
            //        mail.CC.Add(ccEmail);
            //    }
            //}

            mail.Subject = obj.Mail_Subject;
            mail.IsBodyHtml = true;
            mail.Body = obj.Mail_Body;

            objSmtpClient.Send(mail);
            mail.Dispose();
        }

        public class MailQuery
        {
            #region MailQuery

            public const string GetChiefDetails = @"SELECT * FROM SAPSUR.T_APPROVER WHERE APR_DEPT=:DEPT AND APR_PLANT=:PLANT AND APR_LEVEL IN (3)";

            public const string GetApproverDetails = @"SELECT * FROM SAPSUR.T_APPROVER WHERE APR_DEPT=:DEPT AND APR_PLANT=:PLANT AND APR_LEVEL IN (:Approver)";

            public const string GetHeadDetails = @"SELECT * FROM SAPSUR.T_APPROVER WHERE APR_DEPT=:DEPT AND APR_PLANT=:PLANT AND APR_LEVEL IN (2)";

            public const string GetIndenterDetails = @"SELECT umc.REQ_UMC_DESC, indent.INDENT_ID, indent.INDENT_CRT_BY,indent.INDENTOR_DEPT FROM t_sis_umc_indent_details umc JOIN T_sis_Indent_details indent ON umc.indent_id = indent.Indent_id WHERE UMC.UMC_INDENT_ID=:UMC_INDENT_ID AND (UMC.ISACTIVE='Y' AND UMC.UMC_STATUS='10')";

            public const string InsertMail = @"INSERT INTO T_SIS_MAIL_LOG (ID,MAIL_TO,MAIL_CC,MAIL_BCC,INDENT_ID, UMC_INDENT_ID, WF_ID, MAIL_FROM, MAIL_SUB, MAIL_BODY,MAIL_SEND_ON,MAIL_STATUS_CODE,CREATED_BY,MODIFIED_BY,CREATED_DATE,MODIFIED_DATE)
VALUES ((select nvl(max(ID),0)+1 from T_SIS_MAIL_LOG), :MAIL_TO , :MAIL_CC, :MAIL_BCC,:INDENT_ID, :UMC_INDENT_ID, :WF_ID,'SISAdmin @tatasteel.com' ,:MAIL_SUB,:MAIL_BODY,SYSDATE,'SUCCESS', 'SIS ADMIN', :MODIFIED_BY, SYSDATE, :MODIFIED_DATE)";

            public const string GetIndentDetails = @"SELECT INDENT_CRT_BY,INDENTOR_DEPT,INDENTOR_PLANT,INDENT_CRT_DT FROM T_sis_Indent_details WHERE INDENT_ID=:INDENT_ID";

            #endregion
        }
    }
}
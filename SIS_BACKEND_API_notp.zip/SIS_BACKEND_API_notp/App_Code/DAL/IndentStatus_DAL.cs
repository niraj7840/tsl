﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class IndentStatus_DAL
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        IndentStatus_Qry qry = new IndentStatus_Qry();

        public string GetIndentDetails(IndentStatusModel obj)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string dtFlt = (obj.DTF.Length > 0 && obj.DTT.Length > 0) ? "AND trim(M.INDENT_CRT_DT) BETWEEN TO_DATE(:DTF,'YYYY-MM-DD') AND  TO_DATE(:DTT,'YYYY-MM-DD')" : "";
                    string query = qry.GetIndentList.Replace("@DATEFLT",dtFlt);
                    using (var command = new OracleCommand(query, connection))
                    {
                        if (dtFlt.Length > 0)
                        {
                            command.Parameters.Add(new OracleParameter("DTF", obj.DTF));
                            command.Parameters.Add(new OracleParameter("DTT", obj.DTT));
                        }
                        command.Parameters.Add(new OracleParameter("INDENTNO", obj.INDENTNO));
                        command.Parameters.Add(new OracleParameter("DEPT", obj.DEPT));
                        command.Parameters.Add(new OracleParameter("FOD", obj.FOD));
                        command.Parameters.Add(new OracleParameter("DOCTYPE", obj.DOCTYPE));
                        command.Parameters.Add(new OracleParameter("STATUS", obj.STATUS));
                        command.Parameters.Add(new OracleParameter("PNO", obj.PNO));

                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return JsonConvert.SerializeObject(dt);

        }
        public string GetWorkflowDetails(string INDENTNO)
        {
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = qry.getWfDetails;
                    using (var command = new OracleCommand(query, connection))
                    {
                        
                        command.Parameters.Add(new OracleParameter("INDENTNO", INDENTNO.Replace("\'", "")));
                        
                        OracleDataAdapter sda = new OracleDataAdapter(command);
                        sda.Fill(dt);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return JsonConvert.SerializeObject(dt);

        }
    }
    public class IndentStatus_Qry
    {
        public string GetIndentList = @"SELECT DISTINCT
    to_char(M.indent_id) ID,
    M.indentor_loc LOCATION,
    M.indentor_plant PLANT,
  DEPTDESC||'('||M.indentor_dept||')' DEPT,
    M.indent_desc DES,
    M.indent_remarks REMARKS,
    M.indent_crt_by USR,
    TO_CHAR(M.indent_CRT_dt,'DD-MON-YYYY')DT,
IC.CODE_VAL_DESC STATUS,
IC.ID codeID
    FROM T_SIS_INDENT_DETAILS M
    INNER JOIN T_SIS_UMC_INDENT_DETAILS U
ON M.INDENT_ID=U.INDENT_ID
AND U.ISACTIVE='Y'
INNER JOIN SAPSUR.t_s_dept_mst
ON DEPTNO= M.indentor_dept
INNER JOIN T_SIS_CODE_VALUE IC
ON IC.ID=M.INDENT_CURRENT_STATUS
AND IC.ACTIVE_FLG='Y'
WHERE 
M.INDENT_STATUS='CMPLT'
AND
M.ISACTIVE='Y'
@DATEFLT
AND M.INDENT_ID =NVL(:INDENTNO,M.INDENT_ID)
AND INDENTOR_DEPT=NVL(:DEPT,INDENTOR_DEPT)
AND U.FOD_TYPE=NVL(:FOD,U.FOD_TYPE) 
AND U.DOCUMENT_TYPE=NVL(:DOCTYPE,DOCUMENT_TYPE) and INDENT_CURRENT_STATUS=NVL(:STATUS,INDENT_CURRENT_STATUS)
AND M.indent_crt_by=nvl(:PNO,M.indent_crt_by)
ORDER BY M.indent_id
";

        public string getWfDetails = @"SELECT UMC,
  WF,
  DT,
  REQ_QUANTITY,
  APPROVED_QTY,
  MRQTY,
  STOQTY,
  SAPMRDOC,
  MRCRTDATE,
  STONO,
  STOCRTDATE,
  CATEGORY,
  LOCATION,
  PLANT,
  DEPT,
  CSTATUS,
  INDENTSTATUS,
  INDENTDEPT,
  DYS,
  ACTBY,
  ACTDT,
  LISTAGG(PENDINGWITH, ' , ') WITHIN GROUP (
ORDER BY PENDINGWITH) PENDINGWITH,
  DECODE(INDENTSTATUSID,2,'Indent created',3,'Escalated',4,'Processed',5,'Closed')ACTION,
  DECODE(INDENTSTATUSID,2,'YELLOW',3,'RED',4,'#85e685',5,'#85e685')COLR,
  IND,
  SLOC,
  INDENTSTATUSCODE,UOM,IS_CONSUMABLE,SRC_PLANT_ID,SRC_DEPT_ID,WF_STATUS
FROM
  ( SELECT DISTINCT M.INDENT_ID IND,
    REQ_UMC_NO UMC,
    WF_ID WF,
    TO_CHAR(W.CRT_ON,'DD-MON-YYYY') DT,
    REQ_QUANTITY,
    APPROVED_QTY,
    MR_QTY MRQTY,
    STO_QTY STOQTY,
      SAP_MR_DOC SAPMRDOC,
  MR_CRTDATE MRCRTDATE,
  SAP_STO_NO STONO,
  STO_CRTDATE STOCRTDATE,
    WF_TYPE CATEGORY,
    SRC_SLOC SLOC,
    NVL(SRC_LOC_DESC,SRC_LOC_ID) LOCATION,
    NVL(SRC_PLANT_DESC,SRC_PLANT_ID)PLANT,
    WD.DEPTDESC
    ||'('
    ||WD.DEPTNO
    ||')' DEPT,
    WC.CODE_VALUE CSTATUS,
    WC.ID INDENTSTATUSID,
    IC.CODE_VALUE INDENTSTATUS,
    ID.DEPTDESC
    ||'('
    ||M.indentor_dept
    ||')' INDENTDEPT,W.SRC_PLANT_ID,W.SRC_DEPT_ID,W.WF_STATUS,
    APR_ID PENDINGWITH,
    DECODE (W.WF_STATUS,2,TRUNC(SYSDATE)-TRUNC(W.CRT_ON),3,TRUNC(SYSDATE)-TRUNC(W.CRT_ON),NULL) DYS,
    APP_BY ACTBY,
    TO_CHAR(APP_ON,'DD-MON-YYYY') ACTDT,
    IC.ID INDENTSTATUSCODE,U.UOM UOM,U.IS_CONSUMABLE
  FROM T_SIS_INDENT_DETAILS M
  inner JOIN T_SIS_UMC_INDENT_DETAILS U
  ON M.INDENT_ID=U.INDENT_ID
  AND U.ISACTIVE='Y'
  inner JOIN T_SIS_WORK_FLOW W
  ON W.UMC_INDENT_ID=U.UMC_INDENT_ID
  inner JOIN T_SIS_CODE_VALUE WC
  ON WC.ID=W.WF_STATUS
  inner JOIN T_SIS_CODE_VALUE IC
  ON IC.ID         =M.INDENT_CURRENT_STATUS
  AND IC.ACTIVE_FLG='Y'
  INNER JOIN SAPSUR.t_s_dept_mst ID
  ON ID.DEPTNO= M.indentor_dept
  LEFT JOIN SAPSUR.T_APPROVER
  ON APR_DEPT    =W.SRC_DEPT_ID
  AND APR_PLANT  =W.SRC_PLANT_ID
  AND APR_LEVEL  =W.WF_STATUS
  AND APR_LEVEL IN(2,3)
  LEFT JOIN SAPSUR.t_s_dept_mst WD
  ON WD.DEPTNO         =SRC_DEPT_ID
  WHERE M.INDENT_STATUS='CMPLT' AND
   M.ISACTIVE       ='Y'
  AND M.INDENT_ID      =:INDENTNO
  )
GROUP BY UMC,
  WF,
  DT,
  REQ_QUANTITY,
  APPROVED_QTY,
  MRQTY,
  STOQTY,
  SAPMRDOC,
  MRCRTDATE,
  STONO,
  STOCRTDATE,
  CATEGORY,
  LOCATION,
  PLANT,
  DEPT,
  CSTATUS,
  INDENTSTATUS,
  INDENTDEPT,
  INDENTSTATUSID,
  IND,
  SLOC,
  DYS,
  ACTBY,
  ACTDT,
  INDENTSTATUSCODE,UOM,IS_CONSUMABLE,SRC_PLANT_ID,SRC_DEPT_ID,WF_STATUS
ORDER BY INDENTSTATUSID,
  WF";
    }
}
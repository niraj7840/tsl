﻿using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Reflection;
using Microsoft.IdentityModel.Tokens;
using System.Net.Mail;

namespace SIS_BACKEND_API.App_Code.DAL
{
    public class WorkflowDAL
    {
        private SqlCommand cmd;
        private SqlCommand cmd2;
        DataTable dtRet = null;
        private string strConnSISDB = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;

        private ConnectionOracleDB objConn;
        private DataTable dtResult;

        HRServices.Service objHRService = new HRServices.Service();

        HRServices.EmpDetails[] objEmpDetails;

        UtilityDAL objUtilityDAL = new UtilityDAL();


        public DataTable GetWorkFlowDetails(string ADID)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectWorkFlow, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":APR_ID", ADID);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        public string GetWorkFlowStatus(string ID)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.getWFStatus, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":ID", ID);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult.Rows[0][0].ToString();
        }
        public DataTable GetHODActionDetails(string WID)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.GetHodAction, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.            
                objConn.AddParameters(":ID", WID);

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        internal DataTable GetWorkFlowDetailsFromID(string workFlowID)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.oraSelectWorkFlow_WithID, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();

                //Bind the parameters.                
                objConn.AddParameters(":WF_ID", workFlowID);
                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;

                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        internal DataTable GetApprover(string DEPT, string PLANT)
        {
            //List< WorkFlowModel> workFlowModel = new List<WorkFlowModel>();
            //Instantiate the connection object.
            objConn = new ConnectionOracleDB(strConnSISDB, DBConst.getApprover, CommandType.Text, true);

            try
            {
                //Open the connection.
                objConn.OpenConnection();
                objConn.AddParameters(":DEPT", DEPT);
                objConn.AddParameters(":PLANT", PLANT);
                //Bind the parameters.                

                //Execute the query and assign the resultant table.
                objConn.FillDataTable();
                dtResult = objConn.ResultantTable;
                if (dtResult.Rows.Count == 0)
                {

                }
                //Close the connection
                objConn.CloseConnection();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            //return the final Data Table.
            return dtResult;
        }

        internal int UpdateWorkFlowDetailsFromID(WorkFlowModel workflowmodel)
        {
            int attachInsertCount;

            using (OracleConnection connection = new OracleConnection(strConnSISDB))
            {
                connection.Open();

                OracleCommand command = connection.CreateCommand();
                OracleTransaction transaction;

                transaction = connection.BeginTransaction();
                command.Transaction = transaction;

                try
                {
                    command.CommandText = DBConst.oraUpdateWorkFlow_WithID;
                    command.Parameters.Clear();
                    command.Parameters.Add(":WF_STATUS", workflowmodel.WF_STATUS);
                    command.Parameters.Add(":MOD_BY", workflowmodel.MOD_BY);
                    command.Parameters.Add(":APPROVED_QTY", workflowmodel.APPROVED_QTY);
                    command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
                    command.Parameters.Add(":APP_BY", workflowmodel.MOD_BY);
                    
                    command.Parameters.Add(":HOD_ACTION", workflowmodel.HODCHIEFACTION);
                    command.Parameters.Add(":TENTATIVE_CONSUMPTION_DATE", workflowmodel.CONSUMPTION_DATE);
                    command.Parameters.Add(":REASON_FOR_DENIAL", workflowmodel.REASON_FOR_DENIAL);
                    command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);


                    attachInsertCount = command.ExecuteNonQuery();



                    command.Parameters.Clear();
                    command.CommandText = DBConst.oraInsertWorkFlowAudit;
                    command.Parameters.Clear();
                    command.Parameters.Add(":WF_ID", workflowmodel.WF_ID);
                    command.Parameters.Add(":WF_TYPE", workflowmodel.WF_TYPE);
                    command.Parameters.Add(":WF_STATUS", workflowmodel.HODACTION);

                    command.Parameters.Add(":WF_REMARKS", workflowmodel.WF_REMARKS);
                    command.Parameters.Add(":CRT_BY", workflowmodel.MOD_BY);
                    command.Parameters.Add(":ACTION", workflowmodel.ACTION);

                    attachInsertCount = command.ExecuteNonQuery();

                    command.Parameters.Clear();
                    command.CommandText = DBConst.updateExpiryDate;
                    command.Parameters.Clear();

                    command.Parameters.Add(":ID", workflowmodel.INDENT_ID);
                    command.Parameters.Add(":CAT", workflowmodel.WF_TYPE);
                    command.Parameters.Add(":ID", workflowmodel.INDENT_ID);

                    attachInsertCount = command.ExecuteNonQuery();


                    transaction.Commit();

                    if (workflowmodel.WF_STATUS == "4")
                    {
                        WorkFlowModel workflow = GetWorkflowDetails(workflowmodel.WF_ID);

                        bool isWorkflowApprovedByChief = GetWorkflowAuditDetails(Convert.ToInt32(workflowmodel.WF_ID), connection);

                        if (isWorkflowApprovedByChief)
                        {
                            TriggerEmailOnChiefApproval(workflow, connection);
                        }
                        else
                        {
                            TriggerEmailOnHeadApproval(workflow, connection);
                        }
                    }else if(workflowmodel.WF_STATUS == "9")
                    {
                        WorkFlowModel workflow = GetWorkflowDetails(workflowmodel.WF_ID);

                        bool isWorkflowRejectedByChief = GetWorkflowAuditDetails(Convert.ToInt32(workflowmodel.WF_ID), connection);

                        TriggerEmailToIndeterOnRejection(workflow,connection,isWorkflowRejectedByChief);
                    }
                }
                catch (OracleException excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
                catch (Exception excp)
                {
                    transaction.Rollback();
                    throw excp;
                }
            }
            return attachInsertCount;
        }

        public WorkFlowModel GetWorkflowDetails(string wfid)
        {
            WorkFlowModel workFlow = new WorkFlowModel();
            using (OracleConnection connectionWork = new OracleConnection(strConnSISDB))
            {

                using (var command = new OracleCommand(DBConst.GetWorkflowDetails, connectionWork))
                {
                    command.Parameters.Add(new OracleParameter("wfid", wfid));

                    try
                    {
                        if (connectionWork.State == ConnectionState.Closed)
                        {
                            connectionWork.Open();
                        }
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                workFlow.WF_ID = reader["WF_ID"].ToString();
                                workFlow.UMC_INDENT_ID = reader["UMC_INDENT_ID"].ToString();
                                workFlow.REQ_QUANTITY = reader["REQ_QUANTITY"].ToString();
                                workFlow.SRC_PLANT_ID = reader["SRC_PLANT_ID"].ToString();
                                workFlow.SRC_DEPT_ID = reader["SRC_DEPT_ID"].ToString();
                                workFlow.APPROVED_QTY = reader["APPROVED_QTY"] != DBNull.Value ? reader["APPROVED_QTY"].ToString() : "0" ;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error fetching UMC workflows during AIULP Workflow updation: " + ex.Message);
                    }
                }
            }
            return workFlow;
        }

        

        public bool GetWorkflowAuditDetails(int wfID, OracleConnection connection)
        {
            string wfStatus = "";

            using (var command = new OracleCommand(DBConst.pendingWithWhom, connection))
            {
                command.Parameters.Add(new OracleParameter("WF_ID", wfID));

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        wfStatus = reader["WF_STATUS"].ToString();
                    }
                }
            }

            return (wfStatus == "3");
        }

        public void TriggerEmailOnHeadApproval(WorkFlowModel workflow, OracleConnection connection)
        {

            try
            {
                string srcDept = workflow.SRC_DEPT_ID;
                string srcPlant = workflow.SRC_PLANT_ID;
                int umcIndentId = Convert.ToInt32(workflow.UMC_INDENT_ID);
               
                BodyContent bodyRequiredDetails = new BodyContent();

                bodyRequiredDetails.UMCIndentId = umcIndentId;
                bodyRequiredDetails.RequestedQuantity = Convert.ToInt32(workflow.REQ_QUANTITY);
                objUtilityDAL.UpdateBodyRequirement(bodyRequiredDetails, connection);
                
                    string subject = "Spare sharing request has been approved for the material - " + bodyRequiredDetails.MaterialName;
                   
                    string body = "Dear Sir/Ma'am" + ",<br><br>" +
              "A spare sharing request has been approved for the material - " + bodyRequiredDetails.MaterialName + " on " + DateTime.Now.ToString("dd-MMM-yyyy") + " in Smart Indenting System for Spare Sharing.<br><br>" +
              "Request Details:<br>" +
              "- Requested Quantity: " + bodyRequiredDetails.RequestedQuantity + "<br>" +
              "- Material Name: " + bodyRequiredDetails.MaterialName + "<br>" +
              "- Approved Quantity: " + workflow.APPROVED_QTY + "<br>" +
              "- Workflow Id: " + workflow.WF_ID + "<br>" +
              "- Indent Id: " + bodyRequiredDetails.IndentId + "<br>" +
              "- Raised by Department: " + bodyRequiredDetails.IndenterDept + "<br>" +
              "- Raised by: " + bodyRequiredDetails.IndenterName + " (" + bodyRequiredDetails.IndeterADID + ")<br><br>" +
              "Best Regards,<br>" +
              "SIS Admin<br>";

                    MailFormat mailFormat = new MailFormat();
                    mailFormat.Mail_To = new List<string> { bodyRequiredDetails.IndenterEmail };
                    mailFormat.Mail_Subject = subject;
                    mailFormat.Mail_Body = body;
                    mailFormat.Mail_CC = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, 2);


                    objUtilityDAL.SendMail(mailFormat, connection);
                    MailDetails mailDetails = new MailDetails();

                    mailDetails.INDENT_ID = bodyRequiredDetails.IndentId;
                    mailDetails.Mail_To = bodyRequiredDetails.IndenterEmail;
                    mailDetails.Mail_Subject = subject;
                    mailDetails.Mail_Body = body;
                    mailDetails.WF_ID = Convert.ToInt32(workflow.WF_ID);
                    mailDetails.UMCIndentId = umcIndentId;
                    mailDetails.MAIL_CC = String.Join(", ", mailFormat.Mail_CC) ;

                objUtilityDAL.UpdateMailTable(mailDetails, connection);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in sending mail ", ex.ToString());
            }

        }

       

        public void TriggerEmailOnChiefApproval(WorkFlowModel workflow, OracleConnection connection)
        {
            try
            {
                string srcDept = workflow.SRC_DEPT_ID;
                string srcPlant = workflow.SRC_PLANT_ID;
                int umcIndentId = Convert.ToInt32(workflow.UMC_INDENT_ID);


                BodyContent bodyRequiredDetails = new BodyContent();

                bodyRequiredDetails.UMCIndentId = umcIndentId;
                bodyRequiredDetails.RequestedQuantity = Convert.ToInt32(workflow.REQ_QUANTITY);
                objUtilityDAL.UpdateBodyRequirement(bodyRequiredDetails, connection);

                string subject = "Spare sharing request has been approved for the material - " + bodyRequiredDetails.MaterialName;

                string body = "Dear Sir/Ma'am" + ",<br><br>" +
          "A spare sharing request has been approved for the material - " + bodyRequiredDetails.MaterialName + " on " + DateTime.Now.ToString("dd-MMM-yyyy") + " in Smart Indenting System for Spare Sharing.<br><br>" +
          "Request Details:<br>" +
          "- Requested Quantity: " + bodyRequiredDetails.RequestedQuantity + "<br>" +
          "- Material Name: " + bodyRequiredDetails.MaterialName + "<br>" +
          "- Approved Quantity: " + workflow.APPROVED_QTY + "<br>" +
          "- Workflow Id: " + workflow.WF_ID + "<br>" +
          "- Indent Id: " + bodyRequiredDetails.IndentId + "<br>" +
          "- Raised by Department: " + bodyRequiredDetails.IndenterDept + "<br>" +
          "- Raised by: " + bodyRequiredDetails.IndenterName + " (" + bodyRequiredDetails.IndeterADID + ")<br><br>" +
          "Best Regards,<br>" +
          "SIS Admin<br>";

                    MailFormat mailFormat = new MailFormat();
                    mailFormat.Mail_To = new List<string> { bodyRequiredDetails.IndenterEmail };
                    mailFormat.Mail_Subject = subject;
                    mailFormat.Mail_Body = body;
                mailFormat.Mail_CC = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, 2);
                List<string> chiefEmail = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, 3);
                foreach(var email in chiefEmail)mailFormat.Mail_CC.Add(email);

                    objUtilityDAL.SendMail(mailFormat,  connection);

                    MailDetails mailDetails = new MailDetails();
                    mailDetails.INDENT_ID = bodyRequiredDetails.IndentId;
                    mailDetails.Mail_To = String.Join(", ",mailFormat.Mail_To);
                    mailDetails.Mail_Subject = subject;
                    mailDetails.Mail_Body = body;
                    mailDetails.WF_ID = Convert.ToInt32(workflow.WF_ID);
                    mailDetails.UMCIndentId = umcIndentId;
                    mailDetails.MAIL_CC = String.Join(", ",mailFormat.Mail_CC);

                    objUtilityDAL.UpdateMailTable(mailDetails, connection);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in sending mail while approval", ex.ToString());
            }

        }

        public void TriggerEmailToIndeterOnRejection(WorkFlowModel workflow, OracleConnection connection,bool isRejectedByChief)
        {
            try
            {
                string srcDept = workflow.SRC_DEPT_ID;
                string srcPlant = workflow.SRC_PLANT_ID;
                int umcIndentId = Convert.ToInt32(workflow.UMC_INDENT_ID);

                BodyContent bodyRequiredDetails = new BodyContent();

                bodyRequiredDetails.UMCIndentId = umcIndentId;
                bodyRequiredDetails.RequestedQuantity = Convert.ToInt32(workflow.REQ_QUANTITY);
                objUtilityDAL.UpdateBodyRequirement(bodyRequiredDetails, connection);



                    string subject = "Spare Sharing Request has been rejected for the material - " + bodyRequiredDetails.MaterialName;
                    string body = "Dear Sir/Ma'am"  + ",<br><br>" +
              "The spare sharing request has been rejected for the material  - " + bodyRequiredDetails.MaterialName + " on " + DateTime.Now.ToString("dd-MMM-yyyy") + " in Smart Indenting System.<br><br>" +
              "Request Details:<br>" +
              "- Requested Quantity: " + bodyRequiredDetails.RequestedQuantity + "<br>" +
              "- Material Name: " + bodyRequiredDetails.MaterialName + "<br>" +
              "- Workflow Id: " + workflow.WF_ID + "<br>" +
              "- Indent Id: " + bodyRequiredDetails.IndentId + "<br>" +
               "<br><br>" +
              "Best Regards,<br>" +
              "SIS Admin<br>";
                    MailFormat mailFormat = new MailFormat();
                    mailFormat.Mail_To = new List<string> { bodyRequiredDetails.IndenterEmail };
                    mailFormat.Mail_Subject = subject;
                    mailFormat.Mail_Body = body;
                    mailFormat.Mail_CC = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, 2);
                if (isRejectedByChief) {
                    List<string> chiefEmail = objUtilityDAL.GetDetails(srcDept, srcPlant, connection, 3); 
                    foreach (var item in chiefEmail) mailFormat.Mail_CC.Add(item);
                        }
               objUtilityDAL.SendMail(mailFormat, connection);

                    MailDetails mailDetails = new MailDetails();
                    mailDetails.INDENT_ID = bodyRequiredDetails.IndentId;
                    mailDetails.Mail_To = bodyRequiredDetails.IndenterEmail;
                    mailDetails.Mail_Subject = subject;
                    mailDetails.Mail_Body = body;
                    mailDetails.WF_ID = Convert.ToInt32(workflow.WF_ID);
                    mailDetails.UMCIndentId = umcIndentId;
                    mailDetails.MAIL_CC = String.Join(", ",mailFormat.Mail_CC);

                objUtilityDAL.UpdateMailTable(mailDetails, connection);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in sending mail while approval", ex.ToString());
            }

        }

        public class DBConst
        {
            #region WorkFlow
            //added by Animesh
            //        public const string oraSelectWorkFlow = @"select T_SIS_WORK_FLOW.* from sapsur.T_SIS_WORK_FLOW  inner join sapsur.t_approver  on SRC_DEPT_ID=apr_dept and SRC_PLANT_ID = APR_PLANT 
            //and APP_BY = APR_LEVEL Where apr_dept = '253' and APR_PLANT = '025' and APR_LEVEL IN (1,2)";
            public const string oraSelectWorkFlow = @"SELECT DISTINCT WF.WF_ID,IND.INDENT_ID,UMC.REQ_UMC_DESC,UMC.PROC_TYPE,WF.WF_TYPE,IND.INDENTOR_PLANT,UMC.REQ_UMC_NO,WF.REQ_QUANTITY,UMC.UOM,nvl(WF.SRC_PLANT_DESC,WF.SRC_PLANT_ID)SRC_PLANT_DESC,nvl(WF.SRC_LOC_DESC,WF.SRC_LOC_ID)SRC_LOC_DESC,
(select DEPTDESC from SAPSUR.t_s_dept_mst where DEPTNO=WF.SRC_DEPT_ID)||'('||WF.SRC_DEPT_ID||')' SRC_DEPT_DESC,TO_CHAR(WF.CRT_ON,'DD-MON-YYYY') MOD_DT,IND.INDENT_DESC,SRC_SLOC SLOC,WF.SRC_DEPT_ID DEPTID,WF.SRC_PLANT_ID PLANTID,INDENTOR_DEPT INDDEPT,INDENTOR_LOC INDLOC,
DECODE(WF.WF_TYPE,'AIULP',AIULP_QTY,
'INTRA',INTRA_QTY,
'INTER',INTER_QTY,0)INDQTY,TO_CHAR(CONSUMP_DT,'DD-MON-YYYY') CONSDT,TO_CHAR(REQUIREMENT_DATE,'DD-MON-YYYY') REQDT,UMC.UOM UOM,WF.WF_STATUS STATUS,
(select NAME1||'('||INDENTOR_PLANT||')' from SAPSUR.t_s_plant where PLANT=INDENTOR_PLANT) INDENTORPLANT,
(select NAME1||'('||WF.SRC_PLANT_ID||')' from SAPSUR.t_s_plant where PLANT=WF.SRC_PLANT_ID) SOURCEPLANT,
(select DEPTDESC||'('||INDENTOR_DEPT||')' from SAPSUR.t_s_dept_mst where DEPTNO=INDENTOR_DEPT)INDENTORDEPARTMENT
FROM
 T_SIS_work_flow WF INNER JOIN T_SIS_UMC_INDENT_DETAILS UMC on UMC.UMC_INDENT_ID= WF.UMC_INDENT_ID inner join T_SIS_INDENT_DETAILS IND 
on IND.INDENT_ID=UMC.INDENT_ID  LEFT join SAPSUR.t_approver appr on WF.SRC_PLANT_ID= appr.apr_plant  and wf.src_dept_id= appr.apr_dept where
    appr.APR_ID=:APR_ID and appr.APR_LEVEL IN (2,3) and  WF.WF_STATUS in (2,3) and WF.wf_expiry_dt>=sysdate ORDER BY WF.WF_ID ASC
    "; //'500455'
            public const string oraSelectWorkFlow_WithID = @"select UMC.REQ_UMC_NO,UMC.REQ_UMC_DESC,UMC.DEST_SLOC,WF.SRC_PLANT_DESC,WF.SRC_DEPT_DESC,UMC.CONSUMP_DT,UMC.REQ_DT,UMC.PROC_TYPE,
IND.INDENT_DESC,IND.INDENT_REMARKS from
T_SIS_WORK_FLOW WF inner join t_sis_UMC_indent_details UMC on UMC.UMC_INDENT_ID=WF.UMC_INDENT_ID inner join T_SIS_INDENT_DETAILS IND on
IND.INDENT_ID = UMC.INDENT_ID where WF.WF_ID=:WF_ID";
            public const string oraUpdateWorkFlow_WithID = @"update T_SIS_work_flow set WF_STATUS=:WF_STATUS ,MOD_BY=:MOD_BY,APPROVED_QTY=:APPROVED_QTY,WF_REMARKS=:WF_REMARKS ,MOD_ON=SYSDATE,APP_BY=:APP_BY,APP_ON=SYSDATE,HOD_ACTION = :HOD_ACTION,TENTATIVE_CONSUMPTION_DATE = :TENTATIVE_CONSUMPTION_DATE, REASON_FOR_DENIAL = :REASON_FOR_DENIAL where WF_ID=:WF_ID";
            public const string oraInsertWorkFlowAudit = @"insert into T_SIS_WORKFLOW_AUDIT (ID,WF_ID,WF_TYPE,WF_STATUS,WF_REMARKS,CRT_BY,CRT_DT,ACTION_TAKEN) values ((SELECT coalesce(MAX(ID),0) + 1 FROM T_SIS_WORKFLOW_AUDIT),:WF_ID,:WF_TYPE,:WF_STATUS,:WF_REMARKS,:CRT_BY,SYSDATE,:ACTION)";
            public const string getApprover = @"SELECT nvl(APR_ID,'-')APR_ID,HOD,'' USERNAME,APR_DEPT,APR_PLANT from
(select 2 HOD from dual
union
select 3 CHIEF from dual)
 left join SAPSUR.T_APPROVER on
 APR_DEPT=:DEPT AND APR_PLANT=:PLANT AND
 APR_LEVEL =HOD";
            public const string updateExpiryDate = @"UPDATE T_SIS_WORK_FLOW
SET WF_EXPIRY_DT=sysdate
WHERE 0=(
SELECT COUNT(1) FROM T_SIS_WORK_FLOW W
INNER JOIN T_SIS_UMC_INDENT_DETAILS U
ON U.umc_indent_id=W.umc_indent_id
and isactive='Y'
WHERE indent_id=:ID AND wf_STATUS IN(2,3) and WF_TYPE=:CAT)

AND umc_indent_id IN (SELECT umc_indent_id FROM  T_SIS_UMC_INDENT_DETAILS WHERE indent_id=:ID and isactive='Y')";
            public const string pendingWithWhom = @"SELECT WF_STATUS FROM T_SIS_WORKFLOW_AUDIT WHERE WF_ID = :WF_ID AND WF_STATUS IN (2,3)";

            public const string GetWorkflowDetails = @"SELECT * FROM t_sis_work_flow WHERE wf_id = :wfid";
            #endregion
            public const string GetHodAction = @"SELECT ACTION_TAKEN ACT FROM T_SIS_WORKFLOW_AUDIT WHERE WF_ID=:ID AND WF_STATUS='2' AND ACTION_TAKEN IS NOT NULL";
            public const string getWFStatus = @"select WF_STATUS from t_sis_work_flow where WF_ID=:ID";
        }

    }
}
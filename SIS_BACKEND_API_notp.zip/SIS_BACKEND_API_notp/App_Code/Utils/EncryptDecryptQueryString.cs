﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

/// <summary>
/// Class for encryption/decryption of Query String
/// </summary>
public class EncryptDecryptQueryString
{
    /// <summary>
    /// Key for encryption/decryption
    /// </summary>
   
    //private byte[] key = { };
    //private byte[] IV = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xab, 0xcd, 0xef };

    /// <summary>
    /// Function to decrypt
    /// </summary>
    /// <param name="stringToDecrypt"></param>
    /// <returns></returns>
    public static string Decrypt(string stringToDecrypt)
    {
        string EncryptionKey = ConfigurationManager.AppSettings["EncryptKey"].ToString();
        try
        {
            stringToDecrypt = stringToDecrypt.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(stringToDecrypt);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    stringToDecrypt = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return stringToDecrypt;
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    /// <summary>
    /// Function to encrypt
    /// </summary>
    /// <param name="stringToEncrypt"></param>
    /// <returns></returns>
    public static string Encrypt(string stringToEncrypt)
    {
        string EncryptionKey = ConfigurationManager.AppSettings["EncryptKey"].ToString();
        try
        {
            byte[] clearBytes = Encoding.Unicode.GetBytes(stringToEncrypt);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    stringToEncrypt = Convert.ToBase64String(ms.ToArray());
                }
            }
            return stringToEncrypt;
        }
        catch (Exception e)
        {
            throw e;
        }

    }

    /// <summary>
    /// Encrypts a string
    /// </summary>
    /// <param name="PlainText">Text to be encrypted</param>
    /// <param name="Password">Password to encrypt with</param>
    /// <param name="Salt">Salt to encrypt with</param>
    /// <param name="HashAlgorithm">Can be either SHA1 or MD5</param>
    /// <param name="PasswordIterations">Number of iterations to do</param>
    /// <param name="InitialVector">Needs to be 16 ASCII characters long</param>
    /// <param name="KeySize">Can be 128, 192, or 256</param>
    /// <returns>An encrypted string</returns>
    public static string Encrypt(string PlainText, string Password, string Salt, string HashAlgorithm, int PasswordIterations, string InitialVector, int KeySize)
    {
        if (string.IsNullOrEmpty(PlainText))
        {
            return "";
        }
        byte[] InitialVectorBytes = Encoding.ASCII.GetBytes(InitialVector);
        byte[] SaltValueBytes = Encoding.ASCII.GetBytes(Salt);
        byte[] PlainTextBytes = Encoding.UTF8.GetBytes(PlainText);
        PasswordDeriveBytes DerivedPassword = new PasswordDeriveBytes(Password, SaltValueBytes, HashAlgorithm, PasswordIterations);
        byte[] KeyBytes = DerivedPassword.GetBytes(KeySize / 8);
        RijndaelManaged SymmetricKey = new RijndaelManaged();
        SymmetricKey.Mode = CipherMode.CBC;
        byte[] CipherTextBytes = null;
        using (ICryptoTransform Encryptor = SymmetricKey.CreateEncryptor(KeyBytes, InitialVectorBytes))
        {
            using (MemoryStream MemStream = new MemoryStream())
            {
                using (CryptoStream CryptoStream = new CryptoStream(MemStream, Encryptor, CryptoStreamMode.Write))
                {
                    CryptoStream.Write(PlainTextBytes, 0, PlainTextBytes.Length);
                    CryptoStream.FlushFinalBlock();
                    CipherTextBytes = MemStream.ToArray();
                    MemStream.Close();
                    CryptoStream.Close();
                }
            }
        }
        SymmetricKey.Clear();
        return Convert.ToBase64String(CipherTextBytes);
    }

    /// <summary>
    /// Decrypts a string
    /// </summary>
    /// <param name="CipherText">Text to be decrypted</param>
    /// <param name="Password">Password to decrypt with</param>
    /// <param name="Salt">Salt to decrypt with</param>
    /// <param name="HashAlgorithm">Can be either SHA1 or MD5</param>
    /// <param name="PasswordIterations">Number of iterations to do</param>
    /// <param name="InitialVector">Needs to be 16 ASCII characters long</param>
    /// <param name="KeySize">Can be 128, 192, or 256</param>
    /// <returns>A decrypted string</returns>
    public static string Decrypt(string CipherText, string Password, string Salt, string HashAlgorithm, int PasswordIterations, string InitialVector, int KeySize)
    {
        if (string.IsNullOrEmpty(CipherText))
        {
            return "";
        }
        byte[] InitialVectorBytes = Encoding.ASCII.GetBytes(InitialVector);
        byte[] SaltValueBytes = Encoding.ASCII.GetBytes(Salt);
        byte[] CipherTextBytes = Convert.FromBase64String(CipherText);
        PasswordDeriveBytes DerivedPassword = new PasswordDeriveBytes(Password, SaltValueBytes, HashAlgorithm, PasswordIterations);
        byte[] KeyBytes = DerivedPassword.GetBytes(KeySize / 8);
        RijndaelManaged SymmetricKey = new RijndaelManaged();
        SymmetricKey.Mode = CipherMode.CBC;
        byte[] PlainTextBytes = new byte[CipherTextBytes.Length];
        int ByteCount = 0;
        using (ICryptoTransform Decryptor = SymmetricKey.CreateDecryptor(KeyBytes, InitialVectorBytes))
        {
            using (MemoryStream MemStream = new MemoryStream(CipherTextBytes))
            {
                using (CryptoStream CryptoStream = new CryptoStream(MemStream, Decryptor, CryptoStreamMode.Read))
                {

                    ByteCount = CryptoStream.Read(PlainTextBytes, 0, PlainTextBytes.Length);
                    MemStream.Close();
                    CryptoStream.Close();
                }
            }
        }
        SymmetricKey.Clear();
        return Encoding.UTF8.GetString(PlainTextBytes, 0, ByteCount);
    }

    public static string EncryptStringToBytes(string plainText)
    {
        // plainText = "TATASTEEL\\197957"
        byte[] key = Encoding.UTF8.GetBytes(ConfigurationManager.AppSettings["EncryptKey"].ToString());
        byte[] iv = Encoding.UTF8.GetBytes("8056483646328763");

        if (plainText == null || plainText.Length <= 0) throw new ArgumentNullException("plainText");
        if (key == null || key.Length <= 0) throw new ArgumentNullException("Key");
        if (iv == null || iv.Length <= 0) throw new ArgumentNullException("IV");

        byte[] encrypted;

        using (RijndaelManaged rijAlg = new RijndaelManaged())
        {
            rijAlg.Key = key;
            rijAlg.IV = iv;
            ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(plainText);
                    }

                    encrypted = msEncrypt.ToArray();
                }
            }
        }

        return Convert.ToBase64String(encrypted);
    }
}

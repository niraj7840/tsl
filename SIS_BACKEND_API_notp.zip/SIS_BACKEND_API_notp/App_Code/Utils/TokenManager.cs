﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Web;

namespace SIS_BACKEND_API.App_Code.Utils
{
    public class TokenManager
    {
        public static string GenerateToken(string userId)
        {
            string key = System.Configuration.ConfigurationManager.AppSettings["TokenKey"];
            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var secToken = new JwtSecurityToken(signingCredentials: credentials, issuer: "TATASTEEL", audience: "TATASTEEL",
            claims: new[] { new System.Security.Claims.Claim("userId", userId) },
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddMinutes(60));
            var handler = new JwtSecurityTokenHandler();
            var tkn = handler.WriteToken(secToken);
            return tkn;
            //return key;
        }

        public static string VerifyToken(string jwtoken)
        {
            try
            {
                Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true;
                var Tokenkey = System.Configuration.ConfigurationManager.AppSettings["TokenKey"]; ;
                var stream = jwtoken;
                var handler = new JwtSecurityTokenHandler();
                var jsonToken = handler.ReadToken(stream);
                var tokenS = handler.ReadToken(stream) as JwtSecurityToken;
                var userId = tokenS.Claims.First(claim => claim.Type == "userId").Value;
                bool validationStatus = ValidateToken(jwtoken, Tokenkey);
                if (validationStatus == true)
                {
                    //using (efficioEntities db = new efficioEntities())
                    //{
                    //if (db.T_USER_DETAILS.Any(x => x.id == userId && x.active == "Y"))
                    //    userId = userId;
                    //else
                    //    userId = "-1";
                    //}
                }
                else { userId = "-1"; }
                return userId;
            }
            catch (Exception ex)
            {
                return "-1";
            }
        }


        private static bool ValidateToken(string authToken, string key)

        {

            try

            {

                var tokenHandler = new JwtSecurityTokenHandler();

                var validationParameters = GetValidationParameters(key);

                Microsoft.IdentityModel.Tokens.SecurityToken validatedToken;

                IPrincipal principal = tokenHandler.ValidateToken(authToken, validationParameters, out validatedToken);

                return true;

            }

            catch

            {

                return false;

            }

        }
        private static TokenValidationParameters GetValidationParameters(string key)
        {
            return new TokenValidationParameters()
            {
                ValidateLifetime = false,
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidIssuer = "urn://apigee-edge-JWT-policy-test",
                ValidAudience = "audience1",
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)) // The same key as the one that generate the token
            };
        }
    }
}
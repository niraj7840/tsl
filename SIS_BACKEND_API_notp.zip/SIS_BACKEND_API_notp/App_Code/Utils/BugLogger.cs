﻿
using System;
using System.Configuration;
using System.Data;

/// <summary>
/// This class represents the Bug Logger Class for logging bugs/exceptions in the Database table.
/// </summary>
public class BugLogger
{
    /// <summary>
    /// String variable for storing the connection string to Ensafe DB
    /// </summary>
    private string strConnToEnsafeDB;//= ConfigurationManager.ConnectionStrings["connStringToSampleDB"].ConnectionString;

    /// <summary>
    /// Object of the type ConnectionOracleDB to establish connections with the Oracle DB
    /// </summary>
    private ConnectionOracleDB objConn;

    /// <summary>
    /// This method contains the code to log/mail the Bug Details encountered during program run.
    /// </summary>
    /// <param name="strFormName">Name of the form where the exception occurred</param>
    /// <param name="strMethodName">Name of the method where the exception occurred</param>
    /// <param name="strErrorMessage">Exception Message</param>
    /// <param name="strExtraParameterDetails">Optional parameters</param>
    /// <returns></returns>
    public bool LogBug(string strFormName, string strMethodName, string strErrorMessage, string strExtraParameterDetails)
    {

        //Boolean type variable to keep a track as to whether the record was successfully inserted or not.
        bool isInsertDone = false;

        //Integer type variable to keep a track of the number of rows in inserted in database.
        int rowsInserted = 0;
        try
        {
            //TODO: LOG THE BUG DETAILS IN A DATABASE TABLE or/and SEND A MAIL TO A LIST OF INTENDED RECIPIENTS
        }
        catch (Exception)
        {
            //Check the count of the rows inserted and set the boolean flag to false if no rows were inserted.
            if ((rowsInserted > 0))
            {
                isInsertDone = true;
            }
            else
            {
                isInsertDone = false;
            }
        }

        //Return the boolean flag from the function indicating whether the Insertion of the Log was successful or not.
        return isInsertDone;
    }
}
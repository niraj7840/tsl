﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Net.Mail;
using System.Globalization;
using System.IO;
using System.Collections.ObjectModel;
using System.Data;

/// <summary>
/// Summary description for CommonUtils
/// </summary>
public class CommonUtils
{
    //TODO: DEFINE YOUR COMMON UTILS HERE.

    /// <summary>
    /// This method contains the code to remove the special characters from a given string.
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static string RemoveSpecialCharacters(string str)
    {
        StringBuilder sb = new StringBuilder();
        foreach (char c in str)
        {
            if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' ' || c == '_')
            {
                sb.Append(c);
            }
        }
        return sb.ToString();
    }

    /// <summary>
    /// OVERLOADED METHOD TYPE 1
    /// </summary>
    /// <param name="recipients"></param>
    /// <param name="subject"></param>
    /// <param name="message"></param>
    /// <param name="from"></param>
    public static void postMail(string[] recipients, string subject, string message, string from)
    {
        string[] bcc = { };
        string[] cc = { };
        postMail(recipients, subject, message, from, cc, bcc);
    }

    /// <summary>
    /// OVERLOADED METHOD TYPE 2
    /// </summary>
    /// <param name="recipients"></param>
    /// <param name="subject"></param>
    /// <param name="message"></param>
    /// <param name="from"></param>
    /// <param name="cc"></param>
    public static void postMail(string[] recipients, string subject, string message, string from, string[] cc)
    {
        string[] bcc = { };
        postMail(recipients, subject, message, from, cc, bcc);
    }

    /// <summary>
    /// This method contains the code to send mails to a list of recipients. Parent Method for above Overloaded Methods.
    /// </summary>
    /// <param name="recipients"></param>
    /// <param name="subject"></param>
    /// <param name="message"></param>
    /// <param name="from"></param>
    /// <param name="cc"></param>
    /// <param name="bcc"></param>
    public static void postMail(string[] recipients, string subject, string message, string from, string[] cc, string[] bcc)
    {
        //An object of the type SMTPClient - 144.0.16.7
        SmtpClient smtp = new SmtpClient("");

        //Create an object of type MailMessage
        MailMessage mailMessage = new MailMessage();

        //Set the from mail id
        mailMessage.From = new MailAddress(from);

        //Add the TO recipients.
        foreach (string email in recipients)
        {
            if (string.IsNullOrEmpty(email) == false)
            {
                mailMessage.To.Add(email);
            }
        }

        //Add the BCC Recipients
        foreach (string email in bcc)
        {
            if (string.IsNullOrEmpty(email) == false)
            {
                mailMessage.Bcc.Add(email);
            }
        }
        //Add the CC Recipients
        foreach (string email in bcc)
        {
            if (string.IsNullOrEmpty(email) == false)
            {
                mailMessage.CC.Add(email);
            }
        }

        //Set the subject
        mailMessage.Subject = subject;
        //Set the Body
        mailMessage.Body = message;
        //Set the is html to true
        mailMessage.IsBodyHtml = true;
        //Send the mail.
        smtp.Send(mailMessage);
    }    
}
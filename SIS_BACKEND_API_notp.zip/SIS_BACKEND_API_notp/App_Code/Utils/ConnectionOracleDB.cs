﻿
using System;
using System.Data;
using Oracle.ManagedDataAccess.Client;

/// <summary>
/// Summary description for OracleConnection
/// </summary>
public class ConnectionOracleDB
{
    #region variables

    private string connString = null;
    private OracleCommand Command = null;
    private OracleConnection DBConnection = null;
    private OracleDataAdapter DataAdapter = null;
    public DataTable ResultantTable = null;
    public OracleDataReader DataReader = null;
    public string scalarValue = null;

    #endregion variables

    /// <summary>
    /// Parameterized constructor for initializing the connection object and Data Table.
    /// </summary>
    /// <param name="connString"></param>
    /// <param name="needDataTable"></param>
    public ConnectionOracleDB(string connString, string strQuery, CommandType commandType, bool needDataTable)
    {
        //Initialize the OracleConnection object with the passed string.
        DBConnection = new OracleConnection(connString);

        //Initialize the Oracle Command object with the passed Oracle Connection object and SQL Query.
        Command = new OracleCommand(strQuery, DBConnection);
        //Set the command type attribute of the Oracle Command.
        Command.CommandType = commandType;

        //If the data from the query is to be fetched into a Data Table == true
        if (needDataTable == true)
        {
            //Initialize the Data Table.
            ResultantTable = new DataTable();
            //Initialize the Data Adapter.
            DataAdapter = new OracleDataAdapter(Command);
        }
    }

    /// <summary>
    /// This method is used to open the Oracle Connection.
    /// </summary>
    public void OpenConnection()
    {
        //Checks whether the connection has been opened early. If yes it reset the connection string, if no it will open the connection.
        if (DBConnection.State == ConnectionState.Closed)
        {
            DBConnection.Open();
        }
    }

    /// <summary>
    /// This method is used to close the Oracle Connection.
    /// </summary>
    public void CloseConnection()
    {
        //Checks whether the connection has been opened early. If yes it reset the connection string, if no it will open the connection.
        if (DBConnection.State == ConnectionState.Open)
        {
            DBConnection.Close();
        }
    }

    /// <summary>
    /// Adds the Parameters to the Command Object Required for the execution.
    /// </summary>
    /// <param name="ParameterName">Name of the parameter with Prefix : </param>
    /// <param name="Value">Value of the Parameter </param>
    public void AddParameters(String ParameterName, object Value)
    {
        if (Command != null)
        {
            //Add Parameters to the Oracle Command.
            Command.Parameters.Add(ParameterName, Value);
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }

    /// <summary>
    /// Adds the Parameters to the Command Object Required for the execution.
    /// </summary>
    /// <param name="ParameterName">Name of the parameter with Prefix : </param>
    /// <param name="Value">Value of the Parameter </param>
    /// <param name="DataType">Data Type of the Parameter.</param>
    public void AddParametersWithDataType(String ParameterName, object Value, OracleDbType DataType)
    {
        if (Command != null)
        {
            //Add Parameters to the Oracle Command along with the Parameter Type.
            Command.Parameters.Add(ParameterName, DataType).Value = Value;
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }

    /// <summary>
    /// Executes Non Query on the Oracle Command
    /// </summary>
    /// <returns>Returns the No of Rows affected by executing the Stored Procedure/SQL Query</returns>
    public int ExecuteNonQuery()
    {
        //Execute the Command if the connection state is opened else throw an Application Exception.
        if (DBConnection.State == ConnectionState.Open)
        {
            return Command.ExecuteNonQuery();
        }
        else
        {
            throw new ApplicationException("Connnection Not Opened");
        }
    }

    /// <summary>
    ///  This method populates ResultantDataTable with the data fetched by executing the query.
    /// </summary>
    public void FillDataTable()
    {
        //If the data adapter is initialized then invoke the Fill method on the data adapter else throw and Application Exception.
        if (DataAdapter != null)
        {
            DataAdapter.Fill(ResultantTable);
        }
        else
        {
            throw new ApplicationException("Data Adapter is being used without initialization");
        }
    }

    /// <summary>
    /// Executes the Reader Operation
    /// After executing the DataReader will start pointing to the result set.
    /// </summary>
    public void ExecuteReader()
    {
        //Application Exception is thrown if the connection is not opened.
        if (DBConnection.State != ConnectionState.Open)
        {
            throw new ApplicationException("Connnection Not Opened");
        }

        //If the command is not null then the DataReader object is made to point to the result set.Else an ApplicationException is thrown.
        if (Command != null)
        {
            DataReader = Command.ExecuteReader();
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }

    /// <summary>
    /// Executes the Scalar Operation
    /// After executing the single value will be returned from the query.
    /// </summary>
    public void ExecuteScalar()
    {
        //Application Exception is thrown if the connection is not opened.
        if (DBConnection.State != ConnectionState.Open)
        {
            throw new ApplicationException("Connnection Not Opened");
        }

        //If the command is not null then the DataReader object is made to point to the result set.Else an ApplicationException is thrown.
        if (Command != null)
        {
            scalarValue = (string)Command.ExecuteScalar();
        }
        else
        {
            throw new ApplicationException("Sql Command is being used without initialization");
        }
    }
}
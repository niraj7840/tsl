﻿
using System.Configuration;

public class CommonConstants
{
    //TODO: DEFINE YOUR COMMON CONSTANTS HERE

    /// <summary>
    /// Represents the Session Variable Name for CommodityList
    /// </summary>
    public const string SESSION_COMMODITY = "COMMODITY_LIST";
    /// <summary>
    /// Represents the Session Variable Name for User ID
    /// </summary>
    public const string SESSION_USER_ID = "USER_ID";

    /// <summary>
    /// Represents the Session Variable Name for User Full Name
    /// </summary>
    public const string SESSION_USER_FULL_NAME = "USER_FULL_NAME";

    /// <summary>
    /// Represents the Session Variable Name for User Domain
    /// </summary>
    public const string SESSION_USER_DOMAIN = "USER_DOMAIN";

    /// <summary>
    /// Represents the Session Variable Name for User Designation
    /// </summary>
    public const string SESSION_USER_DESIGNATION_DESC = "USER_DESIGNATION_DESC";

    /// <summary>
    /// Represents the Session Variable Name for User Sub Group
    /// </summary>
    public const string SESSION_USER_EMA_EMPL_SUBGRP = "USER_EMA_EMPL_SUBGRP";

    /// <summary>
    /// Represents the Session Variable Name for User Department Description
    /// </summary>
    public const string SESSION_USER_DEPT_DESC = "USER_DEPT_DESC";

    /// <summary>
    /// Represents the Session Variable Name for User Role
    /// </summary>
    public const string SESSION_USER_ROLE= "USER_ROLE";

    /// <summary>
    /// Represents the Session Variable Name for User Role
    /// </summary>
    public const string SESSION_USER_MULTI_ROLE = "USER_MULTI_ROLE";

    /// <summary>
    /// Represents the Session Variable Name for storing the Error Code
    /// </summary>
    public const string SESSION_ERROR_CODE = "ERROR_CODE";

    /// <summary>
    /// Represents the constant for the Info Type Safety Message
    /// </summary>
    public const string SAFETY_MESSAGE_INFO = "INFO";

    /// <summary>
    /// Represents the constant for the Link Type Safety Message
    /// </summary>
    public const string SAFETY_MESSAGE_LINK = "LINK";

    /// <summary>
    /// Represents the constant for the Alert Type Safety Message
    /// </summary>
    public const string SAFETY_MESSAGE_ALERT = "ALERT";

    /// <summary>
    /// Represents the constant for the Tata Steel Domain.
    /// </summary>
    public const string DOMAIN_TATA_STEEL = "TATASTEEL";

    /// <summary>
    /// Represents the string constant for SWEET ALERT TYPE - SUCCESS
    /// </summary>
    public const string SWEET_ALERT_TYPE_SUCCESS = "success";

    /// <summary>
    /// Represents the string constant for SWEET ALERT TYPE - ERROR
    /// </summary>
    public const string SWEET_ALERT_TYPE_ERROR = "error";

    /// <summary>
    /// Represents the string constant for SWEET ALERT TYPE - WARNING
    /// </summary>
    public const string SWEET_ALERT_TYPE_WARNING = "warning";

    /// <summary>
    /// Represents the string constant for SWEET ALERT TYPE - INFO
    /// </summary>
    public const string SWEET_ALERT_TYPE_INFO = "info";

    /// <summary>
    /// Represents the string constant for SWEET ALERT TYPE - QUESTION
    /// </summary>
    public const string SWEET_ALERT_TYPE_QUESTION = "question";

    /// <summary>
    /// Represents the default text for Select for a drop down.
    /// </summary>
    public const string DEFAULT_SELECT_TEXT = "Please Select";

    /// <summary>
    /// Represents the from Mail ID for sending mails.
    /// </summary>
    public const string FROM_MAIL_ID = "ensafe@ensafe.com";

    #region Spare Sharing
    public const string PendingWithHOD = @"2";


    #endregion


    public const string SuperAdmin = "12";
    public const string SCAdmin = "13";



    #region capital planning constants

    public const string level_1 = @"1";

    public const string level_2 = @"2";

    public const string BGG = @"3";

    public const string QUESTIONMASTER = @"57";

    #endregion

    #region DOP constants

    public const string AIULPPENDING = "12";
    public const string INTRAPENDING = "13";
    public const string INTERPENDING = "14";
    public const string CAPEXPENDING = "15";
    public const string PendingForL1 = "41";
    public const string PendingForL2 = "42";
    public const string ReturnByL1 = "43";
    public const string ReturnByL2 = "44";

    public const string PendingForL3 = "46";
    public const string PendingForL4 = "47";
    public const string ReturnByL3 = "48";
    public const string ReturnByL4 = "49";

    public const string PendingForL5 = "50";
    public const string ReturnByL5 = "51";

    public const string PendingForL6 = "00";
    public const string ReturnByL6 = "01";
    #endregion

}
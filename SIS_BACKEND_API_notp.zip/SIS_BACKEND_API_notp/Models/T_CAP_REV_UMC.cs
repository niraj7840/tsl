﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class T_CAP_REV_UMC
    {
        public string CRU_UMC { get; set; }
        public string CRU_TAG { get; set; }
        public string CRU_REQUEST_ID { get; set; }
        public string CRU_STATUS { get; set; }
        public string CRU_CREATED_BY { get; set; }
        public DateTime? CRU_CREATED_ON { get; set; }

    }

    public class T_CAP_REV_UMC_USER
    {
        public int CUA_REQUEST_ID { get; set; }
        public string CUA_LEVEL1_APPRD_BY { get; set; }
        public string CUA_LEVEL1_APPRD_REMARKS { get; set; }

        public string CUA_LEVEL2_APPRD_BY { get; set; }
        public string CUA_LEVEL2_APPRD_REMARKS { get; set; }

        public string CUA_CAPACCNTS_APPRD_BY { get; set; }
        public string CUA_CAPACCNTS_APPRD_REMARKS { get; set; }
        public string CRU_UMC { get; set; }
        public string CRU_TAG { get; set; }
        public string CRU_REQUEST_ID { get; set; }
        public string CRU_STATUS { get; set; }
        public string CRU_CREATED_BY { get; set; }
        public DateTime? CRU_CREATED_ON { get; set; }
        public string taggingWhenRaised {  get; set; }

        public string CUA_INDENT_NO {  get; set; }
    }
}
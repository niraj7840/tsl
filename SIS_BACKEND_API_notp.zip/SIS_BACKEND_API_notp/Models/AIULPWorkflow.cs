﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class AIULPUMC
    {

        public int UmcIndentId {  get; set; }

        public int IndentId { get; set; }

        public int Quantity {  get; set; } 

        public DateTime CreatedDate { get; set; }

        public string UMCStatus { get; set; }

        public int TotalSAPQty { get; set; }

        public int AIULPInventory {  get; set; }

        public int IntaInventory { get; set; }

        
       

    }

    public class MailFormat
    {
        public List<string> Mail_To { get; set; }
        public string Mail_Subject { get; set; }
        public string Mail_Body { get; set; }

        public List<string> Mail_CC { get; set; }
    }

    public class MailDetails
    {
        public string Mail_To { get; set; }
        public string Mail_Subject { get; set; }
        public string Mail_Body { get; set; }
        public string MAIL_CC { get; set; }
        public string MAIL_BCC { get; set; }
        public int INDENT_ID { get; set; }
        public int WF_ID { get; set; }
        public string MAIL_FROM { get; set; }
        public int UMCIndentId { get; set; } 
        
    }

    public class AIULPWorkflow
    {
        public int WfID { get; set; }
        public int UmcIndentId { get; set; }
        public int Quantity { get; set; }

        public int ApprovedQuantity { get; set; }

        public string WFType { get; set; }

        public string WFStatus { get; set; }

        public string SrcPlantId { get; set; }

        public string SrcDeptId { get; set; }

        public DateTime WFExpiryDate { get; set; }
        public DateTime LastUpdated { get; set; }

        public DateTime CreatedDate { get; set; }

        public int MrQTY { get; set; }

        public int StrQTY { get; set; }

        public int StoQty { get; set; }

        public int SAPDOCQTY { get; set; }

        public bool SAPUpdateStatus { get; set; }

        public bool PIStatus { get; set; }

        public string WFRemarks {  get; set; }

        public bool IsDataUpdatedFromSAP { get; set; }

        public string SAPErrorMessage { get; set; }

        public bool IsDataUpdatedOnSAP { get; set; }

        public int Approved_QTY { get; set; }

    }

    public class ApproverDetails
    {
        public string ADID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

    public class BodyContent
    {
        public int WFId { get; set; }
        public string ApproverDepartment { get; set; }
        public int UMCIndentId { get; set; }
        public int IndentId { get; set; }
        public string ApproverPlant { get; set; }
        public string MaterialName { get; set; }
        public DateTime WFExpiryDate { get; set; }
        public int RequestedQuantity { get; set; }
        public string IndenterDept { get; set; }
        public string IndenterName { get; set; }
        public string IndeterADID { get; set; }
        public string IndenterEmail { get; set; }
        public string ApprovedQuantity {  get; set; }
    }
    public class IndenterDetails
    {
        public string IndenterDept { get; set; }
        public string IndenterPlant { get; set; }
        public string IndenterName { get; set; }
        public string IndeterADID { get; set; }
        public string IndenterEmail { get; set; }

        public string IndentCrtDate { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class CAP_UMC_REQ
    {
        public string CUR_REQUEST_ID { get; set; }
        public int CUR_QUESTION_ID { get; set; }
        public string CUR_RESPONSE { get; set; }
        public string CUR_CREATED_BY { get; set; }
        public string CUR_CREATED_ON { get; set; }
    }
}
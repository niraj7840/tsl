﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class UmcCapexApproval
    {
        public int CUA_REQUEST_ID { get; set; }
        public string CUA_UMC { get; set; }
        public string CUA_USER_REMARKS { get; set; }
        public string CUA_STATUS { get; set; }


        public string CUA_LEVEL1_APPRD_BY { get; set; }
        public DateTime? CUA_LEVEL1_APPRD_ON { get; set; }
        public string CUA_LEVEL1_APPRD_REMARKS { get; set; }

        public string CUA_LEVEL2_APPRD_BY { get; set; }
        public DateTime? CUA_LEVEL2_APPRD_ON { get; set; }
        public string CUA_LEVEL2_APPRD_REMARKS { get; set; }


        public string CUA_CAPACCNTS_APPRD_BY { get; set; }
        public DateTime? CUA_CAPACCNTS_APPRD_ON { get; set; }
        public string CUA_CAPACCNTS_APPRD_REMARKS { get; set; }


        public int CUA_INTENT_NO { get; set; }
        public string CUA_DEPTNO { get; set; }

        public string CUA_UMC_TAG { get; set; }
        public string CUA_UMC_DESC { get; set; }
        public string CUA_BGG { get; set; }
    }
}







﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class WorkFlowModel
    {
        public string INDENT_ID { get; set; }
        public string WF_ID { get; set; }
        public string UMC_INDENT_ID { get; set; }
        public string SRC_LOC_ID { get; set; }
        public string SRC_LOC_DESC { get; set; }
        public string SRC_PLANT_ID { get; set; }
        public string SRC_PLANT_DESC { get; set; }
        public string SRC_DEPT_ID { get; set; }
        public string SRC_DEPT_DESC { get; set; }
        public string REQ_QUANTITY { get; set; }
        public string APPROVED_QTY { get; set; }
        public string WF_TYPE { get; set; }
        public string WF_STATUS { get; set; }
        public string WF_EXPIRY_DT { get; set; }
        public string WF_REMARKS { get; set; }
        public string CRT_BY { get; set; }
        public string CRT_DT { get; set; }
        public string MOD_BY { get; set; }
        public string MOD_DT { get; set; }
        public string APP_BY { get; set; }
        public string APP_DT { get; set; }
        public string ACTION { get; set; }
        public string HODACTION { get; set; }
        public DateTime CONSUMPTION_DATE { get; set; }
        public string HODCHIEFACTION { get; set; }
        public string REASON_FOR_DENIAL { get; set; }


    }
}
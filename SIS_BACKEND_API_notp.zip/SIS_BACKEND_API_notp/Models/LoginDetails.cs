﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class LoginDetails
    {
        public T_SII_USER_DETAILS T_SII_USER_DETAILS { get; set; }
      
    }

    public class T_SII_USER_DETAILS
    {
        public string adid { get; set; }
        public string email { get; set; }     
        public string Otp { get; set; }
        public string contactNumber { get; set; }
        public string createdBy { get; set; }
        public string modifiedBy { get; set; }
        public string OTPType { get; set; }

            }

    public class LatestOTP
    {
        public string ADID { get; set; }
        public string LtsOTP { get; set; }
        public string MinDiff { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models.ShoppingCartModel
{
    
    public class ApprovalRequest
    {
        public int tot_amnt { get; set; }
        public string indnt_type { get; set; }
        public int scartno { get; set; }
        public int dept_no { get; set; }
        public int Committed_Expenditure_Val { get; set; }
        public int Spare_Budget_Val { get; set; }       
        
    }

    public class ApprovalSection
    {
        public string nscnum { get; set; }
        public string _status { get; set; }
        public string appr_id { get; set; }
        public string appr_rem { get; set; }      
        public string mail_to { get; set; }
        public string IMEI_no { get; set; }
        
    }


    public class FileUploadModel
    {
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public string Sno { get; set; }
        public string UserId { get; set; }
        public string SCA_FILE_TYPE { get; set; }
    }

    public class CommunicationRequest
    {
        public string SCC_CART_NO { get; set; }
        public string SCC_SEQ_NO { get; set; }
        public string SCC_TYPE { get; set; }
        public string SCC_TEXT { get; set; }
        public string SCC_FROM_ID { get; set; }
        public string SCC_TO_ID { get; set; }
        public string SCC_ACTIVE_FLAG { get; set; }
        public string SCC_STATUS { get; set; }
        public string SCC_CRT_BY { get; set; }
        public string SCC_IS_CONFIDENTIAL { get; set; }


    }

    public class ShoppingCartUpdateRequest
    {
        public string SCH_CART_NO { get; set; }
        public string SCH_STATUS { get; set; }
        public string SCH_UPD_ID { get; set; }

        public string RETURN_TO_ID { get; set; }

        public string RETRUN_LVL { get; set; }

        public string INDENT_NO { get; set; }
    }


    public class IntelliBuyIndentDetails_ODA_SC
    {
        public string DeptBudgetConsumption { get; set; }    
     
        public double COMMITTEDEXPENDITURE { get; set; }
        public double SPAREBUDGET { get; set; }
        public string FY_YEAR { get; set; }
       
      
    }

    public class CartDetail
    {
        public string CartNo { get; set; }
        public string TotalValue { get; set; }
    }

    public class ApprovalRequest_ForRegenHierarchy
    {
        public string DeptNo { get; set; }
        public List<CartDetail> CartDetails { get; set; }  // Updated to match the structure from frontend
    }

    public class AddApprover_SC
    {
        public string scp_cart_no { get; set; }
        public string SCP_APP_LVL { get; set; }
        public string SCP_APPRVR { get; set; }
        public string SCD_CRT_BY { get; set; }
      
      

    }

}



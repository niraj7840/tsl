﻿using SIS_BACKEND_API.Models.IntelliBuyModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models.ShoppingCartModel
{
    public class ShoppingCartModel
    {
        public ShoppingCartHeader ObjShoppingCartHeader { get; set; }

        public List<ShoppingCartItem> ObjShoppingCartItemDetails { get; set; }
        public SustainibilityCSR ObjSustainibilityCSR { get; set; }
        public string IsDraft { get; set; }
    }
    public class ShoppingCartHeader
    {
        public string SCH_CART_NO { get; set; }
        public string SCH_CART_NAME { get; set; }
        public string SCH_CRT_ID { get; set; }
        public string SCH_CRT_DT { get; set; }
        public string SCH_TOT_VAL { get; set; }
        public string SCH_VAL_UNIT { get; set; }
        public string SCH_STATUS { get; set; }
        public string SCH_NOTE_APP { get; set; }
        public string SCH_UPD_ID { get; set; }
        public string SCH_UPD_DT { get; set; }
        public string SCH_INDT_TYP { get; set; }
        public string SCH_COMP_CD { get; set; }
        public string SCH_CRT_TIMESTAMP { get; set; }
        public int SCH_APPR_LVL { get; set; }
        public string SCH_DEPT { get; set; }
        public int SCH_CURR_APPR_LVL { get; set; }
        public int SCH_VERSION { get; set; }
        public string SCH_VAL_ST_DT { get; set; }
        public string SCH_VAL_END_DT { get; set; }
        public string SCH_UR_REF { get; set; }
        public string SCH_OUR_REF { get; set; }
        public string SCH_SALES_PERS { get; set; }
        public string SCH_TEL_NO { get; set; }
        public string SCH_FOD_DOC_RECV_DT { get; set; }
        public string SCH_FOD_DOC_RECV_DT_UID { get; set; }
        public string SCH_RETMAIL_SHOPS { get; set; }
        public string SCH_CHALLAN_NO { get; set; }
        public string SCH_KDATB { get; set; }
        public string SCH_KDATE { get; set; }
        public string SCH_PI_STATUS { get; set; }
        public string SCH_PI_PICK_TIMESTAMP_Z { get; set; }
        public string SCH_PI_ACK_TIMESTAMP_Z { get; set; }
        public string SCH_PI_PICK_TIMESTAMP_X { get; set; }
        public string SCH_PI_ACK_TIMESTAMP_X { get; set; }
        public string SCH_PI_FINAL_TIMESTAMP { get; set; }
        public string SCH_PI_IB_MESSAGE_ID { get; set; }
        public string SCH_PI_OB_MESSAGE_ID { get; set; }
        public string SCH_PI_SOURCE_PGM { get; set; }
        public string SCH_BUDGET_ENABLED { get; set; }
        public string SCH_CONT_OWNER { get; set; }
        public string SCH_CONT_ADMIN { get; set; }
        public string SCH_REGION { get; set; }
        public string SCH_GLOBAL { get; set; }
        public string SCH_SANC_REQ_NO { get; set; }
        public string SCH_BUDGET_EXCEEDED_AMT { get; set; }
        public string SCH_RECOMMENDED_BY { get; set; }
        public string SCH_EXPECTED_ST_DT { get; set; }
        public string SCH_PI_ACT_DT { get; set; }
        public string SCH_GEP_CART_TYPE { get; set; }
        public string SCH_JOB_TYPE { get; set; }
        public string SCH_CRT_FY { get; set; }
    }

    public class ShoppingCartItem
    {
        public List<SCCostAssignment> sccostAssignment { get; set; }
        public string SCI_CART_NO { get; set; }
        public string SCI_ITEM_NO { get; set; }
        public string SCI_ITEM_DESC { get; set; }
        public string SCI_PROD_TYPE { get; set; }
        public string SCI_MATL_NO { get; set; }
        public string SCI_REF_OA_NO { get; set; }
        public string SCI_OA_ITEM_NO { get; set; }
        public string SCI_OA_SERV_LINE_NO { get; set; }
        public string SCI_OA_ITEM_DESC { get; set; }
        public string SCI_OA_VENCD { get; set; }
        public string SCI_MATL_GRP { get; set; }
        public string SCI_PLANT_CD { get; set; }
        public string SCI_STRG_LOC { get; set; }
        public string SCI_DLV_POINT { get; set; }
        public string SCI_PUR_GRP { get; set; }
        public string SCI_DOC_TYPE { get; set; }
        public string SCI_STK_TYPE { get; set; }
        public string SCI_QTY { get; set; }
        public string SCI_QTY_UNIT { get; set; }
        public string SCI_PRICE { get; set; }
        public string SCI_PRICE_UNIT { get; set; }
        public string SCI_REQD_ON_DT { get; set; }
        public string SCI_GOOD_RCPNT { get; set; }
        public string SCI_REQUESTER { get; set; }
        public string SCI_STATUS { get; set; }
        public string SCI_FOD_TYPE { get; set; }
        public string SCI_FOD_ITEM_NO { get; set; }
        public string SCI_FOD_NO { get; set; }
        public string SCI_FOD_CRT_DT { get; set; }
        public string SCI_UPD_ID { get; set; }
        public string SCI_UPD_DT { get; set; }
        public string SCI_AA_CAT { get; set; }
        public string SCI_REQUIRED_DT_TYP { get; set; }
        public string SCI_REQUIRED_FROM_DT { get; set; }
        public string SCI_REQUIRED_TO_DT { get; set; }
        public string SCI_FOD_SERVICE_LINE_NO { get; set; }
        public string SCI_INT_FOD_TYPE { get; set; }
        public string SCI_INT_FOD_NO { get; set; }
        public string SCI_INT_FOD_ITEM_NO { get; set; }
        public string SCI_INT_FOD_SERV_LINE_NO { get; set; }
        public string SCI_OA_SERV_LINE_DESC { get; set; }
        public string SCI_SAP_ERR_MSG { get; set; }
        public string SCI_DEL_IND { get; set; }
        public string SCI_ITM_SAVED_STAT { get; set; }
        public string SCI_FOD_ERR_MAIL { get; set; }
        public string SCI_RCV_PLANT { get; set; }
        public string SCI_RCV_STRG_LOC { get; set; }
        public string SCI_FRN_PRICE { get; set; }
        public string SCI_FRN_CURR_CD { get; set; }
        public string SCI_EXCHNG_RATE { get; set; }
        public string SCI_COST_MODEL_NO { get; set; }
        public string SCI_MR_TEXT { get; set; }
        public string SCI_TXT_PROC_CONS { get; set; }
        public string SCI_IMP_PLANT_MACHINERY { get; set; }
        public string SCI_OSJ_ID { get; set; }
        public string SCI_USC_SOP { get; set; }
        public string SCI_GDCS_UID { get; set; }
        public string SCI_PROP_TAG { get; set; }
        public string SCI_USR_REQ_ID { get; set; }
        public string SCI_SUST_ID { get; set; }
        public string SCI_SUB_PACK_NO { get; set; }
        public string SCI_CREATOR_MOB { get; set; }
        public string SCI_RECEIVER_NAME { get; set; }
        public string SCI_RECEIVER_PNO { get; set; }
        public string SCI_RECIVER_MOB { get; set; }
        public string SCI_CRE_SUP_NAME { get; set; }
        public string SCI_CRE_SUP_PNO { get; set; }
        public string SCI_CRE_SUP_MOB { get; set; }
        public string SCI_BUYER_ID { get; set; }
        public string SCI_PI_STATUS { get; set; }
        public string SCI_PI_PICK_TIMESTAMP { get; set; }
        public string SCI_PI_ACK_TIMESTAMP { get; set; }
        public string SCI_PI_FINAL_TIMESTAMP { get; set; }
        public string SCI_PI_IB_MESSAGE_ID { get; set; }
        public string SCI_PI_OB_MESSAGE_ID { get; set; }
        public string SCI_PI_SOURCE_PGM { get; set; }
        public string SCI_REBURBISH_QTY { get; set; }
        public string SCI_INSTALLED_QTY { get; set; }
        public string SCI_PROC_TYP { get; set; }
        public string SCI_SPARES_CATEGORY { get; set; }
        public string SCI_HAZARD_LVL { get; set; }
        public string SCI_PART_NO { get; set; }
        public string SCI_MFRNR { get; set; }
        public string SCI_SAC_CODE { get; set; }
        public string SCI_RISK_CAT { get; set; }
        public string SCI_RMC_CONTRACT { get; set; }
        public string SCI_RMC_ITEM { get; set; }
        public string SCI_REGION { get; set; }
        public string SCI_RMC_GRADE { get; set; }
        public string SCI_SUBCON_STATUS { get; set; }
        public string SCI_SUBCON_ERR { get; set; }
        public string SCI_SUBCON_NO { get; set; }
        public string SCI_SUBCON_ITEM { get; set; }
        public string PI_OB_MESSAGE_ID { get; set; }
        public string PI_POST_TIMESTAMP { get; set; }
        public string PI_SOURCE_PGM { get; set; }
        public string SCI_MPN_NO { get; set; }
        public string SCI_DATAID { get; set; }
        public string SCI_SANC_REQ_NO { get; set; }
        public string SCI_DECISION { get; set; }
        public string SCI_CHARACTERISTICS { get; set; }
        public string SCI_COMPOSITION { get; set; }
        public string SCI_ENDUSE { get; set; }
        public string SCI_FUNCTION { get; set; }
        public string PG_GRP_DESC { get; set; }
        public string SPARE { get; set; }
        public string SLOC_DESC { get; set; }
        public string DOC_TYPE_DESC { get; set; }
        public string PROC_TYPE { get; set; }
        public string UMC_DESC { get; set; }
        public string Verpr { get; set; }
        public string MAP_VALUE { get; set; }
        public string DEPT { get; set; }
        public string SCH_INDT_TYP { get; set; }
        public string SCH_CART_NAME { get; set; }
        public bool SCI_ClassificationEnable { get; set; }
        public bool MaterialConsumptionPlanEnble { get; set; }
        public int INDENT_CURRENT_STATUS { get; set; }



    }

    public class SCDocument
    {
        public string SCD_CART_NO { get; set; }
        public string SCD_ITEM_NO { get; set; }
        public string SCD_TXT_TYPE { get; set; }
        public string SCD_LINE_NO { get; set; }
        public string SCD_TXT { get; set; }
        public string SCD_UPD_ID { get; set; }
        public string SCD_LVL { get; set; }
    }
    public class SCCostAssignment
    {
        public string SAA_CART_NO { get; set; }
        public string SAA_ITEM_NO { get; set; }
        public string SAA_LINE_NO { get; set; }
        public string SAA_DISTRIBUTION_TP { get; set; }
        public string SAA_CATEGORY { get; set; }
        public string SAA_ASGND_TO { get; set; }
        public string SAA_UPD_ID { get; set; }
        public string SAA_DISTRIBUTION_VAL { get; set; }
        public string SAA_ACTIVITY_NUM { get; set; }
        public string SAA_Dept { get; set; }
        public ShoppingCartItem ObjShoppingCartItemDetails { get; set; }


    }

    public class SustainibilityCSR
    {
        public string SCC_CART_NO { get; set; }
        public string SCC_ITEM_NO { get; set; }
        public string SCC_FOD_TYPE { get; set; }
        public string SCC_FOD_NO { get; set; }
        public string SCC_FOD_ITEM_NO { get; set; }
        public string SCC_DEPT { get; set; }
        public string CSR_ACT_TAG { get; set; }
        public string CSR_COMP { get; set; }
        public string SCC_CRT_ID { get; set; }
        public string SCC_CRT_DT { get; set; }
        public string SCC_SUB_CODE { get; set; }
        public string SCC_SUB_ACTIVITY_CODE { get; set; }
        public string SCC_LOC_CODE { get; set; }
        public string SCC_REMARKS { get; set; }
    }
    public class SC_ATTACHMENT
    {
        public string SCA_CART_NO { get; set; }
        public string SCA_ITEM_NO { get; set; }
        public string SCA_ATTCH_NO { get; set; }
        public string SCA_FILE_NAME { get; set; }
        public string SCA_FILE_TYPE { get; set; }
        public string SCA_FILE_SIZE { get; set; }
        public string SCA_UPD_DT { get; set; }
        public string SCA_UPD_ID { get; set; }
        public byte[] SCA_FILE { get; set; }
        public string SCA_DATAID { get; set; }
    }
    public class Suggestion
    {
        public string Description { get; set; }
        public string CostCenter { get; set; }
    }

    public class BudgetDetails
    {
        public int CurrFY { get; set; }
        public string BudgetPercentage { get; set; }

        public List<BBPRList> BBPRList { get; set; }

    }

    

    public class SourceListSet
    {
        public string Material      { get; set; }
        public string Plant         { get; set; }
        public string Contract { get; set; }
        public string Item_no { get; set; }
        public string Vendor_code { get; set; }
        public string Vendor_name { get; set; }
        public string Source_valid_from { get; set; }
        public string Souce_valid_to { get; set; }
        public string Contract_valid_from { get; set; }
        public string Contract_valid_to { get; set; }
        public string Balance { get; set; }
        public string SCI_CART_NO { get; set; }
        public string SCI_ITEM_NO { get; set; }
        public string SCI_UPD_ID { get; set; }

        public string SCI_REQD_ON_DT { get; set; }
        public string TotalPrice { get; set; }

    }

}


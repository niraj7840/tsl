﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class Plant
    {
        public string plant { get; set; }
    }
    public class CODEVAL
    {
        public string ID { get; set; }
        public string VAL { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class CapitalRequestModel
    {

    }

    public class FormModel
    {
        public string UmcNumber { get; set; }
        public List<string> QuestionResponses { get; set; }
        public string Remarks { get; set; }
        public string tag {  get; set; }
        public string description { get; set; }
        public string BGG {  get; set; }


    }

    public class CapexApprovalRequest
    {
        public List<FormModel> Forms { get; set; }
        public int? CUA_INTENT_NO { get; set; }  // Nullable to handle optional values
        public string CUR_CREATED_BY { get; set; }

    }

    public class CapexApprovalRequestData
    {
        public int CUA_REQUEST_ID { get; set; }
        public string CUA_UMC { get; set; }
        public string CUA_USER_REMARKS { get; set; }
        public int CUR_QUESTION_ID { get; set; }
        public string CUR_RESPONSE { get; set; }
        public string CUR_CREATED_ON { get; set; }

        public string CQM_QUES_DESC { get; set; }

        public string CUA_STATUS { get; set; }
    }

    public class UmcCapexApprovalUpdateModel
    {
        public int CUA_REQUEST_ID { get; set; }
        public string CUA_LEVEL1_APPRD_BY { get; set; }
        public string CUA_LEVEL1_APPRD_REMARKS { get; set; }

        public string CUA_LEVEL2_APPRD_BY { get; set; }
        public string CUA_LEVEL2_APPRD_REMARKS { get; set; }

        public string CUA_CAPACCNTS_APPRD_BY { get; set; }
        public string CUA_CAPACCNTS_APPRD_REMARKS { get; set; }

    }
}
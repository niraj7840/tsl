﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class SaveDraft
    {
        public string UMC_INDENT_ID { get; set; }
        public string REQ_UMC_NO { get; set; }
        public string INDENT_ID { get; set; }
        public string REQ_UMC_DESC { get; set; }
        public string EXISTING_UMC { get; set; }
        public string EXIS_UMC_DESC { get; set; }
        public string DEST_SLOC { get; set; }
        public string UOM { get; set; }
        public string BUOM { get; set; }
        public string QTY { get; set; }
        public string IS_REFURBISHABLE { get; set; }
        public string IS_CRITICAL { get; set; }
        public string IS_PERISHABLE { get; set; }
        public string REQ_DT { get; set; }
        public string consumptionDate { get; set; }
        public string PROC_TYPE { get; set; }

        public string materialBGG { get; set; }
        public string currency { get; set; }
        public string requestedOn { get; set; }
        public string rate { get; set; }
        public string docType { get; set; }
        public string fodType { get; set; }
        public bool OperationalConsumable {  get; set; }


        public string SRC_LOC_ID { get; set; }
        public string SRC_LOC_DESC { get; set; }
        public string SRC_PLANT_ID { get; set; }

        public string SRC_DEPT_ID { get; set; }
        public string SRC_DEPT_DESC { get; set; }
        public string REQ_QUANTITY { get; set; }
        public string APPROVED_QTY { get; set; }
        public string WF_TYPE { get; set; }
        public string WF_STATUS { get; set; }
        public string WF_EXPIRY_DT { get; set; }
        public string WF_REMARKS { get; set; }


        public string umcNo { get; set; }
        public string materialDescription { get; set; }
        public string procurementType { get; set; }
        public string intraInventory { get; set; }
        public string interInventory { get; set; }
        public string aiulpInventory { get; set; }
        public string quantity { get; set; }
        public string unitOfMeasurement { get; set; }
        public string destinationStorage { get; set; }

        public string existingUmcNo { get; set; }

        public string existingMaterialDescription { get; set; }

        public string INDENT_DESC { get; set; }
        public string INDENT_REMARKS { get; set; }
        public string INDENTOR_DEPT { get; set; }
        public string INDENTOR_PLANT { get; set; }
        public string INDENTOR_LOC { get; set; }
        
        public string purchaseGroup { get; set; }
        public string delPoint { get; set; }
        public string INDENTOR { get; set; }
        public string DT { get; set; }

        public string DELPOINT_DESC { get; set; }
        public string FODTYPE_DESC { get; set; }
        public string DOCTYPE_DESC { get; set; }
        public string PURGROUP_DESC { get; set; }

        public string INDENT_CURRENT_STATUS { get; set; }
        public string INDENT_STATUS { get; set; }
        public string INDENT_L1_REMARKS { get; set; }
        public string INDENT_L2_REMARKS { get; set; }
        public string INDDEPT { get; set; }
        public string INDPLANT { get; set; }
        public string TOTALMAP { get; set; }
        public string CSTATUS { get; set; }
        public string ISCONSUMABLE { get; set; }
        
public string INDENT_LEVEL { get; set; }
        public string CONTRACTNUMBER { get; set; }
        public string ITEMNO { get; set; }

    }
    public class TabList
    {
        public string table_name { get; set; }
        public string column_name { get; set; }
        public string data_type { get; set; }
        public string data_length { get; set; }
        public string column_id { get; set; }
        public string nullable { get; set; }
        public string VAL { get; set; }
        public string ACT { get; set; }
    }
}
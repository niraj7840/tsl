﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SIS_BACKEND_API.Models
{
    public class SaveIndent
    {
        public T_SII_INDENT_DETAILS T_SII_INDENT_DETAILS { get; set; }
        public List<WorkFlowModel> WorkFlowModel { get; set; }
        public List<T_SIS_UMC_INDENT_DETAILS> T_SIS_UMC_INDENT_DETAILS { get; set; }
        public List<T_SII_WORK_FLOW> T_SII_WORK_FLOW { get; set; }
        public string IsDraft { get; set; }
    }
    public class T_SII_INDENT_DETAILS
    {
        public string IndentId { get; set; }

        public string IndentorLoc { get; set; }
        public string IndentorPlant { get; set; }
        public string IndentorDept { get; set; }
        public string IndentDesc { get; set; }
        public string IndentRemarks { get; set; }
        public string UserName { get; set; }
        public string STATUS { get; set; }
        public string LEVEL { get; set; }
        public string NEXTLEVEL { get; set; }
        public string DOPSTATUS { get; set; }
        public bool OperationalConsumable { get; set; }

    }
    public class T_SIS_UMC_INDENT_DETAILS
    {
        public string UMC_INDENT_ID { get; set; }
        public string REQ_UMC_NO { get; set; }
        public string INDENT_ID { get; set; }
        public string REQ_UMC_DESC { get; set; }
        public string EXISTING_UMC { get; set; }
        public string EXIS_UMC_DESC { get; set; }
        public string DEST_SLOC { get; set; }
        public string UOM { get; set; }
        public string QTY { get; set; }
        public string IS_REFURBISHABLE { get; set; }
        public string IS_CRITICAL { get; set; }
        public string IS_PERISHABLE { get; set; }
        public string REQ_DT { get; set; }
        public string consumptionDate { get; set; }
        public string PROC_TYPE { get; set; }
        public string USERNAME { get; set; }
        public string intraInventory { get; set; }
        public string interInventory { get; set; }
        public string aiulpInventory { get; set; }
        public string UMC_STATUS { get; set; }
         public string rate { get; set; }
        public string requestedOn { get; set; }
        public string materialBGG { get; set; }
        public string fodType { get; set; }
        public string docType { get; set; }
        public string currency { get; set; }
        public string purchaseGroup { get; set; }
        public string delPoint { get; set; }
        public string MAP { get; set; }
        public string ISCONSUMABLE { get; set; }
        public string CONTRACTNUMBER { get; set; }
        public string ITEMNO { get; set; }

    }

    public class T_SII_WORK_FLOW
    {
        //public int WF_ID { get; set; }
        public string REQ_UMC_NO { get; set; }
        public string INDENT_ID { get; set; }
        public string DEST_SLOC { get; set; }
        public string UMC_INDENT_ID { get; set; }
        public string SRC_LOC_ID { get; set; }
        public string SRC_LOC_DESC { get; set; }
        public string SRC_PLANT_ID { get; set; }
        public string SRC_PLANT_DESC { get; set; }
        public string SRC_DEPT_ID { get; set; }
        public string SRC_DEPT_DESC { get; set; }
        public string REQ_QUANTITY { get; set; }
        public string APPROVED_QTY { get; set; }
        public string WF_TYPE { get; set; }
        public string WF_CATEGORY { get; set; }
        public string WF_STATUS { get; set; }
        public string WF_EXPIRY_DT { get; set; }
        public string WF_REMARKS { get; set; }
        public string USERNAME { get; set; }
        public string SLOC { get; set; }
        public string MappedMaterial { get; set; }
        public string AIULP_QTY { get; set; } = "0";
        public string INTRA_QTY { get; set; } = "0";
        public string INTER_QTY { get; set; } = "0";
        public string InvAge { get; set; }

    }
}
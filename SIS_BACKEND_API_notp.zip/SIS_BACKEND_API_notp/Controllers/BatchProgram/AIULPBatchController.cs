﻿using Newtonsoft.Json.Linq;
using SIS_BACKEND_API.App_Code.DAL.BatchProgramDAL;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static SIS_BACKEND_API.App_Code.DAL.BatchProgramDAL.AIULPBatchDAL;
using System.Linq;

namespace SIS_BACKEND_API.Controllers.BatchProgram
{
    public class AIULPBatchController : ApiController
    {
    }
}
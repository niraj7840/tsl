﻿using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/IndentWF")]
    public class IndentApprovalController : ApiController
    {
        indentApproval_DAL obj = new indentApproval_DAL();
        [HttpGet]
        [Route("GetPendingIndent")]
        public IHttpActionResult GetPendingIndent(string USERNAME)
        {
           

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


           return  Ok(obj.GetPendingIndentDetails(USERNAME));


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            

        }

        [HttpPost]
        [Route("GetPendingIndentAppr")]
        public IHttpActionResult GetPendingIndentAppr(IndentStatusModel objM)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                return Ok(obj.GetPendingIndentApprDetails(objM));


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }


        }

        [HttpPost]
        [Route("UpdateIndentForL1")]
        public IHttpActionResult UpdateIndentForL1([FromBody] SaveIndent SaveIndent)
        {
            string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            string _requester = TokenManager.VerifyToken(token);
            if (_requester.Equals("-1"))
                return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

            var rturn = obj.UpdateIndentbyL1(SaveIndent);
            if (rturn == "error")
            {
                return Ok(new { StatusCode = "error", data = rturn, typ = rturn });
            }
            return Ok(new { StatusCode = "OK", data = rturn, typ = rturn });

        }
        [HttpPost]
        [Route("UpdateIndentForL2")]
        public IHttpActionResult UpdateIndentForL2([FromBody] T_SII_INDENT_DETAILS SaveIndent)
        {
            string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            string _requester = TokenManager.VerifyToken(token);
            if (_requester.Equals("-1"))
                return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

            var rturn = obj.UpdateIndentbyL2(SaveIndent);
            if (rturn == 0)
            {
                return Ok(new { StatusCode = "error", data = rturn });
            }
            return Ok(new { StatusCode = "OK", data = rturn });

        }

        [HttpGet]
        [Route("GetDOPRemarks")]
        public IHttpActionResult GetDOPRemarks(string ID)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                return Ok(obj.getIndentDOPRemarks(ID));


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }


        }

        [HttpGet]
        [Route("GetApproverList")]
        public IHttpActionResult GetApproverList(string PLANT, string DEPT,string LVL,string TYP)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                return Ok(obj.getIndentApproverList(PLANT,DEPT,LVL,TYP));


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }


        }

    }
}

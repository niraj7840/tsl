﻿using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.DAL.CapitalPlanningDAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers.CapitalPlanning
{

    [RoutePrefix("api/RaiseCapReq")]
    public class RaiseCapReqController : ApiController
    {

        RaiseCapReqDAL objRaiseCapitalRequestDAL = new RaiseCapReqDAL();


        //THIS IS THE API FOR POSTING UMC NUMBER, USER REMARKS AND QUESTION RESPONSE
        //FROM USER WHILE RAISING THE CAPITAL REQUEST.

        [HttpPost]
        [Route("AddRequestFinal")]

        public IHttpActionResult AddRequestFinal(CapexApprovalRequest newApprovals)
        {
            string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            string _requester = TokenManager.VerifyToken(token);
            if (_requester.Equals("-1"))
                return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


            var existingUmcDict = new Dictionary<string, List<string>>();
            try
            {
                int insertCount = objRaiseCapitalRequestDAL.AddRequestFinal(newApprovals, existingUmcDict);

                if (insertCount == -1)
                {
                    return Ok(new Message { Text = "Exist", Status = MessageType.error, jsonData = existingUmcDict });
                }

                return Ok(new Message { Text = "Success", Status = MessageType.success, jsonData = "Posted " + insertCount });


                //return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Posted " + insertCount }));

            }
            catch (Exception)
            {

                return null;
            }
        }


        //GET FOR VIEWREQUEST


        [HttpGet]
        [Route("GetPlantFromDept")]

        public IHttpActionResult GetPlantFromDept(string dept)
        {

            try
            {
              string plant = objRaiseCapitalRequestDAL.GetPlant(dept);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = plant }));
            }
            catch (Exception ex)
            {

                return (Ok(new Message { Text = ex.ToString(), Status = MessageType.error, jsonData = null }));
            }

        }


    }
}

using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.UI;
using SIS_BACKEND_API.App_Code.DAL;
using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.App_Code.Utils;

namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/Login")]
    public class LoginController : ApiController
    {

        string connectionString = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        LoginDAL objDal = new LoginDAL();


        HRServices.Service objHRService = new HRServices.Service();

        HRServices.EmpDetails[] objEmpDetails;  
        
        Users users = new Users();
        UsersDetails UrDetails = new UsersDetails();


        [HttpPost]
        [Route("getCurrentLoggedOnUser")]
        [EnableCors("*", "*", "*", SupportsCredentials = true)]
        [AllowAnonymous]
        public IHttpActionResult GetADID()
        {
            if(Request.Method == HttpMethod.Options)
            {
                return Ok();
            }

            string strUserID;
            string strUserDomain;
            try
            {
                string[] arrUserIDParts = HttpContext.Current.Request.LogonUserIdentity.Name.Split('\\');

                if (arrUserIDParts.Length >= 2)
                {
                    //Set the User Personal Number and Domain Name from the extracted AD
                    // strUserID = arrUserIDParts[arrUserIDParts.Length - 1];
                    strUserID = "163402";
                    strUserDomain = arrUserIDParts[arrUserIDParts.Length - 2];
                    objEmpDetails = objHRService.getDetails(new string[] { strUserID });
                    if (objEmpDetails.Length > 0)
                    {
                        string UserName = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                        users.User_Name = String.IsNullOrEmpty(UserName) ? strUserID : UserName;
                        users.User_Dept = objEmpDetails[0].getsetDeptDesc;
                        users.User_Id = strUserID;
                        users.IsSuperAdmin = objDal.IsSuperAdmin(strUserID);
                        users.IsSCAdmin = objDal.IsSCAdmin(strUserID);

                    }
                    var data = new
                    {
                        TOKEN = new
                        {
                            VALID_FROM = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"),
                            VALID_TILL = DateTime.Now.AddMinutes(60).ToString("dd-MMM-yyyy hh:mm tt"),
                            VALUE = TokenManager.GenerateToken(strUserID)
                        },
                        USER = new
                        {
                            USERDETAILS = EncryptDecryptQueryString.EncryptStringToBytes(Newtonsoft.Json.JsonConvert.SerializeObject(users))
                        }
                    };
                    var u = Newtonsoft.Json.JsonConvert.SerializeObject(users);


                    return (Ok(new Message { Text = "authorized", Status = MessageType.success, jsonData = data }));
                }


                else { return (Ok(new Message { Text = "unauthorized!", Status = MessageType.error })); }


            }
            catch (Exception)
            {

                return (Ok(new Message { Text = "unauthorized!", Status = MessageType.error }));
            }

        }


        [HttpGet]
        [Route("ValidateCredentials")]

        public IHttpActionResult GetUserDetails(string adid, string Pass)
        {
            try

            {
                if (adid != "" && Pass != "")
                {
                     ADAuthorizationService.Service1 objADService = new ADAuthorizationService.Service1();  
                    string IsAuth = objADService.GenericIsAuthenticatedWithMessage("TATASTEEL", adid, Pass);
                   // string IsAuth = "Authenticated";     
                                 
                    if ((IsAuth.Equals("Authenticated", StringComparison.InvariantCultureIgnoreCase) == true))
                    {
                        objEmpDetails = objHRService.getDetails(new string[] { adid });
                        if (objEmpDetails.Length > 0)
                        {
                        
                            UrDetails.User_Name = objEmpDetails[0].getsetFname + " " + objEmpDetails[0].getsetLname;
                            UrDetails.User_Dept = objEmpDetails[0].getsetDeptDesc;
                            UrDetails.User_EmailId = objEmpDetails[0].getsetEmailId;
                            UrDetails.User_contactNumber = objEmpDetails[0].getsetPhoneNo;
                            UrDetails.User_Id = adid;

                        }
                        var u = Newtonsoft.Json.JsonConvert.SerializeObject(UrDetails);
                        return (Ok(new Message { Text = "Authenticated", Status = MessageType.success, jsonData = UrDetails }));

                        // return (Ok(new Message { Text = "Authenticated", Status = MessageType.success }));
                    }
                    else
                    {
                        return (Ok(new Message { Text = "unauthorized!", Status = MessageType.error }));
                    }
                }

                else { return (Ok(new Message { Text = "unauthorized!", Status = MessageType.error })); }


            }
            catch (Exception)
            {

                return (Ok(new Message { Text = "unauthorized!", Status = MessageType.error }));
            }

        }


        [HttpPost]
        [Route("LoginDetails")]
        public IHttpActionResult PostUserDetails([FromBody] LoginDetails LoginDetails)
        {
            return Ok(objDal.SaveUserDetails(LoginDetails));
        }

        [HttpGet]
        [Route("GetLatestOTP")]
        public IHttpActionResult GetLatestOTPDetails(string ADID)
        {
            var data = new List<LatestOTP>();
            DataTable dt = new DataTable();
            try
            {
                using (var connection = new OracleConnection(connectionString))
                {
                    string query = @"SELECT ADID, OTP, TO_NUMBER(ROUND(((SYSDATE - OTPEXPIRYDATE) * 24 * 60))) AS MinDiff
FROM (
  SELECT ADID, OTP, OTPEXPIRYDATE, ROW_NUMBER() OVER (ORDER BY CREATEDDATE DESC) AS rn
  FROM T_SIS_USER_DETAILS
  WHERE adid = :adid ) WHERE rn = 1";

                    using (var command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("adid", ADID));

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            dt.Load(reader);
                            reader.Close();
                            connection.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            foreach (DataRow row in dt.Rows)
            {
                var opt = new LatestOTP
                {
                    ADID = row["ADID"] != DBNull.Value ? row["ADID"].ToString() : null,
                    LtsOTP = row["OTP"] != DBNull.Value ? row["OTP"].ToString() : null,
                    MinDiff = row["MinDiff"] != DBNull.Value ? row["MinDiff"].ToString() : null,
                };
                data.Add(opt);
            }

            return Json(data);
        }
    }
}
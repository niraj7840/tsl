﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Http;
//using System.Web.Mvc;
using System.Configuration;


using SIS_BACKEND_API.Models;

namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/Email")]
    public class EmailController : ApiController
    {
        string SISLink = ConfigurationManager.AppSettings["WebURL"];

        [HttpGet]
        [Route("SendOPT")]
        public IHttpActionResult SendMail(String EmailId, string OTP)
        {
            bool SuccessFlag = true;
            string ErrorMessage = "";

            try
            {
                string strSmtpServerHost = "144.0.11.253";
                SmtpClient objSmtpClient = new SmtpClient(strSmtpServerHost);
                MailMessage mail = new MailMessage();

                string MAIL_FROM = "SISAdmin@tatasteel.com";
                mail.From = new MailAddress(MAIL_FROM);
                if (EmailId != null)
                {
                    if (!string.IsNullOrEmpty(EmailId))
                        mail.To.Add(EmailId);
                }

                mail.Subject = "Your OTP";
                mail.IsBodyHtml = true;
                mail.Body = "Your OTP is " + OTP + ". Please Verify ";

                objSmtpClient.Send(mail);
                mail.Dispose();
            }
            catch (Exception ex)
            {
                SuccessFlag = false;
                ErrorMessage = "Exception during processing Send Mail with message: " + ex.Message;
            }

            if (SuccessFlag)
            {
                return Ok(new { success = true, message = "Mail sent successfully" });
            }
            else
            {
                return Ok(new { success = false, message = ErrorMessage });
            }
        }

        [HttpGet]
        [Route("sendEmail")]
        //  public IHttpActionResult SendEmail([FromBody] SendEmailRequest request)
        public IHttpActionResult SendEmail(string from, string to, string  subject, string mToUserName, string textMessage, string commType, string scNo)
        {
            //   if (request == null || string.IsNullOrEmpty(request.To))
            if (from == null || string.IsNullOrEmpty(to))
            {
                return BadRequest("Invalid email request data.");
            }

            try
            {
                string body = string.Empty;
                body = "Dear "+ mToUserName + ", Please respond to the following "+ commType + " for the Shopping Cart No: "+ scNo + ". < b > Message:</ b >  "+ textMessage + " Use the Following Link to log on to respond: < a href = '"+SISLink+ "' > " + SISLink + " </a>";
                // Configure the SMTP client
                SmtpClient smtpClient = new SmtpClient("144.0.11.253"); // Your SMTP server IP
                MailMessage mailMessage = new MailMessage
                {
                    //From = new MailAddress(request.From),
                    //Subject = request.Subject,
                    //Body = request.Body,
                    //IsBodyHtml = true

                    From = new MailAddress(from),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };

                // Add recipient
                mailMessage.To.Add(to);

                // Send the email
                smtpClient.Send(mailMessage);

                return Ok("Email sent successfully.");
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }


        [HttpGet]
        [Route("sendEmailForRejection")]
        //  public IHttpActionResult SendEmail([FromBody] SendEmailRequest request)
        public IHttpActionResult sendEmailForRejection(string from, string to, string subject, string ReturnLevel, string scNo, string mToUserName, string message)
        {
            //   if (request == null || string.IsNullOrEmpty(request.To))
            if (from == null || string.IsNullOrEmpty(to))
            {
                return BadRequest("Invalid email request data.");
            }

            try
            {
                string body = string.Empty;

                //body = "This is a system generated message. Please do not reply to this mail. LVL-"+ ReturnLevel + " SC-"+ scNo + " has been Returned. Dear "+ mToUserName + ", Please respond to the following Question for the Shopping Cart No: "+ scNo + ". < b > Message:</ b > "+ message + ". Use the Following Link to log on to respond: <a href='"+ SISLink + "'>"+ SISLink + "</a>";

                body = "This is a system generated message. Please do not reply to this mail.<br><br>" +
       "LVL-" + ReturnLevel + " SC-" + scNo + " has been Returned.<br><br>" +
       "Dear " + mToUserName + ",<br><br>" +
       "Please respond to the following question for the Shopping Cart No: " + scNo + ".<br><br>" +
       "<b>Message:</b> " + message + ".<br><br>" +
       "Use the following link to log on to respond: <a href='" + SISLink + "'>" + SISLink + "</a><br>";

                // Configure the SMTP client
                SmtpClient smtpClient = new SmtpClient("144.0.11.253"); // Your SMTP server IP
                MailMessage mailMessage = new MailMessage
                {
                    //From = new MailAddress(request.From),
                    //Subject = request.Subject,
                    //Body = request.Body,
                    //IsBodyHtml = true

                    From = new MailAddress(from),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };

                // Add recipient
                mailMessage.To.Add(to);

                // Send the email
                smtpClient.Send(mailMessage);

                return Ok("Email sent successfully.");
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }





    }
}
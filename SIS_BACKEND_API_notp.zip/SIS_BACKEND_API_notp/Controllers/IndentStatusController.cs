﻿using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SIS_BACKEND_API.Controllers
{
    [RoutePrefix("api/Report")]
    public class IndentStatusController : ApiController
    {
        IndentStatus_DAL objDal = new IndentStatus_DAL();
        [HttpPost]
        [Route("GetIndentStatus")]
        public IHttpActionResult GetIndentStatus(IndentStatusModel obj)
        {
            var indentList = "";

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));



                indentList = objDal.GetIndentDetails(obj);
                if (indentList.Length > 0)
                {
                    return Ok(new { statusText = "OK", Data = indentList });
                }
                else
                {

                    return Ok(new { statusText = "error", Data = indentList });
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return Ok(new { statusText = "error", Data = ex.ToString() });
            }
            

        }

        [HttpGet]
        [Route("GetWFDetails")]
        public IHttpActionResult GetWorkflowDetails(string  INDENTNO)
        {
            var workFLowList = "";
            string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            string _requester = TokenManager.VerifyToken(token);
            if (_requester.Equals("-1"))
                return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


            try
            {
                workFLowList = objDal.GetWorkflowDetails(INDENTNO);
                if (workFLowList.Length > 0)
                {
                    return Ok(new { statusText = "OK", Data = workFLowList });
                }
                else
                {

                    return Ok(new { statusText = "error", Data = workFLowList });
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return Ok(new { statusText = "error", Data = ex.ToString() });
            }


        }

    }
}

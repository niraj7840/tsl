﻿using Oracle.ManagedDataAccess.Client;
using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;


namespace SIS_BACKEND_API.Controllers
{

    [RoutePrefix("api/Master")]
    public class MasterController : ApiController
    {
        MasterDAL objDal = new MasterDAL();

        private readonly string _connectionstring;

        public MasterController()
        {
            _connectionstring = ConfigurationManager.ConnectionStrings["OracleConnection"].ConnectionString;
        }

        [HttpGet]
        [Route("GetMaterial")]
        public IHttpActionResult GetMaterial(string Plant, string UMC, string Dept)
        {
            var materialList = "";


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                materialList = objDal.GetMaterial(Plant, UMC, Dept);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Ok(materialList);

        }

        [HttpGet]
        [Route("GetUMCLongDescription")]
        public IHttpActionResult GetUMCLongDescription(string Plant, string UMC)
        {
            var materialList = "";


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                materialList =  objDal.GetUMCLongDescription(Plant, UMC);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Ok(materialList);

        }


        [HttpGet]
        [Route("GetPlantList")]
        public IHttpActionResult GetPlantList(string DEPT,string ADID)
        {
            var plantList = new List<Plant>();

            try
            {

                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                plantList = objDal.GetPlantList(DEPT, ADID);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(plantList);

        }

        [HttpGet]
        [Route("GetCodeList")]
        public IHttpActionResult GetCodeValueList(string CODE)
        {
            var codeVal = new List<CODEVAL>();
          
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                codeVal = objDal.GetCodeValueList(CODE);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(codeVal);

        }

        [HttpGet]
        [Route("GetDocList")]
        public IHttpActionResult GetDocList(string CODE,string MCODE)
        {
            var codeVal = new List<CODEVAL>(); ;

            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                codeVal = objDal.GetDocTypeList(CODE, MCODE);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(codeVal);

        }
        [HttpGet]
        [Route("GetDepartment")]
        public IHttpActionResult GetDepartment(string adid)
        {
            var deptList = new List<Department>();
            string strUserID;

            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                string[] arrUserIDParts = HttpContext.Current.Request.LogonUserIdentity.Name.Split('\\');

                if (arrUserIDParts.Length >=2)
                {
                    //strUserID = arrUserIDParts[arrUserIDParts.Length - 1];
                    strUserID = "163402";
                    if (String.Equals(strUserID, adid))
                    {
                        // var cachedDepartment = CacheService.Instance.Get("Department") as string;
                        //var value = GlobalDataService.Instance.GetValue("deptList");
                       deptList = objDal.GetDepartment(adid);
                    }
                }
                

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(deptList);

        }

        [HttpGet]
        [Route("GetDraftedList")]
        public IHttpActionResult GetDraftedList(string DEPT ,string USERNAME)
        {
            var draftedList = new List<SaveDraft>();
          

            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                draftedList = objDal.GetDraftedList(DEPT, USERNAME);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(draftedList);

        }
        [HttpGet]
        [Route("GetIndentList")]
        public IHttpActionResult GetIndentList(string INDENTID)
        {
            var draftedList = new List<SaveDraft>();


            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                draftedList = objDal.GetIndentList(INDENTID);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(draftedList);

        }
        [HttpGet]
        [Route("GetPurchaseList")]
        public IHttpActionResult GetPurchaseList(string PLANT)
        {
            var codeVal = new List<CODEVAL>();

            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                codeVal = objDal.GetPurchaseGroupList(PLANT);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(codeVal);

        }
        [HttpGet]
        [Route("IsBlockedUMC")]
        public IHttpActionResult IsBlockedUMC(string PLANT,string Req_UMC_No)
        {
            var isBlocked = false;

            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                isBlocked = objDal.IsBlockedUMC(PLANT,Req_UMC_No);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(isBlocked);

        }
        [HttpGet]
        [Route("GetDelPointList")]
        public IHttpActionResult GetDelList(string PLANT)
        {
            var codeVal = new List<CODEVAL>();

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                codeVal = objDal.GetDelPointList(PLANT);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(codeVal);

        }

        [HttpGet]
        [Route("GetStorageList")]
        
        public IHttpActionResult GetStorageList(string PLANT, string UMC, string Dept)
        {
            var codeVal = new List<CODEVAL>();

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                codeVal = objDal.GetStorageList(PLANT, UMC, Dept);
            
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Json(codeVal);

        }

        [HttpGet]
        [Route("GetDashboardCount")]
        public IHttpActionResult GetDashboardCount(string USERNAME)
        {
            var materialList = "";


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                materialList = objDal.GetDashboardCount(USERNAME);


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Ok(materialList);

        }

        [HttpGet]
        [Route("getTabName")]
        public IHttpActionResult getTabName(string TYP,string TAB,string ID)
        {
            DataTable materialList = new DataTable();


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

               
                 if (TYP == "COL")
                {

                    materialList = objDal.GetColName(TAB);
                }
                else if (TYP == "SEL")
                {

                    materialList = objDal.GetColValue(TAB,ID);
                }



            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Ok(materialList);

        }

        [HttpPost]
        [Route("setTabData")]
        public IHttpActionResult setTabData([FromBody] List<TabList>obj)
        {
            string materialList = "";


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

               
                    materialList = objDal.TabAction(obj[0].table_name,"INSERT",obj);
               



            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Ok(materialList);

        }

        [HttpPost]
        [Route("editTabData")]
        public IHttpActionResult editTabData([FromBody]List<TabList> obj)
        {
            string materialList = "";


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                materialList = objDal.TabAction(obj[0].table_name, "UPDATE", obj);




            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);

                return InternalServerError();
            }
            return Ok(materialList);

        }



    }
}



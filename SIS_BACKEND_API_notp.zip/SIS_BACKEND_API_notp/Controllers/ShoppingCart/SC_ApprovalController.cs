﻿
using SIS_BACKEND_API.App_Code.DAL.ShoppingCart;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Web.Http;
using SIS_BACKEND_API.Models;
using System.Web.Http;
using System.IO;
using System.Web;
using System.Data;
using System.Threading.Tasks;
using SIS_BACKEND_API.App_Code.Utils;
using System.Linq;
using System.Web.Http.Results;
using System.Configuration;

namespace SIS_BACKEND_API.Controllers.ShoppingCart
{

    [RoutePrefix("api/ShoppingCart")]
    public class SC_ApprovalController : ApiController
    {

        SC_ApprovalDAL objCommonDAL = new SC_ApprovalDAL();

        [HttpPost]
        [Route("SCApproval")]
        public IHttpActionResult InsertApprovals([FromBody] List<ApprovalRequest> approvals)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                objCommonDAL.InsertApprovals(approvals);
                return (Ok(new Message { Text = "success", Status = MessageType.success }));
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpPost]
        [Route("SCApproverSection")]
        public IHttpActionResult InsertApprovalSecrion([FromBody] ApprovalSection approvalSection)
        {
            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                objCommonDAL.InsertApprovalSection(approvalSection);
                return (Ok(new Message { Text = "success", Status = MessageType.success }));
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error in InsertApprovalSecrion: {ex.Message}");
                // Return a meaningful error response
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("SCApproverFileUpload")]
        public  IHttpActionResult SCApproverFileUpload()
        {

            string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            string _requester = TokenManager.VerifyToken(token);
            if (_requester.Equals("-1"))
                return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

            var httpRequest = HttpContext.Current.Request;

            if (httpRequest.Files.Count == 0)
                return BadRequest("No file uploaded");

            var postedFile = httpRequest.Files[0];
            var sno = httpRequest.Form["Sno"];
            var userId = httpRequest.Form["UserId"];

            byte[] fileData;
            using (var binaryReader = new BinaryReader(postedFile.InputStream))
            {
                fileData = binaryReader.ReadBytes(postedFile.ContentLength);
            }

            var fileUploadModel = new FileUploadModel
            {
                FileName = postedFile.FileName,
                FileContent = fileData,
                SCA_FILE_TYPE = postedFile.ContentType,
                Sno = sno,
                UserId = userId
            };


            if (fileUploadModel.SCA_FILE_TYPE == "application/pdf" && fileUploadModel.FileName.Split('.').Length - 1 == 1)
            {

                int insertCount = objCommonDAL.UploadApprovalFile_Dal(fileUploadModel);

                if (insertCount > 0)
                {
                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated" + insertCount }));

                }

                else
                {
                    return (Ok(new Message { Text = "Failed", Status = MessageType.error, jsonData = "file uploading error." }));
                }
            }
            else
            {
                return (Ok(new Message { Text = "Failed", Status = MessageType.error, jsonData = "Please Upload pdf file." }));
            }
            // int i=  objCommonDAL.UploadApprovalFile_Dal(fileUploadModel);

            //return Ok(new { fileUploadModel.FileName, fileUploadModel.Sno, fileUploadModel.UserId });



        }


        [HttpGet]
        [Route("GetShoppingCartDetails")]
        public IHttpActionResult GetIGetShoppingCartDetails(string SCId)
        {
            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetShoppingCartDetails_DAL(SCId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetSCHeaderAndMaterialDetails")]
        public IHttpActionResult GetSCHeaderAndMaterialDetails(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetSCHeaderAndMaterialDetails_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }



        [HttpGet]
        [Route("SCApprovalHierarchy")]
        public IHttpActionResult GetSCApprovalHierarchy(string SCNo)
        {


            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));



                DataTable dt = objCommonDAL.GetSCApprovalHierarchy_DAL(SCNo);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }



        [HttpGet]
        [Route("SCAppRemarks")]
        public IHttpActionResult GetSCAppRemarks(string SCNo)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetSCAppRemarks_DAL(SCNo);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }




        [HttpGet]
        [Route("SCApprovalPendingList")]
        public IHttpActionResult SCApprovalPendingList(string UserId)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                DataTable dt = objCommonDAL.GetSCApprovalPendingList_DAL(UserId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }


        [HttpGet]
        [Route("GetIntelliBuyChecksDetails_SC")]
        public IHttpActionResult GetIntelliBuyChecksDetailsFromId(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetIntelliBuyChecksHeaderAndItem(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }


        [HttpGet]
        [Route("SCDetailsForApproval")]
        public IHttpActionResult GetSCDetailsForApproval(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetSCDetailsForApproval_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }


        [HttpGet]
        [Route("SCJustification")]
        public IHttpActionResult GetJustification(string SCNo ,string SCI_MATL_NO)
        {
            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                DataTable dt = objCommonDAL.GetJustification_DAL(SCNo , SCI_MATL_NO);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }



        [HttpGet]
        [Route("GetAnswerStatus")]
        public IHttpActionResult GetAnswerStatus(string SCNo, string UserId)
        {
            try
            {
                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                DataTable dt = objCommonDAL.GetAnswerStatus_DAL(SCNo, UserId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }



        //================for Return Api=================
        [HttpGet]
        [Route("getRecord")]
        public async Task<IHttpActionResult> GetRecord(string cartNo)
        {
            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                DataTable dt = await objCommonDAL.GetRecordAsync(cartNo);
                if (dt.Rows.Count == 0)
                {
                    return NotFound();
                }
                return Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt });
            }
            catch (Exception ex)
            {
                // Log the exception
                return InternalServerError(ex);
            }
        }



        [HttpPost]
        [Route("insertCommunication_OnlyInsert")]
        public async Task<IHttpActionResult> insertCommunication_OnlyInsert([FromBody] CommunicationRequest request)
        {
            try
            {
                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                await objCommonDAL.InsertCommunication_OnlyInsertAsync(request);
                return Ok(new Message { Text = "Success.", Status = MessageType.success });
            }
            catch (Exception ex)
            {
                // Log the exception
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("insertCommunication")]
        public async Task<IHttpActionResult> InsertCommunication([FromBody] CommunicationRequest request)
        {
            try
            {

                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                await objCommonDAL.InsertCommunicationAsync(request);
                return Ok(new Message { Text = "Message has been sent successfully.", Status = MessageType.success });
            }
            catch (Exception ex)
            {
                // Log the exception
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("updateShoppingCart")]
        public async Task<IHttpActionResult> UpdateShoppingCart([FromBody] ShoppingCartUpdateRequest request)
        {
            try
            {

                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                await objCommonDAL.UpdateShoppingCartAsync(request);
                return Ok(new Message { Text = "Shopping cart updated successfully.", Status = MessageType.success });
            }
            catch (Exception ex)
            {
                // Log the exception
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("getStatus")]
        public async Task<IHttpActionResult> GetStatus(string cartNo)
        {
            try
            {

                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                var status = await objCommonDAL.GetStatusAsync(cartNo);
                if (status == null)
                {
                    return NotFound();
                }
                return Ok(new { SCH_STATUS = status });
            }
            catch (Exception ex)
            {
                // Log the exception
                return InternalServerError(ex);
            }
        }




        [HttpPost]
        [Route("SC_Recipient")]
        public IHttpActionResult SC_Recipient(string SC_No, string DeptId, string UserId)
        {
            try
            {

                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.SC_Recipient_Dal(SC_No, DeptId, UserId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error in InsertApprovalSecrion: {ex.Message}");
                // Return a meaningful error response
                return InternalServerError(ex);
            }
        }



        [HttpPost]
        [Route("SC_GetReplayCommunications")]
        public IHttpActionResult GetCommunications(string sno, string userId)
        {
            try
            {

                //string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                //string _requester = TokenManager.VerifyToken(token);
                //if (_requester.Equals("-1"))
                //    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.SC_GetReplayCommunications_DAL(sno, userId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error in InsertApprovalSecrion: {ex.Message}");
                // Return a meaningful error response
                return InternalServerError(ex);
            }
        }

        //==========MaxQty==============
        [HttpGet]
        [Route("GetMaxQtyData_SC")]
        public IHttpActionResult SetGetMaxQtyData_SC(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetMaxQtyData_SC_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        //==========RequiConsum Date==============
        [HttpGet]
        [Route("GetRequiConsumData_SC")]
        public IHttpActionResult GetRequiConsumData_SC(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetRequiConsumData_SC_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }


        //==========VMI/ARC	==============
        [HttpGet]
        [Route("GetVMI_ARCData_SC")]
        public IHttpActionResult GetVMI_ARCData_SC(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetVMI_ARCData_SC_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        //==========Refurshibility==============
        [HttpGet]
        [Route("GetRefurshibilityData_SC")]
        public IHttpActionResult GetRefurshibilityData_SC(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetRefurshibilityData_SC_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        //==========Deprop==============
        [HttpGet]
        [Route("GetDepropmData_SC")]
        public IHttpActionResult GetDepropmData_SC(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetDepropmData_SC_DAL(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }


        //==========Deprop==============
        [HttpGet]
        [Route("GetUserEmailId_SC")]
        public IHttpActionResult GetUserEmailId_SC(string UserId)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetUserEmailId_SC_DAL(UserId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }




        [HttpGet]
        [Route("GetIntelliBuyChecksDetailsFromId_ODA_SC")]
        public async Task<IHttpActionResult> GetIntelliBuyChecksDetailsFromId_ODA_SC(string IndentId, string INDENTOR_DEPT)

        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

                List<IntelliBuyIndentDetails_ODA_SC> ObjIntelliBuyIndentDetails_ODA_SC = await objCommonDAL.GetIntelliBuyChecksDetails_ODA_SC_DAL(IndentId, INDENTOR_DEPT).ConfigureAwait(false);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = ObjIntelliBuyIndentDetails_ODA_SC }));

            }
            catch (Exception)
            {

                return null;
            }

        }




        [HttpGet]
        [Route("GetCreaterAndFinalApproverID_SC")]
        public IHttpActionResult GetCreaterAndFinalApproverID_SC(string SCNo)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetCreaterAndFinalApproverID_SC_DAL(SCNo);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        //=====================for Regenerate Approval Hierarchy==========================

        [HttpGet]
        [Route("GetShoppingCart_ForRegenApprover")]
        public IHttpActionResult GetShoppingCart_ForRegenApprover(string cartNo, string creatorName, string fromDate, string toDate, string department)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetShoppingCart_ForRegenApprover_DAL(cartNo, creatorName, fromDate, toDate, department);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception ex)
            {

                return null;
            }

        }



        [HttpPost]
        [Route("GetApprovalReset")]
        public IHttpActionResult GetApprovalReset([FromBody] ApprovalRequest_ForRegenHierarchy request)
        {
            string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
            string _requester = TokenManager.VerifyToken(token);
            if (_requester.Equals("-1"))
                return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


            foreach (var cartDetail in request.CartDetails)
            {
                string cartNo = cartDetail.CartNo;
                string totalValue = cartDetail.TotalValue;

                DataTable approvedByScDt = objCommonDAL.GetApprovedBySc(cartNo);
                DataTable dept = objCommonDAL.GetDeptSc(cartNo);
                string Deptid = dept.Rows[0][0].ToString();
                DataTable deptTypeDt = objCommonDAL.GetDeptType(Deptid);

                if (deptTypeDt.Rows.Count == 0)
                {
                    // Handle department type not found
                }

                string deptType = deptTypeDt.Rows[0]["DEPTTYPE"].ToString();

                // Insert approval record
                objCommonDAL.InsertApprovalRecord(cartNo, totalValue, deptType, Deptid);

                if (approvedByScDt.Rows.Count > 0)
                {
                    foreach (DataRow row in approvedByScDt.Rows)
                    {
                        objCommonDAL.UpdateApprovalStatus(cartNo, row["scp_apprvr"].ToString(), row["scp_app_lvl"].ToString());
                        objCommonDAL.SendApprovalEmail(cartNo, row["scp_app_lvl"].ToString(), row["scp_apprvr"].ToString());
                    }
                    
                }

                // Additional processing for other scenarios if needed
            }

            return Ok("Approval Reset Completed.");
        }


        [HttpGet]
        [Route("GetPGList_SC")]
        public IHttpActionResult GetPGList_SC()
       {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetPGList_SC_DAL();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetBGGList_SC")]
        public IHttpActionResult GetBGGList_SC()
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetBGGList_SC_DAL();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCMBGGMapping_SC")]
        public IHttpActionResult GetCMBGGMapping_SC(string pg, string bgg)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetCMBGGMapping_SC_DAL(pg,bgg);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception ex)
            {

                return null;
            }

        }



        //=====================for Add Approval ==========================

        [HttpGet]
        [Route("GetShoppingCart_ForAddApprover")]
        public IHttpActionResult GetShoppingCart_ForAddApprover(string cartNo)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetShoppingCart_ForAddApprover_DAL(cartNo);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception ex)
            {

                return null;
            }
        }


        [HttpGet]
        [Route("GetApproverLevel")]
        public IHttpActionResult GetApproverLevel(string cartNo)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                DataTable dt = objCommonDAL.GetApproverLevel_DAL(cartNo);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception ex)
            {

                return null;
            }
        }

      

        [HttpPost]
        [Route("SC_AddApprover")]
        public async Task<IHttpActionResult> SC_AddApprover()
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                var httpRequest = HttpContext.Current.Request;

                // Check if a file has been uploaded
                if (httpRequest.Files.Count == 0)
                    return BadRequest("No file uploaded");

                var postedFile = httpRequest.Files[0];

                // Convert file content to byte array
                byte[] fileData;
                using (var binaryReader = new BinaryReader(postedFile.InputStream))
                {
                    fileData = binaryReader.ReadBytes(postedFile.ContentLength);
                }

                // File metadata
                var fileUploadModel = new FileUploadModel
                {
                    FileName = postedFile.FileName,
                    FileContent = fileData,
                    SCA_FILE_TYPE = postedFile.ContentType,
                };

                // Check for valid file type (PDF)
                if (fileUploadModel.SCA_FILE_TYPE == "application/pdf" && fileUploadModel.FileName.Split('.').Last().ToLower() == "pdf")
                {
                    // Reading other form data
                    var form = httpRequest.Form;
                    var request = new AddApprover_SC
                    {
                        scp_cart_no = form["scp_cart_no"],
                        SCP_APP_LVL = form["SCP_APP_LVL"],
                        SCP_APPRVR = form["SCP_APPRVR"],
                        SCD_CRT_BY = form["SCD_CRT_BY"]
                    };

                    // Call DAL for file and approval insertion
                    await objCommonDAL.SC_AddApprover_DAL(request, fileUploadModel);
                    return Ok(new Message { Text = "Success", Status = MessageType.success });
                }
                else
                {
                    return Ok(new Message { Text = "Failed", Status = MessageType.error, jsonData = "Please upload a valid PDF file." });
                }
            }
            catch (Exception ex)
            {
                // Log the exception (if necessary)
                return InternalServerError(ex);
            }
        }


        [HttpGet]
        [Route("GetValidatePIN")]
        public IHttpActionResult GetValidatePIN(string pin)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));



                DataTable dt = objCommonDAL.GetValidatePIN_DAL(pin);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception ex)
            {

                return null;
            }
        }

    }
}
﻿using Newtonsoft.Json.Linq;
using SIS_BACKEND_API.App_Code.DAL.ShoppingCart;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using SIS_BACKEND_API.Models.IntelliBuyModel;
using SIS_BACKEND_API.Models.ShoppingCartModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.DynamicData;
using System.Web.Http;
using System.Web.UI.WebControls;

namespace SIS_BACKEND_API.Controllers.ShoppingCart
{
    [RoutePrefix("api/ShoppingCart")]
    public class ShoppingCartController : ApiController
    {

        ShoppingCartDAL objCommonDAL = new ShoppingCartDAL();
        Dictionary<string, List<string>> validation = new Dictionary<string, List<string>>();

        [HttpGet]
        [Route("GetCostCsrCategory")]
        public IHttpActionResult GetCostCsrCategory()
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.Get_CSR_Category();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        /// <summary>
        /// csr_subsocial 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCostCsrSubCategory")]
        public IHttpActionResult GetCostCsrSubCategory()
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.Get_CSR_CODE_SUB_MASTER();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetCostCsrSubActivity")]
        public IHttpActionResult GetCostCsrSubActivity(string CSR_SUB_CODE)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.Get_CSR_SUB_CODE_ACTIVITY(CSR_SUB_CODE);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetIntelliBuyChecksDetails")]
        public IHttpActionResult GetIntelliBuyChecksDetailsFromId(string IndentId)
        {


            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetIntelliBuyChecksHeaderAndItem(IndentId);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetSCItemDetailsFromUMC")]
        public async Task<IHttpActionResult> GetSCItemDetailsFromUMC(string SC_NO, string UMCNo, string FODTYPE)
        {
            List<ShoppingCartItem> objShoppingCartItemList = new List<ShoppingCartItem>();

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                ShoppingCartItem objShoppingCartItem = await objCommonDAL.GetSCItemDetailsFromUMCAndSCNO(SC_NO, UMCNo, FODTYPE, validation);
                objShoppingCartItemList.Add(objShoppingCartItem);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = new { jsonData = objShoppingCartItemList, errors = validation } }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCostCategory")]
        public IHttpActionResult GetCostCategory(string DeptType, string FODType, string bgg, string contract)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCostCategory(DeptType, FODType, bgg, contract);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetDocumentsText")]
        public IHttpActionResult GetDocumentsText(string FODType, string SCNo, string MatNo)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetDocumentsText(FODType);
                DataTable datatable = objCommonDAL.Get_DocumentsFromSC(SCNo, MatNo);

                if (dt.Rows.Count > 0 && datatable.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in dt.Rows)
                    {

                        var selectedTable = datatable.AsEnumerable()
                            .Where(r => r.Field<string>("TEXT_ID") == dataRow["TEXT_ID"].ToString() && r.Field<string>("txt_lvl") == dataRow["txt_lvl"].ToString()).ToList();
                        if (selectedTable.Count > 0)
                        {

                            if (!String.IsNullOrEmpty(selectedTable[0]["SCD_TXT"].ToString()))
                            {
                                dataRow["classname"] = "#32CD32";
                            }
                        }
                        else
                        {

                        }
                    }

                }
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception ex)
            {

                return null;
            }

        }
        [HttpGet]
        [Route("GetCurrencyCode")]
        public IHttpActionResult GetCurrencyCode()
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCurrencyCode();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCSRLocation")]
        public IHttpActionResult GetCSRLocation()
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCSRLocation();
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("InsertShoppingCartHeadrsAndItemDetails")]
        public async Task<IHttpActionResult> InsertShoppingCartHeadrsAndItemDetails([FromBody] ShoppingCartModel ObjshoppingCartModel, bool isBudgetModalOpen)
        {
            ShoppingCartHeader header = ObjshoppingCartModel.ObjShoppingCartHeader;
            List<ShoppingCartItem> items = ObjshoppingCartModel.ObjShoppingCartItemDetails;
            SustainibilityCSR sustainibilityCSR = ObjshoppingCartModel.ObjSustainibilityCSR;
            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                if (ObjshoppingCartModel.IsDraft == "Y")
                {
                    insertCount = await objCommonDAL.UpdateShoppingCart(header, items, sustainibilityCSR, validation);

                    if (insertCount == 0)
                    {
                        return (Ok(new Message { Text = "Failed", Status = MessageType.success, jsonData = validation }));

                    }
                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = validation }));
                }
                else if (ObjshoppingCartModel.IsDraft == "N")
                {
                    //bool status = objCommonDAL.checkSCFileUploaded(header.SCH_CART_NO);
                    //if (status)
                    //{
                    insertCount = await objCommonDAL.SubmitShoppingCart(header, items, validation, isBudgetModalOpen);
                    if (insertCount == 0)
                    {
                        return (Ok(new Message { Text = "Failed", Status = MessageType.success, jsonData = validation }));

                    }
                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = validation }));
                    //}
                    //else
                    //{
                    //    return (Ok(new Message { Text = "Failed", Status = MessageType.warning, jsonData = "Please upload the shopping cart Document, then process to submit shopping cart." }));
                    //}
                }
                else
                {
                    return (Ok(new Message { Text = "error", Status = MessageType.error, jsonData = "error found! pls try again." }));
                }
            }
            catch (Exception)
            {

                return null;
            }

        }


        [HttpGet]
        [Route("GetCurrencyRateFromCurrency")]
        public IHttpActionResult GetCurrencyRateFromCurrency(string Currency)
        {
            string Rate = "";
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCurrencyRateFromCurrency(Currency);
                if (dt.Rows.Count > 0)
                {
                    Rate = dt.Rows[0]["UKURS"].ToString();
                }
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = Rate }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [Route("GetPRTextDocuments")]
        public IHttpActionResult GetPRTextDocuments(string UMCNo, string Plant, string DocumentName, string SCINO, string ItemNo, string TxtLvl)
        {
            string response = "";
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                if (DocumentName == "B04" || DocumentName == "F03")
                {
                    DataTable dt = new DataTable();
                    dt = objCommonDAL.GetSCDocuments(SCINO, ItemNo, DocumentName, TxtLvl);
                    if (dt.Rows.Count == 0)
                    {
                        dt = objCommonDAL.GetPRTextDocuments(UMCNo, Plant);
                        if (dt.Rows.Count > 0)
                        {
                            response = dt.Rows[0]["LNG_DESC"].ToString();
                        }
                    }
                    else
                    {
                        foreach (DataRow rows in dt.Rows)
                        {
                            response += rows["scd_txt"];
                        }
                    }
                }
                else if (DocumentName == "B51")
                {
                    DataTable dt = objCommonDAL.GetSCDocuments(SCINO, ItemNo, DocumentName, "I");
                    foreach (DataRow rows in dt.Rows)
                    {
                        response += rows["scd_txt"];
                    }


                }

                else
                {
                    DataTable dt = objCommonDAL.GetSCDocuments(SCINO, ItemNo, DocumentName, TxtLvl);
                    foreach (DataRow rows in dt.Rows)
                    {
                        response += rows["scd_txt"];
                    }
                }

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = response }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("InsertSCDocumentDetails")]
        public IHttpActionResult InsertSCDocumentDetails([FromBody] SCDocument sCDocument)
        {

            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                insertCount = objCommonDAL.InsertSCDocumentDetails(sCDocument);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));
            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("InsertCostAssesmentList")]
        public async Task<IHttpActionResult> InsertCostAssesmentList([FromBody] List<SCCostAssignment> objSCCostAssignment)
        {

            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                //var errors = new Dictionary<string, string>();

                insertCount = await objCommonDAL.InsertCostAssesmentList(objSCCostAssignment, validation);

                if (insertCount == 0)
                {
                    return (Ok(new Message { Text = "Failed", Status = MessageType.success, jsonData = validation }));

                }
                else
                {
                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = validation }));
                }


            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("InsertSustainibilityCsr")]
        public IHttpActionResult InsertSustainibilityCsr([FromBody] SustainibilityCSR objSCSustainibilityCSR)
        {

            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                insertCount = objCommonDAL.InsertSustainibilityCsr(objSCSustainibilityCSR, validation);
                if (insertCount == 0)
                {
                    return (Ok(new Message { Text = "Failed", Status = MessageType.success, jsonData = validation }));

                }
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = validation }));
            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetShoppingCSRDetails")]
        public IHttpActionResult GetShoppingCSRDetails(string SCNO, string ItemNo)
        {
            string Rate = "";
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetShoppingCSRDetails(SCNO, ItemNo);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCostAssesmentData")]
        public IHttpActionResult GetCostAssesmentData(string SCNO, string ItemNo)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCostAssesmentData(SCNO, ItemNo);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCurrentSCStatus")]
        public IHttpActionResult GetCurrentSCStatus(string SCNO)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                string CurrentSCStatus = objCommonDAL.GetCurrentSCStatus(SCNO);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = CurrentSCStatus }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetGLAccountNo")]
        public IHttpActionResult GetGLAccountNo(string UMCNO, string Plant, string ACMode)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                string GLAccountNo = objCommonDAL.GetGLAccountNo(UMCNO, Plant, ACMode);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = GLAccountNo }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetCostCenterSearch")]
        public IHttpActionResult GetCostCenterSearch(string costcenter)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetCostCenterSearch(costcenter);
                //var suggestions = dt.AsEnumerable()
                //                       .Select(row => row.Field<string>("DESCRIPTION"))
                //                       .ToList();
                var suggestions = dt.AsEnumerable()
                        .Select(row => new Suggestion
                        {
                            Description = row.Field<string>("DESCRIPTION"),
                            CostCenter = row.Field<string>("COSTCNTR")
                        })
                        .ToList();

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = suggestions }));

            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetVendorMasterDetails")]
        public IHttpActionResult GetVendorMasterDetails(string vendorcode)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dt = objCommonDAL.GetVendorMasterDetails(vendorcode);
                //var suggestions = dt.AsEnumerable()
                //                       .Select(row => row.Field<string>("DESCRIPTION"))
                //                       .ToList();
                var suggestions = dt.AsEnumerable()
                        .Select(row => new Suggestion
                        {
                            Description = row.Field<string>("VendorName"),
                            CostCenter = row.Field<string>("VENDOR")
                        })
                        .ToList();

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = suggestions }));

            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("Getmpndrawingsdetails")]
        public IHttpActionResult Getmpndrawingsdetails(string umcno, string matl_grp, string scno, string itemno, string UserID)
        {
            try
            {

                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                DataTable dataTable = objCommonDAL.Getmpndrawingsdetails(umcno, matl_grp, scno, itemno, UserID);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dataTable }));

            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("UpdateMPNDrawing")]
        public IHttpActionResult UpdateMPNDrawing([FromBody] ShoppingCartItem ObjShoppingCartItemDetails)
        {

            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                insertCount = objCommonDAL.UpdateMPNDrawing(ObjShoppingCartItemDetails);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));
            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetVendorDetails")]
        public IHttpActionResult GetVendorDetails(string vendorcode)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                if (!String.IsNullOrEmpty(vendorcode))
                {
                    DataTable dt = objCommonDAL.GetVendorDetails(vendorcode);

                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
                }
                else { return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "" })); }
            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetSCAttachmentDetails")]
        public IHttpActionResult GetSCAttachmentDetails(string SCNO)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                if (!String.IsNullOrEmpty(SCNO))
                {
                    DataTable dt = objCommonDAL.GetSCAttachmentDetails(SCNO);

                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
                }
                else { return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "" })); }
            }
            catch (Exception ex)
            {

                return null;
            }

        }


        [HttpPost]
        [Route("InsertSCAttachment")]
        public IHttpActionResult InsertSCAttachment()
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                var httpRequest = HttpContext.Current.Request;

                if (httpRequest.Files.Count == 0)
                    return BadRequest("No file uploaded");

                var postedFile = httpRequest.Files[0];
                var sno = httpRequest.Form["Sno"];
                var userId = httpRequest.Form["UserId"];

                byte[] fileData;
                using (var binaryReader = new BinaryReader(postedFile.InputStream))
                {
                    fileData = binaryReader.ReadBytes(postedFile.ContentLength);
                }

                var fileUploadModel = new SC_ATTACHMENT
                {
                    SCA_FILE_NAME = postedFile.FileName,
                    SCA_FILE = fileData,
                    SCA_CART_NO = sno,
                    SCA_UPD_ID = userId,
                    SCA_FILE_TYPE = postedFile.ContentType,
                    SCA_FILE_SIZE = postedFile.ContentType.Length.ToString(),
                };
                if (fileUploadModel.SCA_FILE_TYPE == "application/pdf" && fileUploadModel.SCA_FILE_NAME.Split('.').Length - 1 == 1)
                {

                    int insertCount = objCommonDAL.InsertSCAttachment(fileUploadModel);

                    if (insertCount == 1)
                    {
                        return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated" + insertCount }));

                    }

                    else
                    {
                        return (Ok(new Message { Text = "Failed", Status = MessageType.error, jsonData = "file uploading error." }));
                    }
                }
                else
                {
                    return (Ok(new Message { Text = "Failed", Status = MessageType.error, jsonData = "Please Upload pdf file." }));
                }
                //return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated" }));
            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetBudgetDetails")]
        public async Task<IHttpActionResult> GetBudgetDetails(string dept, string SCH_CART_NO)
        {

            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


                BudgetDetails objBudgetDetails = await objCommonDAL.GetBudgetDetails(dept, SCH_CART_NO);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = objBudgetDetails }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpPost]
        [Route("ChangeShoppingCartDraftStage")]
        public IHttpActionResult ChangeShoppingCart_DraftStage([FromBody] ShoppingCartHeader ObjShoppingCartHDR)
        {

            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                insertCount = objCommonDAL.ChangeShoppingCart_DraftStage(ObjShoppingCartHDR.SCH_CART_NO);
                if (insertCount > 0)
                {
                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "Updated " + insertCount }));
                }
                else
                {
                    return (Ok(new Message { Text = "error", Status = MessageType.error, jsonData = "Shopping Cart Status already updated." }));
                }
            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetPurchaseGroupList")]
        public IHttpActionResult GetPurchaseGroupList(string plantcode, string fodtype, string contract)
        {
            try
            {
                DataTable dt = new DataTable();
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                if (!String.IsNullOrEmpty(plantcode) && !String.IsNullOrEmpty(fodtype))
                {
                    if (fodtype == "PR")
                    {
                        dt = objCommonDAL.GetPurchaseGroupList(plantcode);
                    }
                    else if (fodtype == "RO")
                    {
                        dt = objCommonDAL.GETROPurchaseGroupList(contract, plantcode);
                    }

                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
                }
                else { return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "" })); }
            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("ROVendorList")]
        public async Task<IHttpActionResult> GetROVendorList(string purgrp, string UMCNO, string Dept)
        {
            try
            {
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                if (!String.IsNullOrEmpty(UMCNO))
                {
                    List<SourceListSet> dt = await objCommonDAL.GetROVendorList(purgrp, UMCNO, Dept);

                    return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
                }
                else { return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = "" })); }
            }
            catch (Exception ex)
            {

                return null;
            }

        }
        [HttpPost]
        [Route("UpdateROVendor")]
        public IHttpActionResult UpdateROVendor([FromBody] SourceListSet ObjSourceListSet)
        {

            try
            {
                long insertCount = 0;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                insertCount = objCommonDAL.UpdateROVendor(ObjSourceListSet, validation);
                if (insertCount == 0)
                {
                    return (Ok(new Message { Text = "Failed", Status = MessageType.success, jsonData = validation }));

                }
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = validation }));

            }
            catch (Exception)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetClassificationItemDetails")]
        public IHttpActionResult GetClassificationItemDetails(string type, string umcNo)
        {
            try
            {
                DataTable dt = new DataTable();
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                dt =  objCommonDAL.GetClassificationItemDetails(umcNo, type);
                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = dt }));
                
            }
            catch (Exception ex)
            {

                return null;
            }

        }

        [HttpGet]
        [Route("GetHSN_NO")]
        public IHttpActionResult GetHSN_NO(string SCI_MATL_NO,string SCI_CHARACTERISTICS,string SCI_COMPOSITION,string SCI_ENDUSE,string SCI_FUNCTION)
        {
            try
            {
                ShoppingCartItem objShoppingCartItem = new ShoppingCartItem();
                objShoppingCartItem.SCI_CHARACTERISTICS = SCI_CHARACTERISTICS;
                objShoppingCartItem.SCI_COMPOSITION = SCI_COMPOSITION;
                objShoppingCartItem.SCI_ENDUSE = SCI_ENDUSE;
                objShoppingCartItem.SCI_FUNCTION = SCI_FUNCTION;
                objShoppingCartItem.SCI_MATL_NO = SCI_MATL_NO;
                string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
                string _requester = TokenManager.VerifyToken(token);
                if (_requester.Equals("-1"))
                    return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));
                string CurrentSCStatus = objCommonDAL.GetHSN_NO(objShoppingCartItem);

                return (Ok(new Message { Text = "success", Status = MessageType.success, jsonData = CurrentSCStatus }));

            }
            catch (Exception)
            {

                return null;
            }

        }
    }
}

﻿using SIS_BACKEND_API.App_Code.DAL;
using SIS_BACKEND_API.App_Code.Utils;
using SIS_BACKEND_API.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
[RoutePrefix("api/SAP")]
public class SAPDataController : ApiController
{
    
    [HttpGet]
    [Route("GetData")]
    public async Task<IHttpActionResult> GetData(string UMC,string DEPT)
    {
        string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
        string _requester = TokenManager.VerifyToken(token);
        if (_requester.Equals("-1"))
            return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));


        string BaseURL = ConfigurationManager.AppSettings["ODataBaseURL"];
        string apiUrl = BaseURL + "opu/odata/sap/YMPIG_DEPT_MAT_WISE_SRV/DeptMatWisestockSet?$filter=( InputMaterial eq %27" + UMC +"%27 and DeptCode eq %27"+DEPT+"%27 )&$format=json";

        using (HttpClient client = new HttpClient())
        {
            // Setting the username and password for basic authentication
            string username = ConfigurationManager.AppSettings["ODataUserName"];
            string password = ConfigurationManager.AppSettings["ODataPassword"];
            string authInfo = $"{username}:{password}";
            string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

            try
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string responseData = await response.Content.ReadAsStringAsync();

                    return Ok(new { StatusCode= "success", Response= responseData });
                }
                else
                {
                    return Ok(new { StatusCode = "error", Response = "" });// or BadRequest() or NotFound() based on your needs
                }
            }
            catch (HttpRequestException ex)
            {
                return Ok(new { StatusCode = "error", Response = "" }); // Return the exception details
            }
        }
    }
    [HttpPost]
    [Route("PostMRO_AILUP")]
    public async Task<IHttpActionResult> PostMRO_AilupData(List<T_SII_WORK_FLOW> obj)
    {
        string token = Request.Headers.Where(x => x.Key.ToLower() == "jwt-token").FirstOrDefault().Value.FirstOrDefault().ToString();
        string _requester = TokenManager.VerifyToken(token);
        if (_requester.Equals("-1"))
            return (Ok(new Message { Text = "Unauthorized!", Status = MessageType.error, jsonData = "Token has expired" }));

        if (obj[0].WF_TYPE == "AIULP1")
        {
            foreach (T_SII_WORK_FLOW item in obj)
            {


                string apiUrl = "http://sapfioriqa.tatasteel.co.in:8000/sap/opu/odata/sap/YMPIG_DEPT_MAT_WISE_SRV/update_mroSet?$filter=( Material eq '" + item.REQ_UMC_NO + "' and Werks eq '" + item.SRC_PLANT_ID + "' and Sloc eq '" + item.SLOC + "' and Category eq '" + item.WF_CATEGORY + "' and AuilpQty eq " + item.REQ_QUANTITY + " )&$format=json";

                using (HttpClient client = new HttpClient())
                {
                    // Setting the username and password for basic authentication
                    string username = "SISODATA";
                    string password = "Sap@1234";
                    string authInfo = $"{username}:{password}";
                    string base64AuthInfo = Convert.ToBase64String(Encoding.UTF8.GetBytes(authInfo));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", base64AuthInfo);

                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(apiUrl);

                        if (response.IsSuccessStatusCode)
                        {
                            string responseData = await response.Content.ReadAsStringAsync();


                        }
                        else
                        {
                            return Ok(new { StatusCode = "error", Response = "" });// or BadRequest() or NotFound() based on your needs
                        }
                    }
                    catch (HttpRequestException ex)
                    {
                        return Ok(new { StatusCode = "error", Response = "" }); // Return the exception details
                    }
                }
            }
        }
        return Ok(new { StatusCode = "OK", Response = "success" });
    }

    // Enable CORS for all origins
    //private IHttpActionResult Ok(object data)
    //{
    //    var response = Request.CreateResponse(HttpStatusCode.OK, data, new JsonMediaTypeFormatter());
    //    response.Headers.Add("Access-Control-Allow-Origin", "*");
    //    response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    //    response.Headers.Add("Access-Control-Allow-Headers", "Authorization, Content-Type");
    //    response.Headers.Add("Access-Control-Allow-Credentials", "true");
    //    return ResponseMessage(response);
    //}
    private  static class ReturnResponse
    {
        public static string status { get; set; }
        public static  string response { get; set; }
    }
}
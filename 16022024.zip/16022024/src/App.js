import React, { useState, createContext } from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';

import logo from "./assets/tata_logo.png";
import ClipLoader from "react-spinners/ClipLoader";
import Header from './Components/Layouts/Header';
import Sidebar from './Components/Layouts/Sidebar';
import Logout from './Components/Pages/Logout';
//import Sidebar from './Components/Layouts/SidebarReactPro';

import Dashboard from './Components/Pages/Dashboard';
import OGPCS001 from './Components/Pages/proc_chart/OGPCS001';
import OGPCS001Helper from './Components/Pages/proc_chart/OGPCS001Helper';
import OGPCM003 from './Components/Pages/proc_chart/OGPCM003';
import axios from 'axios';
 
export const UserContext = createContext();

 
function App() {

const [userid , setUserID] = useState();
const [password , setPassword] = useState();
const [dbName , setDBName] = useState();
const [userrole , setUserRole] = useState([]);
const [menuitem , setMenuItem] = useState([]);

const [state, setState] = useState({  
  userAuth: "",  
  loading: false,
  buttonClicked: false
});


 
async function login() {
  setState({
    ...state,
    loading: true,
    buttonClicked: !state.buttonClicked,
  });
 
   

  const data = {
    UserID: userid,
    Password: password,
    DBName: dbName
  };
  localStorage.clear();
  sessionStorage.setItem("UID", userid);
  try {
    const res = await axios.post("http://localhost:59063/api/Login/SignIn", data, {
      headers: {
        'Content-Type': 'application/json',
      }
    });

    setState({
      ...state,      
      userAuth: res.data.Result,
      userrole:res.data.UserRole,
      menuitem:res.data.MenuItems,
      loading: false,
      userType: 1,
      buttonClicked: !state.buttonClicked
    });
 
    if (res.data.Result !== "AUTHENTICATED") {
      console.log(res.data.Result);
      alert("Invalid Credentials");
      setState({
        ...state,
      });
    }
  } catch (error) {
    console.error("Error during login:", error);
    setState({
      ...state,
      loading: false,
      buttonClicked: !state.buttonClicked
    });
  }
}

return (
  <>
    {state.userType !== 0 && state.userAuth === "AUTHENTICATED" ?
      <div className="App">
        <UserContext.Provider value={userid}>
          <Header userName={userid}   />
          <Sidebar userType={state.userType}  Role={state.userrole} Menu={state.menuitem} />
          <div className="height-100 bg-light">
            <Routes>
            <Route path="/dashboard" element={<Dashboard/>}/>                 
            <Route path="/dashboard" element={<Dashboard />}/>
              <Route path="/OGPCS001" element={<OGPCS001Helper />}/>  
              <Route path="/OGPCM003" element={<OGPCM003 />}/>              
                        
            </Routes>
          </div>
        </UserContext.Provider>
      </div>
      :
      <div>
          <div class="row txt-hdr">
            <marquee behavior="alternate" direction="left">
              <b> Welcome To Process Chart Management System</b>
            </marquee>
          </div>
   <div>&nbsp;</div>
      <div className="login">
       
        <center><img src={logo} alt="logo" className="avatar" /><br /></center>
        <label><p><b>User Name</b></p></label>
        <input type="text" name="UserID" id="UserID" placeholder="Username" value={userid} onChange={(e) => setUserID(e.target.value)} />
        <br />
        <label><p><b>Password</b></p></label>
        <input type="Password" name="Password" id="Password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <br />
        <label><p><b>Database</b></p></label>
        <input type="text" name="DBName" id="DBName" placeholder="Database" value={dbName} onChange={(e) => setDBName(e.target.value)} />
        <div className="txt-pwd">
          <label> Change Password? </label>
        </div>
        <center>
          <center>
            <button disabled={state.loading} onClick={() => login()} name="log" id="log">
              <p style={{marginRight:"10px",color:"white"}} >Login</p>
              {state.buttonClicked? <ClipLoader color="white" loading={state.loading}  size={25} /> : null}
            </button>
          </center>
        </center>
       </div>
       <div className="Cont-dtls">
      <table className='tbl'>
        <thead>
          <tr> Contact Details</tr>
          <tr><td> <b className="footer-txt-colour">LPCIS :</b> Phone No. 0657-21-47075 / 0657-21-47096 ,Email ID: lpcis@tatasteel.com , <b className="footer-txt-colour"> IBM Helpdesk : </b> Phone No. 0657-21-47070, Email ID: ibmhelpdesk@tatasteel.com</td></tr>
        </thead>
      </table>
    </div>
</div>
       
    }
   
  </>
  
);
}
 
export default App;
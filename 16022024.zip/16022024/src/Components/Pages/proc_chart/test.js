import React, { useState } from 'react';
 
function App() {
  const [rows, setRows] = useState([
    { id: 1, label: 'Row 1', value: '', options: ['Option 1', 'Option 2', 'Option 3'] },
    { id: 2, label: 'Row 2', value: '', options: ['Option A', 'Option B', 'Option C'] },
  ]);
  const [newRowLabel, setNewRowLabel] = useState('');
  const [newRowOptions, setNewRowOptions] = useState(['Option 1', 'Option 2', 'Option 3']);
 
  const handleChange = (id, value) => {
    setRows(rows.map(row => {
      if (row.id === id) {
        return { ...row, value };
      }
      return row;
    }));
  };
 
  const handleAddRow = () => {
    const newRow = {
      id: rows.length + 1,
      label: newRowLabel,
      value: '',
      options: newRowOptions
    };
    setRows([...rows, newRow]);
    setNewRowLabel('');
    setNewRowOptions(['Option 1', 'Option 2', 'Option 3']); // Reset options for the next row
  };
 
  const handleOptionsChange = (index, value) => {
    const updatedOptions = [...newRowOptions];
    updatedOptions[index] = value;
    setNewRowOptions(updatedOptions);
  };
 
  return (
<div>
<table>
<thead>
<tr>
<th>ID</th>
<th>Label</th>
<th>Value</th>
<th>Options</th>
</tr>
</thead>
<tbody>
          {rows.map(row => (
<tr key={row.id}>
<td>{row.id}</td>
<td>{row.label}</td>
<td><input type="text" value={row.value} onChange={e => handleChange(row.id, e.target.value)} /></td>
<td>
<select value={row.options.find(option => option === row.value)} onChange={e => handleChange(row.id, e.target.value)}>
                  {row.options.map(option => (
<option key={option} value={option}>{option}</option>
                  ))}
</select>
</td>
</tr>
          ))}
<tr>
<td></td>
<td><input type="text" value={newRowLabel} onChange={e => setNewRowLabel(e.target.value)} /></td>
<td></td>
<td>
              {newRowOptions.map((option, index) => (
<input key={index} type="text" value={option} onChange={e => handleOptionsChange(index, e.target.value)} />
              ))}
<button onClick={handleAddRow}>Add Row</button>
</td>
</tr>
</tbody>
</table>
</div>
  );
}
 
export default App;
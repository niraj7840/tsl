//Author : Niraj Kumar

import React, { useState, useEffect, version } from 'react'
import './../table.css'; // Make sure to update the path based on your file structure
// import { Autocomplete, TextField, Button } from '@mui/material';
//import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import { blueGrey, teal } from '@mui/material/colors';
import { Checkbox } from '@mui/material';
import { json, Link } from 'react-router-dom';
import { isVisible } from '@testing-library/user-event/dist/utils';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import { useLocation } from 'react-router-dom';
import { tab } from '@testing-library/user-event/dist/tab';

const OGPCM003 = () => {

  const UID = sessionStorage.getItem("UID");

  const [PCNo, setPCNo] = useState('200');
  const [Version, setVersion] = useState('1');
  const [QualityCode, setQualityCode] = useState('Q123');
  const [TDCNo, setTDCNo] = useState('T123');
  const [ProductGroup, setProductGroup] = useState('1.C');
  const [ProductGroupDesc, setProductGroupDesc] = useState('PGD123');
  const [ProductApplication, setProductApplication] = useState('PA123');
  const [GradeDesc, setGradeDesc] = useState('GD123');



  const location = useLocation();
  const [value, setValue] = useState('');


  // useEffect(() => {
  //   // Retrieve value from sessionStorage
  //   const myValue = sessionStorage.getItem('myValue');
  //   console.log('value from session storage', myValue);
  // }, [location]);


//Start===============================ProductDimension Section======================

const [ProductDimParamList, SetProductDimParamList] = useState([]);
const [SpecialInstn, setSpecialInstn] = useState();
const [SpecificationData, setSpecificationData] = useState([]);

 const  GetProductDimParamList= async()=>
 {
  try {  
    const response = await axios.post('http://localhost:59063/api/ProductDimension/GetProductDimParamList', {});
    SetProductDimParamList(response.data);    
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

const PDPLFilterRow= ProductDimParamList.filter(row => row.Group.includes('PROD_DIMEN')); // For filter data from ProductDimParamList api on Group column
const PDPL_DIMEN_ADD_Row= ProductDimParamList.filter(row => row.Group.includes('DIMEN_ADD')); 

const [txtMin_130, settxtMin_130] = useState({});
const [txtMax_130, settxtMax_130] = useState({});
const [txtAim_130, settxtAim_130] = useState({});
const [txtMin_150, settxtMin_150] = useState({});
const [txtMax_150, settxtMax_150] = useState({});
const [txtAim_150, settxtAim_150] = useState({});

const handleTxtMin_130_Change = (ParameterCode, event) => {
  const { value } = event.target;
  settxtMin_130(prevState => ({ ...prevState, [ParameterCode]: value }));
};

const handleTxtMax_130_Change = (ParameterCode, event) => {
  const { value } = event.target;
  settxtMax_130(prevState => ({ ...prevState, [ParameterCode]: value }));
};

const handleTxtAim_130_Change = (ParameterCode, event) => {
  const { value } = event.target;
  settxtAim_130(prevState => ({ ...prevState, [ParameterCode]: value }));
};

const handleTxtMin_150_Change = (ParameterCode, event) => {
  const { value } = event.target;
  settxtMin_150(prevState => ({ ...prevState, [ParameterCode]: value }));
};

const handleTxtMax_150_Change = (ParameterCode, event) => {
  const { value } = event.target;
  settxtMax_150(prevState => ({ ...prevState, [ParameterCode]: value }));
};

const handleTxtAim_150_Change = (ParameterCode, event) => {
  const { value } = event.target;
  settxtAim_150(prevState => ({ ...prevState, [ParameterCode]: value }));
};


const fetchRows= ()=>{

  const newRows=PDPLFilterRow.map(row => ({
    
    MicCode : row.ParameterCode, 
    MicDesc : row.ParameterDesc,
    MicSeq : row.MicSeq,
    MicTyp: 'SEC_130, SEC_150',
    Unit : row.Unit,  
     Sec1Min: txtMin_130[row.ParameterCode] || '',
     Sec1Max: txtMax_130[row.ParameterCode] || '',
     Sec1Aim: txtAim_130[row.ParameterCode] || '',
     Sec2Min: txtMin_150[row.ParameterCode] || '',
     Sec2Max: txtMax_150[row.ParameterCode] || '',
     Sec2Aim: txtAim_150[row.ParameterCode] || '',
     MicGroup : row.Group
    

  })); 

  setSpecificationData(newRows);
};
const handleSave_PD = async event => {  
  try {   
    fetchRows();      
      const response = await axios.post('http://localhost:59063/api/ProductDimension/SaveOrUpdatePDDetails', {
      ProcessChartNo: PCNo,
      VersionNo: Version,
      Specification:SpecificationData,
      SpecialInstn: SpecialInstn,
      UserId: UID     

    })
   
      .then(response => {
        if (!response.ok) {
          throw new console.error('Fail to Post Data');

        }
       
        return response.json();

      })
  } catch (error) {

  }
}

//End===============================ProductDimension Section======================


  return (
    <div className="main-data">
      <br></br>
      <div className="data-upload">
        <h3>Product Dimension</h3>
      </div>
      <table>
        <tbody>
          <tr>
            <td>Process Chart No.</td>
            <td>
              <input disabled={true} type="text" id="txtPCNo" name="txtPCNo" value={PCNo} style={{ width: '80px' }} />
            </td>
            <td>Version </td>
            <td>
              <input disabled={true} type="text" id="txtVersion" name="txtVersion" value={Version} style={{ width: '80px' }} />
            </td>
            <td>Quality Code </td>
            <td>
              <input disabled={true} type="text" id="txtQualityCode" name="txtQualityCode" value={QualityCode} style={{ width: '80px' }} />
            </td>
            <td>TDC No </td>
            <td>
              <input disabled={true} type="text" id="txtTDCNo" name="txtTDCNo" value={TDCNo} style={{ width: '80px' }} />
            </td>
          </tr>

          <tr>
            <td>Product Group</td>
            <td>
              <input disabled={true} type="text" id="txtProductGroup" value={ProductGroup} name="txtProductGroup" style={{ width: '80px' }} />
            </td>
            <td>Product Group Description </td>
            <td>
              <input disabled={true} type="text" id="txtProductGroupDesc" value={ProductGroupDesc} name="txtProductGroupDesc" style={{ width: '80px' }} />
            </td>

            <td>Product Application </td>
            <td colSpan={3}>
              <textarea disabled={true}
                type="text"
                rows={2}
                id="txtProductApplication"
                name="txtProductApplication" value={ProductApplication}
                style={{ width: '283px' }}
              />
            </td>

          </tr>

          <tr>
            <td>Grade Description</td>
            <td colSpan={2}>
              <textarea disabled={true} type="text" id="txtGradeDesc" name="txtGradeDesc" value={GradeDesc} style={{ width: '380px', height: '35px' }} />
            </td>
            <td colSpan={2} className="td-center">
              <button id="Release" className="btn btn-primary" >
                Release
              </button>
            </td>
            <td className="td-center">

            </td>
            <td colSpan={2} className="td-right">

            </td>
          </tr>

        </tbody>

      </table>

      {/* ----------Start Nav Tab---------- */}
      <div class="col-12">
        <Tabs
          defaultActiveKey="ChemicalComposition"
          id="uncontrolled-tab-example"  
          className='my-tab'  onClick={() => GetProductDimParamList()}         
        >

          <Tab eventKey="ChemicalComposition" title="Chemical Composition" className='tab-txt-clr'>
          
            <table style={{ width: '70%', border: '1.5px solid black', borderTop: '0px' }}>
              <tr>
                <th colSpan={3}>&nbsp;</th> <th colSpan={3}>Specification</th> <th colSpan={3}> To Be Achieved</th>
              </tr>
              <tr>
                <th></th>
                <th align="left">Parameters</th>
                <th>UOM</th>
                <th>Min</th>
                <th>Max</th>
                <th>Aim</th>
                <th>Min</th>
                <th>Max</th>
                <th>Aim</th>

              </tr>

              <tr>
                <td></td>  <td align="left"> Carbon </td> <td> %</td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
              </tr>

              <tr>
                <td></td>  <td align="left">Manganese</td> <td> %</td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
              </tr>

              <tr>
                <td></td>  <td align="left">Sulphur</td> <td> %</td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
              </tr>

              <tr>
                <td></td>  <td align="left">Phosphorus</td> <td> %</td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
              </tr>

              <tr>
                <td></td>  <td align="left">Silicon</td> <td> %</td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
              </tr>

              <tr>
                <td></td>  <td>&nbsp;</td> <td> &nbsp;</td>
                <td>&nbsp;</td>  <td>&nbsp;</td>  <td>&nbsp;</td>
                <td>&nbsp;</td>  <td>&nbsp;</td>  <td>&nbsp;</td>
              </tr>


              <tr>
                <td colSpan={9} align="left">
                  <button id="btnAdd_CC" className="btn btn-success" >Add  </button>&nbsp;
                  <button id="btnDelete_CC" className="btn btn-danger" >Delete  </button>
                </td>
              </tr>
            </table>
            <table style={{ width: '70%', border: '1.5px solid black', borderTop: '0px' }}>
              <tr>
                <th colSpan={10}> Formula </th>
              </tr>
              <tr>
                <th colSpan={4}>&nbsp;</th> <th colSpan={3}>Specification</th> <th colSpan={3}> To Be Achieved</th>
              </tr>
              <tr>
                <th></th>
                <th align="left">Parameters</th>
                <th>UOM</th>
                <th>Formula</th>
                <th>Min</th>
                <th>Max</th>
                <th>Aim</th>
                <th>Min</th>
                <th>Max</th>
                <th>Aim</th>
              </tr>
              <tr>
                <td><Checkbox style={{ width: '10px' }} /></td>  <td align="left"><select style={{ width: '100px' }} /></td> <td> </td> <td><select style={{ width: '100px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
                <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>  <td><input type="text" style={{ width: '70px' }} /></td>
              </tr>
              <tr>
                <td colSpan={3}>Special Instruction</td>
                <td colSpan={7} >
                  <textarea type="text" style={{ width: '500px' }} ></textarea>
                </td>
              </tr>
              <tr>
                <td colSpan={10}  >
                  <button id="btnSave_CC" className="btn btn-success" >Save  </button>&nbsp;
                  <button id="btnExit_CC" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
            <br></br>
          </Tab>

          <Tab eventKey="ProductDimension" title="Product Dimension"  className='tab-txt-clr'>

            <table style={{ width: '70%', border: '1.5px solid black', borderTop: '0px', marginLeft: '169px' }}>
              <tr>
                <th colSpan={3}>&nbsp;</th> <th colSpan={3}>Sec1_130</th> <th colSpan={3}> Sec1_150</th>
              </tr>
              <tr>
                <th></th>
                <th>Parameter</th>
                <th>UMO</th>
                <th>Min</th>
                <th>Max</th>
                <th>Aim</th>
                <th>Min</th>
                <th>Max</th>
                <th>Aim</th>
              </tr>
              {PDPLFilterRow.map((row ) => 
              <tr key={row.ParameterCode}>
                 <td></td> 
                 <td>{row.ParameterDesc}</td>
                 <td>{row.Unit}</td>
                 <td><input type="text" value={txtMin_130[row.ParameterCode] || ''} onChange={(e) => handleTxtMin_130_Change(row.ParameterCode, e)} style={{ width: '70px' }} /></td> 
                 <td><input type="text" value={txtMax_130[row.ParameterCode] || ''} onChange={(e) => handleTxtMax_130_Change(row.ParameterCode, e)} style={{ width: '70px' }} /></td>
                 <td><input type="text" value={txtAim_130[row.ParameterCode] || ''} onChange={(e) => handleTxtAim_130_Change(row.ParameterCode, e)} style={{ width: '70px' }} /></td>
                 <td><input type="text" value={txtMin_150[row.ParameterCode] || ''} onChange={(e) => handleTxtMin_150_Change(row.ParameterCode, e)} style={{ width: '70px' }} /></td>  
                 <td><input type="text" value={txtMax_150[row.ParameterCode] || ''} onChange={(e) => handleTxtMax_150_Change(row.ParameterCode, e)} style={{ width: '70px' }} /></td> 
                 <td><input type="text" value={txtAim_150[row.ParameterCode] || ''} onChange={(e) => handleTxtAim_150_Change(row.ParameterCode, e)} style={{ width: '70px' }} /></td>
               </tr>
              )}

              <tr>
                <td></td>  <td>&nbsp;</td> <td> &nbsp;</td>
                <td>&nbsp;</td>  <td>&nbsp;</td>  <td>&nbsp;</td>
                <td>&nbsp;</td>  <td>&nbsp;</td>  <td>&nbsp;</td>
              </tr>
              <tr>
                <td colSpan={9} align="left">
                  <button id="btnAdd_PD" className="btn btn-success" >Add  </button>&nbsp;
                  <button id="btnDelete_PD" className="btn btn-danger" >Delete  </button>
                </td>
              </tr>
              <tr>
                <td colSpan={3}>Special Instruction</td>
                <td colSpan={6} >
                  <textarea type="text" style={{ width: '450px' }} ></textarea>
                </td>
              </tr>
              <tr>
                <td colSpan={9} align="center" >
                  <button id="btnSave_PD" className="btn btn-success"  onClick={() => handleSave_PD()}>Save  </button>&nbsp;
                  <button id="btnExit_PD" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
            <br></br>
          </Tab>
          <Tab eventKey="PrimarySteelMaking" title="Primary Steel Making" className='tab-txt-clr'>
            <table style={{ width: '45%', border: '1.5px solid black', borderTop: '0px', marginLeft: '318px' }}>
              <tr>
                <td colSpan="4">HotMetal Delsulphurization: </td>
                <td colSpan="4">
                  <input type="radio" name="site_name" /> Mandatory &nbsp;
                  <input type="radio" name="site_name" /> Not Mandatory
                </td>
              </tr>
              <tr>
                <td colSpan="4">Sulphur Input To BOF(%):  </td>
                <td colSpan="4">
                  <input type="text" style={{ width: '50px' }} /> </td>
              </tr>
              <tr>
                <td colSpan={3}>Special Instruction</td>
                <td colSpan={5} >
                  <textarea type="text" style={{ width: '300px' }} ></textarea>
                </td>
              </tr>
              <tr><th colSpan={8}> Ferro Alloy Additions </th></tr>
              <tr><th colSpan={4}>  </th> <th colSpan={2}> OPTION1 </th> <th colSpan={2}> OPTION2 </th></tr>
              <tr>
                <th></th>
                <th colSpan="2">Parameter</th>
                <th>UOM</th>
                <th>Min</th>
                <th>Min</th>
                <th>Min</th>
                <th>Min</th>
              </tr>
              <tr>
                <td><input type="Checkbox"></input></td>
                <td colSpan="2"><select type="option" style={{ width: '180px' }}></select> </td>
                <td>Kg</td>
                <td> <input type="text" style={{ width: '50px' }} /></td>
                <td> <input type="text" style={{ width: '50px' }} /></td>
                <td> <input type="text" style={{ width: '50px' }} /></td>
                <td> <input type="text" style={{ width: '50px' }} /></td>
              </tr>

              <tr><td colSpan={8}>&nbsp;</td></tr>
              <tr>
                <td colSpan={8} align="left">
                  <button id="btnAdd_PSM" className="btn btn-success" >Add  </button>&nbsp;
                  <button id="btnDelete_PSM" className="btn btn-danger" >Delete  </button>
                </td>
              </tr>
              <tr>
                <td colSpan={8} align="center">
                  <button id="btnSave_PSM" className="btn btn-success" >Save  </button>&nbsp;
                  <button id="btnExit_PSM" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
            <br></br>
          </Tab>
          <Tab eventKey="SecondaryMetallurgy" title="Secondary Metallurgy" className='tab-txt-clr'>

            <table style={{ width: '45%', border: '1.5px solid black', borderTop: '0px', marginLeft: '318px' }}>
              <tr>
                <td colSpan="4">Ladle  Furnance Treatment : </td>
                <td colSpan="4">
                  <input type="radio" name="site_name" /> Mandatory &nbsp;
                  <input type="radio" name="site_name" />  Optional
                </td>
              </tr>

              <tr>
                <td colSpan={3}>Special Instruction</td>
                <td colSpan={5} >
                  <textarea type="text" style={{ width: '300px' }} ></textarea>
                </td>
              </tr>
              <tr><th colSpan={8}> Ferro Alloy Additions </th></tr>
              <tr>
                <th>&nbsp;</th>
                <th colSpan="4">Parameter</th>
                <th>UOM</th>
                <th>LF Min</th>
                <th>LF Max</th>

              </tr>
              <tr>
                <td><input type="Checkbox" ></input></td>
                <td colSpan="4"><select type="option" style={{ width: '150px' }}></select> </td>
                <td>m</td>
                <td> <input type="text" style={{ width: '50px' }} /></td>
                <td> <input type="text" style={{ width: '50px' }} /></td>

              </tr>

              <tr><td colSpan={8}>&nbsp;</td></tr>
              <tr>
                <td colSpan={8} align="left">
                  <button id="btnAdd_SM" className="btn btn-success" >Add  </button>&nbsp;
                  <button id="btnDelete_SM" className="btn btn-danger" >Delete  </button>
                </td>
              </tr>
              <tr>
                <td colSpan={8} align="center">
                  <button id="btnSave_SM" className="btn btn-success" >Save  </button>&nbsp;
                  <button id="btnExit_SM" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
          </Tab>
          <Tab eventKey="Casting" title="Casting" className='tab-txt-clr'>
            <table style={{ width: '45%', border: '1.5px solid black', borderTop: '0px', marginLeft: '318px' }}>
              <tr>
                <td colSpan="4">Caster : </td>
                <td colSpan="4">
                  <select type="option" style={{ width: '150px' }}></select>
                </td>
              </tr>

              <tr>
                <td colSpan={3}>Special Instruction</td>
                <td colSpan={5} >
                  <textarea type="text" style={{ width: '300px' }} ></textarea>
                </td>
              </tr>
              <tr>
                <td colSpan={8} align="center">
                  <button id="btnSave_C" className="btn btn-success" >Save  </button>&nbsp;
                  <button id="btnExit_C" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
          </Tab>
          <Tab eventKey="Rolling" title="Rolling" className='tab-txt-clr'>
            <table style={{ width: '98%', border: '1.5px solid black', borderTop: '0px', marginLeft: '0px' }}>
              <tr>
                <td >Plant : </td> <td><select type="option" style={{ width: '80px' }}></select> </td>
                <td >Product Category : </td> <td> <select type="option" style={{ width: '80px' }}></select> </td>
                <td >Cooling Mode : </td> <td> <select type="option" style={{ width: '80px' }}></select> </td>
                <td >Grade : </td> <td> <select type="option" style={{ width: '80px' }}></select> </td>
                <td >Sec Appl : </td> <td> <select type="option" style={{ width: '80px' }}></select> </td>
                <td >Section : </td> <td> <select type="option" style={{ width: '80px' }}></select> </td>
              </tr>
              <tr><td colSpan={12} align="center">

                <table style={{ width: '70%', border: '1.5px solid black', align: "center" }}>
                  <tr>
                    <th></th>  <th>Parameter</th><th>UOM</th>  <th>Min</th><th>Max</th>  <th>Aim</th>
                  </tr>
                  <tr>
                    <td></td><td>Billet Soaking Temp</td><td> °C</td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                  </tr>
                  <tr>
                    <td></td><td>Mill Speed </td><td> m/s</td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                  </tr>
                  <tr>
                    <td></td><td>FRT/LHD Temp</td><td> °C</td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                    <td><input type="text" style={{ width: '70px' }} /></td>
                  </tr>

                  <tr><td colSpan={6}>&nbsp;</td></tr>
                  <tr>
                    <td colSpan={8} align="left">
                      <button id="btnAdd_R" className="btn btn-success" >Add  </button>&nbsp;
                      <button id="btnDelete_R" className="btn btn-danger" >Delete  </button>
                    </td>
                  </tr>


                  <tr><td colSpan="2">Water Box Selected </td>
                    <td colSpan="4">
                      <table style={{ textAlign: "center" }}>
                        <tr><td>WB1</td><td>WB2</td><td>WB3</td></tr>
                        <tr><td><Checkbox style={{ width: '10px' }} /></td><td><Checkbox style={{ width: '10px' }} /></td><td><Checkbox style={{ width: '10px' }} /> </td></tr>
                      </table>
                    </td>
                  </tr>

                  <tr><td colSpan="2">Stelmor Section Speed [ms] </td>
                    <td colSpan="4">
                      <table style={{ textAlign: "center" }}>
                        <tr><td>Sec 0</td><td>Sec 1</td><td>Sec 2</td><td>Sec 3</td><td>Sec 4</td><td>Sec 5</td><td>Sec 6</td></tr>
                        <tr>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                          <td><input type="text" style={{ width: '35px' }} /></td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <tr><td colSpan="2">Bolower selection </td>
                    <td colSpan="4">
                      <table style={{ textAlign: "center" }}>
                        <tr>
                          <td>BL#1</td>
                          <td>BL#2</td>
                          <td>BL#3</td>
                          <td>BL#4</td>
                          <td>BL#5</td>
                          <td>BL#6</td>
                          <td>BL#7</td>
                          <td>BL#8</td>
                          <td>BL#9</td>
                          <td>BL#10</td>

                        </tr>
                        <tr>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                          <td><Checkbox /></td>
                        </tr>
                      </table>
                    </td>
                  </tr>

                  <tr><td colSpan="2">Hood Mod </td>
                    <td colSpan="4">
                      <table style={{ textAlign: "center" }}>
                        <tr rowspan='2'>
                          <td>H1</td>
                          <td>H2</td>
                          <td>H3</td>
                          <td>H4</td>
                          <td>H5</td>
                          <td>H6</td>
                          <td>H7</td>
                          <td>H8</td>
                          <td>H9</td>
                          <td>H10</td>

                        </tr>
                        <tr>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                        </tr>

                        <tr>
                          <td>H11</td>
                          <td>H12</td>
                          <td>H13</td>
                          <td>H14</td>
                          <td>H15</td>
                          <td>H16</td>
                          <td>H17</td>
                          <td></td>
                          <td></td>
                          <td></td>

                        </tr>
                        <tr>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td><select type="option" ></select> </td>
                          <td> </td>
                          <td> </td>
                          <td> </td>
                        </tr>

                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={2}>Special Instruction</td>
                    <td colSpan={4} >
                      <textarea type="text" style={{ width: '400px' }} ></textarea>
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={6} align="center">
                      <button id="btnSave_R" className="btn btn-success" >Save  </button>&nbsp;
                      <button id="btnExit_R" className="btn btn-dark" >Exit  </button>
                    </td>
                  </tr>



                </table>
              </td></tr>

            </table>
            <br></br>
          </Tab>
          <Tab eventKey="ProductProperties" title="Product Properties" className='tab-txt-clr'>
            <table style={{ width: '45%', border: '1.5px solid black', borderTop: '0px', marginLeft: '418px' }}>
              <tr>
                <td></td>
                <td>Plant Product Category : </td>
                <td><select type="option" style={{ width: '80px' }}></select></td>
                <td >Grade : </td><td> <select type="option" style={{ width: '80px' }}></select>
                </td>
              </tr>
              <tr>
                <th></th>
                <th>
                  Parameter
                </th>
                <th >UOM : </th>
                <th>
                  Min
                </th>
                <th>
                  Max
                </th>
              </tr>

              <tr>
                <td></td>
                <td> Depth of Surface defect </td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <tr>
                <td></td>
                <td>Grain Size  </td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <tr>
                <td></td>
                <td>Yield Strength   </td>
                <td>MPa</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <tr>
                <td></td>
                <td>Depth of Decarburization    </td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>



              <tr style={{ display: 'none' }}>
                <td><Checkbox></Checkbox></td>
                <td> <select type="option" style={{ width: '150px' }}></select></td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <td colSpan={5} align="left">
                <button id="btnAdd_PP" className="btn btn-success" >Add  </button>&nbsp;
                <button id="btnDelete_PP" className="btn btn-danger" >Delete  </button>
              </td>
              <tr>
                <td colSpan={2}>Special Instruction</td>
                <td colSpan={3} >
                  <textarea type="text" style={{ width: '250px' }} ></textarea>
                </td>
              </tr>
              <tr>
                <td colSpan={5} align="center">
                  <button id="btnSave_PP" className="btn btn-success" >Save  </button>&nbsp;
                  <button id="btnExit_PP" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
          </Tab>
          <Tab eventKey="ProductSamplingandTesting" title="Product Sampling and Testing" className='tab-txt-clr'>
          <table style={{ width: '45%', border: '1.5px solid black', borderTop: '0px', marginLeft: '418px' }}>
              <tr>
                <td></td>
                <td>Plant Product Category : </td>
                <td><select type="option" style={{ width: '80px' }}></select></td>
                <td></td>
              </tr>
              <tr>
                <th></th>
                <th>
                  Parameter
                </th>
                <th >UOM : </th>
                <th>
                  No. Of Samples
                </th>               
              </tr>

              <tr>
                <td></td>
                <td> Chemical Analysis </td>
                <td>Per Cast</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                
              </tr>
              <tr>
                <td></td>
                <td>Grain Size  </td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <tr>
                <td></td>
                <td>Yield Strength   </td>
                <td>MPa</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <tr>
                <td></td>
                <td>Depth of Decarburization    </td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>



              <tr style={{ display: 'none' }}>
                <td><Checkbox></Checkbox></td>
                <td> <select type="option" style={{ width: '150px' }}></select></td>
                <td>%</td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
                <td><input type="text" style={{ width: '50px' }} ></input></td>
              </tr>
              <td colSpan={5} align="left">
                <button id="btnAdd_PP" className="btn btn-success" >Add  </button>&nbsp;
                <button id="btnDelete_PP" className="btn btn-danger" >Delete  </button>
              </td>
              <tr>
                <td colSpan={2}>Special Instruction</td>
                <td colSpan={3} >
                  <textarea type="text" style={{ width: '250px' }} ></textarea>
                </td>
              </tr>
              <tr>
                <td colSpan={5} align="center">
                  <button id="btnSave_PP" className="btn btn-success" >Save  </button>&nbsp;
                  <button id="btnExit_PP" className="btn btn-dark" >Exit  </button>
                </td>
              </tr>
            </table>
          </Tab>
        </Tabs>
      </div>
      {/*----End Nav Tab-----*/}
    </div>
  );
};
export default OGPCM003;

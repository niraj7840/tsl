//Author : Niraj Kumar

//import { ColumnDirective, ColumnsDirective, GridComponent, Inject, SelectionSettingsModel, Page, RowSelectingEventArgs } from '@syncfusion/ej2-react-grids';

import React, { useState, useEffect, version } from 'react'
import './../table.css'; // Make sure to update the path based on your file structure
// import { Autocomplete, TextField, Button } from '@mui/material';
//import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import { blueGrey } from '@mui/material/colors';
import { Checkbox } from '@mui/material';
import { json, Link  } from 'react-router-dom';
import { isVisible } from '@testing-library/user-event/dist/utils';
import { useNavigate } from "react-router-dom";
import { faEyeLowVision } from '@fortawesome/free-solid-svg-icons';



const OGPCS001 = () => {
  const UID = sessionStorage.getItem("UID");
  const navigate = useNavigate();


  const [isVisible, setIsVisible] = useState(false);
  const rdButton = [{ id: '1', value: 'C', label: ' Copy to Create ' },
  { id: '1', value: 'N', label: ' Create New  ' }];

  const [selectOption, setSelectOption] = useState();
  const handleOptionChange = (event) => {
    setSelectOption(event.target.value);
    let val = event.target.value;
    if (val === 'C') {
      setIsVisible(true);
    }
    else {
      setIsVisible(false);
    }
  }

  const [Pdata, setdata] = useState([]);
  const [PglData, setPglData] = useState([]);
  const [isTableVisible, setIsTableVisible] = useState(false)
  const [isPglTableVisible, setIsPglTableVisible] = useState(false)

  const [PCNo, setPCNo] = useState('');
  const [Version, setVersion] = useState('');
  const [QualityCode, setQualityCode] = useState('');
  const [TDCNo, setTDCNo] = useState('');
  const [ProductGroup, setProductGroup] = useState('');
  const [ProductSubGroup, setProductSubGroup] = useState('');
  const [ProductGroupDesc, setProductGroupDesc] = useState('');
  const [ProductVersion, setProductVersion] = useState('');
  
  const [ProductCategory, setProductCategory] = useState([]);
  const [selectedProdCat, setSelectedProdCat] = useState('');
  const [ProductApplication, setProductApplication] = useState('');
  const [GradeDesc, setGradeDesc] = useState('');
  const [Status, setStatus] = useState('');
  

  const [PCNoCopy, setPCNoCopy] = useState('');
  const [QualityCodeCopy, setQualityCodeCopy] = useState('');
  const [TDCNoCopy, setTDCNoCopy] = useState('');
  const [ProductGroupCopy, setProductGroupCopy] = useState('');
  const [GradeDescCopy, setGradeDescCopy] = useState('');

  const [selectedRow, setSelectedRow] = useState(null);
  const [selectedCurrVal, SetSelectedCurrVal] = useState(null);

  const [selectedRowPC, setSelectedRowPC] = useState(null);
  const [selectedCurrPCVal, SetselectedCurrPCVal] = useState(null); // for strore cuurent process chart no.
  
  

  useEffect(async () => {

    try {
      
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetList', {});

      setProductCategory(response.data.ProductCategory);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }, [])
   const handleCheckboxChange = (row) => {
   
     setSelectedRow(row);
     SetSelectedCurrVal(row.GroupName);
     setProductGroup(row.GroupName);
     setProductSubGroup(row.SubGroup);
     setProductGroupDesc(row.Description);
     setProductVersion(row.ProductVersion);
  };

  //-------------Get Process Chart List Details-----------------
  const handlePCDetails = (row) => {  
   
    setSelectedRowPC(row);
    SetselectedCurrPCVal(`${row.ProcessChartNo}-${row.VersionNo}`);    
    setPCNo(row.ProcessChartNo);
    setVersion(row.VersionNo);
    setQualityCode(row.QualityCode);
    setTDCNo(row.TdcNo);
    setProductGroup(row.ProductGroup);  
    setProductGroupDesc(row.ProductGroupDesc)
    setProductApplication(row.productApplication)
    setGradeDesc(row.gradeDesc);   
    setStatus(row.Status);
 };
  //-----------------Start Save Data-----------------------//
  const handleSubmit = async event => {
    try {
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/SaveOrUpdateProcessChartDetails', {

        ProcessChartNo: PCNo,
        VersionNo: Version,
        QualityCode: QualityCode,
        TdcNo: TDCNo,
        ProductGroup: ProductGroup,
        ProductGroupDesc: ProductGroupDesc,
        ProductSubGroup: ProductSubGroup,
        productCategory: selectedProdCat,
        productApplication: ProductApplication,
        gradeDesc: GradeDesc,
        Status: 'Draft',
        ReasonForChange: '',
        ProductVersion: ProductVersion,
        UserId: UID,
        Flag: "SAVE"

      })
        .then(response => {
          if (!response.ok) {
            throw new console.error('Fail to Post Data');

          }
          return response.json();

        })
    } catch (error) {

    }
  }

  //-----------------Start Save Data-----------------------//
  const handleCreate = async event => {
    try {

      sessionStorage.setItem('myValue', 'hello');
      navigate('/OGPCM003'); // Redirect to new page
     
      // const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/SaveOrUpdateProcessChartDetails', {

      //   ProcessChartNo: PCNo,
      //   VersionNo: Version,
      //   QualityCode: QualityCode,
      //   TdcNo: TDCNo,
      //   ProductGroup: ProductGroup,
      //   ProductGroupDesc: ProductGroupDesc,
      //   ProductSubGroup: ProductSubGroup,
      //   productCategory: selectedProdCat,
      //   productApplication: ProductApplication,
      //   gradeDesc: GradeDesc,
      //   Status: 'Draft',
      //   ReasonForChange: '',
      //   ProductVersion: ProductVersion,
      //   UserId: UID,
      //   Flag: "SAVE"

      // })
      //   .then(response => {
      //     if (!response.ok) {
      //       throw new console.error('Fail to Post Data');
      //     }
      //     else{
      //         return response.json();
      //         }
      //   })


    } catch (error) {

    }
  }

 //-----------------Start DEACTIVE Data-----------------------//
 const handleDeactive = async event => {
  try {
    const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/DeActivateOrReActivateProcessChartNo', {

      ProcessChartNo: PCNo,
      VersionNo: Version,
      QualityCode: QualityCode,
      TdcNo: TDCNo,
      ProductGroup: ProductGroup,
      ProductGroupDesc: ProductGroupDesc,
      ProductSubGroup: ProductSubGroup,
      productCategory: selectedProdCat,
      productApplication: ProductApplication,
      gradeDesc: GradeDesc,
      Status: Status,
      ReasonForChange: '',
      ProductVersion: ProductVersion,
      UserId: UID,
      Flag: "DEACTIVE"

    })
      .then(response => {
        if (!response.ok) {
          throw new console.error('Fail to Post Data');

        }
        return response.json();

      })
  } catch (error) {

  }
}
//-----------------Start REACTIVE Data-----------------------//
const handleReactive = async event => {
  try {
    const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/DeActivateOrReActivateProcessChartNo', {

      ProcessChartNo: PCNo,
      VersionNo: Version,
      QualityCode: QualityCode,
      TdcNo: TDCNo,
      ProductGroup: ProductGroup,
      ProductGroupDesc: ProductGroupDesc,
      ProductSubGroup: ProductSubGroup,
      productCategory: selectedProdCat,
      productApplication: ProductApplication,
      gradeDesc: GradeDesc,
      Status: Status,
      ReasonForChange: '',
      ProductVersion: ProductVersion,
      UserId: UID,
      Flag: "REACTIVE"

    })
      .then(response => {
        if (!response.ok) {
          throw new console.error('Fail to Post Data');

        }
        return response.json();

      })
  } catch (error) {

  }
}
//---------------------------REACTIVE Data end---------------------//
  const handlerbtnSearch = async () => {
    try {
      setIsTableVisible(!isTableVisible);
      setPglData([]);
      setIsPglTableVisible(false);
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetProcessChartDetails', {

        UserId: UID,
        ProcessChartNo: PCNo,
        TdcNo: TDCNo,
        QualityCode: QualityCode,
        ProductGroup: ProductGroup,
        gradeDesc: GradeDesc,
        Flag: 'GET',

      });


      setdata(response.data); // Assuming the API returns data in a property called 'data'
    } catch (error) {
      console.error('Error fetching data:', error);
    }

  }
  const handleGetList = async () => {
    try {
      setIsTableVisible(!isTableVisible);
      setPglData([]);
      setIsPglTableVisible(false);
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetProcessChartDetails', {

        UserId: UID,
        ProcessChartNo: PCNoCopy,
        TdcNo: TDCNoCopy,
        QualityCode: QualityCodeCopy,
        ProductGroup: ProductGroupCopy,
        gradeDesc: GradeDescCopy,
        Flag: 'GET',

      });


      setdata(response.data); // Assuming the API returns data in a property called 'data'
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
  const handlerPGList = async () => {
    try {
      setIsPglTableVisible(!isPglTableVisible);
      setdata([]);
      setIsTableVisible(false);
      const response = await axios.post('http://localhost:59063/api/ProcessChartMaintenance/GetList', {});

      setPglData(response.data.ProductGroupList); // Assuming the API returns data in a property called 'data'
    } catch (error) {
      console.error('Error fetching data:', error);
    }

  }

  return (
    <div className="main-data">
      <div className="data-upload">
        <h3>Create/Display/Modify Process Chart</h3>
      </div>
      <table>

        <tbody>
          <tr>

            <td colSpan={8} style={{ textAlign: 'center' }}>
              {rdButton.map((rdButton) => (
                <label key={rdButton.id} style={{padding: '0px 4px'}}>
                  <input type="radio"
                    value={rdButton.value}
                    checked={selectOption === rdButton.value}
                    onChange={handleOptionChange}
                  />
                  {rdButton.label}
                </label>
              ))}
            </td>
          </tr>
          <tr>
            <td>Process Chart No.</td>
            <td>
              <input type="text" id="txtPCNo" name="txtPCNo" value={PCNo} onChange={(e) => setPCNo(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>Version </td>
            <td>
              <input type="text" id="txtVersion" name="txtVersion"  disabled={true} value={Version} onChange={(e) => setVersion(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>Quality Code </td>
            <td>
              <input type="text" id="txtQualityCode" name="txtQualityCode" value={QualityCode} onChange={(e) => setQualityCode(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>TDC No </td>
            <td>
              <input type="text" id="txtTDCNo" name="txtTDCNo" value={TDCNo} onChange={(e) => setTDCNo(e.target.value)} style={{ width: '80px' }} />
            </td>
          </tr>

          <tr>
            <td>Product Group</td>
            <td>
              <input type="text" id="txtProductGroup" name="txtProductGroup" value={ProductGroup} onChange={(e) => setProductGroup(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>Product Group Description </td>
            <td>
              <input type="text" id="txtProductGroupDesc" name="txtProductGroupDesc" value={ProductGroupDesc} onChange={(e) => setProductGroupDesc(e.target.value)} style={{ width: '80px' }} />
            </td>
            <td>Product Category </td>
            <td>
              <select className="selection-value" value={selectedProdCat} onChange={(e) => setSelectedProdCat(e.target.value)} >
                <option value=""> ---Select--- </option>
                {ProductCategory.map(category =>
                  <option key={category.Code} value={category.Code}>
                    {category.Value}
                  </option>
                )}
              </select>
            </td>
            <td>Product Application </td>
            <td>
              <textarea
                type="text"
                rows={2}
                id="txtProductApplication"
                name="txtProductApplication" value={ProductApplication} onChange={(e) => setProductApplication(e.target.value)}
                style={{ width: '80px' }}
              />
            </td>
          </tr>

          <tr>
            <td>Grade Description</td>
            <td colSpan={2}>
              <textarea type="text" id="txtGradeDesc" name="txtGradeDesc" enable="false" value={GradeDesc} onChange={(e) => setGradeDesc(e.target.value)} style={{ width: '200px', height: '35px' }} />
            </td>
            <td colSpan={2} className="td-center">
              <Link onClick={() => handlerPGList()} > Product Group List</Link>
            </td>
            <td className="td-center">
              <button className="btn btn-warning"  onClick={() => handlerbtnSearch()}>
                <img src="/logo/search-12-16.ico" alt="my image" />
              </button>
            </td>
            <td colSpan={2} className="td-right">
              <button id="Save" className="btn btn-primary" onClick={() => handleSubmit()}>
                Save
              </button>
            </td>
          </tr>
          <tr>
            <td colSpan={8} className="td-center">
              <button id="Create" className="btn btn-success"  onClick={() => handleCreate()} >
                Create
              </button>
              &nbsp;
              <button id="Modify" className="btn btn-secondary">
                Modify
              </button>
              &nbsp;
              <button id="Display" className="btn btn-warning">
                Display
              </button>
              &nbsp;
              <button id="Exit" className="btn btn-dark">
                Exit
              </button>
              &nbsp;
              <button id="Deactive" className="btn btn-danger"  onClick={() => handleDeactive()} >
                Deactive
              </button>
              &nbsp;
              <button id="Reactive" className="btn btn-info"  onClick={() => handleReactive()}>
                Reactive
              </button>
              &nbsp;
            </td>
          </tr>
        </tbody>

      </table>
      {isVisible && (
        <div className='Panel'>
          <div className="data-upload">
            <h3>Copy From</h3>
          </div>
          <table className="copy-tble">
            <tbody>
              <tr>
                <td>
                  Process Chart No. : <input type="text" id="txtPCNoCopy" name="txtPCNoCopy" value={PCNoCopy} onChange={(e) => setPCNoCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  Quality Code : <input type="text" id="txtQualityCodeCopy" name="txtQualityCodeCopy" value={QualityCodeCopy} onChange={(e) => setQualityCodeCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  TDC No. : <input type="text" id="txtTDCNoCopy" name="txtTDCNoCopy" value={TDCNoCopy} onChange={(e) => setTDCNoCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  Product Group: <input type="text" id="txtProductGroupCopy" name="txtProductGroupCopy" value={ProductGroupCopy} onChange={(e) => setProductGroupCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td>
                  Grade Desc: <input type="text" id="txtGradeDescCopy" name="txtGradeDescCopy" value={GradeDescCopy} onChange={(e) => setGradeDescCopy(e.target.value)} style={{ width: '80px' }} />
                </td>
                <td colSpan={3}>
                  <button className="btn btn-warning" onClick={() => handleGetList()}>
                    <img src="/logo/search-12-16.ico" alt="my image" />
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      <div class="container text-center">
        <div class="row justify-content-start">
          <div class="col-12">
            {isTableVisible && (
              <table className="table_request">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>Process Chart No</th>
                    <th>Version</th>
                    <th>Quality Code</th>
                    <th>TDC No</th>
                    <th>Product Group</th>
                    <th>product Category</th>
                    <th>Product Group Description</th>
                    <th>Grade Appl</th>
                    <th>Grade Description</th>
                    <th>Status</th>

                  </tr>
                </thead>
                <tbody>
                  {Array.isArray(Pdata) && Pdata.map((row) => 
                    <tr key={row.ProcessChartNo + Math.random()}>
                      <td> <input type="radio"
                    value={`${row.ProcessChartNo}-${row.version}`}
                    checked={selectedCurrPCVal === `${row.ProcessChartNo}-${row.VersionNo}`}
                    onChange={() => handlePCDetails(row)}
                  /></td>
                      <td>{row.ProcessChartNo}</td>
                      <td>{row.VersionNo}</td>
                      <td>{row.QualityCode}</td>
                      <td>{row.TdcNo}</td>
                      <td>{row.ProductGroup}</td>
                      <td>{row.ProductGroupDesc}</td>
                      <td>{row.productCategory}</td>
                      <td>{row.productApplication}</td>
                      <td>{row.gradeDesc}</td>
                      <td>{row.Status}</td>

                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>

        </div>
      </div>


      <div class="container text-center">
        <div class="row justify-content-start">
          <div class="col-4"></div>

          <div class="col-4">
            {isPglTableVisible && (
              <table className="table_request">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>GroupName</th>
                    <th>SubGroup</th>
                    <th>Description</th>

                  </tr>
                </thead>
                <tbody>                  

 {PglData.map((row) => 
                    <tr key={row.GroupName}>
                      <td>
                      
               <input type="radio"
                    value={row.GroupName}
                    checked={selectedCurrVal === row.GroupName}
                    onChange={() => handleCheckboxChange(row)}
                  />
              
                      </td>
                      <td>{row.GroupName}</td>
                      <td>{row.SubGroup}</td>
                      <td>{row.Description}</td>

                    </tr>
                  )} 
                  
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>



    </div>
  );
};

export default OGPCS001;

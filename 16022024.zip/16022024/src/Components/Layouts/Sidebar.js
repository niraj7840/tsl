import React from 'react'
import { Link } from 'react-router-dom'
import SidebarMenuItem from './Helper/SidebarMenuItem'
import image from '../../assets/tsl_logo.png'
import { Dropdown, NavDropdown, Nav } from 'react-bootstrap';
// import "bootstrap/dist/css/bootstrap.min.css";

const Sidebar = (props) => {
  const { userType } = props;

  const RcvdRole = props.Role;
  const RcvdMenuItem = props.Menu;

  return (
    <div className="l-navbar" id="nav-bar">
      <nav className="nav ">
        <div>

          <Link to="/dashboard" className="nav_logo">
            {/* <i className="bx bx-layer nav_logo-icon" />  */}
            <img src={image} className="brand-image img-circle elevation-3" />
            <span className="nav_logo-name"><b>TATA </b> STEEL</span>
          </Link>
          <div className="nav_list">
            <SidebarMenuItem
               title="Dashboard"
               link="/dashboard"
            >                   
              <i className="bx bx-grid-alt nav_icon" />
            </SidebarMenuItem>

            <div className="nav_list">
           {RcvdMenuItem.map((mainItem) => (
             mainItem.FrmID === 'M' && (
               <SidebarMenuItem key={mainItem.PgmID}>
                 <Dropdown>
                   <Dropdown.Toggle variant="dark" className="sidebar_menu_dropdown">
                     <i className="bx bxs-report nav_icon" />
                     <span className="nav_name">{mainItem.PgmDesc}</span>
                   </Dropdown.Toggle>
                   <Dropdown.Menu variant="dark" className="sidebar_menuitem_dropdown" drop="down">
                     {RcvdMenuItem.map(
                       (subItem) =>
                         subItem.FrmID === 'S' &&
                         subItem.CodeModule === 'OGSPCM' &&
                         subItem.FormFor === 'PC' &&
                         subItem.FormFor === mainItem.FormFor && (
                           <SidebarMenuItem key={subItem.PgmID} title={subItem.PgmDesc} link={subItem.PgmID}>
                             <i className="bx bx-data nav_icon" />
                           </SidebarMenuItem>
                         )
                     )}
                   </Dropdown.Menu>

                   <Dropdown.Menu variant="dark" className="sidebar_menuitem_dropdown" drop="down">
                     {RcvdMenuItem.map(
                       (subItem) =>
                         subItem.FrmID === 'S' &&
                         subItem.CodeModule === 'OGSPCM' &&
                         subItem.FormFor === 'PG' &&
                         subItem.FormFor === mainItem.FormFor && (
                           <SidebarMenuItem key={subItem.PgmID} title={subItem.PgmDesc} link={subItem.PgmID}>
                             <i className="bx bx-data nav_icon" />
                           </SidebarMenuItem>
                         )
                     )}
                   </Dropdown.Menu>


                   <Dropdown.Menu variant="dark" className="sidebar_menuitem_dropdown" drop="down">
                     {RcvdMenuItem.map(
                       (subItem) =>
                         subItem.FrmID === 'S' &&
                         subItem.CodeModule === 'OGSPCM' &&
                         subItem.FormFor === 'IP' &&
                         subItem.FormFor === mainItem.FormFor && (
                           <SidebarMenuItem key={subItem.PgmID} title={subItem.PgmDesc} link={subItem.PgmID}>
                             <i className="bx bx-data nav_icon" />
                           </SidebarMenuItem>
                         )
                     )}
                   </Dropdown.Menu>

                   <Dropdown.Menu variant="dark" className="sidebar_menuitem_dropdown" drop="down">
                     {RcvdMenuItem.map(
                       (subItem) =>
                         subItem.FrmID === 'S' &&
                         subItem.CodeModule === 'OGSQDS' &&
                         subItem.FormFor === 'QD' &&
                         subItem.FormFor === mainItem.FormFor && (
                           <SidebarMenuItem key={subItem.PgmID} title={subItem.PgmDesc} link={subItem.PgmID}>
                             <i className="bx bx-data nav_icon" />
                           </SidebarMenuItem>
                         )
                     )}
                   </Dropdown.Menu>

                   <Dropdown.Menu variant="dark" className="sidebar_menuitem_dropdown" drop="down">
                     {RcvdMenuItem.map(
                       (subItem) =>
                       
                         subItem.FrmID === 'R' &&
                         subItem.CodeModule === 'OGSQDS' &&
                         subItem.FormFor === 'RP' &&
                         subItem.FormFor === mainItem.FormFor && (
                           <SidebarMenuItem key={subItem.PgmID} title={subItem.PgmDesc} link={subItem.PgmID}>
                             <i className="bx bx-data nav_icon" />
                           </SidebarMenuItem>
                         )
                     )}
                   </Dropdown.Menu>

                 </Dropdown>
               </SidebarMenuItem>
             )
           ))}
         </div>

          </div>
        </div>
      </nav>
    </div>
  )
}

export default Sidebar

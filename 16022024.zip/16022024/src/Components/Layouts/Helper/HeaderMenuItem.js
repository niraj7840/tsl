import React from 'react';
import {Link} from 'react-router-dom';

const HeaderMenuItem = (props) => {
    return (
        <>
            

            <Link className="dropdown-item" to={props.link}>
                {props.title}
            </Link>    
                           
                        
        </>
        
    )
}

export default HeaderMenuItem
